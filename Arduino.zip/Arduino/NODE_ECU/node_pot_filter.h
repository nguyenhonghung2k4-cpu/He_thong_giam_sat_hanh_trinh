#pragma once
// Keep the 32-read average and slow smoothing around a stationary knob, but
// track deliberate changes without the old ~0.8-second EMA settling tail.
inline float nodePotFilterStep(float filtered, float measured) {
  const float delta=measured-filtered;
  const float alpha=(delta>=64.0f || delta<=-64.0f) ? 0.65f : 0.25f;
  return filtered+alpha*delta;
}
