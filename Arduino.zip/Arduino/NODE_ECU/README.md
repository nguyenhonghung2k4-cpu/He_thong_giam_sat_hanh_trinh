# NODE ECU v3 - biến trở mô phỏng tốc độ xe 0–180 km/h

Mở `NODE_ECU.ino` bằng Arduino IDE và nạp cho **ESP32 Dev Module** của Node ECU.

## Kết nối

| Thiết bị | Chân ESP32 Node ECU |
|---|---:|
| Biến trở - chân giữa | GPIO34 |
| DS18B20 DATA | GPIO27 |
| SN65HVD230 TXD | GPIO17 |
| SN65HVD230 RXD | GPIO16 |
| CAN-H / CAN-L | Nối sang CAN-H / CAN-L của gateway |

Hai đầu xa nhất của đường CAN dùng điện trở kết thúc 120 ohm. Tất cả module phải chung GND.

## Thư viện Arduino

- OneWire
- DallasTemperature

## CAN 0x101 contract v2

| Byte | Nội dung |
|---|---|
| 0..1 | `speed_x100`, little-endian; `5065` nghĩa là `50.65 km/h` |
| 2..3 | ADC biến trở 12-bit, `0..4095` |
| 4 | Status flags |
| 5 | Sequence |
| 6 | Marker `0x53` (`S`) |
| 7 | Phiên bản `0x02` |

Firmware gateway vẫn nhận bản Node cũ, nhưng để Web hiển thị đúng dải 0–180 km/h hãy nạp bản v3 này. Khi tốc độ vượt 120 km/h, bit cảnh báo quá tốc được đặt; ngưỡng chỉ được re-arm sau khi giảm về ≤115 km/h để tránh rung ngưỡng. RPM không còn bị tạo giả từ cùng một biến trở.

## V11.5.3 — giới hạn việc thử gửi lại CAN

- Giữ **TX GPIO17 / RX GPIO16**, tốc độ bus **500 kbit/s**, các ID và dữ liệu như trước. Giá trị biến trở vẫn được lấy mẫu/gửi tối đa 10 lần mỗi giây.
- Mỗi khung được thử truyền một lần (`single-shot`) trong chế độ `NORMAL`, vẫn bắt buộc có ACK từ thiết bị nhận. Không dùng `NO_ACK` để báo thành công giả.
- Khi liên kết vừa có ACK thật, một hoặc hai khung lỗi liên tiếp không làm dừng toàn bộ việc cập nhật; lần gửi sau lấy dữ liệu mới nhất. Sau ba khung lỗi liên tiếp, hoặc ACK đã quá hạn, Node chuyển sang thử heartbeat với khoảng chờ 0,5 / 1 / 2 / 4 giây.
- Mục đích là tránh một khung cũ bị phần cứng gửi lại không giới hạn trong lúc bus lỗi. Không phải cam kết khắc phục mọi nguyên nhân `BUS_OFF`.
- Nếu bộ điều khiển ở `RECOVERING` quá 5 giây, Serial in `RECOVERY ... STALLED` kèm thời gian chờ. Node tiếp tục đọc cảm biến nhưng **không báo đã có kết nối, không tự khởi động lại cả board và không gọi stop/uninstall trái trạng thái**. Chỉ khi bộ điều khiển thực sự hoàn tất phục hồi, firmware mới khởi động CAN và chờ ACK mới.

Khi thử bản này, ghi lại log Node và gateway trước, trong và sau lúc phát loa. `ACK alerts` tăng là bằng chứng bus có thiết bị xác nhận; vẫn đối chiếu bộ đếm RX/heartbeat trên gateway để xác nhận ứng dụng nhận dữ liệu. Kiểm thử trên máy tính không thay thế kiểm thử hai board thật.
