#include <Arduino.h>
#include <DallasTemperature.h>
#include <OneWire.h>
#include <driver/twai.h>
#include <esp_err.h>
#include <limits.h>
#include <math.h>
#include "node_can_tx_policy.h"
#include "node_pot_filter.h"

// NODE ECU - ESP32 DevKit V1
// SN65HVD230: TX=17, RX=16. Potentiometer=GPIO34. DS18B20=GPIO27.
// CAN 500 kbit/s. This v2 contract sends POTENTIOMETER SPEED, not fake RPM.

constexpr gpio_num_t CAN_TX_PIN = GPIO_NUM_17;
constexpr gpio_num_t CAN_RX_PIN = GPIO_NUM_16;
constexpr uint8_t POTENTIOMETER_PIN = 34;
constexpr uint8_t DS18B20_PIN = 27;
constexpr uint8_t ECU_NODE_ID = 0x01;
constexpr uint8_t FW_MAJOR = 2;
constexpr uint8_t FW_MINOR = 2;

constexpr uint16_t ADC_MAX_VALUE = 4095;
constexpr uint16_t SPEED_MAX_X100 = 18000; // 180.00 km/h
constexpr uint16_t OVERSPEED_WARNING_X100 = 12000; // >120 km/h = warning
constexpr uint16_t OVERSPEED_CLEAR_X100 = 11500;   // hysteresis to avoid warning chatter
constexpr uint8_t SPEED_READY_SAMPLES = 5;            // 5 x 100 ms = ~0.5 s
constexpr uint8_t OVERSPEED_CONFIRM_SAMPLES = 3;      // reject one-frame ADC spikes
constexpr uint32_t RUNTIME_PERIOD_MS = 100;
constexpr uint32_t ONE_SECOND_MS = 1000;
constexpr uint32_t TEMP_CONVERSION_MS = 750;
constexpr uint8_t TEMP_STARTUP_VALID_SAMPLES = 2;
constexpr uint8_t TEMP_ERROR_CONFIRM_SAMPLES = 2;
constexpr float TEMP_WARNING_C = 95.0f;
constexpr float TEMP_CRITICAL_C = 105.0f;

constexpr uint32_t CAN_ID_HEARTBEAT = 0x100;
constexpr uint32_t CAN_ID_RUNTIME = 0x101;
constexpr uint32_t CAN_ID_TEMPERATURE = 0x102;
constexpr uint32_t CAN_ID_DTC = 0x103;

enum class TemperatureState : uint8_t { Normal=0, Warning=1, Critical=2, SensorError=3 };
enum class DtcCode : uint8_t { None=0, TempSensorError=1, TempWarning=2, TempCritical=3 };
enum class Severity : uint8_t { Normal=0, Warning=1, Critical=2 };

struct EcuState {
  uint16_t adcRaw = 0;
  uint16_t speedX100 = 0;
  float temperatureC = NAN;
  bool temperatureValid = false;
  bool temperatureReady = false;
  TemperatureState temperatureState = TemperatureState::SensorError;
  // Do not publish a false DTC before the first DS18B20 conversion finishes.
  DtcCode dtcCode = DtcCode::None;
  Severity severity = Severity::Normal;
  uint8_t sequence = 0;
  bool speedReady = false;
  bool overspeed = false;
} ecu;

OneWire oneWire(DS18B20_PIN);
DallasTemperature temperatureSensor(&oneWire);
bool temperaturePending = false;
bool dtcDirty = true;
bool canRunning = false;
bool canRecovering = false;
bool canInstalled = false;
bool canBusOffSeen = false;
NodeCanTxPolicy canTxPolicy;
uint32_t temperatureRequestMs = 0;
uint32_t lastRuntimeMs = 0, lastHeartbeatMs = 0, lastTemperatureMs = 0;
uint32_t lastDtcMs = 0, lastSerialMs = 0;
uint32_t lastRuntimeTxMs = 0;
uint32_t txQueued = 0, txQueueRejected = 0, txAckAlerts = 0;
uint32_t txSingleQueued = 0, txProbeQueued = 0, txFailedAlerts = 0, txAborted = 0;
uint32_t canBusOffEvents = 0, canRecoveryAttempts = 0, canRestartAttempts = 0;
uint32_t lastCanInitAttemptMs = 0, lastCanRecoveryAttemptMs = 0, lastCanStatusMs = 0;
uint32_t lastCanAbortAttemptMs = 0;
uint32_t canRecoverySinceMs = 0;
bool canRecoveryClockStarted = false;
constexpr uint32_t CAN_RECOVERY_STALL_WARNING_MS = 5000;
uint32_t canInitAttempts = 0;
esp_err_t canLastError = ESP_OK;
twai_status_info_t canStatus{};
float filteredAdc = 0.0f;
bool adcFilterInitialized = false;
uint8_t speedReadySamples = 0;
uint8_t overspeedHighSamples = 0, overspeedClearSamples = 0;
uint8_t temperatureGoodSamples = 0, temperatureBadSamples = 0;
uint32_t temperatureConversionCount = 0;

static void putU16(uint8_t *data,uint8_t at,uint16_t value) {
  data[at]=uint8_t(value);data[at+1]=uint8_t(value>>8);
}

static void putI16(uint8_t *data,uint8_t at,int16_t value) {
  putU16(data,at,uint16_t(value));
}

static void putU32(uint8_t *data,uint8_t at,uint32_t value) {
  data[at]=uint8_t(value);data[at+1]=uint8_t(value>>8);
  data[at+2]=uint8_t(value>>16);data[at+3]=uint8_t(value>>24);
}

static uint8_t statusFlags() {
  uint8_t result=0;
  if(ecu.temperatureValid)result|=1U<<0;
  if(ecu.temperatureState==TemperatureState::Warning)result|=1U<<1;
  if(ecu.temperatureState==TemperatureState::Critical)result|=1U<<2;
  if(ecu.dtcCode!=DtcCode::None)result|=1U<<3;
  if(ecu.overspeed)result|=1U<<4;
  if(ecu.speedReady)result|=1U<<5; // v2 contract: speed data passed startup filter
  return result;
}

static int16_t temperatureX100() {
  if(!ecu.temperatureValid)return INT16_MIN;
  long value=lroundf(ecu.temperatureC*100.0f);
  value=constrain(value,long(INT16_MIN+1),long(INT16_MAX));
  return int16_t(value);
}

static void updateDiagnostic() {
  TemperatureState state=TemperatureState::SensorError;
  if(ecu.temperatureValid){
    if(ecu.temperatureC>=TEMP_CRITICAL_C)state=TemperatureState::Critical;
    else if(ecu.temperatureC>=TEMP_WARNING_C)state=TemperatureState::Warning;
    else state=TemperatureState::Normal;
  }
  DtcCode code=DtcCode::TempSensorError;Severity severity=Severity::Warning;
  if(state==TemperatureState::Normal){code=DtcCode::None;severity=Severity::Normal;}
  else if(state==TemperatureState::Warning){code=DtcCode::TempWarning;severity=Severity::Warning;}
  else if(state==TemperatureState::Critical){code=DtcCode::TempCritical;severity=Severity::Critical;}
  if(state!=ecu.temperatureState||code!=ecu.dtcCode||severity!=ecu.severity)dtcDirty=true;
  ecu.temperatureState=state;ecu.dtcCode=code;ecu.severity=severity;
}

static void requestTemperature(uint32_t now) {
  temperatureSensor.requestTemperatures();temperatureRequestMs=now;temperaturePending=true;
}

static void serviceTemperature(uint32_t now) {
  if(temperaturePending&&now-temperatureRequestMs>=TEMP_CONVERSION_MS){
    const float measured=temperatureSensor.getTempCByIndex(0);
    ++temperatureConversionCount;
    const bool measuredValid=measured!=DEVICE_DISCONNECTED_C&&isfinite(measured)&&measured>=-55.0f&&measured<=125.0f;
    temperaturePending=false;

    // DS18B20 commonly exposes its power-up register value before the first
    // real conversion. Always discard conversion #1, then require two good
    // conversions before publishing temperature/DTC to CAN. A loose wire also
    // needs two consecutive failures before replacing a previously good value.
    if(temperatureConversionCount==1){
      temperatureGoodSamples=temperatureBadSamples=0;
    }else if(measuredValid){
      temperatureBadSamples=0;
      if(temperatureGoodSamples<255)++temperatureGoodSamples;
      if(temperatureGoodSamples>=TEMP_STARTUP_VALID_SAMPLES){
        ecu.temperatureC=measured;
        ecu.temperatureValid=true;
        ecu.temperatureReady=true;
        updateDiagnostic();
      }
    }else{
      temperatureGoodSamples=0;
      if(temperatureBadSamples<255)++temperatureBadSamples;
      if(temperatureBadSamples>=TEMP_ERROR_CONFIRM_SAMPLES){
        ecu.temperatureC=NAN;
        ecu.temperatureValid=false;
        ecu.temperatureReady=true;
        updateDiagnostic();
      }
    }
  }
  if(!temperaturePending&&now-temperatureRequestMs>=ONE_SECOND_MS)requestTemperature(now);
}

static void updatePotentiometerSpeed() {
  // 32-sample average + EMA prevents power-up/ADC noise from becoming a fake
  // speed spike.  The filter initializes from the first real reading, so this
  // is not a multi-minute warm-up.
  uint32_t total=0;
  for(uint8_t i=0;i<32;i++) total += analogRead(POTENTIOMETER_PIN);
  const float raw = total / 32.0f;
  if(!adcFilterInitialized){ filteredAdc=raw; adcFilterInitialized=true; }
  else filteredAdc = nodePotFilterStep(filteredAdc,raw);
  ecu.adcRaw = uint16_t(constrain(lroundf(filteredAdc), 0L, long(ADC_MAX_VALUE)));
  ecu.speedX100 = uint16_t((uint32_t(ecu.adcRaw)*SPEED_MAX_X100)/ADC_MAX_VALUE);

  if(speedReadySamples < SPEED_READY_SAMPLES) ++speedReadySamples;
  ecu.speedReady = speedReadySamples >= SPEED_READY_SAMPLES;
  if(!ecu.speedReady){
    ecu.overspeed=false;overspeedHighSamples=overspeedClearSamples=0;return;
  }

  // Require three consecutive 100 ms samples before entering or clearing the
  // warning state.  Hysteresis remains 120/115 km/h.
  if(!ecu.overspeed){
    if(ecu.speedX100 > OVERSPEED_WARNING_X100){
      overspeedClearSamples=0;
      if(overspeedHighSamples < 255) ++overspeedHighSamples;
      if(overspeedHighSamples >= OVERSPEED_CONFIRM_SAMPLES){ ecu.overspeed=true; overspeedHighSamples=0; }
    }else overspeedHighSamples=0;
  }else{
    if(ecu.speedX100 <= OVERSPEED_CLEAR_X100){
      overspeedHighSamples=0;
      if(overspeedClearSamples < 255) ++overspeedClearSamples;
      if(overspeedClearSamples >= OVERSPEED_CONFIRM_SAMPLES){ ecu.overspeed=false; overspeedClearSamples=0; }
    }else overspeedClearSamples=0;
  }
}

static bool sendFrame(uint32_t identifier,const uint8_t *payload,uint8_t length) {
  const uint32_t now=millis();
  if(!canRunning||!canTxPolicy.maySend(now,identifier==CAN_ID_HEARTBEAT))return false;
  twai_message_t message{};message.identifier=identifier;message.data_length_code=length;
  // A transient fault must not trigger unlimited hardware retransmission of
  // one stale sample. NORMAL mode + ss=1 still requires a real receiver ACK.
  // The scheduler submits latest-value data again, with bounded failure probes.
  message.ss=1;
  memcpy(message.data,payload,length);
  const esp_err_t err=twai_transmit(&message,0);
  if(err==ESP_OK){
    ++txQueued;++txSingleQueued;if(canTxPolicy.probing())++txProbeQueued;
    canTxPolicy.queued(now);return true;
  }
  canLastError=err;++txQueueRejected;canTxPolicy.failed(now);return false;
}

static bool beginCan() {
  lastCanInitAttemptMs=millis();++canInitAttempts;
  twai_general_config_t general=TWAI_GENERAL_CONFIG_DEFAULT(CAN_TX_PIN,CAN_RX_PIN,TWAI_MODE_NORMAL);
  general.tx_queue_len=0;general.rx_queue_len=8; // Enforce one hardware transfer, no stale software TX queue.
  general.alerts_enabled=TWAI_ALERT_BUS_OFF|TWAI_ALERT_BUS_RECOVERED|TWAI_ALERT_TX_SUCCESS|TWAI_ALERT_TX_FAILED|TWAI_ALERT_BUS_ERROR;
  const twai_timing_config_t timing=TWAI_TIMING_CONFIG_500KBITS();
  const twai_filter_config_t filter=TWAI_FILTER_CONFIG_ACCEPT_ALL();
  canLastError=twai_driver_install(&general,&timing,&filter);
  if(canLastError!=ESP_OK){
    Serial.printf("[CAN ] INIT FAIL | install=%s | automatic retry in 2000 ms\n",esp_err_to_name(canLastError));return false;
  }
  canInstalled=true;canStatus.state=TWAI_STATE_STOPPED;
  lastCanRecoveryAttemptMs=millis();canLastError=twai_start();
  canRunning=canLastError==ESP_OK;
  if(canRunning)canStatus.state=TWAI_STATE_RUNNING;
  else Serial.printf("[CAN ] INIT FAIL | start=%s | automatic retry\n",esp_err_to_name(canLastError));
  return canRunning;
}

static void serviceCanAlerts() {
  const uint32_t now=millis();
  if(!canInstalled){if(now-lastCanInitAttemptMs>=2000)beginCan();return;}
  uint32_t alerts=0;twai_read_alerts(&alerts,0);
  if(alerts&TWAI_ALERT_TX_SUCCESS){
    // Alert bits coalesce, therefore this is an ACK observation count, not an
    // exact transmitted-frame counter and not proof of S3 application decode.
    ++txAckAlerts;canTxPolicy.acknowledged(now);
  }
  if(alerts&TWAI_ALERT_TX_FAILED){
    ++txFailedAlerts;canTxPolicy.transmissionFailed(now);
  }
  if(canTxPolicy.ackExpired(now)&&!canTxPolicy.inFlight())canTxPolicy.failed(now);
  if(alerts||now-lastCanStatusMs>=100||canTxPolicy.pendingExpired(now)){
    lastCanStatusMs=now;
    const esp_err_t err=twai_get_status_info(&canStatus);
    if(err!=ESP_OK){canLastError=err;canRunning=false;return;}
    canRunning=canStatus.state==TWAI_STATE_RUNNING;
    canRecovering=canStatus.state==TWAI_STATE_RECOVERING;
    if(canRecovering&&!canRecoveryClockStarted){canRecoverySinceMs=now;canRecoveryClockStarted=true;}
    else if(!canRecovering)canRecoveryClockStarted=false;
    if(canStatus.state==TWAI_STATE_BUS_OFF&&!canBusOffSeen){
      canBusOffSeen=true;++canBusOffEvents;
      if(canTxPolicy.ready()||canTxPolicy.inFlight()||canTxPolicy.failureStreak()==0)canTxPolicy.failed(now);
    }
    if(canStatus.state==TWAI_STATE_BUS_OFF&&now-lastCanRecoveryAttemptMs>=1000){
      lastCanRecoveryAttemptMs=now;++canRecoveryAttempts;canLastError=twai_initiate_recovery();
      canRecovering=canLastError==ESP_OK;
      if(canRecovering){
        canStatus.state=TWAI_STATE_RECOVERING;
        canRecoverySinceMs=now;canRecoveryClockStarted=true;
      }
      Serial.printf("[CAN ] BUS OFF | recovery=%s\n",esp_err_to_name(canLastError));
    }else if(canStatus.state==TWAI_STATE_STOPPED&&now-lastCanRecoveryAttemptMs>=1000&&canTxPolicy.waitRemaining(now)==0){
      lastCanRecoveryAttemptMs=now;++canRestartAttempts;canLastError=twai_start();canRunning=canLastError==ESP_OK;
      if(canRunning){canStatus.state=TWAI_STATE_RUNNING;canRecovering=false;canRecoveryClockStarted=false;canBusOffSeen=false;}
      Serial.printf("[CAN ] restart=%s | awaiting bus ACK\n",esp_err_to_name(canLastError));
    }
  }
  // A single-shot transfer with no completion must not occupy the controller
  // indefinitely. twai_stop aborts the outstanding hardware transfer and
  // clears the queue; restart is then rate-limited above. No driver re-install
  // or counter reset, and no blocking loop that would stop sensor sampling.
  if(canRunning&&canTxPolicy.pendingExpired(now)&&now-lastCanAbortAttemptMs>=NodeCanTxPolicy::PendingLimitMs){
    lastCanAbortAttemptMs=now;canLastError=twai_stop();
    if(canLastError==ESP_OK){
      ++txAborted;canRunning=false;canStatus.state=TWAI_STATE_STOPPED;
      lastCanRecoveryAttemptMs=now;canTxPolicy.failed(now);
      // Discard late completion bits belonging to the now-aborted transfer.
      uint32_t discarded=0;twai_read_alerts(&discarded,0);
      Serial.printf("[CAN ] TX TIMEOUT | aborted after %lu ms | heartbeat probe in %lu ms\n",
        (unsigned long)NodeCanTxPolicy::PendingLimitMs,(unsigned long)canTxPolicy.waitRemaining(now));
    }
  }
  // The ECU currently has no CAN command protocol; do not let incidental
  // incoming frames fill its driver's RX queue forever.
  twai_message_t ignored{};
  for(uint8_t n=0;n<8&&twai_receive(&ignored,0)==ESP_OK;++n){}
}

static bool sendRuntime() {
  uint8_t data[8]{};
  putU16(data,0,ecu.speedX100);putU16(data,2,ecu.adcRaw);
  data[4]=statusFlags();data[5]=ecu.sequence;data[6]=0x53;data[7]=0x02;
  if(!sendFrame(CAN_ID_RUNTIME,data,sizeof(data)))return false;
  ++ecu.sequence;return true;
}

static bool sendHeartbeat(uint32_t now) {
  uint8_t data[8]{};data[0]=ECU_NODE_ID;data[1]=FW_MAJOR;data[2]=FW_MINOR;data[3]=statusFlags();
  putU32(data,4,now/1000UL);return sendFrame(CAN_ID_HEARTBEAT,data,sizeof(data));
}

static bool sendTemperature(uint32_t now) {
  uint8_t data[8]{};putI16(data,0,temperatureX100());data[2]=uint8_t(ecu.temperatureState);
  data[3]=ecu.temperatureValid?1:0;putU32(data,4,now);return sendFrame(CAN_ID_TEMPERATURE,data,sizeof(data));
}

static bool sendDtc() {
  uint8_t data[8]{};data[0]=uint8_t(ecu.dtcCode);data[1]=uint8_t(ecu.severity);
  data[2]=ecu.dtcCode==DtcCode::None?0:1;data[3]=statusFlags();putI16(data,4,temperatureX100());
  data[6]=ecu.sequence;data[7]=ECU_NODE_ID;
  if(!sendFrame(CAN_ID_DTC,data,sizeof(data)))return false;
  dtcDirty=false;return true;
}

static const char *temperatureText() {
  switch(ecu.temperatureState){
    case TemperatureState::Normal:return "NORMAL";
    case TemperatureState::Warning:return "WARNING";
    case TemperatureState::Critical:return "CRITICAL";
    default:return "SENSOR_ERROR";
  }
}

static void printStatus() {
  Serial.println("+---------------- NODE ECU ----------------+");
  Serial.printf("[POT ] SPEED=%6.2f km/h | ADC=%u | %s | %s\n",ecu.speedX100/100.0f,ecu.adcRaw,
                ecu.speedReady?"READY":"FILTERING",ecu.overspeed?"OVERSPEED >120":"NORMAL");
  if(ecu.temperatureValid)Serial.printf("[TEMP] %5.2f C | %s\n",ecu.temperatureC,temperatureText());
  else Serial.printf("[TEMP] INVALID | %s\n",temperatureText());
  Serial.printf("[DTC ] code=0x%02X | severity=%u | active=%s\n",uint8_t(ecu.dtcCode),uint8_t(ecu.severity),ecu.dtcCode==DtcCode::None?"NO":"YES");
  const uint32_t now=millis();
  const bool ackFresh=canTxPolicy.ackFresh(now);
  const char *link=!canInstalled?"INIT_RETRY":canRecovering?"RECOVERING":!canRunning?"STOPPED":ackFresh?"BUS_ACK":canTxPolicy.probing()?"PROBE_WAIT":"WAIT_ACK";
  Serial.printf("[CAN ] %s | TX%d RX%d 500k | queued=%lu | ACK alerts=%lu | failed=%lu | queue_reject=%lu\n",link,int(CAN_TX_PIN),int(CAN_RX_PIN),
    (unsigned long)txQueued,(unsigned long)txAckAlerts,(unsigned long)canStatus.tx_failed_count,(unsigned long)txQueueRejected);
  Serial.printf("      BUS | TEC=%lu REC=%lu | errors=%lu | TX pending=%lu | init=%lu | last=%s\n",
    (unsigned long)canStatus.tx_error_counter,(unsigned long)canStatus.rx_error_counter,
    (unsigned long)canStatus.bus_error_count,(unsigned long)canStatus.msgs_to_tx,(unsigned long)canInitAttempts,esp_err_to_name(canLastError));
  Serial.printf("      TX  | single_shot=%lu | probe_subset=%lu | failed_alerts=%lu | timeout_abort=%lu | backoff=%lu ms | streak=%u\n",
    (unsigned long)txSingleQueued,(unsigned long)txProbeQueued,(unsigned long)txFailedAlerts,(unsigned long)txAborted,
    (unsigned long)canTxPolicy.waitRemaining(now),canTxPolicy.failureStreak());
  if(canRecovering&&canRecoveryClockStarted){
    const uint32_t age=now-canRecoverySinceMs;
    Serial.printf("      RECOVERY | age=%lu ms | %s | awaiting controller recovery; not an ACK\n",
      (unsigned long)age,age>=CAN_RECOVERY_STALL_WARNING_MS?"STALLED":"WAIT");
    if(age>=CAN_RECOVERY_STALL_WARNING_MS)
      Serial.println("      CHECK | Recovery has not completed. Sensors stay active; no blind reboot, stop or uninstall while RECOVERING.");
  }
  if(canTxPolicy.everAcked())Serial.printf("      AGE | last ACK=%lu ms | in-flight=%lu ms | bus_off=%lu recovery=%lu restart=%lu\n",
    (unsigned long)canTxPolicy.ackAge(now),(unsigned long)canTxPolicy.pendingAge(now),
    (unsigned long)canBusOffEvents,(unsigned long)canRecoveryAttempts,(unsigned long)canRestartAttempts);
  else Serial.println("      AGE | no successful ACK observed since boot; queued is NOT delivered");
  if(ackFresh)Serial.println("      ACK | CAN receiver acknowledged; confirm S3 RX/heartbeat to verify application decode.");
  else if(canRunning)Serial.println("      CHECK | No recent bus ACK: check S3 power/TWAI, CTX/CRX, CANH/CANL, common GND and termination.");
  Serial.println("+------------------------------------------+\n");
}

void setup() {
  Serial.begin(115200);delay(1000);
  Serial.println("\nNODE ECU V11.5.3 - ACK-REQUIRED SINGLE-SHOT CAN (TX17/RX16)");
  pinMode(POTENTIOMETER_PIN,INPUT);analogReadResolution(12);analogSetPinAttenuation(POTENTIOMETER_PIN,ADC_11db);
  temperatureSensor.begin();temperatureSensor.setResolution(12);temperatureSensor.setWaitForConversion(false);
  requestTemperature(millis());
  if(!beginCan())Serial.println("[CAN ] WAIT | initialization will retry; sensors remain active");
  const uint32_t now=millis();lastRuntimeMs=now-RUNTIME_PERIOD_MS;lastHeartbeatMs=now-ONE_SECOND_MS;
  lastRuntimeTxMs=now-RUNTIME_PERIOD_MS;
  lastTemperatureMs=now-ONE_SECOND_MS;lastDtcMs=now-ONE_SECOND_MS;lastSerialMs=now-ONE_SECOND_MS;
  Serial.printf("READY | DS18B20 devices=%u | CAN=500 kbit/s\n",temperatureSensor.getDeviceCount());
}

void loop() {
  const uint32_t now=millis();serviceTemperature(now);serviceCanAlerts();
  if(now-lastRuntimeMs>=RUNTIME_PERIOD_MS){lastRuntimeMs=now;updatePotentiometerSpeed();}
  // Sampling never waits for CAN. Send the latest values, one owned transfer
  // at a time, and give heartbeat priority so runtime cannot starve 0x100.
  if(canRunning&&canTxPolicy.maySend(now,true)){
    if(!canTxPolicy.ready()||now-lastHeartbeatMs>=ONE_SECOND_MS){
      if(sendHeartbeat(now))lastHeartbeatMs=now;
    }else if(ecu.temperatureReady&&now-lastTemperatureMs>=ONE_SECOND_MS){
      if(sendTemperature(now))lastTemperatureMs=now;
    }else if(ecu.temperatureReady&&(dtcDirty||now-lastDtcMs>=ONE_SECOND_MS)){
      if(sendDtc())lastDtcMs=now;
    }else if(now-lastRuntimeTxMs>=RUNTIME_PERIOD_MS){
      if(sendRuntime())lastRuntimeTxMs=now;
    }
  }
  if(now-lastSerialMs>=ONE_SECOND_MS){lastSerialMs=now;printStatus();}
  delay(1);
}
