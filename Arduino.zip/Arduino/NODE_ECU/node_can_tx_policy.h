#pragma once
#include <stdint.h>

// One application frame in flight: no stale telemetry queue during a missing
// receiver. Every frame is single-shot in NORMAL mode and needs a real ACK.
// Retry the latest sample in software, not one old frame indefinitely in HW.
class NodeCanTxPolicy {
 public:
  static constexpr uint32_t PendingLimitMs = 250;
  static constexpr uint32_t AckFreshMs = 2500;

  bool ready() const { return phase_ == Ready; }
  bool inFlight() const { return inFlight_; }
  bool everAcked() const { return everAcked_; }
  uint32_t ackAge(uint32_t now) const { return now - lastAckMs_; }
  uint32_t pendingAge(uint32_t now) const { return inFlight_ ? now - queuedMs_ : 0; }
  uint8_t failureStreak() const { return failureStreak_; }
  bool probing() const { return phase_ == Probe; }
  uint8_t transientFailures() const { return transientFailures_; }
  bool ackFresh(uint32_t now) const {
    return ready() && everAcked_ && ackAge(now) <= AckFreshMs;
  }
  uint32_t waitRemaining(uint32_t now) const {
    if (phase_ != Probe) return 0;
    const uint32_t elapsed = now - failedMs_;
    return elapsed >= waitMs_ ? 0 : waitMs_ - elapsed;
  }
  bool maySend(uint32_t now, bool heartbeat) const {
    if (inFlight_) return false;
    if (phase_ == Ready) return ackFresh(now);
    return heartbeat && (phase_ == Initial || waitRemaining(now) == 0);
  }
  void queued(uint32_t now) { inFlight_ = true; queuedMs_ = now; }
  // Ignore completion bits with no owned frame, e.g. after an aborted transfer.
  bool acknowledged(uint32_t now) {
    if (!inFlight_) return false;
    // Alerts carry no wire timestamp. A completion held across a long loop
    // stall must not make an old ACK look fresh when service finally resumes.
    if (pendingExpired(now)) { failed(now); return false; }
    inFlight_ = false; everAcked_ = true; lastAckMs_ = now;
    phase_ = Ready; failureStreak_ = transientFailures_ = 0; waitMs_ = 0;
    return true;
  }
  void transmissionFailed(uint32_t now) {
    if (!inFlight_) return; // Late failure bit from an unowned transfer.
    // An isolated lost frame must not impose a 0.5 s heartbeat-only pause on
    // an otherwise recently acknowledged link. Three consecutive failures,
    // an expired ACK or an expired pending completion require bounded probes.
    const bool recent = ackFresh(now) && !pendingExpired(now);
    inFlight_ = false;
    if (recent && ++transientFailures_ < 3) return;
    failed(now);
  }
  void failed(uint32_t now) {
    inFlight_ = false; phase_ = Probe; failedMs_ = now; transientFailures_ = 0;
    if (failureStreak_ < 4) ++failureStreak_;
    waitMs_ = 500U << (failureStreak_ - 1); // 0.5, 1, 2, 4 s; bounded forever
  }
  bool pendingExpired(uint32_t now) const {
    return inFlight_ && pendingAge(now) >= PendingLimitMs;
  }
  bool ackExpired(uint32_t now) const {
    return ready() && !ackFresh(now);
  }

 private:
  enum Phase : uint8_t { Initial, Ready, Probe };
  Phase phase_ = Initial;
  bool inFlight_ = false, everAcked_ = false;
  uint8_t failureStreak_ = 0, transientFailures_ = 0;
  uint32_t lastAckMs_ = 0, queuedMs_ = 0, failedMs_ = 0, waitMs_ = 0;
};
