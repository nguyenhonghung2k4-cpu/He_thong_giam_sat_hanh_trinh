#pragma once
#include "types.h"
void networkBegin();
void networkPoll();
bool networkOnline();
SendResult networkSend(const String &kind,const String &json);
bool networkSubmit(const String &kind,const String &json);
bool networkSubmitDirectRealtime(const String &json,uint32_t capturedMs,uint32_t canAgeMs,bool canFresh);
int networkLastHttpCode();
uint32_t networkLastSuccessMs();
uint32_t networkSentCount();
size_t networkRamQueueDepth();

uint32_t networkBackoffRemainingMs();
uint32_t networkCoalescedTelemetryCount();
uint32_t networkQueueAllocFailureCount();

// Audio critical section: close the HTTP start gate atomically, wait for every
// in-flight telemetry/event/command/export request to finish, then reopen it
// only after MAX98357A has been disabled. A separate compact direct-demo lane
// may be admitted after quiet startup; ordinary HTTP remains closed.
bool networkWaitForIdleForAudio(uint32_t timeoutMs=1400);
void networkExitAudioCritical();
bool networkHttpBusy();
// Narrow compact-lane exception, only after audio's quiet startup. Does not
// reopen full telemetry, event, command/export or SD operations.
void networkAllowDirectRealtimeForAudio();
