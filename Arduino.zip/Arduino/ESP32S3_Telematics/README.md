# Firmware Arduino IDE — HỆ THỐNG GIÁM SÁT HÀNH TRÌNH

> Bản hiện tại: **11.3.9-GNSS-ANTI-DRIFT**, bộ đầy đủ V11.3.9. Đọc `../../README.md` và `../../README_V11_3_9.md` trước khi nạp. Dùng `CONFIGURE_ESP32.bat` tại gốc bộ mới. Giữ PCM 100%, SD SPI 1 MHz, ADXL345 I²C, không buzzer. Chọn **16M Flash (3MB APP/9.9MB FATFS)**. Thêm bộ lọc GPS; không đổi dây nối. Các nội dung cũ phía dưới là lịch sử, hướng dẫn V11.3.9 được ưu tiên.

Firmware nhiều file cho hộp đen chính **ESP32-S3 N16R8**. Chương trình nhận CAN từ Node ECU, đọc GNSS M10, lấy mẫu ADXL345, chạy model Edge Impulse, ghi MicroSD, cảnh báo ổ gà và gửi dữ liệu lên dashboard bằng HTTP JSON.

Phiên bản V11.3.7 tiếp tục dùng **ADXL345 I²C riêng** và **MicroSD SPI riêng**, đồng thời bổ sung cơ chế bảo vệ nguồn cho thẻ SDHC dung lượng lớn. Cảnh báo âm thanh chỉ phát qua MAX98357A; buzzer/GPIO21 không còn được dùng.

Dashboard và API chạy cục bộ trên máy tính tại `http://IP_MAY_TINH:3000`.

## 1. Cài trên Arduino IDE

1. Cài board package **esp32 by Espressif Systems 3.x**.
2. Cài `TinyGPSPlus` trong Library Manager.
3. Chọn **Sketch → Include Library → Add .ZIP Library...** và cài `ei-telematics-arduino-1.0.1-impulse-1.zip` đi kèm gói bàn giao.
4. Mở `ESP32S3_Telematics.ino` bằng Arduino IDE.
5. Chọn board **ESP32S3 Dev Module** với Flash `16 MB`, PSRAM `OPI`, USB CDC On Boot `Enabled`; nếu sketch vượt phân vùng mặc định, chọn partition có vùng app lớn như `Huge APP`.

Firmware `10.2.5-SDHC-POWER-SAFE` hỗ trợ lệnh `audio_play` từ Auto Demo, giữ quy trình boot SD an toàn của V11.3.6 và bổ sung bộ phân xử nguồn giữa HTTP/Wi-Fi với MicroSD. Hai pha tải lớn không chạy đồng thời và có khoảng nghỉ phục hồi 60 ms khi đổi bên. Công suất phát Wi-Fi được giới hạn ở 8,5 dBm để giảm đỉnh dòng. Firmware không bao giờ tự format hoặc tự xóa dữ liệu trên thẻ.
6. Chạy `CONFIGURE_ESP32.bat` ở thư mục gốc để điền Wi-Fi, địa chỉ máy tính, `DEVICE_ID` và khóa API; sau đó Verify/Upload.

### Tương thích ESP32 core 3.3.11 trên Windows

Nền firmware của project tương thích **esp32 by Espressif Systems 3.3.11** và thư viện Edge Impulse của project. Module gửi mạng có tên `telemetry_network.h/.cpp`; không đổi lại thành `network.h/.cpp`, vì Windows không phân biệt chữ hoa/thường và tên đó sẽ xung đột với `Network.h` của ESP32 core, gây lỗi `network_event_handle_t` cùng các lỗi khai báo trùng. Với bản V11.3.7, hãy bấm **Verify** trong Arduino IDE trước khi Upload.

Build kiểm tra dùng phân vùng mặc định chiếm khoảng 93% vùng chương trình. Với ESP32-S3 N16R8, nên chọn **Flash Size 16 MB**, **PSRAM OPI** và **Partition Scheme → Huge APP** như hướng dẫn ở bước 5.

`HTTP_API_KEY` trong firmware phải giống `ingestApiKey` của `WebDashboard_Localhost/config.local.json`. Công cụ cấu hình ở thư mục gốc đồng bộ hai giá trị này tự động. Không dùng `localhost` trong `SERVER_URL` của ESP32; phải dùng IPv4 LAN của máy tính.

## 2. Đấu nối đã chốt

| Thiết bị | Chân thiết bị | ESP32-S3 |
|---|---|---:|
| SN65HVD230 | TXD / D | GPIO17 |
| SN65HVD230 | RXD / R | GPIO18 |
| GNSS M10 | TX | GPIO16 (RX ESP32) |
| GNSS M10 | RX | GPIO15 (TX ESP32) |
| ADXL345 I²C | SDA / SCL / INT1 | GPIO8 / GPIO2 / GPIO14 |
| ADXL345 mode | CS / SDO-ALT | 3,3 V / GND (`0x53`) |
| MicroSD | SCK / MOSI / MISO / CS | 12 / 11 / 13 / 10 |
| MAX98357A | BCLK / LRC / DIN / SD-EN | 4 / 5 / 6 / 7 |
| MAX98357A | GAIN | Không nối ESP32; để hở=9 dB, GND=12 dB |
| GPIO21 | — | Để trống, không nối buzzer |

ADXL345 không còn nối với GPIO12/11/13/9. Nối CS của ADXL thẳng 3,3 V để khóa chế độ I²C và SDO/ALT ADDRESS xuống GND để chọn địa chỉ `0x53`. Nếu breakout không có sẵn pull-up, thêm khoảng 4,7 kΩ từ SDA và SCL lên 3,3 V. MicroSD là thiết bị duy nhất trên SPI. Tất cả module dùng mức logic 3,3 V và GND chung.

CAN dùng `500 kbit/s`, cần dây CANH/CANL và điện trở kết thúc `120 Ω` ở hai đầu bus. Tất cả khối phải nối chung GND. GNSS của project đã được kiểm tra ở `38.400 baud`; nếu bạn đổi cấu hình bằng u-center thì sửa `GNSS_BAUD` tương ứng. Nguồn GNSS ngoài phải chung GND với ESP32-S3.

## 3. Model Edge Impulse đã đối chiếu

- Header: `telematics_inferencing.h`
- Labels: `duong_bang_phang`, `go_giam_toc`, `o_ga`
- 200 frame × 3 trục = 600 giá trị đầu vào
- Khoảng lấy mẫu 10 ms, tức 100 Hz; cửa sổ 2 giây
- Pipeline Spectral Analysis + Dense Neural Network, model INT8

Firmware lấy kích thước input và chạy `run_classifier()` từ chính metadata của thư viện. `static_assert` sẽ dừng compile nếu thay bằng model không còn 3 trục/100 Hz, tránh chạy sai âm thầm.

ADXL345 được đặt giống firmware đã dùng thu dataset: **full-resolution, ±16 g, 100 Hz**. FIFO stream dùng watermark 16 mẫu và INT1 GPIO14; I²C chạy 400 kHz trên bus riêng. Firmware xác minh địa chỉ `0x53` và thanh ghi `DEVID=0xE5` trước khi báo cảm biến sẵn sàng. Nếu FIFO thật sự tràn, firmware đọc bỏ dữ liệu gián đoạn để xóa cờ phần cứng, reset cửa sổ AI và tự thu lại đủ 200 mẫu trước khi suy luận. Nếu cảnh báo `FIFO overrun recovered` xuất hiện liên tục, kiểm tra INT1, SDA/SCL, pull-up, CS nối 3,3 V, SDO nối GND, nguồn 3,3 V và giữ đúng hướng lắp cảm biến như lúc thu dataset; lỗi SD không còn giữ bus ADXL.

## 4. CAN frame từ Node ECU

Tất cả số nhiều byte là little-endian:

| CAN ID | DLC tối thiểu | Nội dung |
|---:|---:|---|
| `0x100` | 8 | node ID, FW major, FW minor, status; byte 4..7 `uptime_s uint32` |
| `0x101` | 8 | byte 0..1 `speed_x100 uint16`, byte 2..3 `ADC uint16`, status, sequence, marker `0x53`, version `0x02` |
| `0x102` | 4 | `temperature int16 / 100` °C, state, valid; byte 4..7 là thời điểm lấy mẫu |
| `0x103` | 4 | DTC code `uint8`, severity, active, status; byte 4..5 lặp nhiệt độ `/100` |

Gateway báo ECU offline sau 3 giây không có heartbeat. Bộ lọc TWAI chỉ nhận `0x100..0x103`, có hàng đợi RX và tự thử phục hồi khi CAN bus-off.

Mở và nạp `Arduino/NODE_ECU/NODE_ECU.ino` cho ESP32 DevKit của Node ECU. Biến trở tạo tốc độ `0,00..180,00 km/h`; ví dụ word `5065` nghĩa là `50,65 km/h`, còn ADC vẫn là `0..4095`. Gateway cũng tự nhận bố cục cũ để tương thích, nhưng Web chỉ coi bản v2 là nguồn tốc độ xe và không bịa RPM từ cùng một biến trở.

## 5. Dữ liệu gửi lên web

Firmware gửi nền, không chặn vòng lặp chính:

- `POST {SERVER_URL}/api/telemetry` mỗi 1 giây
- `POST {SERVER_URL}/api/events` khi có ổ gà, gờ giảm tốc, DTC, ECU offline/recovered hoặc cảnh báo geofence
- `Content-Type: application/json`
- `Authorization: Bearer <HTTP_API_KEY>`
- `OAI-Sites-Authorization` được bỏ trống ở bản localhost

Ghi log telemetry cũng chạy qua hàng đợi/task riêng để thẻ MicroSD chậm không giữ vòng lặp chính đang đọc CAN và GNSS.

Payload telemetry điển hình:

```json
{
  "type": "telemetry",
  "device_id": "blackbox-esp32s3-01",
  "boot_id": "00000000A1B2C3D4-12AB34CD",
  "seq": 25,
  "ts": "2026-08-11T02:10:00Z",
  "uptime_ms": 24500,
  "location": {
    "valid": true,
    "lat": 20.9057170,
    "lon": 105.8276270,
    "speed_kph": 32.4,
    "satellites": 12,
    "hdop": 1.24,
    "altitude_m": 8.4,
    "course_deg": 64.0
  },
  "ecu": {
    "online": true,
    "uptime_s": 7240,
    "status": 0,
    "speed_kph": 40.01,
    "speed_source": "potentiometer",
    "runtime_contract": 2,
    "rpm": null,
    "adc_raw": 2048,
    "temperature_c": 84.2,
    "dtc_code": 0,
    "dtc_severity": 0,
    "dtc_active": false
  },
  "road": {
    "valid": true,
    "label": "duong_bang_phang",
    "confidence": 0.9821,
    "x_g": 0.01,
    "y_g": -0.02,
    "z_g": 1.01,
    "inference_ms": 18,
    "scores": {
      "duong_bang_phang": 0.9821,
      "go_giam_toc": 0.0102,
      "o_ga": 0.0077
    }
  },
  "system": {
    "sd_ok": true,
    "wifi_rssi": -54,
    "free_heap": 238400,
    "free_psram": 8165000,
    "queue_bytes": 0
  },
  "trip": { "distance_km": 4.82 }
}
```

`boot_id + seq` là mã duy nhất cho từng thông điệp. Backend dùng hai trường này để bỏ bản ghi trùng khi ESP32 đã gửi thành công nhưng mất gói phản hồi.

## 6. MicroSD và gửi lại khi có mạng

### Chuẩn thẻ và dung lượng

Firmware hỗ trợ **SanDisk SDHC 16 GB** và không có giới hạn 1 GB. Trước khi dùng, sao lưu dữ liệu rồi chuẩn bị thẻ theo đúng cấu hình:

- bảng phân vùng **MBR**, không dùng GPT;
- một phân vùng chính **FAT32**, không dùng exFAT;
- allocation unit/cluster **32 KiB**;
- còn ít nhất 4 MiB dung lượng trống; nên để dư nhiều hơn cho log và hàng đợi mất mạng.

Nếu thẻ ADATA 1 GB chạy được nhưng SanDisk 16 GB vẫn lỗi, hãy thử đầu đọc khác, chạy `chkdsk X: /f` (thay `X:` bằng đúng ký tự ổ thẻ) và kiểm tra toàn bộ dung lượng bằng H2testw sau khi đã sao lưu. Lỗi còn lại trên một thẻ FAT32 sạch thường liên quan đến tiếp xúc, module chuyển mức, dây SPI hoặc nguồn cấp hơn là kích thước 16 GB.

Firmware mount ở 1 MHz để nhận thẻ an toàn, sau đó mới dùng tốc độ phù hợp. Khi cắm nóng sau lỗi/tháo thẻ, firmware chờ tiếp điểm ổn định, kiểm tra thẻ, phục hồi metadata rồi giữ yên trước khi ghi lại. Nếu chưa thành công, thời gian thử lại tăng dần thay vì liên tục gây tải nguồn và bus SPI.

### Ba trạng thái không được nhầm lẫn

| Trạng thái | Ý nghĩa | Cách firmware xử lý |
|---|---|---|
| `physical_full` | Dung lượng trống của toàn thẻ xuống dưới mức an toàn | Giữ thẻ online, dừng ghi telemetry không quan trọng, chờ người dùng xóa/xuất log |
| `daily_log_quota` | Log trong ngày đã đạt hạn mức segment, thẻ vẫn có thể còn trống | Không remount; dừng log ngày và tiếp tục cho phép quản lý thẻ |
| `io_error` | Mở/ghi/đọc file thất bại do FAT, tiếp xúc, nguồn hoặc phần cứng | Debounce lỗi, sau đủ ngưỡng mới lên lịch reset bus/remount |

Dòng `daily telemetry log segments full/unavailable` ở bản cũ từng gộp cả ba trường hợp. V11.3.7 tách thành nguyên nhân cụ thể trên Serial, telemetry và Dashboard. Hạn mức log theo ngày hiện là tối đa **128 segment × 16 MiB**. Việc đạt hạn mức không có nghĩa thẻ 16 GB không được hỗ trợ.

Bộ phân xử nguồn V11.3.7 khóa tuần tự các pha ghi SD và truyền HTTP, thêm 60 ms phục hồi khi chuyển tải, đồng thời giới hạn Wi-Fi ở **8,5 dBm**. Firmware không tự format và không tự xóa log khi đầy.

### Yêu cầu nguồn và dây nối

- Dây SCK/MOSI/MISO/CS ngắn, tránh chạy song song với dây loa; GND mọi khối phải nối chung chắc chắn.
- Module SD phải nhận đúng điện áp theo thiết kế module; tín hiệu vào ESP32-S3 phải ở mức logic 3,3 V.
- Đặt tụ gốm 100 nF và tụ 10–47 µF sát chân cấp nguồn module SD; thêm tụ tổng 220–470 µF trên nhánh nguồn của hệ thống.
- Cấp MAX98357A từ nhánh 5 V riêng hoặc lọc riêng, không để dòng loa làm sụt nguồn SD/ESP32-S3.
- Không tắt brownout detector để che lỗi nguồn.

Serial báo các nguyên nhân chi tiết như `daily_log_quota`, `physical_full`, `offline_queue_open_failed`, `daily_log_open_failed`, `file_write_failed` hoặc lỗi mount/verify tương ứng.

Khi khởi động, Serial có dòng `[BOOT] reset=...`. Nếu hiện `BROWNOUT`, cần xử lý nguồn phần cứng: module SD 3,3 V có MISO tri-state, dây ngắn, GND chung, pull-up khoảng 10 kΩ tại CS10, tụ 100–470 µF kèm 100 nF gần module SD; nguồn 5 V của MAX98357A nên được lọc riêng. Không tắt brownout detector. Tháo thẻ lúc đang ghi vẫn có thể làm hỏng FAT; nên dừng xe/tác vụ ghi trước khi tháo khi có thể.

- `/logs/YYYY-MM-DD_NN.ndjson`: log hộp đen theo ngày, mỗi segment tối đa 16 MB
- `/pending.ndjson`: hàng đợi HTTP dạng append-only, tổng dữ liệu chưa xác nhận tối đa 8 MB
- `/pending.next.ndjson`: phần nối tiếp tạm thời khi đầu file chính đã được xác nhận; được đổi tên tự động, không phải sao chép cả file trên bus SPI
- `/pending.cursor`: vị trí đã được server xác nhận
- `/rejected.log`: bản ghi hỏng hoặc bị server từ chối vĩnh viễn, dùng để chẩn đoán và không chặn các bản ghi mới
- `/potholes.csv`: danh sách tọa độ ổ gà phục vụ geofence
- `/speed_bumps.csv`: danh sách tọa độ gờ giảm tốc phục vụ geofence

Mỗi dòng hàng đợi có dạng `telemetry<TAB>{json}` hoặc `event<TAB>{json}`. Với bản ghi hợp lệ, cursor chỉ tiến sau phản hồi HTTP `201` có `{ "ok": true }`; mất điện có thể làm gửi lặp nhưng không làm mất bản ghi, và backend tự bỏ lặp. Lỗi mạng, xác thực, giới hạn tốc độ và lỗi máy chủ vẫn được thử lại. Chỉ payload được API đánh dấu rõ là không hợp lệ (`invalid_json`, `413/415/422`) mới được chuyển sang `/rejected.log`; cursor chỉ bỏ qua nó sau khi file từ chối đã ghi thành công. Khi file chính đã được xác nhận hết, phần nối tiếp được nâng lên thành file chính bằng thao tác đổi tên an toàn khi mất điện.

Khi mạng phục hồi, firmware gửi lại tối đa 2 bản ghi mỗi chu kỳ 1,2 giây, nhưng tạm dừng trong lúc SD đang remount hoặc phát giọng nói. Mỗi gói resend được đánh dấu riêng nên không thể thay thế telemetry LIVE trên Dashboard.

Ba giọng nói `o_ga`, `go_giam_toc` và `qua_toc_do` đã được nhúng trực tiếp vào Flash dưới dạng WAV PCM16. Parser quét đúng các chunk `fmt`/`data` (không giả định header 44 byte) và phát theo từng khối 1.024 byte, nên không chiếm nhiều RAM và vẫn hoạt động khi MicroSD lỗi. V10.2 chỉ dùng loa MAX98357A; nếu I²S/loa lỗi, Serial báo `[AUDIO] FAIL/SKIP` và cảnh báo âm thanh đó bị bỏ, không có buzzer dự phòng.

`GAIN` không nối với GPIO7 và không được firmware điều khiển. Theo MAX98357A, để hở là 9 dB còn nối thẳng `GAIN` xuống GND là 12 dB; cách nối này phải làm tiếng lớn hơn chứ không mute. GPIO7 phải đi đúng vào `SD/EN` (`SD_MODE`): firmware giữ LOW khi nghỉ và chỉ đưa HIGH trong lúc phát. Nếu kéo `SD/EN` xuống GND, IC shutdown và loa im. Sau khi đổi GAIN nên ngắt/cấp lại nguồn. Xem sơ đồ đo từng chân và cách nhận biết log tại `Docs/CHANDOAN_MAX98357A_GAIN.md`.

Để thử loa mà không cần lái qua geofence hay vặn quá tốc, tạm đổi `AUDIO_BOOT_SELF_TEST = true` trong `config.h`, nạp lại và nhấn RESET. Firmware sẽ phát một lần giọng ổ gà sau khi setup mà không tạo event/marker. Serial phải có các dòng `[AUDIO] TEST`, `[AUDIO] PLAY`, `[AUDIO] AMP` và cuối cùng `[AUDIO] OK`. Trả cấu hình về `false` sau khi thử.

## 7. Phát hiện điểm đen và geofence 10 m

- Ngưỡng mặc định cho `o_ga` và `go_giam_toc`: 0,80
- Hai điểm cùng loại trong bán kính 8 m được coi là một điểm bản đồ
- Ổ gà được lưu vào `potholes.csv`; gờ giảm tốc được lưu vào `speed_bumps.csv`
- Lần đầu TinyML phát hiện một ổ gà hoặc gờ giảm tốc chỉ ghi catalog và gửi event, hoàn toàn không phát âm thanh
- Điểm vừa ghi bị disarm; sau khi xe ra ngoài 20 m điểm đó mới được re-arm
- Ở lượt tiếp cận sau, khi xe tiến vào hoặc đoạn di chuyển GNSS cắt qua vòng 10 m, firmware phát đúng một lần giọng nói của loại điểm đen
- Đứng trong vùng 10 m không phát lặp; mỗi lượt mới phải ra ngoài ít nhất 20 m trước khi quay lại
- Điểm nạp lại từ MicroSD sau khi khởi động cũng bắt đầu ở trạng thái disarm: khởi động ngay trong vùng 10 m sẽ im lặng, còn fix GPS đầu tiên ở ngoài 20 m sẽ arm điểm cho lượt tiếp cận kế tiếp
- Tối đa 100 điểm mỗi loại được giữ trong RAM; event báo `map_capacity_full` khi đầy
- Nếu SD lỗi lúc boot rồi phục hồi, catalog được nạp/ghép lại và các điểm chưa lưu được ghi bù tự động

Các ngưỡng trong `config.h` là điểm khởi đầu. Hãy hiệu chỉnh sau khi test ngoài thực tế với tốc độ xe, vị trí lắp cảm biến và loại mặt đường thật.

## 8. Mạng LAN và bảo mật

Dashboard localhost dùng HTTP trong mạng LAN riêng. `HTTP_API_KEY` ngăn thiết bị không có khóa ghi dữ liệu vào database, nhưng lưu lượng LAN không được mã hóa. Không mở cổng 3000 trực tiếp ra Internet. Nếu triển khai ra ngoài LAN, chuyển sang HTTPS và đặt CA tin cậy trong `TLS_ROOT_CA`.

## 9. Kiểm tra sau khi nạp

Mở Serial Monitor `115200`, nhấn RESET. Mặc định firmware không in toàn bộ JSON dài; thay vào đó là trạng thái dễ đọc, ví dụ:

```text
[CAN ] OK   | Node ECU -> ESP32-S3 | RX=236 | ECU uptime=18 s
       DATA | SPEED(CAN)=50.65 km/h | ADC=2593 | TEMP=32.25 C | DTC=0x00/0
[GNSS] WAIT | no valid fix | SAT=0 | HDOP=99.9
[AI  ] OK   | o_ga               | 99.6% | XYZ=0.020,0.004,0.881 g | 11 ms
[SD  ] OK   | SPI=4.0 MHz | offline queue=0 bytes
[WEB ] OK   | last HTTP 201=825 ms ago | sent=16 | RAM queue=0
```

Sau đó kiểm tra:

1. `[CAN ] OK` xác nhận ESP32 Node ECU đã truyền heartbeat `0x100` tới ESP32-S3; `SPEED(CAN)`, ADC và nhiệt độ phải đúng với Serial của Node.
2. `[WEB ] OK ... HTTP 201` xác nhận server đã lưu dữ liệu. Cửa sổ server đồng thời in `[RX ] SAVED`.
3. `[GNSS] OK` và `location.valid=true` chỉ xuất hiện khi M10 đã fix; khi `SAT=0`, bản đồ chưa thể đặt xe nhưng tốc độ CAN, AI và trạng thái hệ thống vẫn có dữ liệu.
4. Nhấc dây CAN để thấy event `ecu_offline`, nối lại thấy `ecu_recovered`.
5. Tắt Wi-Fi, xác nhận `offline queue` tăng; bật lại và chờ về 0.
6. Test ba mặt đường và xem label/confidence trên dashboard.
7. Với từng lớp `o_ga` và `go_giam_toc`, xác nhận lần phát hiện đầu tiên chỉ tạo event/marker và không phát âm thanh. Sau đó đưa vị trí ra xa ít nhất 20 m rồi tiếp cận lại trong 10 m để nghe đúng một giọng qua MAX98357A; đứng trong vùng phải im lặng. Vặn tốc độ CAN qua 120 km/h để kiểm tra câu `qua_toc_do`.
8. Kiểm tra GPIO21 không có kết nối/hoạt động. Giữ đúng hướng/vị trí lắp ADXL345 như lúc thu dữ liệu train.

Muốn chẩn đoán API bằng JSON thô, đổi `SERIAL_PRINT_RAW_JSON` thành `true` trong `config.h`; để dùng bình thường nên giữ `false`.

Phiên bản nền trước đó đã biên dịch thành công bằng Arduino-ESP32 `3.3.11` cùng model Edge Impulse của project. Các thay đổi V11.3.7 đã được kiểm tra API và audit tĩnh; môi trường đóng gói không được phép cập nhật `Arduino15/inventory.yaml`, nên chưa tạo binary mới tự động. Hãy chọn `Huge APP` trên ESP32-S3 N16R8 và bấm **Verify** trong Arduino IDE trước khi Upload.

### Ổn định khi khởi động

Firmware không dùng delay nhiều phút. Dữ liệu chỉ được công nhận khi subsystem đã sẵn sàng:

- CAN speed chỉ hợp lệ khi ECU online và frame `0x101` còn mới trong 1,5 s.
- GNSS cần 3 fix liên tiếp, ít nhất 4 vệ tinh và HDOP ≤3,0 trước khi bản đồ/geofence được phép hoạt động.
- TinyML cần qua grace 2,5 s, có ít nhất 2 lần inference hợp lệ và một hazard phải xuất hiện ở 2 cửa sổ liên tiếp mới được ghi nhận.
- Dữ liệu chưa sẵn sàng được gửi lên Web dưới dạng `null`/`valid=false`, tránh hiển thị số rác lúc boot.
- Cảnh báo quá tốc phát event `overspeed` khi tốc độ >120 km/h và re-arm khi giảm về ≤115 km/h.
