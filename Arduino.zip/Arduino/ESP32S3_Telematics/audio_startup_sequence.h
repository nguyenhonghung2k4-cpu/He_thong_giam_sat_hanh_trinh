#pragma once
#include <stddef.h>
#include <stdint.h>

// Keep shutdown asserted while clearing and advancing the DMA ring. Clearing
// memory alone does not prove that the transmitter has started consuming it.
// Io is the real I2S transport in firmware and a fault-injection fake in tests.
template <typename Io>
bool audioPrimeMuted(Io &io, size_t ringCapacityBytes) {
  io.mute();
  const uint8_t zeros[1024] = {};
  if (ringCapacityBytes == 0 || ringCapacityBytes > SIZE_MAX - sizeof(zeros)) return false;
  if (!io.clearDma()) return false;
  size_t remaining = ringCapacityBytes + sizeof(zeros);
  while (remaining) {
    const size_t count = remaining < sizeof(zeros) ? remaining : sizeof(zeros);
    if (!io.writeZeros(zeros, count)) return false;
    remaining -= count;
  }
  return true; // Caller must also check readiness and request age before enable.
}
