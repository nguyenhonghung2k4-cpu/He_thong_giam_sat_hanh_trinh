#pragma once
#include <stdint.h>
#include <math.h>

// Admission of real, valid TinyML results. A model score is NOT a measured
// classification accuracy. Ordinary scores retain temporal confirmation;
// a strong score can preserve a short impact which occurs in only one window.
namespace roadevent {
enum class State : uint8_t { Warmup, ScopeSettling, Invalid, Flat, BelowThreshold,
                             PendingConfirmation, Confirmed, Latched };
inline const char *stateName(State state) {
  switch (state) {
    case State::Warmup: return "warmup";
    case State::ScopeSettling: return "scope_settling";
    case State::Invalid: return "invalid";
    case State::BelowThreshold: return "below_threshold";
    case State::PendingConfirmation: return "pending_confirmation";
    case State::Confirmed: return "confirmed";
    case State::Latched: return "latched";
    default: return "flat";
  }
}
struct Decision {
  State state = State::Warmup;
  const char *reason = "awaiting_ready_window";
  const char *confirmation = "none";
  uint8_t kind = 0, windows = 0, requiredWindows = 2;
  bool firstObservation = false, confirmed = false;
};
class Gate {
  uint8_t candidate = 0, windows = 0, latchedMask = 0, clearWindows = 0;
  uint32_t lastCandidateMs = 0;
 public:
  void reset() { candidate = windows = latchedMask = clearWindows = 0; lastCandidateMs = 0; }
  Decision observe(uint8_t kind, float score, float threshold, bool ready,
                   bool scopeSettling, uint32_t now, uint8_t required = 2,
                   float strongThreshold = .95f, uint32_t maxCandidateGapMs = 1500) {
    Decision out;
    out.kind = kind;
    out.requiredWindows = required > 0 ? required : 1;
    if (scopeSettling || !ready) {
      reset();
      out.state = scopeSettling ? State::ScopeSettling : State::Warmup;
      out.reason = scopeSettling ? "awaiting_clean_scope_window" : "awaiting_ready_window";
      return out;
    }
    if (kind > 2 || !isfinite(score) || score < 0 || score > 1 ||
        !isfinite(threshold) || threshold < .5f || threshold > 1 ||
        !isfinite(strongThreshold) || strongThreshold < .5f || strongThreshold > 1) {
      candidate = windows = 0;
      out.state = State::Invalid; out.reason = "invalid_model_result";
      return out;
    }
    if (!kind || score < threshold) {
      candidate = windows = 0;
      // Two clear windows release BOTH class latches. A different class alone
      // cannot repeatedly re-arm its neighbour and produce A/B/A/B storms.
      if (latchedMask && ++clearWindows >= 2) { latchedMask = 0; clearWindows = 0; }
      out.state = kind ? State::BelowThreshold : State::Flat;
      out.reason = kind ? "score_below_configured_threshold" : "no_hazard_class";
      return out;
    }
    clearWindows = 0;
    const uint8_t bit = uint8_t(1u << (kind - 1));
    if (latchedMask & bit) {
      candidate = windows = 0;
      out.state = State::Latched; out.reason = "class_already_recorded_until_clear";
      return out;
    }
    if (candidate != kind || uint32_t(now - lastCandidateMs) > maxCandidateGapMs) {
      candidate = kind; windows = 1; out.firstObservation = true;
    } else if (windows < 255) ++windows;
    lastCandidateMs = now; out.windows = windows;
    // If the other class has just been recorded, require matching windows even
    // for a strong score. This admits a real following obstacle but not a
    // single alternating classification from the same ringing impact.
    const bool strong = !latchedMask && score >= fmaxf(threshold, strongThreshold);
    if (strong || windows >= out.requiredWindows) {
      latchedMask |= bit; candidate = windows = 0;
      out.confirmed = true; out.state = State::Confirmed;
      out.confirmation = strong ? "strong_score" : "matching_windows";
      out.reason = strong ? "strong_score_confirmed" : "matching_windows_confirmed";
      return out;
    }
    out.state = State::PendingConfirmation; out.reason = "awaiting_matching_window";
    return out;
  }
};
}
