#include <Arduino.h>
#include <driver/i2s.h>
#include <driver/gpio.h>
#include <pgmspace.h>
#include "config.h"
#include "alerts.h"
#include "audio_assets.h"
#include "audio_pcm_math.h"
#include "audio_startup_sequence.h"
#include "storage.h"
#include "telemetry_network.h"
#include "direct_demo.h"

namespace {

constexpr uint8_t ALERT_POTHOLE = 1;
constexpr uint8_t ALERT_SPEED_BUMP = 2;
constexpr uint8_t ALERT_OVERSPEED = 3;
constexpr size_t AUDIO_CHUNK_BYTES = 1024;
constexpr size_t AUDIO_DMA_BUFFER_COUNT = 8;
constexpr size_t AUDIO_DMA_BUFFER_FRAMES = 256;
static_assert(AUDIO_PCM_GAIN_PERCENT > 0 && AUDIO_PCM_GAIN_PERCENT <= 100,
              "AUDIO_PCM_GAIN_PERCENT must be 1..100");

struct AlertRequest {
  uint8_t code;
  uint32_t queuedAtMs;
  char directSession[49] = {};
  uint32_t directPass = 0;
  double lat = 0, lon = 0;
  float radius = 0;
};

struct WavView {
  uint16_t format = 0;
  uint16_t channels = 0;
  uint16_t bits = 0;
  uint32_t sampleRate = 0;
  size_t dataOffset = 0;
  size_t dataBytes = 0;
};

static bool i2sReady = false;
static bool earlyMuteDone = false;
static QueueHandle_t alertQueue = nullptr;
static volatile uint8_t pendingMask = 0;
static bool overspeedWanted = false;
static bool audioActive = false;
static portMUX_TYPE pendingMux = portMUX_INITIALIZER_UNLOCKED;
static uint32_t alertsStartedMs = 0;

static void setAudioActive(bool active) {
  portENTER_CRITICAL(&pendingMux);
  audioActive = active;
  portEXIT_CRITICAL(&pendingMux);
}

static void setOverspeedWanted(bool wanted) {
  portENTER_CRITICAL(&pendingMux);
  overspeedWanted = wanted;
  portEXIT_CRITICAL(&pendingMux);
}

static bool isOverspeedWanted() {
  portENTER_CRITICAL(&pendingMux);
  const bool wanted = overspeedWanted;
  portEXIT_CRITICAL(&pendingMux);
  return wanted;
}

static bool requestIsCurrent(const AlertRequest &request) {
  return millis() - request.queuedAtMs < AUDIO_ALERT_MAX_AGE_MS &&
         (request.code != ALERT_OVERSPEED || isOverspeedWanted()) &&
         (!request.directSession[0] || directDemoAudioCurrent(request.directSession,
           request.directPass,request.lat,request.lon,request.radius));
}

static uint32_t remainingAlertWait(const AlertRequest &request, uint32_t maximumMs) {
  const uint32_t age = millis() - request.queuedAtMs;
  if (age >= AUDIO_ALERT_MAX_AGE_MS) return 0;
  const uint32_t remaining = AUDIO_ALERT_MAX_AGE_MS - age;
  // Direct movement must not sit behind a 4-second SD wait followed by a
  // 1.4-second HTTP drain. Failed short admission releases BOTH gates and
  // retries through the existing 200-ms maintenance gap; no SD overlap.
  if (request.directSession[0] && maximumMs > 150) maximumMs = 150;
  return remaining < maximumMs ? remaining : maximumMs;
}

static uint16_t readU16(const uint8_t *source, size_t offset) {
  return uint16_t(pgm_read_byte(source + offset)) |
         (uint16_t(pgm_read_byte(source + offset + 1)) << 8);
}

static uint32_t readU32(const uint8_t *source, size_t offset) {
  return uint32_t(pgm_read_byte(source + offset)) |
         (uint32_t(pgm_read_byte(source + offset + 1)) << 8) |
         (uint32_t(pgm_read_byte(source + offset + 2)) << 16) |
         (uint32_t(pgm_read_byte(source + offset + 3)) << 24);
}

static bool matches(const uint8_t *source, size_t offset, const char text[5]) {
  for (size_t i = 0; i < 4; ++i) {
    if (pgm_read_byte(source + offset + i) != uint8_t(text[i])) return false;
  }
  return true;
}

static bool parseWav(const uint8_t *source, size_t length, WavView &wav) {
  if (!source || length < 12 || !matches(source, 0, "RIFF") || !matches(source, 8, "WAVE")) return false;

  bool haveFormat = false;
  bool haveData = false;
  size_t cursor = 12;
  while (cursor + 8 <= length) {
    const uint32_t chunkBytes = readU32(source, cursor + 4);
    const size_t payload = cursor + 8;
    if (chunkBytes > length - payload) return false;

    if (matches(source, cursor, "fmt ") && chunkBytes >= 16) {
      wav.format = readU16(source, payload);
      wav.channels = readU16(source, payload + 2);
      wav.sampleRate = readU32(source, payload + 4);
      wav.bits = readU16(source, payload + 14);
      haveFormat = true;
    } else if (matches(source, cursor, "data")) {
      wav.dataOffset = payload;
      wav.dataBytes = chunkBytes;
      haveData = true;
    }

    if (haveFormat && haveData) break;
    const size_t padded = size_t(chunkBytes) + (chunkBytes & 1U);
    if (padded > length - payload) return false;
    cursor = payload + padded;
  }

  return haveFormat && haveData && wav.format == 1 && wav.bits == 16 &&
         (wav.channels == 1 || wav.channels == 2) && wav.sampleRate >= 8000 &&
         wav.sampleRate <= 48000 && wav.dataBytes > 0 &&
         wav.dataBytes % (wav.channels * sizeof(int16_t)) == 0 &&
         wav.dataOffset <= length && wav.dataBytes <= length - wav.dataOffset;
}

static void applyPcmEnvelope(uint8_t *buffer, size_t count, size_t firstFrame,
                             const WavView &wav) {
  // The envelope uses absolute WAV frames, not chunk positions. Both stereo
  // channels get the same gain; consecutive chunks do not restart the fade.
  const size_t frameBytes = wav.channels * sizeof(int16_t);
  const size_t totalFrames = wav.dataBytes / frameBytes;
  const size_t fadeFrames = (uint64_t(wav.sampleRate) * AUDIO_FADE_MS) / 1000U;
  for (size_t i = 0; i < count; i += frameBytes) {
    const size_t frame = firstFrame + i / frameBytes;
    const uint32_t envelopeQ15 = audioEnvelopeQ15(frame, totalFrames, fadeFrames);
    for (size_t channel = 0; channel < wav.channels; ++channel) {
      const size_t j = i + channel * sizeof(int16_t);
      const int16_t sample = int16_t(uint16_t(buffer[j]) | (uint16_t(buffer[j + 1]) << 8));
      const uint16_t out = uint16_t(audioScalePcm16(sample, AUDIO_PCM_GAIN_PERCENT, envelopeQ15));
      buffer[j] = uint8_t(out & 0xFF);
      buffer[j + 1] = uint8_t(out >> 8);
    }
  }
}

static bool writePcmBlock(const uint8_t *buffer, size_t count) {
  size_t written = 0;
  const esp_err_t result = i2s_write(I2S_NUM_0, buffer, count, &written, pdMS_TO_TICKS(150));
  if (result == ESP_OK && written == count) return true;
  Serial.printf("[AUDIO] ERROR | i2s_write=%s (0x%X), wrote %u/%u bytes\n",
                esp_err_to_name(result), (unsigned)result, (unsigned)written, (unsigned)count);
  return false;
}

struct MutedI2sTransport {
  void mute() { digitalWrite(PIN_MAX98357_SD_EN, LOW); }
  bool clearDma() {
    const esp_err_t result = i2s_zero_dma_buffer(I2S_NUM_0);
    if (result == ESP_OK) return true;
    Serial.printf("[AUDIO] ERROR | silent DMA clear failed: %s\n", esp_err_to_name(result));
    return false;
  }
  bool writeZeros(const uint8_t *data, size_t count) { return writePcmBlock(data, count); }
};

static bool primeMutedI2s() {
  MutedI2sTransport transport;
  // Stereo PCM16 is the maximum DMA capacity used by this driver. This also
  // exceeds the ring when playing mono; all queued data are literal zero PCM.
  return audioPrimeMuted(transport, AUDIO_DMA_BUFFER_COUNT * AUDIO_DMA_BUFFER_FRAMES * 4U);
}

static bool drainPcmWithSilence() {
  // i2s_write() acknowledges copying into DMA, NOT final playback. Push more
  // than the maximum DMA ring capacity (stereo PCM16) so the last voice frame
  // has actually left the queue before muting. Do not zero live DMA mid-tail.
  const uint8_t silence[AUDIO_CHUNK_BYTES] = {};
  size_t remaining = AUDIO_DMA_BUFFER_COUNT * AUDIO_DMA_BUFFER_FRAMES * 4U + AUDIO_CHUNK_BYTES;
  while (remaining > 0) {
    const size_t count = remaining < sizeof(silence) ? remaining : sizeof(silence);
    if (!writePcmBlock(silence, count)) return false;
    remaining -= count;
  }
  delay(AUDIO_POST_SILENCE_MS);
  return true;
}

static bool playEmbeddedWav(const uint8_t *source, size_t length,
                            const AlertRequest &request, bool &amplifierWasEnabled) {
  amplifierWasEnabled = false;
  digitalWrite(PIN_MAX98357_SD_EN, LOW);
  if (!i2sReady) {
    Serial.println("[AUDIO] ERROR | I2S driver is not ready");
    return false;
  }

  WavView wav;
  if (!parseWav(source, length, wav)) {
    Serial.println("[AUDIO] ERROR | embedded WAV is not PCM16 mono/stereo or is truncated");
    return false;
  }
  const i2s_channel_t channelMode = wav.channels == 1 ? I2S_CHANNEL_MONO : I2S_CHANNEL_STEREO;
  const esp_err_t clockResult = i2s_set_clk(I2S_NUM_0, wav.sampleRate, I2S_BITS_PER_SAMPLE_16BIT, channelMode);
  if (clockResult != ESP_OK) {
    Serial.printf("[AUDIO] ERROR | i2s_set_clk failed: %s (0x%X)\n",
                  esp_err_to_name(clockResult), (unsigned)clockResult);
    return false;
  }

  // set_clk can restart the transmitter. Prove silent DMA progress at the NEW
  // format while SD/EN is still LOW; do not enable on a failed/partial write.
  if (!primeMutedI2s()) {
    Serial.println("[AUDIO] MUTED | I2S silence did not prime; amplifier stays OFF");
    return false;
  }
  if (!requestIsCurrent(request)) return false;
  digitalWrite(PIN_MAX98357_SD_EN, HIGH);
  amplifierWasEnabled = true;
  delay(1);
  // Reading the output pad cannot prove that the amplifier is healthy, but it
  // catches the common wiring error where GPIO7/SD-EN is accidentally shorted
  // to GND. In that case stop immediately instead of driving the short for the
  // whole voice clip.
  if (digitalRead(PIN_MAX98357_SD_EN) != HIGH) {
    Serial.printf("[AUDIO] ERROR | SD/EN GPIO%d reads LOW after HIGH; check short to GND and do not confuse SD/EN with GAIN\n",
                  PIN_MAX98357_SD_EN);
    digitalWrite(PIN_MAX98357_SD_EN, LOW);
    return false;
  }
  Serial.printf("[AUDIO] AMP  | SD/EN GPIO%d=HIGH | WAV=%lu Hz/%u-bit/%u ch | GAIN pin is hardware-only\n",
                PIN_MAX98357_SD_EN, (unsigned long)wav.sampleRate, (unsigned)wav.bits,
                (unsigned)wav.channels);
  delay(AUDIO_AMP_SETTLE_MS);
  // Only compact direct-demo motion may overlap PCM playback. Full HTTP and
  // MicroSD remain gated, and even compact HTTP still takes the SD rail lock.
  // Do not open this during drain, DMA priming or amplifier settling.
  networkAllowDirectRealtimeForAudio();
  uint8_t buffer[AUDIO_CHUNK_BYTES];
  size_t offset = wav.dataOffset;
  size_t remaining = wav.dataBytes;
  bool complete = true;
  while (remaining > 0) {
    const size_t count = min(remaining, sizeof(buffer));
    memcpy_P(buffer, source + offset, count);
    applyPcmEnvelope(buffer, count,
                     (offset - wav.dataOffset) / (wav.channels * sizeof(int16_t)), wav);
    if (!writePcmBlock(buffer, count)) {
      complete = false;
      break;
    }
    offset += count;
    remaining -= count;
  }
  if (complete) complete = drainPcmWithSilence();
  digitalWrite(PIN_MAX98357_SD_EN, LOW);
  // Safe only now: the amp is off, and successful speech was already drained.
  i2s_zero_dma_buffer(I2S_NUM_0);
  return complete;
}

static void finishAlert(uint8_t code) {
  const uint8_t bit = uint8_t(1U << code);
  portENTER_CRITICAL(&pendingMux);
  pendingMask &= uint8_t(~bit);
  portEXIT_CRITICAL(&pendingMux);
}

static void alertTask(void *) {
  AlertRequest request{};
  for (;;) {
    if (xQueueReceive(alertQueue, &request, portMAX_DELAY) != pdTRUE) continue;
    const uint8_t code = request.code;
    const uint8_t *audio = nullptr;
    size_t audioLength = 0;
    const char *name = "unknown";
    if (code == ALERT_POTHOLE) {
      audio = AUDIO_O_GA_WAV; audioLength = AUDIO_O_GA_WAV_LEN; name = "o_ga";
    } else if (code == ALERT_SPEED_BUMP) {
      audio = AUDIO_GO_GIAM_TOC_WAV; audioLength = AUDIO_GO_GIAM_TOC_WAV_LEN; name = "go_giam_toc";
    } else if (code == ALERT_OVERSPEED) {
      audio = AUDIO_QUA_TOC_DO_WAV; audioLength = AUDIO_QUA_TOC_DO_WAV_LEN; name = "qua_toc_do";
    }
    if (!audio || !audioLength) { finishAlert(code); continue; }

    bool attemptedPlayback = false;
    unsigned attempts = 0;
    while (i2sReady && requestIsCurrent(request)) {
      ++attempts;
      setAudioActive(true);
      Serial.printf("[AUDIO] HOLD | %-13s | attempt=%u | quiescing MicroSD + HTTP\n", name, attempts);
      const bool sdQuiet = storageEnterAudioCritical(remainingAlertWait(request, AUDIO_SD_QUIESCE_TIMEOUT_MS));
      const bool httpQuiet = sdQuiet && requestIsCurrent(request) &&
                            networkWaitForIdleForAudio(remainingAlertWait(request, AUDIO_HTTP_QUIESCE_TIMEOUT_MS));
      if (sdQuiet && httpQuiet) {
        const uint32_t quietStarted = millis();
        while (requestIsCurrent(request) && millis() - quietStarted < AUDIO_PRE_PLAY_QUIET_MS)
          vTaskDelay(pdMS_TO_TICKS(10));
        if (requestIsCurrent(request)) {
          Serial.printf("[AUDIO] PLAY | %-13s | %.1f kB | gain=%u%% | fade=%u ms\n",
                        name, audioLength / 1024.0f, (unsigned)AUDIO_PCM_GAIN_PERCENT, (unsigned)AUDIO_FADE_MS);
          bool amplifierWasEnabled = false;
          const bool played = playEmbeddedWav(audio, audioLength, request, amplifierWasEnabled);
          attemptedPlayback = true;
          storageExitAudioCritical(amplifierWasEnabled);
          if (amplifierWasEnabled) {
            const uint32_t recoveryStarted = millis();
            while (storageRecoveryBusy() && millis() - recoveryStarted < AUDIO_POST_RECOVERY_WAIT_MS)
              vTaskDelay(pdMS_TO_TICKS(10));
          }
          networkExitAudioCritical();
          setAudioActive(false);
          // Driver success proves PCM transmission only, not speaker wiring,
          // rail voltage or card health. Report the actual storage state.
          Serial.printf("[AUDIO] %s | %-13s | %s | SD state=%s reason=%s\n",
                        played ? "DONE" : "FAIL", name,
                        played ? "PCM transmitted and tail drained; amp OFF"
                               : "PCM not completed; amp OFF (check earlier diagnostic)",
                        storageStateText(), storageLastError());
          break;
        }
      }
      digitalWrite(PIN_MAX98357_SD_EN, LOW);
      storageExitAudioCritical(false);
      networkExitAudioCritical();
      setAudioActive(false);
      // Retain this request, but open BOTH gates so maintenance/HTTP can make
      // progress. Queued alerts alone must not hold the hardware indefinitely.
      if (requestIsCurrent(request)) {
        Serial.printf("[AUDIO] RETRY | %-13s | voice not started; SD=%s HTTP=%s | maintenance gap\n",
                      name, sdQuiet ? "IDLE" : "BUSY", httpQuiet ? "IDLE" : "BUSY");
        vTaskDelay(pdMS_TO_TICKS(AUDIO_RETRY_GAP_MS));
      }
    }
    if (!attemptedPlayback) {
      Serial.printf("[AUDIO] SKIP | %-13s | %s | voice NOT played\n", name,
                    !i2sReady ? "I2S unavailable" :
                    (code == ALERT_OVERSPEED && !isOverspeedWanted()) ? "overspeed cleared before play" :
                    request.directSession[0] ? "direct scope expired / changed / left zone; stale voice discarded" :
                    "alert expired while waiting; stale voice discarded");
    }
    finishAlert(code);
  }
}

static bool enqueueAlert(uint8_t code, bool bypassBootInhibit = false, const AlertRequest *scope = nullptr) {
  if (!bypassBootInhibit && millis() - alertsStartedMs < AUDIO_BOOT_INHIBIT_MS) {
    if (code == ALERT_OVERSPEED) setOverspeedWanted(false);
    if (!scope) Serial.printf("[AUDIO] WAIT | alert code=%u suppressed during %lu-ms power/SD boot guard\n",
                              (unsigned)code, (unsigned long)AUDIO_BOOT_INHIBIT_MS);
    return false;
  }
  const uint8_t bit = uint8_t(1U << code);
  if (!alertQueue || !i2sReady) {
    Serial.printf("[AUDIO] SKIP | alert code=%u | audio queue unavailable; speaker-only mode\n", (unsigned)code);
    return false;
  }

  portENTER_CRITICAL(&pendingMux);
  const bool duplicate = (pendingMask & bit) != 0;
  if (!duplicate) pendingMask |= bit;
  portEXIT_CRITICAL(&pendingMux);
  if (duplicate) return false;

  AlertRequest request{};
  if (scope) request=*scope;
  request.code=code; request.queuedAtMs=millis();
  if (xQueueSend(alertQueue, &request, 0) != pdTRUE) {
    finishAlert(code);
    Serial.printf("[AUDIO] SKIP | alert code=%u | audio queue full; speaker-only mode\n", (unsigned)code);
    return false;
  }
  return true;
}

}  // namespace

void alertsEarlyMute() {
  if (earlyMuteDone) return;
  // gpio_set_level sets the output latch even before Arduino registers a pin
  // as GPIO; digitalWrite before pinMode is not reliable in Arduino-ESP32 3.x.
  const int pins[] = {PIN_MAX98357_SD_EN, PIN_I2S_DIN, PIN_I2S_BCLK, PIN_I2S_LRC};
  for (const int pin : pins) {
    gpio_set_level(static_cast<gpio_num_t>(pin), 0);
    pinMode(pin, OUTPUT);
    digitalWrite(pin, LOW);
  }
  earlyMuteDone = true;
}

bool alertsBegin() {
  alertsEarlyMute();
  alertsStartedMs = millis();
  digitalWrite(PIN_MAX98357_SD_EN, LOW);

  i2s_config_t config{};
  config.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX);
  config.sample_rate = 16000;
  config.bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT;
  config.channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT;
  config.communication_format = I2S_COMM_FORMAT_STAND_I2S;
  config.intr_alloc_flags = 0;
  config.dma_desc_num = AUDIO_DMA_BUFFER_COUNT;
  config.dma_frame_num = AUDIO_DMA_BUFFER_FRAMES;
  config.use_apll = false;
  config.tx_desc_auto_clear = true;
  config.fixed_mclk = 0;

  i2s_pin_config_t pins{};
  pins.mck_io_num = I2S_PIN_NO_CHANGE;
  pins.bck_io_num = PIN_I2S_BCLK;
  pins.ws_io_num = PIN_I2S_LRC;
  pins.data_out_num = PIN_I2S_DIN;
  pins.data_in_num = I2S_PIN_NO_CHANGE;

  const esp_err_t installResult = i2s_driver_install(I2S_NUM_0, &config, 0, nullptr);
  const esp_err_t pinResult = installResult == ESP_OK ? i2s_set_pin(I2S_NUM_0, &pins) : installResult;
  i2sReady = installResult == ESP_OK && pinResult == ESP_OK;
  if (i2sReady && !primeMutedI2s()) {
    i2sReady = false;
    Serial.println("[AUDIO] MUTED | startup silent DMA failed; voice disabled");
  }
  if (installResult == ESP_OK && !i2sReady) i2s_driver_uninstall(I2S_NUM_0);

  Serial.printf("[AUDIO] INIT | I2S0 BCLK=%d LRC=%d DIN=%d | SD/EN=%d (LOW idle, HIGH only while speaking)\n",
                PIN_I2S_BCLK, PIN_I2S_LRC, PIN_I2S_DIN, PIN_MAX98357_SD_EN);
  Serial.println("[AUDIO] WIRE | GAIN->GND = 12 dB; SD/EN->GND = shutdown/mute. GPIO7 must connect to SD/EN, not GAIN");
  if (installResult != ESP_OK)
    Serial.printf("[AUDIO] ERROR | i2s_driver_install failed: %s (0x%X)\n",
                  esp_err_to_name(installResult), (unsigned)installResult);
  else if (pinResult != ESP_OK)
    Serial.printf("[AUDIO] ERROR | i2s_set_pin failed: %s (0x%X)\n",
                  esp_err_to_name(pinResult), (unsigned)pinResult);
  if (i2sReady) Serial.println("[AUDIO] READY | early mute + silent DMA verified | amplifier remains OFF until a valid alert");

  alertQueue = xQueueCreate(4, sizeof(AlertRequest));
  if (!alertQueue) return false;
  if (xTaskCreatePinnedToCore(alertTask, "audioAlerts", 5120, nullptr, 4, nullptr, 0) != pdPASS) {
    vQueueDelete(alertQueue);
    alertQueue = nullptr;
    return false;
  }
  if (!i2sReady) Serial.println("[AUDIO] ERROR | MAX98357A I2S unavailable; voice alerts disabled (speaker-only mode)");
  return i2sReady;
}

void alertPothole() { enqueueAlert(ALERT_POTHOLE); }
void alertSpeedBump() { enqueueAlert(ALERT_SPEED_BUMP); }
void alertOverspeed() { setOverspeedWanted(true); enqueueAlert(ALERT_OVERSPEED); }
void cancelOverspeedAlert() { setOverspeedWanted(false); }
bool alertDirectHazard(uint8_t kind,const char *session,uint32_t pass,double lat,double lon,float radius) {
  if ((kind!=ALERT_POTHOLE && kind!=ALERT_SPEED_BUMP) ||
      !directDemoAudioCurrent(session,pass,lat,lon,radius)) return false;
  AlertRequest request{};
  strncpy(request.directSession,session,sizeof(request.directSession)-1);
  request.directPass=pass; request.lat=lat; request.lon=lon; request.radius=radius;
  return enqueueAlert(kind,false,&request);
}
void alertAudioSelfTest() {
  Serial.println("[AUDIO] TEST | queueing embedded pothole voice; no event or map point is created");
  enqueueAlert(ALERT_POTHOLE, true);
}

// Separate queue deduplication from the active hardware reservation. Retry
// gaps must let SD recovery and HTTP finish; explicit gate APIs protect the
// start race before the amp can be enabled.
bool alertsAudioBusy() {
  portENTER_CRITICAL(&pendingMux);
  const bool busy = audioActive;
  portEXIT_CRITICAL(&pendingMux);
  return busy;
}
