#include "config.h"
#include "power_arbiter.h"

namespace {
SemaphoreHandle_t railMutex = nullptr;
volatile uint32_t lastReleaseMs = 0;

bool acquireRail(uint32_t timeoutMs) {
  if (!railMutex && !powerArbiterBegin()) return false;
  const uint32_t started = millis();
  if (xSemaphoreTake(railMutex, pdMS_TO_TICKS(timeoutMs)) != pdTRUE) return false;

  // Hold the mutex during the recovery gap so the next high-current client
  // cannot start early. Unsigned elapsed arithmetic remains safe at millis wrap.
  const uint32_t released = lastReleaseMs;
  if (released != 0) {
    const uint32_t sinceRelease = millis() - released;
    if (sinceRelease < POWER_CLIENT_SWITCH_GAP_MS) {
      const uint32_t waitMs = POWER_CLIENT_SWITCH_GAP_MS - sinceRelease;
      if (millis() - started + waitMs > timeoutMs) {
        xSemaphoreGive(railMutex);
        return false;
      }
      vTaskDelay(pdMS_TO_TICKS(waitMs));
    }
  }
  return true;
}

void releaseRail() {
  if (!railMutex) return;
  lastReleaseMs = millis();
  xSemaphoreGive(railMutex);
}
}  // namespace

bool powerArbiterBegin() {
  if (!railMutex) railMutex = xSemaphoreCreateMutex();
  return railMutex != nullptr;
}

bool powerAcquireSd(uint32_t timeoutMs) { return acquireRail(timeoutMs); }
void powerReleaseSd() { releaseRail(); }
bool powerAcquireHttp(uint32_t timeoutMs) { return acquireRail(timeoutMs); }
void powerReleaseHttp() { releaseRail(); }

