#pragma once
#include "types.h"
bool gnssBegin();
void gnssPoll(GnssData &data);

