#pragma once
#include <stdint.h>
namespace motionwindow {
// lastSampleMs timestamps a FIFO drain, not every hardware sample. The budget
// must cover a normal 16-frame interrupt/poll cadence plus bounded bus jitter.
constexpr uint32_t fifoFreshnessBudgetMs(uint32_t sampleIntervalMs, uint32_t watermark,
                                        uint32_t pollTimeoutMs, uint32_t i2cTimeoutMs) {
  return (sampleIntervalMs * watermark > pollTimeoutMs ? sampleIntervalMs * watermark : pollTimeoutMs)
       + sampleIntervalMs * 2 + i2cTimeoutMs * 2;
}
inline bool ready(bool healthy, uint32_t readyFrames, uint32_t requiredFrames,
                  uint32_t generation, uint32_t previousInferenceFrame,
                  uint32_t minimumNewFrames, uint32_t now, uint32_t lastDrainMs,
                  uint32_t maximumDrainAgeMs) {
  return healthy && readyFrames >= requiredFrames &&
         uint32_t(generation - previousInferenceFrame) >= minimumNewFrames &&
         uint32_t(now - lastDrainMs) <= maximumDrainAgeMs;
}
}
