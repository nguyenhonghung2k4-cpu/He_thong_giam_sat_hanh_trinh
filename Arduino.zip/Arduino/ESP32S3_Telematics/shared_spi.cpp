#include "shared_spi.h"

static SemaphoreHandle_t spiBusMutex = nullptr;

bool sharedSpiBegin() {
  if (!spiBusMutex) spiBusMutex = xSemaphoreCreateMutex();
  return spiBusMutex != nullptr;
}

bool sharedSpiLock(uint32_t timeoutMs) {
  if (!spiBusMutex && !sharedSpiBegin()) return false;
  return xSemaphoreTake(spiBusMutex, pdMS_TO_TICKS(timeoutMs)) == pdTRUE;
}

void sharedSpiUnlock() {
  if (spiBusMutex) xSemaphoreGive(spiBusMutex);
}
