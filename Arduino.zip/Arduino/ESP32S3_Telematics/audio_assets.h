#pragma once

#include <Arduino.h>

// User-provided RIFF/WAV prompts stored in flash. They are PCM16, mono,
// 16 kHz and are streamed in small chunks, never copied wholly into RAM.
extern const uint8_t AUDIO_O_GA_WAV[] PROGMEM;
extern const size_t AUDIO_O_GA_WAV_LEN;
extern const uint8_t AUDIO_GO_GIAM_TOC_WAV[] PROGMEM;
extern const size_t AUDIO_GO_GIAM_TOC_WAV_LEN;
extern const uint8_t AUDIO_QUA_TOC_DO_WAV[] PROGMEM;
extern const size_t AUDIO_QUA_TOC_DO_WAV_LEN;
