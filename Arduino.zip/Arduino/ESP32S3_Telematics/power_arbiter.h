#pragma once
#include <Arduino.h>

// SD writes and Wi-Fi RF/HTTP bursts can draw their peak current at the same
// instant even though they use different buses. This mutex serializes those
// high-current phases and inserts a short rail-recovery gap when ownership
// changes. It does not replace the SD SPI mutex or the HTTP/audio gate.
bool powerArbiterBegin();
bool powerAcquireSd(uint32_t timeoutMs);
void powerReleaseSd();
bool powerAcquireHttp(uint32_t timeoutMs);
void powerReleaseHttp();

