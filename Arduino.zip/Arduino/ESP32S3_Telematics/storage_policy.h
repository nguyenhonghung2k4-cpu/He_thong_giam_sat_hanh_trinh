#pragma once
#include <stddef.h>
#include <stdint.h>

// Pure bounded policy helpers; callers serialize EventTickets with their mux.
// No filesystem calls or dynamic allocation are performed here.
namespace storage_policy {
template <size_t Capacity> class EventTickets {
  struct Entry { uint32_t id = 0; bool durable = false; bool callerOwns = false; };
  Entry entries_[Capacity]{};
  uint32_t next_ = 1;
public:
  constexpr uint32_t reserve() {
    for (size_t i = 0; i < Capacity; ++i) if (!entries_[i].id) {
      uint32_t id = 0;
      bool collision=false;
      do {
        id = next_++;
        if (!next_) next_ = 1;
        collision = !id;
        for (const auto &e : entries_) if (e.id == id) collision = true;
      } while (collision);
      entries_[i] = {id, false, true};
      return id;
    }
    return 0; // Backpressure: never evict an outstanding acknowledgement.
  }
  constexpr bool durable(uint32_t id) const {
    if (!id) return false;
    for (const auto &e : entries_) if (e.id == id) return e.durable;
    return false;
  }
  constexpr void markDurable(uint32_t id) {
    for (auto &e : entries_) if (e.id == id && id) {
      e.durable = true;
      if (!e.callerOwns) e = {};
      return;
    }
  }
  constexpr void release(uint32_t id) {
    for (auto &e : entries_) if (e.id == id && id) {
      e.callerOwns = false;
      if (e.durable) e = {};
      return;
    }
  }
  // Only for publication failure: no worker can still own this ticket.
  constexpr void cancel(uint32_t id) {
    for (auto &e : entries_) if (e.id == id && id) { e = {}; return; }
  }
};

// Weighted round robin: events receive two slots, but a blocked/continuously
// busy event lane cannot starve telemetry. 0=event, 1=offline, 2=daily log.
constexpr int chooseLane(uint8_t &cursor, const bool eligible[3]) {
  for (uint8_t n = 0; n < 4; ++n) {
    const uint8_t lane = cursor < 2 ? 0 : uint8_t(cursor - 1);
    cursor = uint8_t((cursor + 1) % 4);
    if (eligible[lane]) return lane;
  }
  return -1;
}
} // namespace storage_policy
