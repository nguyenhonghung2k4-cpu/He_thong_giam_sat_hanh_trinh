#pragma once
#include <stddef.h>
#include <stdint.h>
#include <string.h>

namespace directrealtime {
constexpr uint32_t PeriodMs = 200, MaxAgeMs = 500;
constexpr size_t Capacity = 1024;
constexpr bool due(uint32_t now, uint32_t last) { return uint32_t(now-last) >= PeriodMs; }
constexpr bool fresh(uint32_t now, uint32_t captured) { return uint32_t(now-captured) <= MaxAgeMs; }
constexpr bool canFreshAtSend(uint32_t now, uint32_t captured, uint32_t canAge, uint32_t staleMs) {
  return canAge <= staleMs && uint32_t(now-captured) <= staleMs-canAge;
}
constexpr bool gateAllows(bool compact, bool active, bool audioGate, bool playbackAllowed) {
  return !audioGate || (compact && active && playbackAllowed);
}
// Owner supplies the cross-core lock. Fixed capacity, one newest packet, no
// allocation/FIFO/retry/persistence. Old motion is useless after an outage.
struct Packet {
  char json[Capacity] = {};
  size_t length = 0;
  uint32_t capturedMs = 0, canAgeMs = 0;
  bool canWasFresh = false;
};
class LatestPacketSlot {
  Packet value;
  bool occupied = false;
 public:
  bool publish(const char *json, size_t length, uint32_t captured, uint32_t canAge, bool canFresh) {
    if(!json || !length || length>=Capacity) return false;
    memcpy(value.json,json,length); value.json[length]=0;
    value.length=length; value.capturedMs=captured; value.canAgeMs=canAge; value.canWasFresh=canFresh;
    occupied=true; return true;
  }
  bool take(Packet &out) { if(!occupied)return false;out=value;occupied=false;return true; }
  bool pending() const { return occupied; }
};
}
