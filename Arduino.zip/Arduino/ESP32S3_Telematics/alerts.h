#pragma once
#include <stdint.h>

// First setup() statement: holds shutdown/data/clocks low before slow startup.
// Does not cover the ROM/bootloader interval before setup(). Never call while playing.
void alertsEarlyMute();
bool alertsBegin();
void alertPothole();
void alertSpeedBump();
void alertOverspeed();
void cancelOverspeedAlert();
// Admission only, NOT proof of playback. Scope is rechecked just before amp ON.
bool alertDirectHazard(uint8_t kind, const char *session, uint32_t pass,
                       double lat, double lon, float radius);
// Diagnostic only: play one embedded voice without creating a telemetry/map
// event. Enable AUDIO_BOOT_SELF_TEST in config.h to call this after boot.
void alertAudioSelfTest();

// True while quiescing SD/HTTP, playing, or waiting for post-audio recovery.
// False during bounded retry gaps even with alerts queued, so maintenance can
// progress. Explicit storage/network gates arbitrate before amplifier enable.
bool alertsAudioBusy();
