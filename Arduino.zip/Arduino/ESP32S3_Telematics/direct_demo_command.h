#pragma once
#include "direct_demo_engine.h"
#include "demo_json_reader.h"

namespace directdemo {
struct Command {
  uint32_t id=0, queuedMs=0, ttlMs=2000;
  bool start=false;
  char session[49]={}, operation[12]={};
  float multiplier=2;
  size_t count=0;
  Point points[MaxVertices];
};
inline const char *parseCommand(const char *json,size_t length,Command &out) {
  DemoJsonReader reader(json,length); DemoJsonSpan command,span;
  if(!reader.valid()||!reader.objectMember(reader.root(),"command",command)) return "invalid_command_json";
  if(!reader.objectMember(command,"session_id",span)||!reader.simpleString(span,out.session,sizeof(out.session))||!Engine::sessionValid(out.session)) return "invalid_session_id";
  if(!reader.objectMember(command,"action",span)) return "missing_action";
  out.start=reader.stringEquals(span,"direct_demo_start");
  if(!out.start&&!reader.stringEquals(span,"direct_demo_control")) return "invalid_action";
  // Expiry is relative to server response, so an unset ESP RTC is irrelevant.
  double ttl=0;
  if(!reader.objectMember(command,"expires_in_ms",span)||!reader.number(span,ttl)||ttl<=0) return "expired_or_missing_expiry";
  out.ttlMs=uint32_t(ttl>2000 ? 2000 : ttl);
  if(!out.ttlMs) return "expired_command";
  if(!out.start) {
    if(!reader.objectMember(command,"operation",span)||!reader.simpleString(span,out.operation,sizeof(out.operation))) return "invalid_operation";
    return nullptr;
  }
  double multiplier=2;
  if(reader.objectMember(command,"speed_multiplier",span)&&!reader.number(span,multiplier)) return "invalid_multiplier";
  if(multiplier<.5||multiplier>5) return "invalid_multiplier";
  out.multiplier=float(multiplier);
  double flat[MaxVertices*2]; size_t count=0;
  if(!reader.objectMember(command,"route_points",span)||!reader.boundedNumberArray(span,flat,MaxVertices*2,count)||count<4||count%2) return "invalid_route_points";
  out.count=count/2;
  for(size_t i=0;i<out.count;i++) out.points[i]={flat[i*2],flat[i*2+1]};
  return nullptr;
}
}
