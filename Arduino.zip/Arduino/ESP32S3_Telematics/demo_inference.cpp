#include "demo_inference.h"
#include "demo_json_reader.h"
#include "motion_ai.h"
#include "runtime_config.h"
#include <stdlib.h>

static bool rejectDemo(const char *error,String &result){
  result=String("{\"inference_ok\":false,\"error\":\"")+error+"\"}";
  Serial.printf("[DEMO] FAIL | TinyML request rejected: %s\n",error);
  return false;
}
static bool memberNumber(const DemoJsonReader &reader,DemoJsonSpan object,
                         const char *key,double &number){
  DemoJsonSpan span;return reader.objectMember(object,key,span)&&reader.number(span,number);
}

bool demoInferenceCommand(const String &json,String &result){
  const uint32_t receivedAt=millis();
  DemoJsonReader reader(json.c_str(),json.length());
  if(!reader.valid())return rejectDemo("invalid_or_oversize_json",result);
  DemoJsonSpan command,params,span;
  if(!reader.objectMember(reader.root(),"command",command))
    return rejectDemo("missing_command",result);
  // /next flattens params today; a nested params object is also accepted for
  // API compatibility. Required fields are looked up only in this object.
  params=command;
  DemoJsonSpan nested;
  if(reader.objectMember(command,"params",nested))params=nested;
  if(!reader.objectMember(command,"action",span)||!reader.stringEquals(span,"demo_infer"))
    return rejectDemo("invalid_demo_action",result);
  if(!reader.objectMember(params,"source",span)||!reader.stringEquals(span,"auto_demo_tinyml"))
    return rejectDemo("invalid_demo_source",result);
  if(!reader.objectMember(params,"units",span)||!reader.stringEquals(span,"g"))
    return rejectDemo("invalid_acceleration_units",result);
  char sampleId[81];
  if(!reader.objectMember(params,"sample_id",span)||!reader.simpleString(span,sampleId,sizeof(sampleId)))
    return rejectDemo("invalid_sample_id",result);
  double frames=0,frequency=0;
  if(!memberNumber(reader,params,"frames",frames)||frames!=(double)motionModelSampleCount())
    return rejectDemo("model_window_mismatch",result);
  if(!memberNumber(reader,params,"sample_rate_hz",frequency)||
     fabs(frequency-motionModelFrequencyHz())>0.0001)
    return rejectDemo("model_frequency_mismatch",result);
  // Use the server's remaining delivery TTL: ESP uptime is not UTC, and GNSS
  // may legitimately have no fix indoors. Never compare an epoch to millis().
  double ttl=0;
  if(!memberNumber(reader,params,"expires_in_ms",ttl)){
    double expiry=0,serverNow=0;
    if(!memberNumber(reader,params,"expires_at_ms",expiry)||
       !memberNumber(reader,params,"server_now_ms",serverNow))
      return rejectDemo("missing_command_expiry",result);
    ttl=expiry-serverNow;
  }
  if(ttl<=0||ttl>120000)return rejectDemo("expired_or_invalid_command_ttl",result);
  if(!reader.objectMember(params,"values",span))return rejectDemo("missing_acceleration_values",result);
  const size_t count=motionModelInputCount();
  float *values=(float*)malloc(count*sizeof(float));
  if(!values)return rejectDemo("inference_allocation_failed",result);
  const bool parsed=reader.numberArray(span,values,count);
  if(!parsed){free(values);return rejectDemo("invalid_acceleration_values",result);}
  if((double)(uint32_t)(millis()-receivedAt)>=ttl){
    free(values);return rejectDemo("command_expired_before_inference",result);
  }
  Serial.printf("[DEMO] AI   | %s | %u XYZ frames | %.1f Hz | isolated model inference\n",
                sampleId,(unsigned)motionModelSampleCount(),motionModelFrequencyHz());
  AiData demoAi;const bool inferred=motionInferWindow(values,count,demoAi,2000);
  free(values);
  if(!inferred||!demoAi.valid)return rejectDemo("classifier_busy_or_failed",result);
  if((double)(uint32_t)(millis()-receivedAt)>=ttl)
    return rejectDemo("command_expired_during_inference",result);
  const RuntimeConfig &config=runtimeConfigGet();
  const bool accepted=(demoAi.label=="o_ga"&&demoAi.confidence>=config.potholeConfidence)||
                      (demoAi.label=="go_giam_toc"&&demoAi.confidence>=config.speedBumpConfidence);
  // sample_id is audit metadata only. Prediction and confidence are exclusively
  // supplied by Edge Impulse, including flat/low-confidence classifications.
  result="{\"inference_ok\":true,\"label\":\""+demoAi.label+"\",\"confidence\":"+
         String(demoAi.confidence,6)+",\"scores\":{\"duong_bang_phang\":"+
         String(demoAi.flatConfidence,6)+",\"go_giam_toc\":"+String(demoAi.speedBumpConfidence,6)+
         ",\"o_ga\":"+String(demoAi.potholeConfidence,6)+"},\"inference_ms\":"+
         String(demoAi.inferenceMs)+",\"frame_samples\":"+String((unsigned)motionModelSampleCount())+
         ",\"frequency_hz\":"+String(motionModelFrequencyHz(),3)+",\"units\":\"g\",\"hazard_accepted\":"+
         String(accepted?"true":"false")+",\"model_version\":\""+motionModelVersion()+
         "\",\"x_g\":"+String(demoAi.x,6)+",\"y_g\":"+String(demoAi.y,6)+
         ",\"z_g\":"+String(demoAi.z,6)+"}";
  Serial.printf("[DEMO] AI OK| %-18s | %.1f%% | %lu ms | hazard=%s | live GNSS/SD unchanged\n",
                demoAi.label.c_str(),demoAi.confidence*100.0f,(unsigned long)demoAi.inferenceMs,
                accepted?"accepted":"not accepted");
  return true;
}
