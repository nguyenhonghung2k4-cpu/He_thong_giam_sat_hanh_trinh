#pragma once
#include "types.h"
struct CanDiagnostics {
  bool installed = false, workerRunning = false;
  bool serviceSeen = false, workerResponsive = false;
  int32_t state = -1, lastError = 0;
  uint32_t initAttempts = 0, recoveryAttempts = 0, recoveryStarts = 0;
  uint32_t passiveRestartAttempts = 0, passiveRestarts = 0;
  uint32_t serviceCycles = 0, lastServiceMs = 0, serviceAgeMs = 0;
  uint32_t statusErrors = 0, receiveErrors = 0, queueFlushes = 0;
  uint32_t rawRx = 0, rejectedRx = 0, lastRxMs = 0;
  // Lifetime counters/last observations survive stop/start. ECU validity does not.
  uint32_t idRx[4] = {}, lastIdMs[4] = {};
  uint32_t rxPending = 0, rxMissed = 0, rxOverrun = 0;
  uint32_t txErrorCounter = 0, rxErrorCounter = 0, busErrors = 0;
};
bool canBegin();
void canPoll(EcuData &ecu);
CanDiagnostics canGetDiagnostics();
void canPrintDiagnostics(const EcuData &ecu);

