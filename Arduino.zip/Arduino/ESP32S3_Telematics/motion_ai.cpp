#include <Wire.h>
#include <telematics_inferencing.h>
#include "config.h"
#include "motion_ai.h"
#include "motion_window_policy.h"
#include <freertos/semphr.h>
#include <math.h>

static constexpr uint8_t REG_DEVID=0x00, REG_BW_RATE=0x2C, REG_POWER_CTL=0x2D,
                         REG_INT_ENABLE=0x2E, REG_INT_MAP=0x2F, REG_INT_SOURCE=0x30,
                         REG_DATA_FORMAT=0x31, REG_DATAX0=0x32,
                         REG_FIFO_CTL=0x38, REG_FIFO_STATUS=0x39;
static constexpr uint8_t INT_OVERRUN=0x01, INT_WATERMARK=0x02;
static constexpr uint8_t FIFO_WATERMARK=16, FIFO_STREAM_CFG=0x80|FIFO_WATERMARK;
static constexpr uint32_t FIFO_SERVICE_TIMEOUT_MS=180;
static constexpr uint32_t FIFO_SAMPLE_FRESHNESS_MS=motionwindow::fifoFreshnessBudgetMs(
  uint32_t(EI_CLASSIFIER_INTERVAL_MS),FIFO_WATERMARK,FIFO_SERVICE_TIMEOUT_MS,ADXL345_I2C_TIMEOUT_MS);

static float samples[EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE];
static volatile uint32_t writeFrame=0, framesReady=0;
static volatile uint32_t totalFrames=0,lastSampleMs=0;
static volatile uint32_t lastInferenceFrame=0;
static portMUX_TYPE sampleMux=portMUX_INITIALIZER_UNLOCKED;
static TaskHandle_t sampleTaskHandle=nullptr;
static volatile bool sensorHealthy=false;
static volatile uint32_t fifoServiceCount=0;
static volatile uint32_t fifoOverrunCount=0;
static uint32_t lastOverrunWarningMs=0;
static SemaphoreHandle_t classifierMutex=nullptr;

static_assert(EI_CLASSIFIER_RAW_SAMPLES_PER_FRAME == 3, "Model must use x,y,z axes");
static_assert(EI_CLASSIFIER_RAW_SAMPLE_COUNT == 200, "This firmware expects the trained 200-sample window");
static_assert(EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE == EI_CLASSIFIER_RAW_SAMPLE_COUNT*3,
              "Model input must be 200 x 3 accelerometer values");
static_assert(EI_CLASSIFIER_FREQUENCY == 100, "ADXL345 ODR configuration expects a 100 Hz model");
static_assert(ADXL345_I2C_FREQUENCY_HZ <= 400000,
              "ADXL345 I2C fast-mode maximum is 400 kHz");

static void IRAM_ATTR adxlDataReady(){
  BaseType_t wake=pdFALSE;
  if(sampleTaskHandle)vTaskNotifyGiveFromISR(sampleTaskHandle,&wake);
  if(wake)portYIELD_FROM_ISR();
}

// ADXL345 is the only device on this dedicated Wire bus. Each helper checks
// the complete I2C transaction so a disconnected or stuck sensor can never
// turn partial bytes into valid acceleration samples.
static bool readRegisters(uint8_t reg,uint8_t *data,size_t length){
  if(!data||length==0)return false;
  Wire.beginTransmission(ADXL345_I2C_ADDRESS);
  if(Wire.write(reg)!=1){
    (void)Wire.endTransmission(true);
    return false;
  }
  if(Wire.endTransmission(false)!=0)return false;

  const size_t received=Wire.requestFrom(ADXL345_I2C_ADDRESS,length,true);
  if(received!=length){
    while(Wire.available())(void)Wire.read();
    return false;
  }
  for(size_t i=0;i<length;i++){
    if(!Wire.available())return false;
    data[i]=(uint8_t)Wire.read();
  }
  return true;
}

static bool regRead(uint8_t reg,uint8_t &value){
  return readRegisters(reg,&value,1);
}

static bool regWrite(uint8_t reg,uint8_t value){
  Wire.beginTransmission(ADXL345_I2C_ADDRESS);
  if(Wire.write(reg)!=1||Wire.write(value)!=1){
    (void)Wire.endTransmission(true);
    return false;
  }
  return Wire.endTransmission(true)==0;
}

static bool readXYZ(float &x,float &y,float &z){
  uint8_t b[6];
  if(!readRegisters(REG_DATAX0,b,sizeof(b)))return false;

  constexpr float G_PER_LSB=0.0039f;
  x=int16_t(uint16_t(b[0])|(uint16_t(b[1])<<8))*G_PER_LSB;
  y=int16_t(uint16_t(b[2])|(uint16_t(b[3])<<8))*G_PER_LSB;
  z=int16_t(uint16_t(b[4])|(uint16_t(b[5])<<8))*G_PER_LSB;
  return true;
}

static bool configureSensor(){
  // Hardware straps select I2C mode/address: CS -> 3.3 V, SDO -> GND (0x53).
  uint8_t value=0;
  if(!regRead(REG_DEVID,value)||value!=0xE5)return false;
  if(!regWrite(REG_POWER_CTL,0)||
     !regWrite(REG_INT_ENABLE,0)||
     !regWrite(REG_FIFO_CTL,0)||
     !regWrite(REG_INT_MAP,0x00)||       // Watermark interrupt -> INT1.
     !regWrite(REG_DATA_FORMAT,0x0B)||   // Full resolution, +/-16 g.
     !regWrite(REG_BW_RATE,0x0A))        // 100 Hz, matching the EI model.
    return false;

  float x,y,z;
  (void)readXYZ(x,y,z);
  (void)regRead(REG_INT_SOURCE,value);
  if(!regWrite(REG_FIFO_CTL,FIFO_STREAM_CFG)||
     !regWrite(REG_POWER_CTL,0x08)||
     !regWrite(REG_INT_ENABLE,INT_WATERMARK|INT_OVERRUN))
    return false;
  return regRead(REG_DEVID,value)&&value==0xE5;
}

static void resetWindow(){
  portENTER_CRITICAL(&sampleMux);
  writeFrame=0;framesReady=0;totalFrames=0;lastSampleMs=0;lastInferenceFrame=0;
  portEXIT_CRITICAL(&sampleMux);
}

static void pushSample(float x,float y,float z){
  portENTER_CRITICAL(&sampleMux);
  uint32_t i=(writeFrame%EI_CLASSIFIER_RAW_SAMPLE_COUNT)*3;
  samples[i]=x;samples[i+1]=y;samples[i+2]=z;
  writeFrame=(writeFrame+1)%EI_CLASSIFIER_RAW_SAMPLE_COUNT;
  if(framesReady<EI_CLASSIFIER_RAW_SAMPLE_COUNT)framesReady++;
  totalFrames++;lastSampleMs=millis();
  portEXIT_CRITICAL(&sampleMux);
}

static void sampler(void*){
  uint32_t lastIdentityCheck=0;
  for(;;){
    if(!sensorHealthy){
      if(!configureSensor()){vTaskDelay(pdMS_TO_TICKS(100));continue;}
      resetWindow();
      sensorHealthy=true;
      Serial.printf("[AI  ] I2C  | ADXL345 ready at 0x%02X (SDA=%d SCL=%d, 100 Hz)\n",
                    ADXL345_I2C_ADDRESS,PIN_ADXL_SDA,PIN_ADXL_SCL);
    }

    // INT1 wakes at 16 samples (~160 ms). Timeout remains below FIFO capacity,
    // so a missed edge still drains the FIFO before the 32-sample limit.
    ulTaskNotifyTake(pdTRUE,pdMS_TO_TICKS(FIFO_SERVICE_TIMEOUT_MS));

    const uint32_t now=millis();
    if(now-lastIdentityCheck>=500){
      lastIdentityCheck=now;
      uint8_t deviceId=0;
      if(!regRead(REG_DEVID,deviceId)||deviceId!=0xE5){
        sensorHealthy=false;
        resetWindow();
        continue;
      }
    }

    uint8_t interruptSource=0,fifoStatus=0;
    if(!regRead(REG_INT_SOURCE,interruptSource)||
       !regRead(REG_FIFO_STATUS,fifoStatus)){
      sensorHealthy=false;
      resetWindow();
      continue;
    }
    const uint8_t available=fifoStatus&0x3F;
    // ADXL345 can expose 32 FIFO entries plus the output-register sample.
    if(available>33){
      sensorHealthy=false;
      resetWindow();
      continue;
    }

    const bool overrun=(interruptSource&INT_OVERRUN)!=0;
    uint8_t reads=(overrun&&available==0)?1:available;
    ++fifoServiceCount;

    // If FIFO overflowed, discard the stale inference window but retain the
    // newest complete frames still available in the hardware FIFO.
    if(overrun){
      ++fifoOverrunCount;
      resetWindow();
    }
    while(reads--){
      float x,y,z;
      if(!readXYZ(x,y,z)){sensorHealthy=false;break;}
      pushSample(x,y,z);
    }

    if(!sensorHealthy){resetWindow();continue;}
    if(overrun){
      uint8_t ignored=0;
      (void)regRead(REG_INT_SOURCE,ignored);
      if(lastOverrunWarningMs==0||now-lastOverrunWarningMs>=1000){
        lastOverrunWarningMs=now;
        Serial.printf("[AI  ] WARN | ADXL I2C FIFO overrun #%lu; newest samples retained\n",
                      (unsigned long)fifoOverrunCount);
      }
    }
  }
}

static float inferenceBuf[EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE];
static int signalGet(size_t off,size_t len,float*out){
  if(!out||off>EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE||
     len>EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE-off)return -1;
  memcpy(out,inferenceBuf+off,len*sizeof(float));
  return 0;
}

// run_classifier() and its signal callback use shared SDK/model state. Both
// live and injected windows must hold this mutex for copy + inference + result
// mapping, not merely while copying the input. ADXL sampling has its own short
// critical section and continues at 100 Hz while either inference runs.
struct ClassifierGuard {
  bool acquired=false;
  explicit ClassifierGuard(uint32_t timeoutMs){
    if(classifierMutex)
      acquired=xSemaphoreTake(classifierMutex,pdMS_TO_TICKS(timeoutMs))==pdTRUE;
  }
  ~ClassifierGuard(){if(acquired)xSemaphoreGive(classifierMutex);}
};

static bool classifyCurrentBuffer(AiData &d){
  d.valid=false;
  d.x=inferenceBuf[(EI_CLASSIFIER_RAW_SAMPLE_COUNT-1)*3];
  d.y=inferenceBuf[(EI_CLASSIFIER_RAW_SAMPLE_COUNT-1)*3+1];
  d.z=inferenceBuf[(EI_CLASSIFIER_RAW_SAMPLE_COUNT-1)*3+2];
  signal_t sig{};
  sig.total_length=EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE;
  sig.get_data=signalGet;
  ei_impulse_result_t result{};
  const uint32_t started=millis();
  const EI_IMPULSE_ERROR err=run_classifier(&sig,&result,false);
  d.inferenceMs=millis()-started;
  if(err!=EI_IMPULSE_OK)return false;
  d.confidence=-1;d.flatConfidence=0;d.speedBumpConfidence=0;d.potholeConfidence=0;
  for(size_t i=0;i<EI_CLASSIFIER_LABEL_COUNT;i++){
    const char *label=result.classification[i].label;
    const float value=result.classification[i].value;
    if(!label||!isfinite(value)||value<0||value>1)return false;
    if(strcmp(label,"duong_bang_phang")==0)d.flatConfidence=value;
    else if(strcmp(label,"go_giam_toc")==0)d.speedBumpConfidence=value;
    else if(strcmp(label,"o_ga")==0)d.potholeConfidence=value;
    if(value>d.confidence){d.confidence=value;d.label=label;}
  }
  if(d.confidence<0)return false;
  d.valid=true;d.lastUpdateMs=millis();
  return true;
}

bool motionBegin(){
  if(!classifierMutex)classifierMutex=xSemaphoreCreateMutex();
  if(!classifierMutex){
    Serial.println("[AI  ] FAIL | Cannot create classifier serialization mutex");
    return false;
  }
  pinMode(PIN_ADXL_INT,INPUT);

  if(!Wire.begin(PIN_ADXL_SDA,PIN_ADXL_SCL,ADXL345_I2C_FREQUENCY_HZ)){
    Serial.println("[AI  ] FAIL | Cannot start dedicated ADXL345 I2C bus");
    return false;
  }
  Wire.setTimeOut(ADXL345_I2C_TIMEOUT_MS);
  attachInterrupt(digitalPinToInterrupt(PIN_ADXL_INT),adxlDataReady,RISING);

  sensorHealthy=configureSensor();
  if(xTaskCreatePinnedToCore(sampler,"adxl100Hz",4096,nullptr,5,&sampleTaskHandle,1)!=pdPASS){
    sensorHealthy=false;
    detachInterrupt(digitalPinToInterrupt(PIN_ADXL_INT));
    return false;
  }
  if(!sensorHealthy)
    Serial.printf("[AI  ] WARN | ADXL345 not found at I2C 0x%02X; sampler will retry\n",
                  ADXL345_I2C_ADDRESS);
  return true;
}

bool motionInfer(AiData &d){
  // Live loop never blocks behind a remote inference. A complete fresh live
  // window remains available on the following loop iteration.
  ClassifierGuard guard(0);
  if(!guard.acquired)return false;
  constexpr uint32_t MIN_NEW_FRAMES=(EI_CLASSIFIER_FREQUENCY*INFERENCE_PERIOD_MS+999)/1000;
  uint32_t generation=0,sampleTime=0,readyFrames=0;
  portENTER_CRITICAL(&sampleMux);
  generation=totalFrames;sampleTime=lastSampleMs;readyFrames=framesReady;
  portEXIT_CRITICAL(&sampleMux);

  // FIFO service is normally every160ms, not every10ms. The old50ms age
  // test phase-locked against500ms inference and skipped healthy windows for
  // seconds. This bound (~250ms at100Hz) still rejects stalled sampling; FIFO
  // overrun/I2C errors independently reset the complete model window.
  if(!motionwindow::ready(sensorHealthy,readyFrames,EI_CLASSIFIER_RAW_SAMPLE_COUNT,
       generation,lastInferenceFrame,MIN_NEW_FRAMES,millis(),sampleTime,FIFO_SAMPLE_FRESHNESS_MS))return false;

  portENTER_CRITICAL(&sampleMux);
  // A FIFO overrun/disconnect may have reset the ring between the cheap
  // readiness check above and this copy. Never classify a partially reset ring.
  if(!motionwindow::ready(sensorHealthy,framesReady,EI_CLASSIFIER_RAW_SAMPLE_COUNT,
       totalFrames,lastInferenceFrame,MIN_NEW_FRAMES,millis(),lastSampleMs,FIFO_SAMPLE_FRESHNESS_MS)) {
    portEXIT_CRITICAL(&sampleMux);
    return false;
  }
  const uint32_t start=writeFrame;
  for(uint32_t n=0;n<EI_CLASSIFIER_RAW_SAMPLE_COUNT;n++){
    uint32_t src=((start+n)%EI_CLASSIFIER_RAW_SAMPLE_COUNT)*3;
    memcpy(inferenceBuf+n*3,samples+src,3*sizeof(float));
  }
  lastInferenceFrame=totalFrames;
  portEXIT_CRITICAL(&sampleMux);

  return classifyCurrentBuffer(d);
}

bool motionInferWindow(const float *values,size_t count,AiData &d,uint32_t timeoutMs){
  if(!values||count!=EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE)return false;
  for(size_t i=0;i<count;i++)
    if(!isfinite(values[i])||fabsf(values[i])>16.0f)return false;
  ClassifierGuard guard(timeoutMs);
  if(!guard.acquired)return false;
  memcpy(inferenceBuf,values,sizeof(inferenceBuf));
  return classifyCurrentBuffer(d);
}
size_t motionModelSampleCount(){return EI_CLASSIFIER_RAW_SAMPLE_COUNT;}
size_t motionModelInputCount(){return EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE;}
float motionModelFrequencyHz(){return EI_CLASSIFIER_FREQUENCY;}
const char *motionModelVersion(){return MODEL_VERSION;}

bool motionSensorHealthy(){return sensorHealthy;}
uint32_t motionFifoOverrunCount(){return fifoOverrunCount;}
uint32_t motionFifoServiceCount(){return fifoServiceCount;}
