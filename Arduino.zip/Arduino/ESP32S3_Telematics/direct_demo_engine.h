#pragma once
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include "geofence_policy.h"

// Deterministic, allocation-free engine. Only the Arduino loop owns this state.
// No sensor samples, clocks, GPIOs, network calls or SD catalog writes here.
namespace directdemo {
constexpr size_t MaxVertices = 64, MaxHazards = 64;
struct Point { double lat = 0, lon = 0; };
inline double distance(Point a, Point b) {
  constexpr double r = 0.017453292519943295;
  const double p = sin((b.lat-a.lat)*r/2), q = sin((b.lon-a.lon)*r/2);
  double h = p*p+cos(a.lat*r)*cos(b.lat*r)*q*q;
  h = h < 0 ? 0 : h > 1 ? 1 : h;
  return 12742000.0*atan2(sqrt(h),sqrt(1-h));
}
inline double segmentDistance(Point a, Point b, Point p) {
  constexpr double r = 0.017453292519943295, earth = 6371000.0;
  const double c = cos((a.lat+b.lat+p.lat)*r/3);
  const double x = (a.lon-p.lon)*r*earth*c, y = (a.lat-p.lat)*r*earth;
  const double dx = (b.lon-a.lon)*r*earth*c, dy = (b.lat-a.lat)*r*earth;
  const double d = dx*dx+dy*dy;
  double t = d > .0001 ? -(x*dx+y*dy)/d : 0;
  t = t < 0 ? 0 : t > 1 ? 1 : t;
  return sqrt((x+t*dx)*(x+t*dx)+(y+t*dy)*(y+t*dy));
}
struct Hazard {
  Point point;
  uint8_t kind = 0;
  float confidence = 0, previousDistance = INFINITY, warningDistance = 0;
  bool armed = false, warningPending = false, warningReported = false;
  uint32_t warningAtMs = 0;
};
enum class State : uint8_t { None, Running, Paused, CanStale, Completed, Stopped };
struct Snapshot {
  char session[49] = {};
  State state = State::None;
  Point point;
  double distanceM = 0, lengthM = 0;
  float speed = 0, inputSpeed = 0, multiplier = 2;
  uint32_t passIndex = 1;
  uint32_t captureMs = 0;
  bool active() const { return state != State::None && state != State::Stopped; }
};
inline const char *stateName(State s) {
  switch(s) {
    case State::Running: return "running";
    case State::Paused: return "paused";
    case State::CanStale: return "can_stale";
    case State::Completed: return "completed";
    case State::Stopped: return "stopped";
    default: return "none";
  }
}
class Engine {
  Point route[MaxVertices];
  double cumulative[MaxVertices] = {};
  size_t vertices = 0, hazardCount_ = 0;
  Hazard hazards[MaxHazards];
  Snapshot snapshot_;
  uint32_t previousMs = 0;
  void locate() {
    size_t i = 1;
    while(i+1 < vertices && cumulative[i] < snapshot_.distanceM) ++i;
    const double segment = cumulative[i]-cumulative[i-1];
    double t = segment > 0 ? (snapshot_.distanceM-cumulative[i-1])/segment : 0;
    t = t < 0 ? 0 : t > 1 ? 1 : t;
    snapshot_.point = {route[i-1].lat+(route[i].lat-route[i-1].lat)*t,
                       route[i-1].lon+(route[i].lon-route[i-1].lon)*t};
  }
 public:
  const Snapshot &snapshot() const { return snapshot_; }
  size_t hazardCount() const { return hazardCount_; }
  const Hazard &hazard(size_t i) const { return hazards[i]; }
  static bool sessionValid(const char *id) {
    if(!id) return false;
    const size_t n = strlen(id);
    if(n < 1 || n > 48) return false;
    for(size_t i=0;i<n;i++) {
      const char c=id[i];
      if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'||c=='-')) return false;
    }
    return true;
  }
  const char *start(const char *session, const Point *points, size_t count, float multiplier, uint32_t now) {
    if(!sessionValid(session)) return "invalid_session_id";
    if(!strcmp(snapshot_.session,session)) return snapshot_.active() ? nullptr : "session_already_stopped";
    if(snapshot_.active()) return "direct_demo_already_active";
    if(!points || count<2 || count>MaxVertices || !isfinite(multiplier) || multiplier<.5f || multiplier>5) return "invalid_route_or_multiplier";
    double total=0;
    for(size_t i=0;i<count;i++) {
      if(!isfinite(points[i].lat)||!isfinite(points[i].lon)||fabs(points[i].lat)>85||fabs(points[i].lon)>180) return "invalid_coordinate";
      if(i) {
        const double step=distance(points[i-1],points[i]);
        if(step<.01 || fabs(points[i].lon-points[i-1].lon)>180) return "invalid_route_segment";
        total+=step;
      }
    }
    if(total<30||total>2000) return "route_length_out_of_range";
    snapshot_=Snapshot{};
    strcpy(snapshot_.session,session);
    snapshot_.state=State::CanStale;
    snapshot_.multiplier=multiplier;
    snapshot_.lengthM=total;
    snapshot_.point=points[0];
    vertices=count; hazardCount_=0; previousMs=now; snapshot_.captureMs=now;
    for(size_t i=0;i<count;i++) {
      route[i]=points[i]; cumulative[i]=i ? cumulative[i-1]+distance(points[i-1],points[i]) : 0;
    }
    return nullptr;
  }
  const char *control(const char *session, const char *operation, uint32_t now) {
    if(!session || !operation || !snapshot_.session[0] || strcmp(session,snapshot_.session)) return "session_mismatch";
    snapshot_.captureMs=now;
    if(!strcmp(operation,"stop")) {
      snapshot_.state=State::Stopped; snapshot_.speed=0; previousMs=now;
      for(size_t i=0;i<hazardCount_;i++) hazards[i].warningPending=false;
      return nullptr;
    }
    if(!snapshot_.active()) return "session_not_active";
    if(!strcmp(operation,"pause")) {
      if(snapshot_.state!=State::Completed) snapshot_.state=State::Paused;
    } else if(!strcmp(operation,"resume")) {
      if(snapshot_.state==State::Completed) return "route_completed_use_repeat";
      if(snapshot_.state==State::Paused) snapshot_.state=State::CanStale;
    } else if(!strcmp(operation,"repeat")) {
      if(snapshot_.state!=State::Paused && snapshot_.state!=State::Completed) return "pause_before_repeat";
      if(snapshot_.passIndex==UINT32_MAX) return "pass_counter_full";
      ++snapshot_.passIndex;
      snapshot_.distanceM=0; snapshot_.point=route[0]; snapshot_.state=State::CanStale;
      // This is a teleport, NEVER a driven segment through every warning zone.
      // Require a real observed outside position after the jump before rearm.
      for(size_t i=0;i<hazardCount_;i++) {
        hazards[i].armed=false; hazards[i].previousDistance=INFINITY; hazards[i].warningPending=false;
      }
    } else return "invalid_operation";
    snapshot_.speed=0; previousMs=now; return nullptr;
  }
  void step(uint32_t now, bool fresh, float input, float radius, float rearm) {
    uint32_t dt=now-previousMs; previousMs=now;
    if(!snapshot_.active()) return;
    snapshot_.captureMs=now;
    const bool usable=fresh && isfinite(input) && input>=0 && input<=180;
    snapshot_.inputSpeed=usable ? input : 0;
    snapshot_.speed=0;
    if(snapshot_.state==State::Paused || snapshot_.state==State::Completed) return;
    if(!usable) { snapshot_.state=State::CanStale; return; }
    snapshot_.state=State::Running;
    snapshot_.speed=input*snapshot_.multiplier;
    if(dt>250) dt=250; // No catch-up jump after a blocked loop or long pause.
    const Point previous=snapshot_.point;
    const double advance=snapshot_.speed/3.6*dt/1000.0;
    snapshot_.distanceM+=advance;
    if(snapshot_.distanceM>=snapshot_.lengthM) {
      snapshot_.distanceM=snapshot_.lengthM; snapshot_.state=State::Completed; snapshot_.speed=0;
    }
    locate();
    if(!isfinite(radius)||!isfinite(rearm)||radius<=0||rearm<=radius) return;
    for(size_t i=0;i<hazardCount_;i++) {
      Hazard &h=hazards[i];
      const float current=float(distance(snapshot_.point,h.point));
      if(!h.armed) {
        if(current>=rearm) h.armed=true;
      } else if(advance>0) {
        const float segment=float(segmentDistance(previous,snapshot_.point,h.point));
        if(navigation::geofenceShouldWarn(true,current,h.previousDistance,segment,true,radius,0.00001f)) {
          h.armed=false; h.warningPending=true; h.warningReported=false;
          h.warningAtMs=now; h.warningDistance=fminf(current,segment);
        }
      }
      h.previousDistance=current;
    }
  }
  int detect(uint8_t kind, float confidence, float duplicateRadius, bool &added) {
    return detectAt(kind, confidence, duplicateRadius, snapshot_, added);
  }
  int detectAt(uint8_t kind, float confidence, float duplicateRadius,
               const Snapshot &observed, bool &added) {
    added=false;
    if(!snapshot_.active() || (kind!=1&&kind!=2) || !isfinite(confidence)||confidence<0||confidence>1 ||
       !isfinite(duplicateRadius)||duplicateRadius<0 || !observed.active() ||
       strcmp(observed.session,snapshot_.session) || observed.passIndex!=snapshot_.passIndex ||
       !isfinite(observed.point.lat)||!isfinite(observed.point.lon) ||
       fabs(observed.point.lat)>85||fabs(observed.point.lon)>180) return -1;
    for(size_t i=0;i<hazardCount_;i++)
      if(hazards[i].kind==kind && distance(hazards[i].point,observed.point)<=duplicateRadius) return int(i);
    if(hazardCount_>=MaxHazards) return -1;
    Hazard &h=hazards[hazardCount_]; h=Hazard{};
    h.point=observed.point; h.kind=kind; h.confidence=confidence;
    h.previousDistance=float(distance(snapshot_.point,h.point));
    added=true; return int(hazardCount_++);
  }
  int takeWarning() {
    for(size_t i=0;i<hazardCount_;i++) if(hazards[i].warningPending) {
      hazards[i].warningPending=false; return int(i);
    }
    return -1;
  }
  int pendingWarning(size_t first=0) const {
    for(size_t i=first;i<hazardCount_;i++) if(hazards[i].warningPending) return int(i);
    return -1;
  }
  void reportWarning(size_t i) { if(i<hazardCount_) hazards[i].warningReported=true; }
  void dismissWarning(size_t i) { if(i<hazardCount_) hazards[i].warningPending=false; }
};
}
