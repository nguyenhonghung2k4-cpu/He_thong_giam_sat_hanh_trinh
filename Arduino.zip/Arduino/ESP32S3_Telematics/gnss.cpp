#include <TinyGPSPlus.h>
#include "config.h"
#include "gnss.h"
#include "gnss_position_filter.h"

static TinyGPSPlus gps;
static HardwareSerial gnssSerial(1);

static navigation::Config positionFilterConfig() {
  navigation::Config c;
  c.maxHdop = GNSS_MAX_HDOP;
  c.minSatellites = GNSS_MIN_SATELLITES;
  c.staleMs = GNSS_STALE_MS;
  c.stationarySpeedKph = GNSS_HOLD_SPEED_KPH;
  c.stationaryRadiusM = GNSS_HOLD_RADIUS_M;
  c.stationaryMs = GNSS_HOLD_CONFIRM_MS;
  c.resumeSpeedKph = GNSS_RESUME_SPEED_KPH;
  c.displacementUnlockM = GNSS_SLOW_MOVE_UNLOCK_M;
  return c;
}
static navigation::PositionFilter positionFilter(positionFilterConfig());

// Howard Hinnant civil-calendar conversion, adapted to small embedded use.
// Returns days since 1970-01-01 for a Gregorian date.
static int64_t daysFromCivil(int year, unsigned month, unsigned day) {
  year -= month <= 2;
  const int era = (year >= 0 ? year : year - 399) / 400;
  const unsigned yoe = static_cast<unsigned>(year - era * 400);
  const unsigned doy = (153 * (month + (month > 2 ? -3 : 9)) + 2) / 5 + day - 1;
  const unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
  return static_cast<int64_t>(era) * 146097 + static_cast<int64_t>(doe) - 719468;
}

static uint32_t gpsEpochUtc() {
  if (!gps.date.isValid() || !gps.time.isValid()) return 0;
  const int y = gps.date.year();
  const unsigned mo = gps.date.month(), d = gps.date.day();
  if (y < 1970 || mo < 1 || mo > 12 || d < 1 || d > 31) return 0;
  const int64_t days = daysFromCivil(y, mo, d);
  const int64_t seconds = days * 86400LL + gps.time.hour() * 3600LL +
                          gps.time.minute() * 60LL + gps.time.second();
  if (seconds <= 0 || seconds > 0xFFFFFFFFLL) return 0;
  return static_cast<uint32_t>(seconds);
}

bool gnssBegin() {
  gnssSerial.begin(GNSS_BAUD, SERIAL_8N1, PIN_GNSS_RX, PIN_GNSS_TX);
  return true;
}

void gnssPoll(GnssData &d) {
  d.locationUpdated = false;
  while (gnssSerial.available()) gps.encode(gnssSerial.read());

  const bool newLocation = gps.location.isUpdated();
  d.rawValid = gps.location.isValid() && gps.location.age() <= GNSS_STALE_MS;
  if (d.rawValid) {
    d.rawLat = gps.location.lat();
    d.rawLon = gps.location.lng();
    if (newLocation) { d.locationUpdated = true; d.fixSequence++; }
  } else {
    d.rawLat = d.rawLon = NAN;
  }

  if (gps.speed.isValid() && gps.speed.age() <= GNSS_STALE_MS) d.rawSpeedKph = gps.speed.kmph(); else d.rawSpeedKph = NAN;
  if (gps.satellites.isValid() && gps.satellites.age() <= GNSS_STALE_MS) d.satellites = gps.satellites.value(); else d.satellites = 0;
  if (gps.hdop.isValid() && gps.hdop.age() <= GNSS_STALE_MS) d.hdop = gps.hdop.hdop(); else d.hdop = 99.9f;
  if (gps.altitude.isValid() && gps.altitude.age() <= GNSS_STALE_MS) d.altitudeM = gps.altitude.meters(); else d.altitudeM = NAN;
  if (gps.course.isValid() && gps.course.age() <= GNSS_STALE_MS) d.courseDeg = gps.course.deg(); else d.courseDeg = NAN;

  navigation::Fix fix;
  fix.lat = d.rawLat; fix.lon = d.rawLon;
  fix.speedKph = d.rawSpeedKph; fix.hdop = d.hdop;
  fix.satellites = d.satellites; fix.nowMs = millis();
  fix.sequence = d.fixSequence; fix.valid = d.rawValid;
  // Called even without a new fix: a held point must expire when GPS stops.
  const navigation::Output &position = positionFilter.update(fix);
  d.valid = position.valid;
  d.lat = position.lat; d.lon = position.lon;
  d.speedKph = position.valid ? position.speedKph : NAN;
  d.filterStationary = position.stationary;
  d.filterSegmentValid = position.segmentValid;
  d.filterState = position.state;
  d.positionEpoch = position.epoch;
  d.rejectedFixes = position.rejected;

  d.timeValid = gps.date.isValid() && gps.time.isValid() && gps.time.age() <= GNSS_STALE_MS;
  if (d.timeValid) {
    char s[25];
    snprintf(s, sizeof(s), "%04d-%02d-%02dT%02d:%02d:%02dZ",
             gps.date.year(), gps.date.month(), gps.date.day(),
             gps.time.hour(), gps.time.minute(), gps.time.second());
    d.utc = s;
    d.epoch = gpsEpochUtc();
  } else {
    d.epoch = 0;
  }
}
