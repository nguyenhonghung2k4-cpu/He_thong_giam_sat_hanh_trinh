#ifndef ESP32S3_TELEMATICS_TYPES_H
#define ESP32S3_TELEMATICS_TYPES_H
#pragma once
#include <Arduino.h>

struct EcuData {
  bool online = false;
  uint32_t lastHeartbeatMs = 0, uptimeSec = 0;
  uint32_t lastCanFrameMs = 0, lastRuntimeMs = 0, lastTemperatureMs = 0, rxFrameCount = 0;
  uint16_t adcRaw = 0, rpm = 0, dtcCode = 0;
  float vehicleSpeedKph = NAN;
  float temperatureC = NAN;
  uint8_t nodeId = 0, fwMajor = 0, fwMinor = 0;
  uint8_t status = 0, runtimeSequence = 0, runtimeContract = 0;
  uint8_t temperatureState = 3, dtcSeverity = 0;
  bool temperatureValid = false, dtcActive = false;
  bool vehicleSpeedValid = false, rpmValid = false, overspeed = false;
};

struct GnssData {
  bool valid = false, timeValid = false;
  bool locationUpdated = false;
  double lat = 0, lon = 0;
  float speedKph = NAN, hdop = 99.9f;
  float altitudeM = NAN, courseDeg = NAN;
  uint32_t satellites = 0;
  uint32_t fixSequence = 0;
  // Raw observations remain available for diagnostics; lat/lon above are filtered.
  bool rawValid = false, filterStationary = false, filterSegmentValid = false;
  double rawLat = NAN, rawLon = NAN;
  float rawSpeedKph = NAN;
  uint32_t positionEpoch = 0, rejectedFixes = 0;
  const char *filterState = "acquiring";
  String utc;
  uint32_t epoch = 0;  // UTC Unix time when GNSS date/time is valid.
};

struct AiData {
  String label = "unknown";
  bool valid = false;
  float confidence = 0;
  float x = 0, y = 0, z = 0;
  uint32_t inferenceMs = 0;
  uint32_t lastUpdateMs = 0;
  float flatConfidence = 0, speedBumpConfidence = 0, potholeConfidence = 0;
};

struct HazardPoint {
  double lat = 0, lon = 0;
  uint32_t seen = 0;       // millis() retained for backward compatibility/debug.
  float confidence = 0;
  uint32_t epoch = 0;      // UTC Unix time at detection; 0 for legacy/undated rows.
};
using PotholePoint = HazardPoint;  // Compatibility with older sketch helpers.

// The resend queue distinguishes a temporary transport failure from a payload
// that the server has permanently rejected. This prevents one bad record from
// blocking every newer black-box record behind it.
enum class SendResult : uint8_t { Accepted, Retry, Discard };

#endif  // ESP32S3_TELEMATICS_TYPES_H
