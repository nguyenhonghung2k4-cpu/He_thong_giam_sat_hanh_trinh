#pragma once

// Keep this header self-contained when it is copied to config.h. Some .cpp
// files include the configuration before Arduino.h.
#include <stdint.h>
#include <stddef.h>

// ===== User configuration =====
#define WIFI_SSID       "YOUR_WIFI_SSID"
#define WIFI_PASSWORD   "YOUR_WIFI_PASSWORD"
#define SERVER_URL      "http://DIA_CHI_IP_MAY_TINH:3000"
#define DEVICE_ID       "blackbox-esp32s3-01"
#define HTTP_API_KEY    "KHOA_API_TRUNG_VOI_SERVER"
#define SITES_BYPASS_TOKEN ""
#define TLS_ALLOW_INSECURE  0
#define TLS_ROOT_CA         ""
// The router is close to the prototype. Limiting TX power reduces the RF peak
// current that previously coincided with SanDisk SDHC write allocation.
#define WIFI_TX_POWER_LEVEL WIFI_POWER_8_5dBm

#define FIRMWARE_VERSION "11.6.1-MARKER-FIFO-FIX"
#define MODEL_VERSION    "telematics-ei-1.0.1"

// Hardware fixed by the project
constexpr int PIN_CAN_TX = 17, PIN_CAN_RX = 18;
constexpr int PIN_GNSS_RX = 16, PIN_GNSS_TX = 15;
constexpr int PIN_SPI_SCK = 12, PIN_SPI_MOSI = 11, PIN_SPI_MISO = 13;
// ADXL345 has its own I2C bus; MicroSD is the only SPI peripheral.
// Wire ADXL CS directly to 3.3 V and SDO directly to GND (address 0x53).
constexpr int PIN_ADXL_SDA = 8, PIN_ADXL_SCL = 2;
constexpr int PIN_ADXL_INT = 14, PIN_SD_CS = 10;
constexpr uint8_t ADXL345_I2C_ADDRESS = 0x53;
constexpr uint32_t ADXL345_I2C_FREQUENCY_HZ = 400000;
constexpr uint16_t ADXL345_I2C_TIMEOUT_MS = 25;
constexpr int PIN_I2S_BCLK = 4;
constexpr int PIN_I2S_LRC = 5;
constexpr int PIN_I2S_DIN = 6;
// GPIO7 controls MAX98357A SD/EN (also named SD_MODE), NOT its GAIN pin.
// GAIN is a hardware strap: floating=9 dB, direct GND=12 dB, 100 kOhm to
// GND=15 dB. Pulling SD/EN to GND shuts the amplifier down completely.
constexpr int PIN_MAX98357_SD_EN = 7;
static_assert(PIN_I2S_BCLK != PIN_I2S_LRC && PIN_I2S_BCLK != PIN_I2S_DIN &&
              PIN_I2S_BCLK != PIN_MAX98357_SD_EN && PIN_I2S_LRC != PIN_I2S_DIN &&
              PIN_I2S_LRC != PIN_MAX98357_SD_EN && PIN_I2S_DIN != PIN_MAX98357_SD_EN,
              "MAX98357A BCLK/LRC/DIN/SD-EN pins must be unique");

constexpr uint32_t CAN_BITRATE = 500000;
// u-blox M10 baud rate already verified in this project with u-center/Serial.
constexpr uint32_t GNSS_BAUD = 38400;
constexpr uint32_t ECU_OFFLINE_MS = 3000;
constexpr uint32_t ECU_BOOT_GRACE_MS = 10000;
constexpr uint32_t ECU_RUNTIME_STALE_MS = 1500;
constexpr uint32_t ECU_TEMPERATURE_STALE_MS = 3000;
constexpr float VEHICLE_SPEED_MAX_KPH = 180.0f;
constexpr float OVERSPEED_WARNING_KPH = 120.0f;
constexpr float OVERSPEED_CLEAR_KPH = 115.0f;
constexpr uint8_t OVERSPEED_CONFIRM_FRAMES = 3;
constexpr uint8_t SPEED_READY_FRAMES = 5;

// 100% PCM amplitude requested by the user. Requires a stable, separately
// branched amplifier supply; software cannot prevent a physical rail collapse.
constexpr uint8_t AUDIO_PCM_GAIN_PERCENT = 100;
constexpr uint16_t AUDIO_FADE_MS = 20;
constexpr uint16_t AUDIO_PRE_PLAY_QUIET_MS = 150;
constexpr uint16_t AUDIO_AMP_SETTLE_MS = 40;
constexpr uint16_t AUDIO_POST_SILENCE_MS = 80;
constexpr uint32_t AUDIO_ALERT_MAX_AGE_MS = 12000;
constexpr uint16_t AUDIO_RETRY_GAP_MS = 200;
static_assert(AUDIO_PCM_GAIN_PERCENT > 0 && AUDIO_PCM_GAIN_PERCENT <= 100, "PCM gain must be 1..100 percent");
// Covers the 2.5-s post-remount settle window so a real hazard voice normally
// waits for SD safety instead of being dropped or colliding with recovery.
constexpr uint16_t AUDIO_SD_QUIESCE_TIMEOUT_MS = 4000;
constexpr uint16_t AUDIO_HTTP_QUIESCE_TIMEOUT_MS = 1400;
constexpr uint16_t SD_POST_AUDIO_QUIET_MS = 1500;
constexpr uint16_t SD_POST_AUDIO_VERIFY_GAP_MS = 350;
// Bounded allowance for the 1500-ms quiet window and read-only verification
// attempts. HTTP stays gated for the complete SD recovery window.
constexpr uint16_t AUDIO_POST_RECOVERY_WAIT_MS = 6000;
// Prevent CAN/AI startup transients from powering the amplifier while the SD
// card and the prototype supply rail are still settling.
constexpr uint32_t AUDIO_BOOT_INHIBIT_MS = 12000;
// Set true only while diagnosing the speaker. It queues the embedded pothole
// voice once after all subsystems finish setup; it does not create a map event.
constexpr bool AUDIO_BOOT_SELF_TEST = false;
constexpr uint8_t GNSS_STABLE_FIX_COUNT = 3;
constexpr float GNSS_STARTUP_MAX_STEP_M = 80.0f;
constexpr uint32_t GNSS_STARTUP_FIX_MAX_GAP_MS = 2500;
constexpr uint32_t GNSS_STALE_MS = 3000;
constexpr float GNSS_MAX_HDOP = 3.0f;
constexpr uint8_t GNSS_MIN_SATELLITES = 4;
// GNSS motion is independent of the ECU's simulated potentiometer speed.
constexpr float GNSS_HOLD_SPEED_KPH = 1.5f;
constexpr float GNSS_HOLD_RADIUS_M = 3.0f;
constexpr uint32_t GNSS_HOLD_CONFIRM_MS = 5000;
constexpr float GNSS_RESUME_SPEED_KPH = 2.5f;
constexpr float GNSS_SLOW_MOVE_UNLOCK_M = 6.0f;
constexpr uint32_t AI_STARTUP_GRACE_MS = 2500;
constexpr uint8_t AI_READY_INFERENCES = 2;
constexpr uint8_t AI_HAZARD_CONFIRM_WINDOWS = 2;
// Strong single-window admission still obeys the configured class threshold.
constexpr float AI_HAZARD_STRONG_SCORE = 0.95f;
constexpr uint32_t TELEMETRY_PERIOD_MS = 1000;
// Display-only 5 Hz lane, direct demo + local HTTP only; no extra SD logs.
constexpr bool DIRECT_REALTIME_ENABLED = true;
// Keep SD quiet; allow compact Wi-Fi packets after amp/DMA quiet startup.
// Requires a stable supply. Set false if diagnosing an electrical rail fault.
constexpr bool DIRECT_REALTIME_DURING_AUDIO = true;
constexpr uint32_t HTTP_CONNECT_TIMEOUT_MS = 450;
constexpr uint32_t HTTP_RESPONSE_TIMEOUT_MS = 1200;
constexpr uint32_t HTTP_POWER_ARBITER_TIMEOUT_MS = 350;
constexpr uint32_t POWER_CLIENT_SWITCH_GAP_MS = 60;
constexpr uint32_t WEB_BACKOFF_BASE_MS = 1500;
constexpr uint32_t WEB_BACKOFF_MAX_MS = 15000;
constexpr uint32_t OFFLINE_TELEMETRY_SPOOL_MS = 2000;
constexpr uint32_t INFERENCE_PERIOD_MS = 500;
// V6: ESP32 polls the localhost server for SD-management commands.
constexpr uint32_t DEVICE_COMMAND_POLL_MS = 3000;
// Daily log filenames use local civil date. Vietnam = UTC+7.
constexpr int LOG_TIMEZONE_OFFSET_MINUTES = 420;
// 128 x 16 MiB = 2 GiB per local date/"undated" base. Reaching this
// application quota is reported separately and never unmounts the card.
constexpr uint16_t MAX_DAILY_LOG_SEGMENTS = 128;
constexpr uint16_t SD_LOG_LIST_MAX_FILES = 160;
constexpr uint8_t SD_LOG_VIEW_MAX_LINES = 12;
// V8: export SD logs to the PC project folder in bounded SD/SPI slices.
constexpr size_t SD_EXPORT_READ_SLICE_BYTES = 1024;
constexpr size_t SD_EXPORT_HTTP_BATCH_BYTES = 16384;
constexpr uint32_t SD_SPI_FREQUENCY_HZ = 1000000;
constexpr uint32_t SD_SPI_FALLBACK_FREQUENCY_HZ = 1000000;
// Cold boot now starts at the conservative clock only after the card supply,
// socket contacts and MAX98357A shutdown pin have had time to settle.
constexpr uint32_t SD_BOOT_POWER_SETTLE_MS = 1500;
constexpr uint8_t SD_BOOT_VERIFY_PASSES = 2;
constexpr uint32_t SD_BOOT_VERIFY_PERIOD_MS = 250;
// A single temporary create/read/delete failure must not reject the card at
// boot. Each retry fully resets and remounts the SD SPI bus first.
constexpr uint8_t SD_WRITE_PROBE_ATTEMPTS = 3;
constexpr uint32_t SD_WRITE_PROBE_RETRY_MS = 250;
constexpr uint8_t SD_POST_AUDIO_VERIFY_ATTEMPTS = 3;
constexpr uint32_t SD_POST_AUDIO_VERIFY_RETRY_MS = 750;
constexpr uint32_t SD_CARD_CHECK_PERIOD_MS = 5000;
constexpr uint32_t SD_INSERT_SETTLE_MS = 1000;
constexpr uint32_t SD_REMOUNT_VERIFY_PERIOD_MS = 350;
constexpr uint8_t SD_REMOUNT_VERIFY_PASSES = 2;
constexpr uint32_t SD_RETRY_INITIAL_MS = 2000;
constexpr uint32_t SD_RETRY_MAX_MS = 30000;
constexpr uint32_t SD_POST_REMOUNT_QUIET_MS = 2500;
constexpr uint32_t SD_WORKER_WRITE_GAP_MS = 120;
constexpr uint32_t SD_WORKER_FAILURE_GAP_MS = 750;
constexpr uint32_t SD_SPACE_REFRESH_MS = 30000;
// Stop non-critical daily/offline telemetry while 4 MiB remains, but reserve a
// smaller emergency tail for critical hazard/event records and cursor metadata.
// Neither threshold formats, deletes, or unmounts the card.
constexpr uint64_t SD_MIN_FREE_BYTES = 4ULL * 1024ULL * 1024ULL;
constexpr uint64_t SD_CRITICAL_FREE_BYTES = 512ULL * 1024ULL;
static_assert(SD_CRITICAL_FREE_BYTES < SD_MIN_FREE_BYTES,
              "Critical SD reserve must be smaller than the telemetry reserve");
constexpr uint32_t SD_CAPACITY_WARNING_PERIOD_MS = 10000;
constexpr uint32_t SD_RETRY_PERIOD_MS = SD_RETRY_INITIAL_MS;
constexpr uint8_t SD_IO_FAILURES_BEFORE_REMOUNT = 3;
constexpr uint8_t SD_CARD_MISSING_CONFIRMATIONS = 3;
// Keep Serial Monitor readable. Set true only when raw API JSON is needed.
constexpr bool SERIAL_PRINT_RAW_JSON = false;
constexpr uint32_t SERIAL_STATUS_PERIOD_MS = 2000;
constexpr float POTHOLE_MIN_CONFIDENCE = 0.80f;
constexpr float SPEED_BUMP_MIN_CONFIDENCE = 0.80f;
constexpr float EVENT_DUPLICATE_RADIUS_M = 8.0f;
// One voice prompt per approach: enter <=10 m, re-arm only after leaving >=20 m.
constexpr float GEOFENCE_WARNING_RADIUS_M = 10.0f;
constexpr float GEOFENCE_REARM_RADIUS_M = 20.0f;
constexpr float GEOFENCE_APPROACH_EPSILON_M = 0.5f;
constexpr uint32_t GEOFENCE_MAX_SEGMENT_GAP_MS = 3000;
constexpr float GEOFENCE_MAX_SEGMENT_LENGTH_M = 150.0f;
constexpr size_t MAX_POTHOLES = 100;
constexpr size_t MAX_SPEED_BUMPS = 100;
constexpr size_t UPLOAD_QUEUE_LENGTH = 24;
constexpr size_t LOG_QUEUE_LENGTH = 24;
constexpr size_t SD_OFFLINE_WRITE_QUEUE_LENGTH = 24;
constexpr size_t SD_EVENT_WRITE_QUEUE_LENGTH = 16;
constexpr size_t RESEND_BATCH_SIZE = 2;
constexpr size_t MAX_LOG_BYTES = 16 * 1024 * 1024;
constexpr size_t MAX_QUEUE_BYTES = 8 * 1024 * 1024;
constexpr size_t MAX_REJECTED_BYTES = 512 * 1024;
constexpr size_t MAX_EVENT_QUEUE_BYTES = 32 * 1024 * 1024;

// V6 daily telemetry archive. Each date can have multiple 16 MB segments.
constexpr char SD_LOG_DIR[] = "/logs";
constexpr char SD_UNDATED_LOG_BASE[] = "undated";
// Legacy V5 files are kept readable and are deleted only by "delete all logs".
constexpr char SD_LEGACY_LOG_PATH[] = "/telemetry.ndjson";
constexpr char SD_LEGACY_LOG_OLD_PATH[] = "/telemetry.old.ndjson";
constexpr char SD_EVENT_QUEUE_PATH[] = "/events.pending.ndjson";
constexpr char SD_EVENT_CURSOR_PATH[] = "/events.pending.cursor";
constexpr char SD_EVENT_CURSOR_TMP_PATH[] = "/events.pending.cursor.tmp";
constexpr char SD_QUEUE_PATH[] = "/pending.ndjson";
constexpr char SD_QUEUE_NEXT_PATH[] = "/pending.next.ndjson";
constexpr char SD_QUEUE_TMP_PATH[] = "/pending.tmp";
constexpr char SD_QUEUE_BACKUP_PATH[] = "/pending.bak";
constexpr char SD_QUEUE_CURSOR_PATH[] = "/pending.cursor";
constexpr char SD_QUEUE_CURSOR_TMP_PATH[] = "/pending.cursor.tmp";
constexpr char SD_REJECTED_PATH[] = "/rejected.log";
constexpr char SD_REJECTED_OLD_PATH[] = "/rejected.old.log";
constexpr char SD_POTHOLE_PATH[] = "/potholes.csv";
constexpr char SD_SPEED_BUMP_PATH[] = "/speed_bumps.csv";
