#pragma once
#include <stddef.h>
#include <stdint.h>

// Absolute frame envelope. A chunk boundary must not restart a fade. Zero
// frames and out-of-range positions are silent rather than unsigned-wrap loud.
constexpr uint32_t audioEnvelopeQ15(size_t frame, size_t totalFrames, size_t fadeFrames) {
  if (totalFrames == 0 || frame >= totalFrames) return 0;
  if (fadeFrames == 0) return 32768;
  const size_t endDistance = totalFrames - 1 - frame;
  const size_t edgeDistance = frame < endDistance ? frame : endDistance;
  return edgeDistance >= fadeFrames ? 32768 :
         uint32_t((uint64_t(edgeDistance) * 32768U) / fadeFrames);
}

constexpr int16_t audioScalePcm16(int16_t sample, uint8_t gainPercent, uint32_t envelopeQ15) {
  // Divide the percent gain BEFORE multiplying by Q15. At 100% the largest
  // intermediate magnitude is 32768 * 32768 = 1073741824, safe for int32_t.
  const int32_t gainAdjusted = (int32_t(sample) * gainPercent) / 100;
  return int16_t((gainAdjusted * int32_t(envelopeQ15)) / 32768);
}

// These are checked by the actual Arduino C++ compiler, with no runtime cost.
static_assert(audioEnvelopeQ15(0, 16000, 320) == 0, "fade must start at silence");
static_assert(audioEnvelopeQ15(15999, 16000, 320) == 0, "fade must end at silence");
static_assert(audioEnvelopeQ15(160, 16000, 320) == 16384, "half fade-in");
static_assert(audioEnvelopeQ15(15839, 16000, 320) == 16384, "half fade-out");
static_assert(audioEnvelopeQ15(320, 16000, 320) == 32768, "unity after fade");
static_assert(audioEnvelopeQ15(511, 16000, 320) == audioEnvelopeQ15(512, 16000, 320),
              "chunk boundary must not reset envelope");
static_assert(audioEnvelopeQ15(0, 0, 320) == 0, "empty clip stays silent");
static_assert(audioScalePcm16(-32768, 100, 32768) == -32768, "100% negative peak safe");
static_assert(audioScalePcm16(32767, 100, 32768) == 32767, "100% positive peak safe");
static_assert(audioScalePcm16(-32768, 100, 16384) == -16384, "100% half fade safe");
static_assert(audioScalePcm16(32767, 100, 0) == 0, "first sample silent even at 100%");
static_assert(audioScalePcm16(-32768, 25, 32768) == -8192, "lower gain supported");
