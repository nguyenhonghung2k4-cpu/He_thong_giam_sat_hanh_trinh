#include <Arduino.h>
#include <driver/twai.h>
#include <esp_err.h>
#include "config.h"
#include "can_bus.h"

static uint16_t u16le(const uint8_t *d) { return uint16_t(d[0]) | (uint16_t(d[1]) << 8); }
static uint32_t u32le(const uint8_t *d) { return uint32_t(d[0]) | (uint32_t(d[1])<<8) | (uint32_t(d[2])<<16) | (uint32_t(d[3])<<24); }
static constexpr uint32_t CAN_INIT_RETRY_MS=2000, CAN_RECOVERY_RETRY_MS=1000;
static constexpr uint32_t CAN_SERVICE_STALE_MS=1000, CAN_PASSIVE_STALL_MS=3000;
static constexpr uint32_t CAN_PASSIVE_RESTART_COOLDOWN_MS=15000;
static TaskHandle_t canWorkerHandle=nullptr;
static portMUX_TYPE canSnapshotMux=portMUX_INITIALIZER_UNLOCKED;
// Only the CAN worker (or the foreground fallback if task allocation fails)
// owns the TWAI driver and decoder. Readers copy a plain-data snapshot.
static EcuData workerEcu, publishedEcu;
static CanDiagnostics workerDiagnostics, publishedDiagnostics;
static bool beginCalled=false;
static uint32_t lastInitAttempt=0,lastRecoveryAttempt=0,lastStatusPoll=0;
static bool recoveryPending=false;
static bool serviceClockStarted=false, passiveObserved=false, passiveRestartPending=false;
static bool passiveRestartAttempted=false;
static bool queueFlushRequired=false;
static uint32_t lastServiceCompleted=0, passiveSince=0, runningSince=0, lastPassiveRestart=0;
enum class RuntimeLayout : uint8_t { LegacyAdcRpm=1, SpeedX100Adc=2 };
// The current project uses the potentiometer as vehicle speed.  Start with the
// current layout so a zero-position potentiometer is still decoded correctly.
// Three unambiguous legacy frames are required before falling back to v1.
static RuntimeLayout runtimeLayout=RuntimeLayout::SpeedX100Adc;
static uint8_t legacyEvidence=0,speedEvidence=0;
static uint8_t speedValidFrames=0;
static_assert(CAN_BITRATE==500000,"This firmware's TWAI timing preset is 500 kbit/s");

static uint16_t speedFromAdc(uint16_t adc) {
  return uint16_t((uint32_t(adc)*18000UL)/4095UL);
}

static uint16_t legacyRpmFromAdc(uint16_t adc) {
  return uint16_t((uint32_t(adc)*8000UL)/4095UL);
}

static bool nearU16(uint16_t a,uint16_t b,uint16_t tolerance=3) {
  return a>b ? (a-b)<=tolerance : (b-a)<=tolerance;
}

static void decodeRuntimeFrame(const twai_message_t &m,EcuData &e) {
  const uint16_t first=u16le(m.data),second=u16le(m.data+2);
  const bool markedV2=m.data_length_code>=8&&m.data[6]==0x53&&m.data[7]==0x02;
  const bool looksV2=first<=18000&&second<=4095&&nearU16(first,speedFromAdc(second),5);
  const bool looksLegacy=first<=4095&&second<=8000&&nearU16(second,legacyRpmFromAdc(first),5);

  if(markedV2){runtimeLayout=RuntimeLayout::SpeedX100Adc;speedEvidence=3;legacyEvidence=0;}
  else if(looksV2&&!looksLegacy){if(speedEvidence<3)speedEvidence++;legacyEvidence=0;if(speedEvidence>=3)runtimeLayout=RuntimeLayout::SpeedX100Adc;}
  else if(looksLegacy&&!looksV2){if(legacyEvidence<3)legacyEvidence++;speedEvidence=0;if(legacyEvidence>=3)runtimeLayout=RuntimeLayout::LegacyAdcRpm;}

  e.status=m.data[4];e.runtimeSequence=m.data[5];
  if(runtimeLayout==RuntimeLayout::SpeedX100Adc){
    e.runtimeContract=2;e.adcRaw=second;e.vehicleSpeedKph=first/100.0f;
    const bool coherent=first<=18000&&second<=4095&&(markedV2||looksV2);
    if(coherent){ if(speedValidFrames<255)++speedValidFrames; } else speedValidFrames=0;
    const bool nodeReady=(e.status&(1U<<5))!=0;
    e.vehicleSpeedValid=coherent&&(nodeReady||speedValidFrames>=SPEED_READY_FRAMES);
    e.rpm=0;e.rpmValid=false;
    e.overspeed=e.vehicleSpeedValid&&(((e.status&(1U<<4))!=0)||e.vehicleSpeedKph>OVERSPEED_WARNING_KPH);
  }else{
    e.runtimeContract=1;e.adcRaw=first;e.rpm=second;e.rpmValid=true;
    e.vehicleSpeedKph=NAN;e.vehicleSpeedValid=false;e.overspeed=false;
  }
}

// Queued frames have no reception timestamp. After a prolonged task stall or a
// driver restart, discard old measurements and require a newly received HB.
// Keep cumulative frame counts for diagnosis instead of presenting a reset as
// successful ECU communication.
static void invalidateEcu() {
  const uint32_t lifetimeFrames=workerEcu.rxFrameCount;
  workerEcu=EcuData();workerEcu.rxFrameCount=lifetimeFrames;
  speedValidFrames=legacyEvidence=speedEvidence=0;
  runtimeLayout=RuntimeLayout::SpeedX100Adc;
}

static void markDriverStarted(uint32_t now) {
  workerDiagnostics.state=TWAI_STATE_RUNNING;
  workerDiagnostics.rxPending=0;
  runningSince=now;passiveObserved=false;
  invalidateEcu();
}

static void publishCanSnapshot() {
  portENTER_CRITICAL(&canSnapshotMux);
  publishedEcu=workerEcu;
  publishedDiagnostics=workerDiagnostics;
  portEXIT_CRITICAL(&canSnapshotMux);
}

static void completeCanService() {
  lastServiceCompleted=millis();serviceClockStarted=true;
  workerDiagnostics.lastServiceMs=lastServiceCompleted;
  workerDiagnostics.serviceSeen=true;++workerDiagnostics.serviceCycles;
  publishCanSnapshot();
}

static bool installCanDriver() {
  lastInitAttempt=millis();
  ++workerDiagnostics.initAttempts;
  twai_general_config_t g = TWAI_GENERAL_CONFIG_DEFAULT((gpio_num_t)PIN_CAN_TX, (gpio_num_t)PIN_CAN_RX, TWAI_MODE_NORMAL);
  g.rx_queue_len = 64;
  g.tx_queue_len = 0; // Receiver still ACKs valid CAN frames in NORMAL mode.
  g.alerts_enabled=TWAI_ALERT_BUS_OFF|TWAI_ALERT_BUS_RECOVERED|TWAI_ALERT_RX_QUEUE_FULL|TWAI_ALERT_BUS_ERROR|TWAI_ALERT_ERR_PASS;
  twai_timing_config_t t = TWAI_TIMING_CONFIG_500KBITS();
  // Count all bus traffic for diagnosis, then accept only standard data frames
  // 0x100..0x103 in the decoder. Wrong IDs must be distinguishable from no RX.
  const twai_filter_config_t f=TWAI_FILTER_CONFIG_ACCEPT_ALL();
  esp_err_t err=twai_driver_install(&g,&t,&f);
  workerDiagnostics.lastError=err;
  if(err!=ESP_OK)return false;
  workerDiagnostics.installed=true;
  workerDiagnostics.state=TWAI_STATE_STOPPED;
  lastRecoveryAttempt=millis();
  err=twai_start();workerDiagnostics.lastError=err;
  if(err!=ESP_OK){
    // Keep our installed driver and retry start by querying its actual state.
    return false;
  }
  markDriverStarted(millis());
  return true;
}

static void refreshValidity(EcuData &e,uint32_t now) {
  e.online=e.lastHeartbeatMs&&(now-e.lastHeartbeatMs<=ECU_OFFLINE_MS);
  if(!e.online||!e.lastRuntimeMs||now-e.lastRuntimeMs>ECU_RUNTIME_STALE_MS){
    e.vehicleSpeedValid=false;e.rpmValid=false;e.overspeed=false;
  }
  if(!e.online||!e.lastTemperatureMs||now-e.lastTemperatureMs>ECU_TEMPERATURE_STALE_MS){
    e.temperatureValid=false;e.temperatureC=NAN;
  }
}

static void serviceCanDriver() {
  const uint32_t now=millis();
  if(!workerDiagnostics.installed){
    if(now-lastInitAttempt>=CAN_INIT_RETRY_MS)installCanDriver();
    refreshValidity(workerEcu,now);completeCanService();return;
  }
  // USB CDC/Serial is deliberately NEVER used by the service/decoder: a full
  // USB TX buffer must not stall the sole CAN owner. Logging is foreground only.
  uint32_t alerts=0;
  const esp_err_t alertResult=twai_read_alerts(&alerts,0);
  if(alertResult!=ESP_OK&&alertResult!=ESP_ERR_TIMEOUT){
    workerDiagnostics.lastError=alertResult;++workerDiagnostics.statusErrors;
  }
  bool freshStatus=false;
  // Alerts are coalesced bits, not a reliable state machine or event counter.
  // Query status periodically even if BUS_OFF/BUS_RECOVERED was missed.
  if((alerts&(TWAI_ALERT_BUS_OFF|TWAI_ALERT_BUS_RECOVERED))||now-lastStatusPoll>=250){
    lastStatusPoll=now;
    twai_status_info_t status{};
    const esp_err_t err=twai_get_status_info(&status);
    if(err==ESP_OK){
      freshStatus=true;
      workerDiagnostics.state=status.state;
      workerDiagnostics.rxPending=status.msgs_to_rx;
      workerDiagnostics.rxMissed=status.rx_missed_count;
      workerDiagnostics.rxOverrun=status.rx_overrun_count;
      workerDiagnostics.txErrorCounter=status.tx_error_counter;
      workerDiagnostics.rxErrorCounter=status.rx_error_counter;
      workerDiagnostics.busErrors=status.bus_error_count;
      if(status.state!=TWAI_STATE_RUNNING){invalidateEcu();passiveObserved=false;}
      if(status.state==TWAI_STATE_BUS_OFF&&now-lastRecoveryAttempt>=CAN_RECOVERY_RETRY_MS){
        lastRecoveryAttempt=now;++workerDiagnostics.recoveryAttempts;
        workerDiagnostics.lastError=twai_initiate_recovery();
        if(workerDiagnostics.lastError==ESP_OK){
          recoveryPending=true;workerDiagnostics.state=TWAI_STATE_RECOVERING;
        }
      }else if(status.state==TWAI_STATE_STOPPED&&now-lastRecoveryAttempt>=CAN_RECOVERY_RETRY_MS){
        lastRecoveryAttempt=now;++workerDiagnostics.recoveryAttempts;
        workerDiagnostics.lastError=twai_start();
        if(workerDiagnostics.lastError==ESP_OK){
          if(recoveryPending)++workerDiagnostics.recoveryStarts;
          if(passiveRestartPending)++workerDiagnostics.passiveRestarts;
          recoveryPending=passiveRestartPending=false;markDriverStarted(now);
          freshStatus=false; // The old STOPPED snapshot is no longer current.
        }
      }
    }else {workerDiagnostics.lastError=err;++workerDiagnostics.statusErrors;}
  }
  // A suspended/fallback task can leave old frames in the driver's RX queue.
  // They must not be time-stamped "now" and make an old speed/heartbeat fresh.
  if(serviceClockStarted&&now-lastServiceCompleted>CAN_SERVICE_STALE_MS)queueFlushRequired=true;
  if(queueFlushRequired){
    invalidateEcu();
    const esp_err_t err=twai_clear_receive_queue();workerDiagnostics.lastError=err;
    if(err==ESP_OK){queueFlushRequired=false;++workerDiagnostics.queueFlushes;workerDiagnostics.rxPending=0;}
    else {++workerDiagnostics.receiveErrors;completeCanService();return;}
  }
  EcuData &e=workerEcu;
  twai_message_t m{};
  // Do not decode queued pre-recovery data while STOPPED/RECOVERING/BUS_OFF.
  for(uint8_t processed=0;workerDiagnostics.state==TWAI_STATE_RUNNING&&processed<64;processed++){
    const esp_err_t err=twai_receive(&m,0);
    if(err!=ESP_OK){
      if(err!=ESP_ERR_TIMEOUT){workerDiagnostics.lastError=err;++workerDiagnostics.receiveErrors;}
      break;
    }
    ++workerDiagnostics.rawRx;workerDiagnostics.lastRxMs=millis();
    if (m.extd || m.rtr || m.data_length_code>8){++workerDiagnostics.rejectedRx;continue;}
    bool decoded=false;
    switch (m.identifier) {
      // NODE_ECU.ino contract:
      // [node id, FW major, FW minor, status flags, uptime_s u32 LE]
      case 0x100:
        if (m.data_length_code >= 8) {
          e.nodeId=m.data[0];e.fwMajor=m.data[1];e.fwMinor=m.data[2];e.status=m.data[3];
          e.uptimeSec=u32le(m.data+4);e.lastHeartbeatMs=millis();decoded=true;
        }
        break;
      // Contract v2: [speed_x100 u16 LE, ADC raw u16 LE, status, sequence, 0x53, 0x02].
      // Unmarked speed-first frames from the project's previous Node build and
      // the legacy [ADC,RPM] layout are both recognized for compatibility.
      case 0x101:
        if (m.data_length_code >= 6) {
          decodeRuntimeFrame(m,e);e.lastRuntimeMs=millis();decoded=true;
        }
        break;
      // [temperature signed int16 in 0.01 C, state, valid, sample_time_ms u32 LE]
      case 0x102:
        if (m.data_length_code >= 4) {
          int16_t raw=int16_t(u16le(m.data));
          e.temperatureState=m.data[2];
          e.temperatureValid=m.data[3]!=0&&raw!=INT16_MIN;
          e.temperatureC=e.temperatureValid?raw/100.0f:NAN;
          e.lastTemperatureMs=millis();
          decoded=true;
        }
        break;
      // [DTC code u8, severity u8, active u8, status, temperature 0.01 C, sequence, node id]
      case 0x103:
        if (m.data_length_code >= 4) {
          e.dtcCode=m.data[0];e.dtcSeverity=m.data[1];e.dtcActive=m.data[2]!=0;
          e.status=m.data[3];decoded=true;
        }
        break;
    }
    if(decoded){
      e.lastCanFrameMs=millis();e.rxFrameCount++;
      const uint8_t index=uint8_t(m.identifier-0x100);
      ++workerDiagnostics.idRx[index];workerDiagnostics.lastIdMs[index]=millis();
    }
    else ++workerDiagnostics.rejectedRx;
  }
  // A receive-only controller can remain RUNNING but error-passive indefinitely.
  // Stop/start only after sustained passive state AND no physical frame progress;
  // wrong IDs still count as progress. Never reset an ordinary quiet/healthy bus.
  // This is bounded recovery, not a cure for wiring/termination/power faults.
  if(freshStatus&&workerDiagnostics.state==TWAI_STATE_RUNNING){
    const bool passive=workerDiagnostics.rxErrorCounter>=128||workerDiagnostics.txErrorCounter>=128;
    if(passive){
      if(!passiveObserved){passiveObserved=true;passiveSince=now;}
      // receive() can cross a millisecond boundary; never subtract its newer
      // timestamp from the older time captured at service entry.
      const uint32_t recoveryNow=millis();
      const uint32_t noRxAge=workerDiagnostics.rawRx?recoveryNow-workerDiagnostics.lastRxMs:recoveryNow-runningSince;
      if(recoveryNow-passiveSince>=CAN_PASSIVE_STALL_MS&&recoveryNow-runningSince>=CAN_PASSIVE_STALL_MS&&
         noRxAge>=CAN_PASSIVE_STALL_MS&&
         (!passiveRestartAttempted||recoveryNow-lastPassiveRestart>=CAN_PASSIVE_RESTART_COOLDOWN_MS)){
        // Recheck just before stopping: ISR state/REC/RX queue can have changed
        // while frames were drained. A stop/state race is not a successful reset.
        twai_status_info_t confirm{};
        const esp_err_t statusResult=twai_get_status_info(&confirm);
        if(statusResult!=ESP_OK){
          workerDiagnostics.lastError=statusResult;++workerDiagnostics.statusErrors;
          refreshValidity(e,millis());completeCanService();return;
        }
        workerDiagnostics.state=confirm.state;
        workerDiagnostics.rxPending=confirm.msgs_to_rx;
        workerDiagnostics.rxErrorCounter=confirm.rx_error_counter;
        workerDiagnostics.txErrorCounter=confirm.tx_error_counter;
        if(confirm.state!=TWAI_STATE_RUNNING||confirm.msgs_to_rx||
           (confirm.rx_error_counter<128&&confirm.tx_error_counter<128)){
          if(confirm.state!=TWAI_STATE_RUNNING){invalidateEcu();passiveObserved=false;}
          else if(confirm.rx_error_counter<128&&confirm.tx_error_counter<128)passiveObserved=false;
          refreshValidity(e,millis());completeCanService();return;
        }
        passiveRestartAttempted=true;lastPassiveRestart=recoveryNow;
        ++workerDiagnostics.passiveRestartAttempts;
        workerDiagnostics.lastError=twai_stop();
        if(workerDiagnostics.lastError==ESP_OK){
          workerDiagnostics.state=TWAI_STATE_STOPPED;invalidateEcu();passiveObserved=false;
          passiveRestartPending=true;lastRecoveryAttempt=recoveryNow;
          // start() clears the RX queue. No reinstall, no second task/driver owner.
          workerDiagnostics.lastError=twai_start();
          if(workerDiagnostics.lastError==ESP_OK){
            ++workerDiagnostics.passiveRestarts;passiveRestartPending=false;markDriverStarted(millis());
          }
        }
      }
    }else passiveObserved=false;
  }
  refreshValidity(e,millis());
  if(!e.online)speedValidFrames=0;
  completeCanService();
}

static void canWorker(void *) {
  for(;;){serviceCanDriver();vTaskDelay(pdMS_TO_TICKS(5));}
}

bool canBegin() {
  if(beginCalled)return canGetDiagnostics().state==TWAI_STATE_RUNNING;
  beginCalled=true;
  const bool ready=installCanDriver();
  lastServiceCompleted=millis();serviceClockStarted=true;
  publishCanSnapshot();
  // 4 KiB stack, no heap allocations or storage/network calls in the RX loop.
  // Core 0 continues receiving while the Arduino loop waits for SD or TinyML.
  workerDiagnostics.workerRunning=true;
  if(xTaskCreatePinnedToCore(canWorker,"can_rx",4096,nullptr,2,&canWorkerHandle,0)!=pdPASS){
    workerDiagnostics.workerRunning=false;canWorkerHandle=nullptr;
    Serial.println("[CAN ] WARN | RX task allocation failed; using foreground polling");
    publishCanSnapshot();
  }
  return ready;
}

void canPoll(EcuData &e) {
  if(!beginCalled)canBegin();
  if(!canWorkerHandle)serviceCanDriver();
  portENTER_CRITICAL(&canSnapshotMux);e=publishedEcu;portEXIT_CRITICAL(&canSnapshotMux);
  refreshValidity(e,millis());
}

CanDiagnostics canGetDiagnostics() {
  CanDiagnostics result;
  portENTER_CRITICAL(&canSnapshotMux);result=publishedDiagnostics;portEXIT_CRITICAL(&canSnapshotMux);
  result.serviceAgeMs=millis()-result.lastServiceMs;
  result.workerResponsive=result.serviceSeen&&result.serviceAgeMs<=CAN_SERVICE_STALE_MS;
  return result;
}

void canPrintDiagnostics(const EcuData &e) {
  const CanDiagnostics d=canGetDiagnostics();
  const char *state=!d.installed?"INIT_RETRY":d.state==TWAI_STATE_RUNNING?"RUNNING":
    d.state==TWAI_STATE_BUS_OFF?"BUS_OFF":d.state==TWAI_STATE_RECOVERING?"RECOVERING":"STOPPED";
  const char *workerState=!d.serviceSeen?"STARTING":d.workerResponsive?(d.workerRunning?"ACTIVE":"FALLBACK"):"STALE";
  Serial.printf("      TWAI | %s | RX task=%s | TX%d RX%d 500k | raw=%lu decoded=%lu rejected=%lu\n",state,workerState,PIN_CAN_TX,PIN_CAN_RX,
    (unsigned long)d.rawRx,(unsigned long)e.rxFrameCount,(unsigned long)d.rejectedRx);
  Serial.printf("      BUS  | TEC=%lu REC=%lu | errors=%lu missed=%lu overrun=%lu | init=%lu recovery=%lu/%lu | last=%s\n",
    (unsigned long)d.txErrorCounter,(unsigned long)d.rxErrorCounter,(unsigned long)d.busErrors,
    (unsigned long)d.rxMissed,(unsigned long)d.rxOverrun,(unsigned long)d.initAttempts,
    (unsigned long)d.recoveryStarts,(unsigned long)d.recoveryAttempts,esp_err_to_name(d.lastError));
  Serial.printf("      RX   | service=%lu age=%lu ms | passive restart=%lu/%lu | stale queue flush=%lu | API errors status/rx=%lu/%lu\n",
    (unsigned long)d.serviceCycles,(unsigned long)d.serviceAgeMs,(unsigned long)d.passiveRestarts,
    (unsigned long)d.passiveRestartAttempts,(unsigned long)d.queueFlushes,
    (unsigned long)d.statusErrors,(unsigned long)d.receiveErrors);
  const uint32_t now=millis();
  for(uint8_t i=0;i<4;++i){
    if(d.idRx[i])Serial.printf("      ID   | 0x%03X count=%lu age=%lu ms\n",unsigned(0x100+i),(unsigned long)d.idRx[i],(unsigned long)(now-d.lastIdMs[i]));
    else Serial.printf("      ID   | 0x%03X count=0 age=NEVER\n",unsigned(0x100+i));
  }
  if(d.serviceSeen&&!d.workerResponsive)Serial.println("      CHECK| CAN service stalled; ON/task allocation is not proof of RX progress. No second driver/task is started.");
  else if(d.state==TWAI_STATE_RUNNING&&(d.rxErrorCounter>=128||d.txErrorCounter>=128))
    Serial.println("      CHECK| Error-passive bus; bounded recovery cannot fix missing ACK, wiring, termination or power.");
  if(!e.online&&d.installed&&d.state==TWAI_STATE_RUNNING){
    if(!d.rawRx)Serial.println("      CHECK| No CAN frame: check Node bus ACK, 500k, CTX/CRX, CANH/CANL, common GND and termination.");
    else Serial.println("      CHECK| Frames seen but no fresh valid 0x100 heartbeat; check Node IDs/payload and RX/error counters.");
  }
}
