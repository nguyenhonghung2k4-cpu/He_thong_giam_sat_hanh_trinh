#pragma once
#include <Arduino.h>
#include "direct_demo_engine.h"

// Main-loop only functions. No network worker may touch the engine directly.
bool directDemoPoll(bool canFresh, float inputSpeed, float warningRadius, float rearmRadius);
bool directDemoActive(); // published flag safe from either task
String directDemoSnapshotJson();
String directDemoSnapshotJson(const directdemo::Snapshot &snapshot);
const directdemo::Snapshot &directDemoSnapshot();
int directDemoDetect(uint8_t kind, float confidence, float duplicateRadius, bool &added);
int directDemoDetectAt(uint8_t kind, float confidence, float duplicateRadius,
                       const directdemo::Snapshot &observed, bool &added);
const directdemo::Hazard &directDemoHazard(size_t index);
int directDemoTakeWarning();
int directDemoPendingWarning(size_t first=0);
void directDemoReportWarning(size_t index);
void directDemoDismissWarning(size_t index);
// Audio worker reads a locked published copy, never the main-loop engine.
bool directDemoAudioCurrent(const char *session, uint32_t pass, double lat, double lon, float radius);
// Network task: validates, posts bounded mailbox and waits for APPLIED result.
bool directDemoCommand(uint32_t commandId, const String &response, String &result);
