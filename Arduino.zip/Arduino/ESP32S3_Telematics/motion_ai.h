#pragma once
#include "types.h"
bool motionBegin();
bool motionInfer(AiData &data);
// Demo inference uses the same deployed model, but does not overwrite the
// live ADXL window or the caller's live telemetry. The sampler never waits on
// this classifier mutex.
bool motionInferWindow(const float *values, size_t count, AiData &data,
                       uint32_t timeoutMs=2000);
size_t motionModelSampleCount();
size_t motionModelInputCount();
float motionModelFrequencyHz();
const char *motionModelVersion();


// V9 health counters
bool motionSensorHealthy();
uint32_t motionFifoOverrunCount();
uint32_t motionFifoServiceCount();
