#include "direct_demo.h"
#include "direct_demo_command.h"
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

namespace {
directdemo::Engine engine;
portMUX_TYPE mailboxMux=portMUX_INITIALIZER_UNLOCKED;
directdemo::Command pending;
bool hasPending=false, executing=false, publishedActive=false;
directdemo::Snapshot audioSnapshot;
bool audioCanFresh=false;
struct AppliedResult { uint32_t id=0; bool ok=false; char json[640]={}; };
AppliedResult resultCache[8];
size_t nextResult=0;
uint32_t highestApplied=0;

void formatSnapshot(char *out,size_t capacity,const directdemo::Snapshot &s=engine.snapshot()) {
  if(!s.session[0]) { snprintf(out,capacity,"null"); return; }
  snprintf(out,capacity,
    "{\"session_id\":\"%s\",\"active\":%s,\"state\":\"%s\",\"pass_index\":%lu,\"capture_ms\":%lu,\"lat\":%.7f,\"lon\":%.7f,\"distance_m\":%.3f,\"route_length_m\":%.3f,\"speed_kph\":%.3f,\"input_speed_kph\":%.3f,\"speed_multiplier\":%.3f}",
    s.session,s.active()?"true":"false",directdemo::stateName(s.state),(unsigned long)s.passIndex,(unsigned long)s.captureMs,s.point.lat,s.point.lon,
    s.distanceM,s.lengthM,s.speed,s.inputSpeed,s.multiplier);
}
bool cached(uint32_t id,AppliedResult &out) {
  bool found=false;
  portENTER_CRITICAL(&mailboxMux);
  for(const auto &result:resultCache) if(result.id==id) { out=result; found=true; break; }
  portEXIT_CRITICAL(&mailboxMux);
  return found;
}
}

bool directDemoActive() {
  portENTER_CRITICAL(&mailboxMux); const bool active=publishedActive; portEXIT_CRITICAL(&mailboxMux);
  return active;
}
String directDemoSnapshotJson() { char json[480]; formatSnapshot(json,sizeof(json)); return String(json); }
String directDemoSnapshotJson(const directdemo::Snapshot &snapshot) { char json[480]; formatSnapshot(json,sizeof(json),snapshot); return String(json); }
const directdemo::Snapshot &directDemoSnapshot() { return engine.snapshot(); }
int directDemoDetect(uint8_t kind,float confidence,float radius,bool &added) { return engine.detect(kind,confidence,radius,added); }
int directDemoDetectAt(uint8_t kind,float confidence,float radius,const directdemo::Snapshot &observed,bool &added) { return engine.detectAt(kind,confidence,radius,observed,added); }
const directdemo::Hazard &directDemoHazard(size_t i) { return engine.hazard(i); }
int directDemoTakeWarning() { return engine.takeWarning(); }
int directDemoPendingWarning(size_t first) { return engine.pendingWarning(first); }
void directDemoReportWarning(size_t i) { engine.reportWarning(i); }
void directDemoDismissWarning(size_t i) { engine.dismissWarning(i); }
bool directDemoAudioCurrent(const char *session,uint32_t pass,double lat,double lon,float radius) {
  directdemo::Snapshot copy;
  bool fresh;
  portENTER_CRITICAL(&mailboxMux);
  copy=audioSnapshot; fresh=audioCanFresh;
  portEXIT_CRITICAL(&mailboxMux);
  return session && fresh && millis()-copy.captureMs<500 &&
    !strcmp(session,copy.session) && pass==copy.passIndex &&
    (copy.state==directdemo::State::Running || copy.state==directdemo::State::Completed) &&
    isfinite(radius) && radius>0 && directdemo::distance(copy.point,{lat,lon})<=radius;
}

bool directDemoPoll(bool canFresh,float inputSpeed,float warningRadius,float rearmRadius) {
  directdemo::Command command;
  bool apply=false, scopeChanged=false;
  portENTER_CRITICAL(&mailboxMux);
  if(hasPending) { command=pending; hasPending=false; executing=true; apply=true; }
  portEXIT_CRITICAL(&mailboxMux);
  if(apply) {
    const char *error=nullptr;
    const bool wasActive=engine.snapshot().active();
    char previousSession[49]; strcpy(previousSession,engine.snapshot().session);
    if(millis()-command.queuedMs>command.ttlMs) error="command_expired_before_apply";
    else if(command.id<=highestApplied) error="stale_command_id";
    else if(command.start) error=engine.start(command.session,command.points,command.count,command.multiplier,millis());
    else error=engine.control(command.session,command.operation,millis());
    if(!error) scopeChanged=wasActive!=engine.snapshot().active() || strcmp(previousSession,engine.snapshot().session) || (!command.start&&!strcmp(command.operation,"repeat"));
    // Snapshot ACK is the main-loop state after application, never optimistic.
    engine.step(millis(),canFresh,inputSpeed,warningRadius,rearmRadius);
    AppliedResult result; result.id=command.id; result.ok=error==nullptr;
    char snapshot[480]; formatSnapshot(snapshot,sizeof(snapshot));
    if(error) snprintf(result.json,sizeof(result.json),"{\"error\":\"%s\",\"direct_demo\":%s}",error,snapshot);
    else snprintf(result.json,sizeof(result.json),"{\"applied\":true,\"direct_demo\":%s}",snapshot);
    portENTER_CRITICAL(&mailboxMux);
    resultCache[nextResult]=result; nextResult=(nextResult+1)%8;
    if(command.id>highestApplied) highestApplied=command.id;
    executing=false; publishedActive=engine.snapshot().active();
    // Publish the audio scope atomically with the command ACK, before Serial
    // can yield: an acknowledged pause/stop/repeat must reject stale speech.
    audioSnapshot=engine.snapshot(); audioCanFresh=canFresh;
    portEXIT_CRITICAL(&mailboxMux);
    Serial.printf("[DIRECT] CMD | %lu | %s | %s | %s\n",(unsigned long)command.id,command.start?"start":command.operation,error?error:"APPLIED",directdemo::stateName(engine.snapshot().state));
  }
  engine.step(millis(),canFresh,inputSpeed,warningRadius,rearmRadius);
  portENTER_CRITICAL(&mailboxMux);
  audioSnapshot=engine.snapshot(); audioCanFresh=canFresh;
  portEXIT_CRITICAL(&mailboxMux);
  return scopeChanged;
}

bool directDemoCommand(uint32_t id,const String &response,String &result) {
  AppliedResult applied;
  if(cached(id,applied)) { result=applied.json; return applied.ok; }
  directdemo::Command command; command.id=id;
  const char *error=directdemo::parseCommand(response.c_str(),response.length(),command);
  if(error) { result=String("{\"error\":\"")+error+"\"}"; return false; }
  command.queuedMs=millis();
  bool busy=false;
  portENTER_CRITICAL(&mailboxMux);
  busy=hasPending||executing;
  if(!busy) { pending=command; hasPending=true; }
  portEXIT_CRITICAL(&mailboxMux);
  if(busy) { result="{\"error\":\"direct_command_busy\"}"; return false; }
  const uint32_t waitStarted=millis();
  while(millis()-waitStarted<=2100) {
    if(cached(id,applied)) { result=applied.json; return applied.ok; }
    vTaskDelay(pdMS_TO_TICKS(5));
  }
  portENTER_CRITICAL(&mailboxMux);
  if(hasPending && pending.id==id) hasPending=false; // Never apply later after a timeout ACK.
  portEXIT_CRITICAL(&mailboxMux);
  if(cached(id,applied)) { result=applied.json; return applied.ok; }
  result="{\"error\":\"direct_main_loop_timeout\"}";
  return false;
}
