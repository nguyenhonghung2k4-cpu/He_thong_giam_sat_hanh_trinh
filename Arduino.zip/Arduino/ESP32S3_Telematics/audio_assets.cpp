#include "audio_assets.h"

const uint8_t AUDIO_O_GA_WAV[] PROGMEM = {
#include "audio_o_ga.inc"
};
const size_t AUDIO_O_GA_WAV_LEN = sizeof(AUDIO_O_GA_WAV);

const uint8_t AUDIO_GO_GIAM_TOC_WAV[] PROGMEM = {
#include "audio_go_giam_toc.inc"
};
const size_t AUDIO_GO_GIAM_TOC_WAV_LEN = sizeof(AUDIO_GO_GIAM_TOC_WAV);

const uint8_t AUDIO_QUA_TOC_DO_WAV[] PROGMEM = {
#include "audio_qua_toc_do.inc"
};
const size_t AUDIO_QUA_TOC_DO_WAV_LEN = sizeof(AUDIO_QUA_TOC_DO_WAV);
