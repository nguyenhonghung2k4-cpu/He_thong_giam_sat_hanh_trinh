#pragma once
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Small, bounded, read-only JSON reader. It validates the complete document
// before inspecting fields, so "values" inside another string/object cannot
// masquerade as the command's array. No ArduinoJson dependency is required.
struct DemoJsonSpan {
  size_t begin,end;
  DemoJsonSpan(size_t first=0,size_t last=0):begin(first),end(last){}
};
class DemoJsonReader {
  const char *text;
  size_t length;
  static bool space(char c){return c==' '||c=='\r'||c=='\n'||c=='\t';}
  static bool digit(char c){return c>='0'&&c<='9';}
  static bool hex(char c){return digit(c)||(c>='a'&&c<='f')||(c>='A'&&c<='F');}
  void whitespace(size_t &p)const{while(p<length&&space(text[p]))++p;}
  bool stringToken(size_t &p)const{
    if(p>=length||text[p++]!='"')return false;
    while(p<length){
      const unsigned char c=(unsigned char)text[p++];
      if(c=='"')return true;
      if(c<0x20)return false;
      if(c=='\\'){
        if(p>=length)return false;
        const char escape=text[p++];
        if(escape=='u'){
          for(unsigned i=0;i<4;i++)if(p>=length||!hex(text[p++]))return false;
        }else if(escape=='\0'||!strchr("\"\\/bfnrt",escape))return false;
      }
    }
    return false;
  }
  bool numberToken(size_t &p)const{
    if(p<length&&text[p]=='-')++p;
    if(p>=length)return false;
    if(text[p]=='0')++p;
    else{
      if(text[p]<'1'||text[p]>'9')return false;
      do{++p;}while(p<length&&digit(text[p]));
    }
    if(p<length&&text[p]=='.'){
      ++p;const size_t start=p;
      while(p<length&&digit(text[p]))++p;
      if(p==start)return false;
    }
    if(p<length&&(text[p]=='e'||text[p]=='E')){
      ++p;if(p<length&&(text[p]=='+'||text[p]=='-'))++p;
      const size_t start=p;while(p<length&&digit(text[p]))++p;
      if(p==start)return false;
    }
    return true;
  }
  bool value(size_t &p,unsigned depth,size_t &tokens)const{
    whitespace(p);
    if(p>=length||depth>12||++tokens>4096)return false;
    const char c=text[p];
    if(c=='"')return stringToken(p);
    if(c=='{'||c=='['){
      const bool object=c=='{';const char close=object?'}':']';
      ++p;whitespace(p);if(p<length&&text[p]==close){++p;return true;}
      for(;;){
        if(object){
          if(!stringToken(p))return false;
          whitespace(p);if(p>=length||text[p++]!=':')return false;
        }
        if(!value(p,depth+1,tokens))return false;
        whitespace(p);if(p>=length)return false;
        if(text[p]==close){++p;return true;}
        if(text[p++]!=',')return false;
        whitespace(p);
      }
    }
    const char *literal=c=='t'?"true":c=='f'?"false":c=='n'?"null":nullptr;
    if(literal){
      const size_t size=strlen(literal);
      if(size>length-p||memcmp(text+p,literal,size))return false;
      p+=size;return true;
    }
    return numberToken(p);
  }
 public:
  DemoJsonReader(const char *input,size_t size):text(input),length(size){}
  DemoJsonSpan root()const{return DemoJsonSpan{0,length};}
  bool valid()const{
    if(!text||length==0||length>32768)return false;
    size_t p=0,tokens=0;
    if(!value(p,0,tokens))return false;
    whitespace(p);return p==length;
  }
  bool objectMember(DemoJsonSpan object,const char *key,DemoJsonSpan &out)const{
    size_t p=object.begin,tokens=0;whitespace(p);
    if(p>=object.end||text[p++]!='{')return false;
    const size_t keyLength=strlen(key);bool found=false;
    whitespace(p);if(p<object.end&&text[p]=='}')return false;
    for(;;){
      const size_t keyStart=p;
      if(!stringToken(p))return false;
      const bool match=p-keyStart==keyLength+2&&!memcmp(text+keyStart+1,key,keyLength);
      whitespace(p);if(p>=object.end||text[p++]!=':')return false;
      whitespace(p);const size_t start=p;
      if(!value(p,0,tokens)||p>object.end)return false;
      if(match){if(found)return false;found=true;out=DemoJsonSpan{start,p};}
      whitespace(p);if(p>=object.end)return false;
      if(text[p]=='}')return found;
      if(text[p++]!=',')return false;
      whitespace(p);
    }
  }
  bool stringEquals(DemoJsonSpan span,const char *expected)const{
    const size_t size=strlen(expected);
    return span.end<=length&&span.end-span.begin==size+2&&text[span.begin]=='"'&&
           text[span.end-1]=='"'&&!memcmp(text+span.begin+1,expected,size);
  }
  bool simpleString(DemoJsonSpan span,char *out,size_t capacity)const{
    if(!out||capacity==0||span.end>length||span.end-span.begin<2||
       text[span.begin]!='"'||text[span.end-1]!='"')return false;
    const size_t size=span.end-span.begin-2;if(size==0||size>=capacity)return false;
    for(size_t i=0;i<size;i++){
      const unsigned char c=(unsigned char)text[span.begin+1+i];
      if(c<0x20||c>=0x7f||c=='\\'||c=='"')return false;
    }
    memcpy(out,text+span.begin+1,size);out[size]='\0';return true;
  }
  bool number(DemoJsonSpan span,double &out)const{
    if(span.end>length||span.end<=span.begin||span.end-span.begin>=64)return false;
    size_t p=span.begin;if(!numberToken(p)||p!=span.end)return false;
    char buffer[64];const size_t size=span.end-span.begin;
    memcpy(buffer,text+span.begin,size);buffer[size]='\0';
    char *end=nullptr;out=strtod(buffer,&end);
    return end==buffer+size&&isfinite(out);
  }
  bool numberArray(DemoJsonSpan array,float *out,size_t count)const{
    if(!out||array.end>length)return false;
    size_t p=array.begin;whitespace(p);
    if(p>=array.end||text[p++]!='[')return false;
    for(size_t i=0;i<count;i++){
      whitespace(p);const size_t start=p;
      if(!numberToken(p))return false;
      double parsed=0;
      if(!number(DemoJsonSpan{start,p},parsed)||fabs(parsed)>16.0)return false;
      out[i]=(float)parsed;
      whitespace(p);
      if(p>=array.end)return false;
      if(i+1<count){if(text[p++]!=',')return false;}
      else if(text[p++]!=']')return false;
    }
    whitespace(p);return p==array.end;
  }
  // Coordinate command array, deliberately separate from the +/-16 g sample
  // parser above. Preserve double precision and reject excess values.
  bool boundedNumberArray(DemoJsonSpan array,double *out,size_t capacity,size_t &count)const{
    count=0;
    if(!out||array.end>length)return false;
    size_t p=array.begin;whitespace(p);
    if(p>=array.end||text[p++]!='[')return false;
    whitespace(p);if(p<array.end&&text[p]==']'){++p;whitespace(p);return p==array.end;}
    for(;;){
      whitespace(p);const size_t start=p;
      if(count>=capacity||!numberToken(p)||!number(DemoJsonSpan{start,p},out[count]))return false;
      ++count;whitespace(p);if(p>=array.end)return false;
      if(text[p]==']'){++p;whitespace(p);return p==array.end;}
      if(text[p++]!=',')return false;
    }
  }
};
