#pragma once
// Caller supplies synchronization and deletes returned displaced pointers
// OUTSIDE its critical section. This helper neither allocates nor owns memory.
template <class T> class LatestSlot {
  T *pending_=nullptr;
public:
  constexpr bool pending() const { return pending_!=nullptr; }
  constexpr T *publish(T *newest) {
    T *displaced=pending_;pending_=newest;return displaced;
  }
  constexpr T *take() {
    T *item=pending_;pending_=nullptr;return item;
  }
  // Return nullptr when retained, or the obsolete retry when a newer sample
  // arrived during HTTP. A retry must NEVER overwrite that newer sample.
  constexpr T *retry(T *item) {
    if(pending_)return item;
    pending_=item;return nullptr;
  }
};
