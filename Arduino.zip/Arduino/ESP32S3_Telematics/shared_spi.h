#pragma once
#include <Arduino.h>

// MicroSD is the only SPI peripheral in V10.2. This mutex serializes the SD
// driver's logger, resend, export and audio-quiesce paths. ADXL345 uses its own
// I2C bus and never takes this lock.
bool sharedSpiBegin();
bool sharedSpiLock(uint32_t timeoutMs = 250);
void sharedSpiUnlock();
