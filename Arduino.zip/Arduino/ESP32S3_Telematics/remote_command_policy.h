#pragma once
#include <stdint.h>

// HTTP receipt is not permission to play a cancelled/expired demo command.
constexpr bool remoteAudioMayPlay(int httpCode, bool deviceAccepted, bool ackOk,
                                 bool commandDone, bool playAuthorized,
                                 uint32_t commandId, uint32_t lastPlayedId) {
  return httpCode == 200 && deviceAccepted && ackOk && commandDone &&
         playAuthorized && commandId != 0 && commandId != lastPlayedId;
}

constexpr uint32_t remoteCommandPollInterval(bool demoActive, uint32_t suggested,
                                             uint32_t normalInterval) {
  return !demoActive ? normalInterval :
         suggested < 500 ? 500 : suggested > normalInterval ? normalInterval : suggested;
}
