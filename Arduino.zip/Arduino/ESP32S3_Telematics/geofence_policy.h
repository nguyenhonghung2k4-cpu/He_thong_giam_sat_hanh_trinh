#pragma once
#include <math.h>

namespace navigation {
inline bool confirmedResume(bool previousValid, bool previousStationary,
                            bool currentValid, bool currentStationary, bool epochChanged) {
  return previousValid && previousStationary && currentValid && !currentStationary && epochChanged;
}

inline bool geofenceShouldWarn(bool armed, float distance, float previousDistance,
                              float segmentDistance, bool segmentUsable,
                              float radius, float approachEpsilon) {
  if (!armed || !isfinite(distance) || !isfinite(radius) || radius <= 0) return false;
  const bool approaching = !isfinite(previousDistance) || distance < previousDistance - approachEpsilon;
  const bool crossed = segmentUsable && previousDistance > radius &&
                       isfinite(segmentDistance) && segmentDistance <= radius;
  return (distance <= radius && approaching) || crossed;
}
}
