#ifndef TELEMATICS_GNSS_POSITION_FILTER_H
#define TELEMATICS_GNSS_POSITION_FILTER_H

// GPS-only anti-drift filter. Header-only, deterministic, no heap or Arduino API.
// nowMs is the CURRENT monotonic time on EVERY call. sequence changes only when
// the receiver supplies a NEW location fix; repeated reads are not evidence.
// Filters do not improve absolute GPS accuracy. Keep raw data for diagnostics.
#include <stdint.h>
#include <math.h>

namespace navigation {

struct Config {
  float maxHdop = 3.0f;
  uint32_t minSatellites = 4;
  uint32_t staleMs = 3000;
  uint32_t acquireFixes = 3;
  uint32_t acquireMs = 2000;
  float stationarySpeedKph = 1.5f;
  float stationaryRadiusM = 3.0f;
  // Directional progress is different from jitter inside the stop radius.
  // Without this guard a pedestrian can be re-locked every few seconds.
  float stationaryProgressM = 0.5f;
  uint32_t stationaryFixes = 5;
  uint32_t stationaryMs = 5000;
  float resumeSpeedKph = 2.5f;
  uint32_t resumeFixes = 2;
  uint32_t resumeMs = 500;
  float displacementUnlockM = 6.0f;
  uint32_t displacementFixes = 3;
  uint32_t displacementMs = 1500;
  float maxSpeedKph = 200.0f;
  float positionSpeedSlackKph = 15.0f;
  float jumpSlackM = 10.0f;
  float smoothingTauMs = 350.0f;
};

struct Fix {
  double lat = 0.0;
  double lon = 0.0;
  float speedKph = 0.0f;
  float hdop = 99.9f;
  uint32_t satellites = 0;
  uint32_t nowMs = 0;
  uint32_t sequence = 0;
  bool valid = false;
};

struct Output {
  bool valid = false;
  bool stationary = false;
  bool segmentValid = false;
  double lat = 0.0;
  double lon = 0.0;
  float speedKph = 0.0f;
  uint32_t epoch = 0;
  uint32_t rejected = 0;
  const char *state = "acquiring";
};

class PositionFilter {
 public:
  explicit PositionFilter(const Config &config = Config()) : cfg_(config) {}
  const Output &current() const { return out_; }

  const Output &update(const Fix &fix) {
    const bool isNew = !haveSequence_ || fix.sequence != lastSequence_;
    // Check a gap BEFORE assigning the arrival time of a returning receiver.
    const bool gap = haveSequence_ && elapsed(fix.nowMs, lastNewMs_) > cfg_.staleMs;
    if (gap) resetAcquisition("stale");
    if (isNew) {
      haveSequence_ = true;
      lastSequence_ = fix.sequence;
      lastNewMs_ = fix.nowMs;
    }
    if (!quality(fix)) {
      resetAcquisition("invalid");
      return out_;
    }
    if (!isNew) return out_;

    if (mode_ == Acquiring) return acquire(fix);

    if (!plausible(lastRaw_, fix)) {
      ++out_.rejected;
      invalidate("rejected");
      // A single jump is never adopted. Several coherent samples at a new
      // location trigger reacquisition, not a bridge from the old anchor.
      if (!relocationCount_ || !plausible(relocationLast_, fix)) {
        relocationCount_ = 1;
        relocationStartMs_ = fix.nowMs;
      } else {
        increment(relocationCount_);
      }
      relocationLast_ = fix;
      if (relocationCount_ >= cfg_.acquireFixes &&
          elapsed(fix.nowMs, relocationStartMs_) >= cfg_.acquireMs) {
        resetAcquisition("acquiring");
        return acquire(fix);
      }
      return out_;
    }
    relocationCount_ = 0;
    const uint32_t sampleMs = elapsed(fix.nowMs, lastRaw_.nowMs);
    lastRaw_ = fix;

    if (mode_ == Stationary) {
      if (shouldResume(fix)) {
        mode_ = Moving;
        stopCount_ = 0;
        // Do not charge the released hold/anchor offset as travelled distance.
        breakContinuity_ = true;
        publish(fix.lat, fix.lon, fix.speedKph, false);
      } else {
        publish(anchorLat_, anchorLon_, 0.0f, true);
      }
      return out_;
    }

    considerStop(fix);
    if (stopCount_ >= cfg_.stationaryFixes &&
        elapsed(fix.nowMs, stopStartMs_) >= cfg_.stationaryMs) {
      mode_ = Stationary;
      anchorLat_ = stopLat_;
      anchorLon_ = stopLon_;
      resetResume();
      breakContinuity_ = true;
      publish(anchorLat_, anchorLon_, 0.0f, true);
      return out_;
    }

    // Speed-adaptive first-order smoothing: ~350 ms at walking pace and
    // substantially less at road speed. Never average positions across gaps.
    const double tau = cfg_.smoothingTauMs / (1.0 + fix.speedKph / 10.0);
    const double alpha = sampleMs == 0 ? 1.0 : sampleMs / (sampleMs + tau);
    const double lat = out_.lat + alpha * (fix.lat - out_.lat);
    const double lon = wrapLon(out_.lon + alpha * longitudeDelta(fix.lon, out_.lon));
    publish(lat, lon, fix.speedKph, false);
    return out_;
  }

 private:
  enum Mode { Acquiring, Moving, Stationary };
  Config cfg_;
  Output out_;
  Mode mode_ = Acquiring;
  bool haveSequence_ = false;
  bool breakContinuity_ = true;
  uint32_t lastSequence_ = 0, lastNewMs_ = 0;
  Fix lastRaw_;
  uint32_t acquireCount_ = 0, acquireStartMs_ = 0;
  uint32_t stopCount_ = 0, stopStartMs_ = 0;
  double stopLat_ = 0, stopLon_ = 0, stopOriginLat_ = 0, stopOriginLon_ = 0;
  double stopPathM_ = 0;
  Fix stopLast_;
  double anchorLat_ = 0, anchorLon_ = 0;
  uint32_t resumeCount_ = 0, resumeStartMs_ = 0;
  uint32_t displacementCount_ = 0, displacementStartMs_ = 0;
  Fix resumeLast_, displacementLast_;
  uint32_t relocationCount_ = 0, relocationStartMs_ = 0;
  Fix relocationLast_;

  static uint32_t elapsed(uint32_t now, uint32_t before) { return now - before; }
  static void increment(uint32_t &value) { if (value != UINT32_MAX) ++value; }
  static double degreesToRadians(double degrees) { return degrees * 0.017453292519943295; }
  static double longitudeDelta(double a, double b) {
    double d = a - b;
    if (d > 180.0) d -= 360.0;
    if (d < -180.0) d += 360.0;
    return d;
  }
  static double wrapLon(double value) {
    if (value > 180.0) value -= 360.0;
    if (value < -180.0) value += 360.0;
    return value;
  }
  static double distance(double aLat, double aLon, double bLat, double bLon) {
    const double dLat = degreesToRadians(bLat - aLat);
    const double dLon = degreesToRadians(longitudeDelta(bLon, aLon));
    const double sLat = sin(dLat * 0.5), sLon = sin(dLon * 0.5);
    double a = sLat * sLat + cos(degreesToRadians(aLat)) * cos(degreesToRadians(bLat)) * sLon * sLon;
    if (a < 0.0) a = 0.0;
    if (a > 1.0) a = 1.0;
    return 12742000.0 * atan2(sqrt(a), sqrt(1.0 - a));
  }
  bool quality(const Fix &f) const {
    return f.valid && isfinite(f.lat) && isfinite(f.lon) &&
      isfinite(f.speedKph) && isfinite(f.hdop) &&
      f.lat >= -90.0 && f.lat <= 90.0 && f.lon >= -180.0 && f.lon <= 180.0 &&
      f.speedKph >= 0.0f && f.speedKph <= cfg_.maxSpeedKph &&
      f.hdop > 0.0f && f.hdop <= cfg_.maxHdop && f.satellites >= cfg_.minSatellites;
  }
  bool plausible(const Fix &before, const Fix &after) const {
    const uint32_t ms = elapsed(after.nowMs, before.nowMs);
    // Never let a string of rejected fixes grow the allowed jump indefinitely.
    if (ms > cfg_.staleMs) return false;
    double speed = before.speedKph > after.speedKph ? before.speedKph : after.speedKph;
    speed += cfg_.positionSpeedSlackKph;
    if (speed > cfg_.maxSpeedKph) speed = cfg_.maxSpeedKph;
    const double limit = cfg_.jumpSlackM + speed * ms / 3600.0;
    return distance(before.lat, before.lon, after.lat, after.lon) <= limit;
  }
  void invalidate(const char *state) {
    out_.valid = false;
    out_.stationary = false;
    out_.segmentValid = false;
    out_.state = state;
    breakContinuity_ = true;
  }
  void resetResume() { resumeCount_ = 0; displacementCount_ = 0; }
  void resetAcquisition(const char *state) {
    mode_ = Acquiring;
    acquireCount_ = 0;
    stopCount_ = 0;
    relocationCount_ = 0;
    resetResume();
    invalidate(state);
  }
  const Output &acquire(const Fix &f) {
    if (!acquireCount_ || !plausible(lastRaw_, f)) {
      acquireCount_ = 1;
      acquireStartMs_ = f.nowMs;
      stopCount_ = 0;
    } else {
      increment(acquireCount_);
    }
    lastRaw_ = f;
    considerStop(f);
    if (acquireCount_ < cfg_.acquireFixes || elapsed(f.nowMs, acquireStartMs_) < cfg_.acquireMs) {
      invalidate("acquiring");
      return out_;
    }
    mode_ = Moving;
    breakContinuity_ = true;
    publish(f.lat, f.lon, f.speedKph, false);
    return out_;
  }
  void beginStopCandidate(const Fix &f) {
    stopCount_ = 1;
    stopStartMs_ = f.nowMs;
    stopLat_ = stopOriginLat_ = f.lat;
    stopLon_ = stopOriginLon_ = f.lon;
    stopPathM_ = 0;
    stopLast_ = f;
  }
  void considerStop(const Fix &f) {
    if (f.speedKph > cfg_.stationarySpeedKph) { stopCount_ = 0; return; }
    // Radius is measured from a FIXED candidate origin, not an EMA that can
    // slowly follow a pedestrian and falsely classify their motion as a stop.
    const double progress = distance(stopOriginLat_, stopOriginLon_, f.lat, f.lon);
    if (!stopCount_ || progress > cfg_.stationaryRadiusM) {
      beginStopCandidate(f);
      return;
    }
    stopPathM_ += distance(stopLast_.lat, stopLast_.lon, f.lat, f.lon);
    stopLast_ = f;
    // A nearly straight sequence is evidence of motion even below the normal
    // resume speed. Do not let slow walking repeatedly enter stationary hold.
    // A random jitter path normally has much less net progress than path length.
    // GPS alone still cannot distinguish true creeping from coherent drift.
    if (stopCount_ >= 2 && elapsed(f.nowMs, stopStartMs_) >= 1500 &&
        progress + 0.001 >= cfg_.stationaryProgressM && progress >= 0.8 * stopPathM_) {
      beginStopCandidate(f);
      return;
    }
    increment(stopCount_);
    stopLat_ += (f.lat - stopLat_) / stopCount_;
    stopLon_ = wrapLon(stopLon_ + longitudeDelta(f.lon, stopLon_) / stopCount_);
  }
  bool outwardCoherent(const Fix &before, const Fix &after, bool mustGrow) const {
    const double oldDistance = distance(anchorLat_, anchorLon_, before.lat, before.lon);
    const double newDistance = distance(anchorLat_, anchorLon_, after.lat, after.lon);
    if (distance(before.lat, before.lon, after.lat, after.lon) < 0.20) return false;
    if (mustGrow && newDistance < oldDistance + 0.15) return false;
    const double cosine = cos(radians(anchorLat_));
    const double bx = longitudeDelta(before.lon, anchorLon_) * cosine;
    const double by = before.lat - anchorLat_;
    const double ax = longitudeDelta(after.lon, anchorLon_) * cosine;
    const double ay = after.lat - anchorLat_;
    const double product = sqrt((bx * bx + by * by) * (ax * ax + ay * ay));
    return product == 0.0 || (bx * ax + by * ay) / product >= 0.5;
  }
  bool shouldResume(const Fix &f) {
    const double fromAnchor = distance(anchorLat_, anchorLon_, f.lat, f.lon);
    if (f.speedKph >= cfg_.resumeSpeedKph && fromAnchor > cfg_.stationaryRadiusM) {
      if (!resumeCount_) {
        resumeCount_ = 1;
        resumeStartMs_ = f.nowMs;
        resumeLast_ = f;
      } else if (distance(resumeLast_.lat, resumeLast_.lon, f.lat, f.lon) >= 0.20) {
        if (outwardCoherent(resumeLast_, f, false)) increment(resumeCount_);
        else { resumeCount_ = 1; resumeStartMs_ = f.nowMs; }
        resumeLast_ = f;
      }
      // Sub-20 cm changes keep the reference instead of resetting it: at high
      // fix rates a walking person may move only a few centimetres per sample.
      if (resumeCount_ >= cfg_.resumeFixes && elapsed(f.nowMs, resumeStartMs_) >= cfg_.resumeMs) return true;
    } else resumeCount_ = 0;

    if (fromAnchor >= cfg_.displacementUnlockM) {
      if (!displacementCount_) {
        displacementCount_ = 1;
        displacementStartMs_ = f.nowMs;
        displacementLast_ = f;
      } else if (distance(displacementLast_.lat, displacementLast_.lon, f.lat, f.lon) >= 0.20) {
        if (outwardCoherent(displacementLast_, f, true)) increment(displacementCount_);
        else { displacementCount_ = 1; displacementStartMs_ = f.nowMs; }
        displacementLast_ = f;
      }
      return displacementCount_ >= cfg_.displacementFixes &&
        elapsed(f.nowMs, displacementStartMs_) >= cfg_.displacementMs;
    }
    displacementCount_ = 0;
    return false;
  }
  void publish(double lat, double lon, float speed, bool stationary) {
    out_.segmentValid = !breakContinuity_ && out_.valid;
    if (breakContinuity_) ++out_.epoch;
    breakContinuity_ = false;
    out_.valid = true;
    out_.stationary = stationary;
    out_.lat = lat;
    out_.lon = lon;
    out_.speedKph = speed;
    out_.state = stationary ? "stationary" : "moving";
  }
};

}  // namespace navigation
#endif
