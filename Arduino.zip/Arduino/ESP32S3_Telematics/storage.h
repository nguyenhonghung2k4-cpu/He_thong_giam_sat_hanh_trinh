#pragma once
#include "types.h"

bool storageBegin();
bool storageReady();
// True only while an automatic remount is being verified/recovered or during
// its short post-mount quiet window. Network/audio users can use this to avoid
// simultaneous current and CPU bursts.
bool storageRecoveryBusy();
uint32_t storageFrequencyHz();
// Stable machine-readable state for Serial JSON/dashboard diagnostics:
// boot_settling, mounting, verifying, post_mount_settle, online, degraded,
// retry_wait, post_audio_settle or post_audio_verify.
const char *storageStateText();
const char *storageLastError();
const char *storageCardTypeText();
uint64_t storageTotalBytes();
uint64_t storageUsedBytes();
uint64_t storageDailyLogBytes();
uint64_t storageDailyLogQuotaBytes();
const char *storageWriteBlockReason();
uint32_t storageTelemetryLogDropCount();
uint32_t storageTelemetryCoalescedCount();
uint32_t storageOfflineCoalescedCount();
size_t storageLogQueueDepth();
size_t storageOfflineQueueDepth();
size_t storageEventRamQueueDepth();
uint32_t storageQueueAllocFailureCount();
const char *storageWorkerStage();
// Elapsed time in the current worker stage, NOT SD transaction latency.
uint32_t storageWorkerAgeMs();
void storagePoll();
bool storageLock(uint32_t timeoutMs=1500);
void storageUnlock();

// V10.0.2 audio/SD arbitration ------------------------------------------------
// The MAX98357A can create a large supply-current step while speaking.  Before
// enabling the amplifier, the audio task asks storage to finish the current SD
// transaction and prevents any new SD transaction until the voice is complete.
bool storageEnterAudioCritical(uint32_t timeoutMs=1200);
void storageExitAudioCritical(bool amplifierWasEnabled=true);
bool storageAudioCritical();

// V6 daily archive. utcIso may be empty/null until GNSS time becomes valid.
void storageAppendLog(const String &json, const String &utcIso = String());

bool storageQueue(const String &kind,const String &json);
// Returns a non-zero RAM ticket when accepted. The ticket becomes durable only
// after the SD worker has appended that exact event to the outbox.
uint32_t storageQueueEvent(const String &json);
bool storageEventTicketDurable(uint32_t ticket);
// Release the uploader's ownership on completion/abandonment. A pending SD
// append retains its own ownership until committed; no event is discarded.
void storageReleaseEventTicket(uint32_t ticket);
bool storageDeadLetter(const String &kind,const String &json,const char *reason);
void storageFlushQueue(SendResult (*sender)(const String&,const String&),size_t maxRecords);
void storageFlushEventQueue(SendResult (*sender)(const String&,const String&),size_t maxRecords);
size_t storageQueueBytes();
size_t storageEventQueueBytes();

size_t storageLoadHazards(const char *path,HazardPoint *out,size_t capacity);
bool storageSaveHazard(const char *path,const HazardPoint &point);
size_t storageLoadPotholes(PotholePoint *out,size_t capacity);
bool storageSavePothole(const PotholePoint &point);

// Web/remote MicroSD manager -------------------------------------------------
// Returned strings are JSON objects and can be embedded directly in the
// command-result response sent to the localhost server.
bool storageBuildLogListJson(String &outJson);
bool storageReadLogTailJson(const String &fileName, size_t maxLines, String &outJson);
// V8: read a bounded raw chunk from a log. Each call owns SD/SPI only for the
// read, keeping logging and project-folder export responsive.
bool storageReadLogChunk(const String &fileName, size_t offset, size_t maxBytes,
                         String &outData, size_t &totalSize);
bool storageDeleteLogs(const String &fromDate, const String &toDate, bool deleteAll,
                       bool deleteHazards, uint32_t fromEpoch, uint32_t toEpoch,
                       String &outJson);
// V10: remove one map hazard from the persistent MicroSD catalog. The server
// deletes its marker only after this function is ACKed successfully.
bool storageDeleteHazardPoint(const String &kind, double lat, double lon, float radiusM, String &outJson);
// The main sketch consumes this after a hazard CSV rewrite so in-RAM geofence
// catalogs are rebuilt immediately and deleted points cannot warn again.
bool storageConsumeHazardCatalogChanged();

// V9 health counters
uint32_t storageIoFailureCount();
uint32_t storageRemountCount();
uint8_t storageIoFailureStreak();
