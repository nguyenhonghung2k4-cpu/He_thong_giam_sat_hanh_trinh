#include <Preferences.h>
#include <math.h>
#include "config.h"
#include "runtime_config.h"

static Preferences prefs;
static bool prefsOpen=false;
static RuntimeConfig cfg={OVERSPEED_WARNING_KPH,OVERSPEED_CLEAR_KPH,GEOFENCE_WARNING_RADIUS_M,GEOFENCE_REARM_RADIUS_M,POTHOLE_MIN_CONFIDENCE,SPEED_BUMP_MIN_CONFIDENCE};

static bool validCfg(const RuntimeConfig &v){
  return isfinite(v.overspeedWarningKph)&&v.overspeedWarningKph>=30&&v.overspeedWarningKph<=VEHICLE_SPEED_MAX_KPH&&
         isfinite(v.overspeedClearKph)&&v.overspeedClearKph>=20&&v.overspeedClearKph<v.overspeedWarningKph&&(v.overspeedWarningKph-v.overspeedClearKph)>=1&&
         isfinite(v.geofenceWarningRadiusM)&&v.geofenceWarningRadiusM>=3&&v.geofenceWarningRadiusM<=50&&
         isfinite(v.geofenceRearmRadiusM)&&v.geofenceRearmRadiusM>=v.geofenceWarningRadiusM+2&&v.geofenceRearmRadiusM<=100&&
         isfinite(v.potholeConfidence)&&v.potholeConfidence>=.50f&&v.potholeConfidence<=.99f&&
         isfinite(v.speedBumpConfidence)&&v.speedBumpConfidence>=.50f&&v.speedBumpConfidence<=.99f;
}
String runtimeConfigJson(){
  String j="{\"overspeed_warning_kph\":"+String(cfg.overspeedWarningKph,1);
  j+=",\"overspeed_clear_kph\":"+String(cfg.overspeedClearKph,1);
  j+=",\"geofence_warning_m\":"+String(cfg.geofenceWarningRadiusM,1);
  j+=",\"geofence_rearm_m\":"+String(cfg.geofenceRearmRadiusM,1);
  j+=",\"pothole_confidence\":"+String(cfg.potholeConfidence,3);
  j+=",\"speed_bump_confidence\":"+String(cfg.speedBumpConfidence,3)+"}";return j;
}
bool runtimeConfigBegin(){
  prefsOpen=prefs.begin("telematics",false);
  if(!prefsOpen){Serial.println("[CFG ] WARN | NVS unavailable; defaults active");return false;}
  RuntimeConfig v=cfg;
  v.overspeedWarningKph=prefs.getFloat("spd_warn",v.overspeedWarningKph);
  v.overspeedClearKph=prefs.getFloat("spd_clear",v.overspeedClearKph);
  v.geofenceWarningRadiusM=prefs.getFloat("geo_warn",v.geofenceWarningRadiusM);
  v.geofenceRearmRadiusM=prefs.getFloat("geo_rearm",v.geofenceRearmRadiusM);
  v.potholeConfidence=prefs.getFloat("pot_conf",v.potholeConfidence);
  v.speedBumpConfidence=prefs.getFloat("bump_conf",v.speedBumpConfidence);
  if(validCfg(v))cfg=v;
  Serial.printf("[CFG ] OK   | speed %.0f/%.0f | geo %.0f/%.0f m | AI %.0f/%.0f%%\n",cfg.overspeedWarningKph,cfg.overspeedClearKph,cfg.geofenceWarningRadiusM,cfg.geofenceRearmRadiusM,cfg.potholeConfidence*100,cfg.speedBumpConfidence*100);
  return true;
}
const RuntimeConfig &runtimeConfigGet(){return cfg;}
bool runtimeConfigUpdate(float sw,float sc,float gw,float gr,float pc,float bc,String &result){
  RuntimeConfig v{sw,sc,gw,gr,pc,bc};if(!validCfg(v)){result="{\"error\":\"invalid_runtime_config\"}";return false;}cfg=v;
  if(!prefsOpen){result="{\"error\":\"nvs_unavailable\"}";return false;}
  prefs.putFloat("spd_warn",cfg.overspeedWarningKph);prefs.putFloat("spd_clear",cfg.overspeedClearKph);
  prefs.putFloat("geo_warn",cfg.geofenceWarningRadiusM);prefs.putFloat("geo_rearm",cfg.geofenceRearmRadiusM);
  prefs.putFloat("pot_conf",cfg.potholeConfidence);prefs.putFloat("bump_conf",cfg.speedBumpConfidence);
  result="{\"saved\":true,\"config\":"+runtimeConfigJson()+"}";
  Serial.printf("[CFG ] SAVE | speed %.0f/%.0f | geo %.0f/%.0f | AI %.0f/%.0f%%\n",sw,sc,gw,gr,pc*100,bc*100);return true;
}
