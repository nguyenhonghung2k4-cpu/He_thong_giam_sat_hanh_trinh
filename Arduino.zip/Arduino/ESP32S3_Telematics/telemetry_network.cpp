#include <WiFi.h>
#include <WiFiClient.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <new>
#include "config.h"
#include "telemetry_network.h"
#include "storage.h"
#include "runtime_config.h"
#include <math.h>
#include <ctype.h>
#include "alerts.h"
#include "power_arbiter.h"
#include "latest_slot_policy.h"
#include "demo_inference.h"
#include "direct_demo.h"
#include "direct_realtime_policy.h"
#include "remote_command_policy.h"

struct UploadItem {
  String kind;
  String json;
  bool rejected=false;
  uint32_t eventPersistenceTicket=0;
  bool ramRetryOnly=false;
  bool offlineQueued=false;
};
static QueueHandle_t uploadQueue=nullptr;
// Critical events retain their FIFO. Live telemetry uses ONE replaceable slot
// so SD recovery cannot turn the dashboard into minutes of stale playback.
static portMUX_TYPE uploadStateMux=portMUX_INITIALIZER_UNLOCKED;
static LatestSlot<UploadItem> latestTelemetry;
static bool eventInFlight=false,telemetryInFlight=false;
static uint32_t queueAllocationFailures=0;
static volatile int lastHttpCode=0;
static volatile uint32_t lastWebSuccess=0,sentCount=0;
static bool resendInProgress=false;
static wl_status_t lastPrintedWifiStatus=WL_NO_SHIELD;
static bool wifiTxPowerApplied=false;
static volatile uint8_t serverFailStreak=0;
static volatile uint32_t serverBackoffUntil=0;
static volatile uint32_t droppedTelemetryRetryCount=0;
static uint32_t lastOfflineTelemetrySpool=0;
static uint32_t commandPollIntervalMs=DEVICE_COMMAND_POLL_MS;
static uint32_t lastPlayedRemoteAudioId=0;
static void disposeUpload(UploadItem *item){
  if(!item)return;
  storageReleaseEventTicket(item->eventPersistenceTicket);
  delete item;
}
static UploadItem *makeUpload(const String &kind,const String &json,uint32_t ticket=0,bool catalog=false){
  UploadItem *item=new(std::nothrow) UploadItem{kind,json,false,ticket,catalog,false};
  if(item&&item->kind.length()==kind.length()&&item->json.length()==json.length())return item;
  // Caller still owns ticket when construction fails.
  delete item;
  portENTER_CRITICAL(&uploadStateMux);++queueAllocationFailures;portEXIT_CRITICAL(&uploadStateMux);
  return nullptr;
}
static void publishLatestTelemetry(UploadItem *item){
  portENTER_CRITICAL(&uploadStateMux);
  UploadItem *old=latestTelemetry.publish(item);
  if(old)++droppedTelemetryRetryCount;
  portEXIT_CRITICAL(&uploadStateMux);
  disposeUpload(old); // String/free operations must not run inside a critical section.
}
static UploadItem *takeLatestTelemetry(){
  portENTER_CRITICAL(&uploadStateMux);
  UploadItem *item=latestTelemetry.take();
  telemetryInFlight=item!=nullptr;
  portEXIT_CRITICAL(&uploadStateMux);
  return item;
}
static void finishLatestTelemetry(UploadItem *item,bool retry){
  portENTER_CRITICAL(&uploadStateMux);
  telemetryInFlight=false;
  if(retry){
    item=latestTelemetry.retry(item);
    if(item)++droppedTelemetryRetryCount; // Newer sample wins.
  }
  portEXIT_CRITICAL(&uploadStateMux);
  disposeUpload(item);
}
// Audio and HTTP run on different FreeRTOS tasks. A boolean "busy" flag is not
// sufficient: audio can observe false just before an HTTP request starts, and
// command/export requests used to bypass the flag entirely. This gate and
// in-flight counter share one critical section, so either the request reserves
// its slot first (audio waits) or audio closes the gate first (request defers).
static portMUX_TYPE httpStateMux=portMUX_INITIALIZER_UNLOCKED;
static volatile uint32_t httpRequestsInFlight=0;
static volatile bool httpAudioGate=false;
static bool directAudioRealtimeAllowed=false;
static uint32_t lastHttpPowerHoldLog=0;
static portMUX_TYPE realtimeMux=portMUX_INITIALIZER_UNLOCKED;
static directrealtime::LatestPacketSlot realtimeSlot;
static uint32_t realtimeLastAttempt=0,realtimeBackoffUntil=0,realtimeLastLog=0;
static uint32_t realtimeSent=0,realtimeDropped=0;
static uint8_t realtimeFailStreak=0;

static bool httpGateOpen(){
  portENTER_CRITICAL(&httpStateMux);
  const bool open=!httpAudioGate;
  portEXIT_CRITICAL(&httpStateMux);
  return open;
}

struct HttpFlightGuard {
  bool acquired=false,powerLocked=false;
  explicit HttpFlightGuard(bool compactDirect=false){
    const bool active=compactDirect&&DIRECT_REALTIME_ENABLED&&directDemoActive();
    portENTER_CRITICAL(&httpStateMux);
    if(directrealtime::gateAllows(compactDirect,active,httpAudioGate,directAudioRealtimeAllowed)){
      ++httpRequestsInFlight;acquired=true;
    }
    portEXIT_CRITICAL(&httpStateMux);
    if(acquired&&!powerAcquireHttp(compactDirect?25:HTTP_POWER_ARBITER_TIMEOUT_MS)){
      // Local SD/rail contention is not a server failure: remove the in-flight
      // reservation and let the normal queue retry without opening a socket or
      // advancing the web circuit breaker.
      portENTER_CRITICAL(&httpStateMux);
      if(httpRequestsInFlight>0)--httpRequestsInFlight;
      portEXIT_CRITICAL(&httpStateMux);
      acquired=false;
      if(millis()-lastHttpPowerHoldLog>=2000){
        lastHttpPowerHoldLog=millis();
        Serial.println("[PWR ] HOLD | HTTP deferred; MicroSD owns the high-current rail window");
      }
      return;
    }
    powerLocked=acquired;
  }
  ~HttpFlightGuard(){
    if(!acquired)return;
    if(powerLocked){powerReleaseHttp();powerLocked=false;}
    portENTER_CRITICAL(&httpStateMux);
    if(httpRequestsInFlight>0)--httpRequestsInFlight;
    portEXIT_CRITICAL(&httpStateMux);
  }
};

static bool serverAttemptAllowed(){
  // During voice playback, avoid Wi-Fi TX/HTTP bursts on core 0 and the power
  // rail. Queued telemetry/events resume immediately after the alert finishes.
  return !alertsAudioBusy() && !storageRecoveryBusy() && httpGateOpen() && networkOnline() &&
         (int32_t)(millis()-serverBackoffUntil)>=0;
}
static void noteServerResult(int code){
  // Any HTTP response below 500 proves the localhost server/socket is alive.
  if(code>0 && code<500){
    serverFailStreak=0;serverBackoffUntil=0;return;
  }
  if(serverFailStreak<10)++serverFailStreak;
  uint32_t shift=serverFailStreak>5?4:(serverFailStreak?serverFailStreak-1:0);
  uint32_t waitMs=WEB_BACKOFF_BASE_MS<<shift;
  if(waitMs>WEB_BACKOFF_MAX_MS)waitMs=WEB_BACKOFF_MAX_MS;
  serverBackoffUntil=millis()+waitMs;
  Serial.printf("[WEB ] BACKOFF | server unavailable | retry in %lu ms | streak=%u\n",
                (unsigned long)waitMs,(unsigned)serverFailStreak);
}


bool networkOnline(){return WiFi.status()==WL_CONNECTED&&strlen(SERVER_URL)>0;}


static String apiBaseUrl(){String base=SERVER_URL;while(base.endsWith("/"))base.remove(base.length()-1);return base;}
static void addApiHeaders(HTTPClient &http){
  http.addHeader("Connection","close");http.addHeader("Content-Type","application/json");
  if(strlen(SITES_BYPASS_TOKEN))http.addHeader("OAI-Sites-Authorization",String("Bearer ")+SITES_BYPASS_TOKEN);
  if(strlen(HTTP_API_KEY))http.addHeader("Authorization",String("Bearer ")+HTTP_API_KEY);
}
static String jsonStringField(const String &json,const char *key){
  String needle=String("\"")+key+"\":";int p=json.indexOf(needle);if(p<0)return String();p+=needle.length();
  while(p<(int)json.length()&&isspace((unsigned char)json[p]))++p;if(p>=(int)json.length()||json[p]!='\"')return String();++p;
  String out;bool escape=false;for(;p<(int)json.length();++p){char c=json[p];if(escape){if(c=='n')out+='\n';else if(c=='r')out+='\r';else if(c=='t')out+='\t';else out+=c;escape=false;}else if(c=='\\')escape=true;else if(c=='\"')break;else out+=c;}return out;
}
static uint32_t jsonUIntField(const String &json,const char *key,uint32_t fallback=0){
  String needle=String("\"")+key+"\":";int p=json.indexOf(needle);if(p<0)return fallback;p+=needle.length();while(p<(int)json.length()&&isspace((unsigned char)json[p]))++p;
  uint64_t value=0;bool any=false;while(p<(int)json.length()&&json[p]>='0'&&json[p]<='9'){any=true;value=value*10+(json[p++]-'0');if(value>0xFFFFFFFFULL)return 0xFFFFFFFFUL;}return any?(uint32_t)value:fallback;
}
static bool jsonBoolField(const String &json,const char *key,bool fallback=false){
  String needle=String("\"")+key+"\":";int p=json.indexOf(needle);if(p<0)return fallback;p+=needle.length();while(p<(int)json.length()&&isspace((unsigned char)json[p]))++p;
  if(json.substring(p,p+4)=="true")return true;if(json.substring(p,p+5)=="false")return false;return fallback;
}
static float jsonFloatField(const String &json,const char *key,float fallback=NAN){String needle=String("\"")+key+"\":";int p=json.indexOf(needle);if(p<0)return fallback;p+=needle.length();while(p<(int)json.length()&&isspace((unsigned char)json[p]))++p;int e=p;while(e<(int)json.length()&&((json[e]>='0'&&json[e]<='9')||json[e]=='-'||json[e]=='+'||json[e]=='.'||json[e]=='e'||json[e]=='E'))++e;if(e==p)return fallback;return json.substring(p,e).toFloat();}
static String jsonEscapeNetwork(const String &value){String out;out.reserve(value.length()+8);for(size_t i=0;i<value.length();++i){char c=value[i];if(c=='\\'||c=='\"'){out+='\\';out+=c;}else if(c=='\n')out+="\\n";else if(c=='\r')out+="\\r";else if((uint8_t)c>=0x20)out+=c;}return out;}

static int commandHttpGet(const String &url,String &body){
  body="";
  // Declare the guard before NetworkClient. Reverse destruction order keeps
  // the request counted until HTTPClient::end() and the socket object both
  // finish, so MAX98357A audio cannot overlap lwIP teardown.
  HttpFlightGuard flight;if(!flight.acquired)return -1;
  if(url.startsWith("https://")){
    WiFiClientSecure client;
#if TLS_ALLOW_INSECURE
    client.setInsecure();
#else
    if(strlen(TLS_ROOT_CA)==0)return -1;client.setCACert(TLS_ROOT_CA);
#endif
    HTTPClient http;if(!http.begin(client,url)){noteServerResult(-1);return -1;}http.setReuse(false);http.useHTTP10(true);http.setConnectTimeout(HTTP_CONNECT_TIMEOUT_MS);http.setTimeout(HTTP_RESPONSE_TIMEOUT_MS);addApiHeaders(http);int code=http.GET();if(code>0)body=http.getString();http.end();noteServerResult(code);return code;
  }
  WiFiClient client;HTTPClient http;if(!http.begin(client,url)){noteServerResult(-1);return -1;}http.setReuse(false);http.useHTTP10(true);http.setConnectTimeout(HTTP_CONNECT_TIMEOUT_MS);http.setTimeout(HTTP_RESPONSE_TIMEOUT_MS);addApiHeaders(http);int code=http.GET();if(code>0)body=http.getString();http.end();noteServerResult(code);return code;
}
static int commandHttpPost(const String &url,const String &payload,String &body){
  body="";
  HttpFlightGuard flight;if(!flight.acquired)return -1;
  if(url.startsWith("https://")){
    WiFiClientSecure client;
#if TLS_ALLOW_INSECURE
    client.setInsecure();
#else
    if(strlen(TLS_ROOT_CA)==0)return -1;client.setCACert(TLS_ROOT_CA);
#endif
    HTTPClient http;if(!http.begin(client,url)){noteServerResult(-1);return -1;}http.setReuse(false);http.useHTTP10(true);http.setConnectTimeout(HTTP_CONNECT_TIMEOUT_MS);http.setTimeout(HTTP_RESPONSE_TIMEOUT_MS);addApiHeaders(http);int code=http.POST(payload);if(code>0)body=http.getString();http.end();noteServerResult(code);return code;
  }
  WiFiClient client;HTTPClient http;if(!http.begin(client,url)){noteServerResult(-1);return -1;}http.setReuse(false);http.useHTTP10(true);http.setConnectTimeout(HTTP_CONNECT_TIMEOUT_MS);http.setTimeout(HTTP_RESPONSE_TIMEOUT_MS);addApiHeaders(http);int code=http.POST(payload);if(code>0)body=http.getString();http.end();noteServerResult(code);return code;
}
static String base64EncodeNetwork(const String &raw){
  static const char table[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  String out;out.reserve(((raw.length()+2)/3)*4);
  const uint8_t *data=(const uint8_t*)raw.c_str();const size_t len=raw.length();
  for(size_t i=0;i<len;i+=3){
    const uint32_t a=data[i];const uint32_t b=i+1<len?data[i+1]:0;const uint32_t c=i+2<len?data[i+2]:0;
    const uint32_t triple=(a<<16)|(b<<8)|c;
    out+=table[(triple>>18)&0x3F];out+=table[(triple>>12)&0x3F];
    out+=i+1<len?table[(triple>>6)&0x3F]:'=';out+=i+2<len?table[triple&0x3F]:'=';
  }
  return out;
}

// V8: copy one SD log into <project>/SD_Logs/<device_id>/ on the localhost PC.
// SD is read in 1 KiB slices and the SD SPI lock is released after every
// slice. Several slices are then grouped into one HTTP request for efficiency.
static bool exportLogToProject(const String &fileName,String &resultJson){
  resultJson="{\"error\":\"export_failed\"}";
  if(!networkOnline()||!fileName.length())return false;
  size_t offset=0,snapshotSize=0;bool haveSnapshot=false;String lastServerBody;
  for(;;){
    String batch;batch.reserve(SD_EXPORT_HTTP_BATCH_BYTES);
    while(batch.length()<SD_EXPORT_HTTP_BATCH_BYTES){
      if(haveSnapshot&&offset+batch.length()>=snapshotSize)break;
      const size_t room=SD_EXPORT_HTTP_BATCH_BYTES-batch.length();
      size_t request=min((size_t)SD_EXPORT_READ_SLICE_BYTES,room);
      if(haveSnapshot)request=min(request,snapshotSize-(offset+batch.length()));
      if(request==0)break;
      String slice;size_t currentSize=0;
      if(!storageReadLogChunk(fileName,offset+batch.length(),request,slice,currentSize)){
        resultJson="{\"error\":\"sd_read_failed\"}";return false;
      }
      if(!haveSnapshot){snapshotSize=currentSize;haveSnapshot=true;}
      // The active daily file may grow while it is exported. V8 exports the
      // exact snapshot length seen at the start and leaves newer bytes for the
      // next export, instead of holding the SD lock until driving stops.
      if(offset+batch.length()>snapshotSize){resultJson="{\"error\":\"file_changed\"}";return false;}
      if(slice.length())batch+=slice;
      if(offset+batch.length()>=snapshotSize||slice.length()==0)break;
      vTaskDelay(pdMS_TO_TICKS(2));
    }
    if(!haveSnapshot){resultJson="{\"error\":\"sd_read_failed\"}";return false;}
    const bool eof=offset+batch.length()>=snapshotSize;
    const String encoded=base64EncodeNetwork(batch);
    const String payload="{\"device_id\":\""+jsonEscapeNetwork(DEVICE_ID)+"\",\"file\":\""+
      jsonEscapeNetwork(fileName)+"\",\"offset\":"+String((unsigned long)offset)+
      ",\"total_size\":"+String((unsigned long)snapshotSize)+",\"eof\":"+(eof?"true":"false")+
      ",\"data_b64\":\""+encoded+"\"}";
    String body;const int code=commandHttpPost(apiBaseUrl()+"/api/sd/export-chunk",payload,body);
    if((code!=200&&code!=201)||body.indexOf("\"ok\":true")<0){
      Serial.printf("[SDEX] FAIL | %s | offset=%u/%u | HTTP=%d\n",fileName.c_str(),(unsigned)offset,(unsigned)snapshotSize,code);
      resultJson="{\"error\":\"project_upload_failed\",\"http_code\":"+String(code)+"}";return false;
    }
    lastServerBody=body;offset+=batch.length();
    Serial.printf("[SDEX] COPY | %s | %u/%u bytes%s\n",fileName.c_str(),(unsigned)offset,(unsigned)snapshotSize,eof?" | DONE":"");
    if(eof){
      const String relative=jsonStringField(lastServerBody,"relative_path");
      resultJson="{\"name\":\""+jsonEscapeNetwork(fileName)+"\",\"size\":"+String((unsigned long)snapshotSize)+
                 ",\"exported_bytes\":"+String((unsigned long)offset)+",\"relative_path\":\""+
                 jsonEscapeNetwork(relative)+"\"}";return true;
    }
    vTaskDelay(pdMS_TO_TICKS(4));
  }
}

static void pollDeviceCommand(){
  if(!serverAttemptAllowed())return;
  String response;String url=apiBaseUrl()+"/api/device-commands/next?device_id="+String(DEVICE_ID);
  int code=commandHttpGet(url,response);
  if(code!=200){commandPollIntervalMs=DEVICE_COMMAND_POLL_MS;return;}
  commandPollIntervalMs=remoteCommandPollInterval(jsonBoolField(response,"demo_active",false),
    jsonUIntField(response,"next_poll_ms",DEVICE_COMMAND_POLL_MS),DEVICE_COMMAND_POLL_MS);
  if(response.indexOf("\"command\":null")>=0)return;
  const uint32_t commandId=jsonUIntField(response,"id",0);const String action=jsonStringField(response,"action");if(!commandId||!action.length())return;
  bool ok=false;String result="{}";uint8_t audioAfterAck=0;
  // One bounded cached result makes demo inference idempotent when the ACK
  // socket fails and the server delivers the same command again. Neither path
  // creates live events, audio, SD records or synthetic GNSS coordinates.
  static uint32_t lastDemoCommandId=0;
  static bool lastDemoOk=false;
  static String lastDemoResult;
  if(action=="direct_demo_start" || action=="direct_demo_control"){
    ok=directDemoCommand(commandId,response,result);
  }else if(directDemoActive() && (action=="demo_infer" || action=="audio_play")){
    result="{\"error\":\"direct_demo_active_real_sensor_only\"}";
  }else if(action=="demo_infer"){
    if(commandId==lastDemoCommandId&&lastDemoResult.length()){
      ok=lastDemoOk;result=lastDemoResult;
      Serial.printf("[DEMO] ACK  | id=%lu | cached TinyML result; no repeated inference\n",
                    (unsigned long)commandId);
    }else{
      ok=demoInferenceCommand(response,result);
      lastDemoCommandId=commandId;lastDemoOk=ok;lastDemoResult=result;
    }
  }else if(action=="sd_list")ok=storageBuildLogListJson(result);
  else if(action=="sd_read"){
    String file=jsonStringField(response,"file");size_t lines=(size_t)jsonUIntField(response,"max_lines",SD_LOG_VIEW_MAX_LINES);
    ok=storageReadLogTailJson(file,lines,result);
  }else if(action=="sd_export"){
    const String file=jsonStringField(response,"file");
    ok=exportLogToProject(file,result);
  }else if(action=="sd_delete"){
    String fromDate=jsonStringField(response,"from_date"),toDate=jsonStringField(response,"to_date");
    bool deleteAll=jsonBoolField(response,"delete_all",false),deleteHazards=jsonBoolField(response,"delete_hazards",false);
    uint32_t fromEpoch=jsonUIntField(response,"from_epoch",0),toEpoch=jsonUIntField(response,"to_epoch",0xFFFFFFFFUL);
    ok=storageDeleteLogs(fromDate,toDate,deleteAll,deleteHazards,fromEpoch,toEpoch,result);
  }else if(action=="hazard_delete"){
    const String kind=jsonStringField(response,"kind");
    const double lat=jsonFloatField(response,"lat",NAN),lon=jsonFloatField(response,"lon",NAN);
    const float radius=jsonFloatField(response,"radius_m",8.0f);
    ok=storageDeleteHazardPoint(kind,lat,lon,radius,result);
  }else if(action=="config_get"){
    result="{\"config\":"+runtimeConfigJson()+"}";ok=true;
  }else if(action=="config_set"){
    const RuntimeConfig &c=runtimeConfigGet();
    ok=runtimeConfigUpdate(jsonFloatField(response,"overspeed_warning_kph",c.overspeedWarningKph),jsonFloatField(response,"overspeed_clear_kph",c.overspeedClearKph),jsonFloatField(response,"geofence_warning_m",c.geofenceWarningRadiusM),jsonFloatField(response,"geofence_rearm_m",c.geofenceRearmRadiusM),jsonFloatField(response,"pothole_confidence",c.potholeConfidence),jsonFloatField(response,"speed_bump_confidence",c.speedBumpConfidence),result);
  }else if(action=="audio_play"){
    // Auto Demo runs on the PC and therefore cannot call the local geofence
    // callback. Accept only the two embedded hazard voices. The sound is queued
    // after the command ACK below; queuing it earlier would close the HTTP audio
    // gate, lose the ACK and allow the same command to play again.
    const String sound=jsonStringField(response,"sound");
    if(sound=="pothole"){audioAfterAck=1;ok=true;result="{\"speaker_accepted\":true,\"sound\":\"pothole\"}";}
    else if(sound=="speed_bump"){audioAfterAck=2;ok=true;result="{\"speaker_accepted\":true,\"sound\":\"speed_bump\"}";}
    else result="{\"error\":\"invalid_audio_sound\"}";
  }else{
    result="{\"error\":\"unsupported_action\"}";
  }
  String payload="{\"device_id\":\""+jsonEscapeNetwork(DEVICE_ID)+"\",\"command_id\":"+String((unsigned long)commandId)+
                 ",\"ok\":"+String(ok?"true":"false")+",\"result\":"+result+"}";
  String ackBody;int ack=commandHttpPost(apiBaseUrl()+"/api/device-commands/result",payload,ackBody);
  Serial.printf("[%s] CMD  | id=%lu | %s | %s | HTTP=%d\n",action=="demo_infer"?"DEMO":"SDUI",
                (unsigned long)commandId,action.c_str(),ok?"OK":"FAIL",ack);
  const bool audioAllowed=remoteAudioMayPlay(ack,ok,jsonBoolField(ackBody,"ok",false),
    jsonStringField(ackBody,"status")=="done",jsonBoolField(ackBody,"play_audio",false),
    commandId,lastPlayedRemoteAudioId);
  if(audioAfterAck&&audioAllowed&&!directDemoActive()){
    if(audioAfterAck==1)alertPothole();else alertSpeedBump();
    lastPlayedRemoteAudioId=commandId;
    Serial.printf("[AUDIO] REMOTE | id=%lu | %s | ACK complete; voice queued once\n",
                  (unsigned long)commandId,audioAfterAck==1?"o_ga":"go_giam_toc");
  }else if(audioAfterAck){
    Serial.printf("[AUDIO] HOLD | id=%lu | server did not authorize a fresh completed voice command (HTTP=%d)\n",
                  (unsigned long)commandId,ack);
  }
}

static SendResult performHttpRequest(NetworkClient&client,const String&kind,const String&json,const String&url){
  // HTTPClient must be destroyed before the NetworkClient referenced by it.
  // Keeping both operations in this helper prevents the dangling-client bug
  // that can corrupt an lwIP pbuf when a connection fails or is closed early.
  HTTPClient http;
  if(!http.begin(client,url)){noteServerResult(-1);return SendResult::Retry;}
  http.setReuse(false);
  http.useHTTP10(true);
  http.setConnectTimeout(HTTP_CONNECT_TIMEOUT_MS);http.setTimeout(HTTP_RESPONSE_TIMEOUT_MS);http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  http.addHeader("Connection","close");
  http.addHeader("Content-Type","application/json");
  // Records read from the MicroSD outbox must never masquerade as current
  // telemetry on the dashboard. The localhost server stores this delivery
  // mode and keeps the newest LIVE packet authoritative while replay drains.
  http.addHeader("X-Telematics-Resend",resendInProgress?"1":"0");
  if(strlen(SITES_BYPASS_TOKEN))http.addHeader("OAI-Sites-Authorization",String("Bearer ")+SITES_BYPASS_TOKEN);
  if(strlen(HTTP_API_KEY))http.addHeader("Authorization",String("Bearer ")+HTTP_API_KEY);
  uint32_t started=millis();
  int code=http.POST(json);String response=code>0?http.getString():String();
  uint32_t elapsed=millis()-started;
  String detail=code<0?http.errorToString(code):String(code);
  http.end();
  lastHttpCode=code;
  noteServerResult(code);
  bool accepted=code==201&&(response.indexOf("\"ok\":true")>=0||response.indexOf("\"ok\": true")>=0);
  const char* phase=resendInProgress?"RESEND":"SEND";
  if(accepted){
    lastWebSuccess=millis();sentCount++;
    Serial.printf("[WEB ] OK   | %s %-9s | HTTP 201 | %lu ms | total=%lu\n",phase,kind.c_str(),(unsigned long)elapsed,(unsigned long)sentCount);
    return SendResult::Accepted;
  }
  Serial.printf("[WEB ] FAIL | %s %-9s | %s | %lu ms | will queue/retry\n",phase,kind.c_str(),detail.c_str(),(unsigned long)elapsed);
  if(response.length())Serial.printf("[WEB ] BODY | %.160s\n",response.c_str());
  // Discard only an explicitly identified payload error. A generic HTTP 400
  // can be produced by an older backend for a temporary database exception,
  // so it remains retryable unless the API supplies this machine-readable code.
  bool invalidJson=code==400&&response.indexOf("\"code\":\"invalid_json\"")>=0;
  if(invalidJson||code==413||code==415||code==422)return SendResult::Discard;
  return SendResult::Retry;
}

SendResult networkSend(const String&kind,const String&json){
  if(!serverAttemptAllowed())return SendResult::Retry;
  String base=SERVER_URL;while(base.endsWith("/"))base.remove(base.length()-1);
  String url=base+(kind=="event"?"/api/events":"/api/telemetry");
  // Close the race between serverAttemptAllowed() and the actual request. If
  // audio closed the gate in between, defer without treating it as a network
  // failure or advancing the circuit breaker.
  HttpFlightGuard flight;if(!flight.acquired)return SendResult::Retry;
  if(url.startsWith("https://")){
    WiFiClientSecure secure;
#if TLS_ALLOW_INSECURE
    secure.setInsecure();
#else
    if(strlen(TLS_ROOT_CA)==0){Serial.println("TLS_ROOT_CA is empty");return SendResult::Retry;}
    secure.setCACert(TLS_ROOT_CA);
#endif
    return performHttpRequest(secure,kind,json,url);
  }
  WiFiClient plain;
  return performHttpRequest(plain,kind,json,url);
}

static void serviceLatestTelemetry(){
  UploadItem *sample=takeLatestTelemetry();
  if(!sample)return;
  bool retry=true;
  if(sample->rejected){
    retry=!(storageReady()&&!storageRecoveryBusy()&&storageDeadLetter(sample->kind,sample->json,"http_rejected"));
  }else{
    const SendResult result=networkSend(sample->kind,sample->json);
    if(result==SendResult::Accepted)retry=false;
    else if(result==SendResult::Discard){
      sample->rejected=true;
      retry=!(storageReady()&&!storageRecoveryBusy()&&storageDeadLetter(sample->kind,sample->json,"http_rejected"));
    }else if(!sample->offlineQueued&&millis()-lastOfflineTelemetrySpool>=OFFLINE_TELEMETRY_SPOOL_MS){
      lastOfflineTelemetrySpool=millis();
      sample->offlineQueued=storageQueue(sample->kind,sample->json);
      // This is RAM admission, not an SD durability acknowledgement. Retain the
      // latest live copy regardless until HTTP accepts it or a newer one arrives.
    }
  }
  finishLatestTelemetry(sample,retry);
}

static void serviceDirectRealtime(){
  if(!DIRECT_REALTIME_ENABLED || !directDemoActive() || !networkOnline() ||
     strncmp(SERVER_URL,"http://",7)!=0 || !directrealtime::due(millis(),realtimeLastAttempt) ||
     (int32_t)(millis()-realtimeBackoffUntil)<0)return;
  portENTER_CRITICAL(&realtimeMux);
  const bool pending=realtimeSlot.pending();
  portEXIT_CRITICAL(&realtimeMux);
  if(!pending)return;
  // Same uploader task and per-call socket ownership as durable HTTP; no new
  // networking task/client shared with commands, audio or the Arduino loop.
  HttpFlightGuard flight(true);if(!flight.acquired)return;
  directrealtime::Packet packet;
  portENTER_CRITICAL(&realtimeMux);
  const bool have=realtimeSlot.take(packet);
  portEXIT_CRITICAL(&realtimeMux);
  if(!have)return;
  const uint32_t now=millis();
  if(!directrealtime::fresh(now,packet.capturedMs) ||
     (packet.canWasFresh&&!directrealtime::canFreshAtSend(now,packet.capturedMs,packet.canAgeMs,ECU_RUNTIME_STALE_MS))){
    ++realtimeDropped;return;
  }
  realtimeLastAttempt=now;
  WiFiClient client;HTTPClient http;
  int code=-1;
  if(http.begin(client,apiBaseUrl()+"/api/direct-demo/realtime")){
    http.setReuse(false);http.useHTTP10(true);http.setConnectTimeout(200);http.setTimeout(300);
    addApiHeaders(http);
    code=http.POST(reinterpret_cast<uint8_t*>(packet.json),packet.length);
    // The endpoint has a tiny JSON reply. Always finish/close before the
    // in-flight guard releases; never race socket teardown from another task.
    http.end();
  }
  if(code>=200&&code<300){
    ++realtimeSent;realtimeFailStreak=0;realtimeBackoffUntil=0;
  }else{
    if(realtimeFailStreak<4)++realtimeFailStreak;
    realtimeBackoffUntil=millis()+(250U<<(realtimeFailStreak-1));
    ++realtimeDropped;
  }
  // Fast motion is never replayed or written to SD. A later fresh sample wins.
  if(millis()-realtimeLastLog>=3000){
    realtimeLastLog=millis();
    Serial.printf("[LIVE] %s | direct 5Hz | HTTP=%d | sent=%lu dropped=%lu | audio=%s\n",
      code>=200&&code<300?"OK":"WAIT",code,(unsigned long)realtimeSent,(unsigned long)realtimeDropped,
      alertsAudioBusy()?"ON":"OFF");
  }
}

static void uploaderTask(void*){
  uint32_t lastResend=0,lastEventFlush=0,lastCommandPoll=0,lastBackoffLog=0,lastAudioHoldLog=0;
  UploadItem* item=nullptr;
  for(;;){
    // Independent of a blocked critical event: always allow the newest live
    // sample to reach HTTP as soon as the audio/recovery gates are released.
    serviceDirectRealtime();
    serviceLatestTelemetry();
    if(alertsAudioBusy() && millis()-lastAudioHoldLog>=1500){
      lastAudioHoldLog=millis();
      Serial.println("[WEB ] HOLD | audio: durable HTTP/SD paused; compact direct lane remains eligible after quiet startup");
    }

    // Durable events always win. When the server is in circuit-breaker
    // backoff we do NOT touch the SD resend files, which prevents an unreachable
    // web server from generating extra SD traffic during network failure.
    if(serverAttemptAllowed()&&millis()-lastEventFlush>=250){
      lastEventFlush=millis();resendInProgress=true;
      storageFlushEventQueue(networkSend,2);
      resendInProgress=false;
    }
    // An event resend above can start backoff during this same iteration.
    // Re-read the gate before polling so a failed resend cannot immediately
    // open a second socket or restart the retry countdown.
    if(serverAttemptAllowed()&&millis()-lastCommandPoll>=commandPollIntervalMs){
      lastCommandPoll=millis();pollDeviceCommand();
    }
    serviceDirectRealtime();

    if(!item){
      xQueueReceive(uploadQueue,&item,pdMS_TO_TICKS(directDemoActive()?10:60));
      portENTER_CRITICAL(&uploadStateMux);eventInFlight=item!=nullptr;portEXIT_CRITICAL(&uploadStateMux);
    }
    if(item){
      bool done=false;
      if(item->rejected){
        done=storageReady()&&!storageRecoveryBusy()&&storageDeadLetter(item->kind,item->json,"http_rejected");
      }else{
        SendResult result=networkSend(item->kind,item->json);
        if(result==SendResult::Accepted){
          done=true;
        }else if(result==SendResult::Retry){
          if(item->kind=="event"){
            if(item->ramRetryOnly){
              // Catalog-sync records are reproducible from potholes.csv /
              // speed_bumps.csv. Keep the current RAM copy until the server
              // returns instead of writing hundreds of sync records to SD.
              done=false;
            }else{
              // A RAM queue ticket is not yet durable. Keep the live HTTP copy
              // until the SD worker confirms that this exact ticket reached the
              // append-only event outbox.
              if(!item->eventPersistenceTicket)
                item->eventPersistenceTicket=storageQueueEvent(item->json);
              done=storageEventTicketDurable(item->eventPersistenceTicket);
            }
          }else{
            // Telemetry is already archived by storageAppendLog(). During a
            // server outage, spool only at a bounded cadence instead of doing
            // two SD writes every second (daily log + offline outbox).
            const uint32_t now=millis();
            if(now-lastOfflineTelemetrySpool>=OFFLINE_TELEMETRY_SPOOL_MS){
              lastOfflineTelemetrySpool=now;
              done=storageQueue(item->kind,item->json);
              if(done)Serial.printf("[SDQ ] QUEUED | %-9s | pending=%u bytes\n",item->kind.c_str(),(unsigned)storageQueueBytes());
            }else{
              done=storageQueue(item->kind,item->json);
            }
          }
        }else{
          item->rejected=true;
          done=storageReady()&&!storageRecoveryBusy()&&storageDeadLetter(item->kind,item->json,"http_rejected");
        }
      }
      if(done){
        disposeUpload(item);item=nullptr;
        portENTER_CRITICAL(&uploadStateMux);eventInFlight=false;portEXIT_CRITICAL(&uploadStateMux);
      }
      else vTaskDelay(pdMS_TO_TICKS(80));
    }

    serviceDirectRealtime();
    if(serverAttemptAllowed()&&millis()-lastResend>=1200){
      lastResend=millis();resendInProgress=true;
      storageFlushQueue(networkSend,RESEND_BATCH_SIZE);
      resendInProgress=false;
    }

    if(!serverAttemptAllowed() && !alertsAudioBusy() && networkOnline() && millis()-lastBackoffLog>=3000){
      lastBackoffLog=millis();
      uint32_t remain=(int32_t)(serverBackoffUntil-millis())>0?serverBackoffUntil-millis():0;
      const char *reason=storageRecoveryBusy()?"SD recovery":!httpGateOpen()?"audio gate":remain?"HTTP retry backoff":"local resource gate";
      Serial.printf("[WEB ] HOLD | %s | retry=%lu ms | latest telemetry replaced=%lu\n",
                    reason,(unsigned long)remain,(unsigned long)networkCoalescedTelemetryCount());
    }
    vTaskDelay(pdMS_TO_TICKS(1));
  }
}

void networkBegin(){
  const bool modeOk=WiFi.mode(WIFI_STA);WiFi.setAutoReconnect(true);WiFi.persistent(false);
  wifiTxPowerApplied=modeOk&&WiFi.setTxPower(WIFI_TX_POWER_LEVEL);
  Serial.printf("[WIFI] PWR  | STA=%s | requested 8.5 dBm=%s | SD/HTTP rail arbiter enabled\n",
                modeOk?"OK":"FAIL",wifiTxPowerApplied?"OK":"will retry after connect");
  uploadQueue=xQueueCreate(UPLOAD_QUEUE_LENGTH,sizeof(UploadItem*));
  if(uploadQueue&&xTaskCreatePinnedToCore(uploaderTask,"cloudUploader",8192,nullptr,1,nullptr,0)!=pdPASS){vQueueDelete(uploadQueue);uploadQueue=nullptr;Serial.println("ERROR: cloud uploader task not started");}
  if(String(WIFI_SSID)!="YOUR_WIFI_SSID"){
    Serial.printf("[WIFI] WAIT | connecting to %s\n",WIFI_SSID);
    WiFi.begin(WIFI_SSID,WIFI_PASSWORD);
  }else Serial.println("[WIFI] OFF  | configure WIFI_SSID in config.h");
}

void networkPoll(){
  wl_status_t status=WiFi.status();
  if(status!=lastPrintedWifiStatus){
    lastPrintedWifiStatus=status;
    if(status==WL_CONNECTED){
      // Some driver start/reconnect paths can reject the pre-WiFi.begin power
      // request. Re-apply it once per connection so SDHC cards never run beside
      // an unnoticed default high-power RF setting.
      wifiTxPowerApplied=WiFi.setTxPower(WIFI_TX_POWER_LEVEL);
      const float actualDbm=((int)WiFi.getTxPower())/4.0f;
      Serial.printf("[WIFI] OK   | IP=%s | RSSI=%d dBm | TX=%.2f dBm (%s) | server=%s\n",
                    WiFi.localIP().toString().c_str(),WiFi.RSSI(),actualDbm,
                    wifiTxPowerApplied?"limited":"CHECK POWER",SERVER_URL);
    }else{
      wifiTxPowerApplied=false;
      Serial.printf("[WIFI] WAIT | status=%d | automatic reconnect active\n",(int)status);
    }
  }
  // WiFi auto-reconnect owns recovery. Do not call WiFi.reconnect() here:
  // networkPoll runs on the Arduino loop task while HTTP POST runs on the
  // uploader task, and a station reconnect can otherwise race a live socket.
}

bool networkSubmit(const String&kind,const String&json){
  if(kind=="telemetry"){
    if(!uploadQueue)return storageQueue(kind,json);
    UploadItem *sample=makeUpload(kind,json);
    if(!sample)return storageQueue(kind,json);
    publishLatestTelemetry(sample);
    return true;
  }
  // Critical events are copied to BOTH paths: (1) RAM HTTP queue for immediate
  // web response and (2) asynchronous durable SD outbox. Duplicate delivery is
  // harmless because the V10 server deduplicates by event.id.
  const bool catalogSync=kind=="event" && json.indexOf("\"catalog_sync\":true")>=0;
  uint32_t eventPersistenceTicket=0;
  if(kind=="event" && !catalogSync){
    eventPersistenceTicket=storageQueueEvent(json);
    if(eventPersistenceTicket)
      Serial.printf("[EVQ ] RAM   | event ticket=%lu pending SD append | queue=%u bytes\n",
                    (unsigned long)eventPersistenceTicket,(unsigned)storageEventQueueBytes());
    else
      Serial.println("[EVQ ] WARN  | persistence queue full; keeping live HTTP/RAM copy");
  }
  if(catalogSync && !serverAttemptAllowed())return false;

  if(!uploadQueue){
    const bool admitted=eventPersistenceTicket!=0 || (!catalogSync && storageQueue(kind,json));
    storageReleaseEventTicket(eventPersistenceTicket);
    return admitted;
  }
  UploadItem* item=makeUpload(kind,json,eventPersistenceTicket,catalogSync);
  if(!item){
    const bool admitted=catalogSync?false:(eventPersistenceTicket!=0 || storageQueue(kind,json));
    storageReleaseEventTicket(eventPersistenceTicket);
    return admitted;
  }
  if(xQueueSend(uploadQueue,&item,0)!=pdTRUE){
    disposeUpload(item);
    // Never perform a direct blocking SD write from the Arduino producer path.
    // storageQueue()/storageQueueEvent() are asynchronous in V10.0.1.
    if(kind=="event")return eventPersistenceTicket!=0;
    return storageQueue(kind,json);
  }
  return true;
}

bool networkSubmitDirectRealtime(const String &json,uint32_t capturedMs,uint32_t canAgeMs,bool canFresh){
  if(!DIRECT_REALTIME_ENABLED || !uploadQueue || !directDemoActive() || strncmp(SERVER_URL,"http://",7)!=0)return false;
  portENTER_CRITICAL(&realtimeMux);
  const bool queued=realtimeSlot.publish(json.c_str(),json.length(),capturedMs,canAgeMs,canFresh);
  portEXIT_CRITICAL(&realtimeMux);
  return queued;
}

int networkLastHttpCode(){return lastHttpCode;}
uint32_t networkLastSuccessMs(){return lastWebSuccess;}
uint32_t networkSentCount(){return sentCount;}
size_t networkRamQueueDepth(){
  portENTER_CRITICAL(&uploadStateMux);
  const size_t active=(latestTelemetry.pending()?1U:0U)+(eventInFlight?1U:0U)+(telemetryInFlight?1U:0U);
  portEXIT_CRITICAL(&uploadStateMux);
  return active+(uploadQueue?uxQueueMessagesWaiting(uploadQueue):0);
}
uint32_t networkBackoffRemainingMs(){
  if((int32_t)(serverBackoffUntil-millis())<=0)return 0;
  return serverBackoffUntil-millis();
}
uint32_t networkCoalescedTelemetryCount(){
  portENTER_CRITICAL(&uploadStateMux);const uint32_t count=droppedTelemetryRetryCount;portEXIT_CRITICAL(&uploadStateMux);
  return count;
}
uint32_t networkQueueAllocFailureCount(){
  portENTER_CRITICAL(&uploadStateMux);const uint32_t count=queueAllocationFailures;portEXIT_CRITICAL(&uploadStateMux);
  return count;
}


bool networkHttpBusy(){
  portENTER_CRITICAL(&httpStateMux);
  const bool busy=httpRequestsInFlight!=0;
  portEXIT_CRITICAL(&httpStateMux);
  return busy;
}
bool networkWaitForIdleForAudio(uint32_t timeoutMs){
  // Atomically stop future requests before inspecting the counter. This closes
  // the old check-then-start race and also covers command/config/SD-export HTTP.
  portENTER_CRITICAL(&httpStateMux);
  httpAudioGate=true;
  directAudioRealtimeAllowed=false;
  portEXIT_CRITICAL(&httpStateMux);
  const uint32_t started=millis();
  while(networkHttpBusy()){
    if(millis()-started>=timeoutMs)return false;
    vTaskDelay(pdMS_TO_TICKS(10));
  }
  return true;
}
void networkExitAudioCritical(){
  portENTER_CRITICAL(&httpStateMux);
  httpAudioGate=false;
  directAudioRealtimeAllowed=false;
  portEXIT_CRITICAL(&httpStateMux);
}

void networkAllowDirectRealtimeForAudio(){
  portENTER_CRITICAL(&httpStateMux);
  if(httpAudioGate)directAudioRealtimeAllowed=DIRECT_REALTIME_DURING_AUDIO;
  portEXIT_CRITICAL(&httpStateMux);
}
