#include <WiFi.h>
#include <SPI.h>
#include <esp_system.h>
#include <math.h>
#include "config.h"
#include "types.h"
#include "can_bus.h"
#include "gnss.h"
#include "geofence_policy.h"
#include "motion_ai.h"
#include "alerts.h"
#include "storage.h"
#include "telemetry_network.h"
#include "shared_spi.h"
#include "runtime_config.h"
#include "direct_demo.h"
#include "direct_realtime_policy.h"
#include "road_event_policy.h"

// Keep a safe default so an incomplete localhost config still compiles.
#ifndef DEVICE_ID
#define DEVICE_ID "blackbox-esp32s3-01"
#endif

enum class HazardKind : uint8_t { Pothole = 1, SpeedBump = 2 };

struct GeofenceState {
  float previousDistance = INFINITY;
  bool armed = true;
  bool persisted = false;
};

EcuData ecu;
GnssData gnss;
AiData ai;
HazardPoint potholes[MAX_POTHOLES];
HazardPoint speedBumps[MAX_SPEED_BUMPS];
GeofenceState potholeStates[MAX_POTHOLES];
GeofenceState speedBumpStates[MAX_SPEED_BUMPS];
size_t potholeCount = 0;
size_t speedBumpCount = 0;

static uint32_t lastTelemetry = 0, lastInference = 0, lastSerialStatus = 0;
static uint32_t lastHazardPersistence = 0;
static uint32_t messageSequence = 0, localEventCounter = 0;
static String bootId;
static bool ecuStateKnown = false, lastEcuOnline = false;
static uint32_t bootStartedMs = 0, ecuBootDeadlineMs = 0;
static bool navigationReady = false;
static uint32_t navigationEpoch = 0;
static bool navigationWasStationary = false, navigationResumed = false;
static uint8_t aiSuccessfulInferences = 0;
static bool aiReady = false;
static bool overspeedLatched = false;
static uint32_t lastOverspeedRuntimeMs = 0;
static uint8_t overspeedHighFrames = 0, overspeedClearFrames = 0;
static uint16_t lastDtcCode = 0;
static bool lastDtcActive = false;
static double tripKm = 0, lastTripLat = 0, lastTripLon = 0;
static bool haveTripPoint = false;
static double lastNavigationLat = 0, lastNavigationLon = 0;
static bool haveNavigationPoint = false;
static uint32_t lastNavigationFixMs = 0;
static bool storageSessionLoaded = false;
static size_t catalogSyncPotholeIndex = 0, catalogSyncSpeedBumpIndex = 0;
static uint32_t lastCatalogSyncMs = 0;
static bool catalogSyncComplete = false;
static roadevent::Gate roadEventGate;
static roadevent::Decision roadEventDecision;
struct HazardObservation {
  bool direct = false, gpsUsable = false, currentGpsUsable = false;
  directdemo::Snapshot directSnapshot;
  double lat = 0, lon = 0;
  uint32_t firstInferenceMs = 0, epoch = 0;
  float firstConfidence = 0;
};
static HazardObservation roadEventObservation;
static String lastRoadEventId;
static const char *lastRoadEventLabel = "unknown", *lastRoadEventReason = "none";
static uint32_t lastRoadEventMs = 0;
static bool lastRoadEventPosition = false, lastRoadEventNewPoint = false;
static uint32_t detectionScopeChangedMs = 0;
static bool detectionScopeSettling = false;
static uint32_t lastDirectRealtime=0,directRealtimeSequence=0;


static const char *hazardTypeName(HazardKind kind);

static String makeEventId(const char *name) {
  ++localEventCounter;
  return String(DEVICE_ID) + "-" + bootId + "-" + String(millis()) + "-" +
         String(localEventCounter) + "-" + String(name);
}

static String makeCatalogEventId(HazardKind kind, const HazardPoint &point) {
  const long latE7 = lround(point.lat * 10000000.0);
  const long lonE7 = lround(point.lon * 10000000.0);
  return String(DEVICE_ID) + "-catalog-" + hazardTypeName(kind) + "-" +
         String(latE7) + "-" + String(lonE7);
}

static String quoted(const String &value) {
  String out = value;
  out.replace("\\", "\\\\");
  out.replace("\"", "\\\"");
  return "\"" + out + "\"";
}

static String roadEventJson() {
  const auto &cfg = runtimeConfigGet();
  const float threshold = ai.label == "go_giam_toc" ? cfg.speedBumpConfidence : cfg.potholeConfidence;
  return String("{\"state\":") + quoted(roadevent::stateName(roadEventDecision.state)) +
    ",\"reason\":" + quoted(roadEventDecision.reason) +
    ",\"threshold\":" + String(threshold, 4) +
    ",\"strong_threshold\":" + String(fmaxf(threshold, AI_HAZARD_STRONG_SCORE), 4) +
    ",\"candidate_windows\":" + String(roadEventDecision.windows) +
    ",\"required_windows\":" + String(roadEventDecision.requiredWindows) +
    ",\"last_event_id\":" + quoted(lastRoadEventId) +
    ",\"last_event_label\":" + quoted(lastRoadEventLabel) +
    ",\"last_event_uptime_ms\":" + String(lastRoadEventMs) +
    ",\"last_event_position_attached\":" + String(lastRoadEventPosition ? "true" : "false") +
    ",\"last_event_new_map_point\":" + String(lastRoadEventNewPoint ? "true" : "false") +
    ",\"last_event_reason\":" + quoted(lastRoadEventReason) + "}";
}

static void noteRoadEvent(const String &id, HazardKind kind, bool position, bool added, const char *reason) {
  lastRoadEventId = id; lastRoadEventLabel = hazardTypeName(kind); lastRoadEventMs = millis();
  lastRoadEventPosition = position; lastRoadEventNewPoint = added; lastRoadEventReason = reason;
}

static String roadConfirmationJson(const HazardObservation &observed) {
  return String(",\"detection_confirmed\":true,\"confirmation\":") + quoted(roadEventDecision.confirmation) +
    ",\"first_inference_uptime_ms\":" + String(observed.firstInferenceMs) +
    ",\"confirming_inference_uptime_ms\":" + String(ai.lastUpdateMs) +
    ",\"first_inference_confidence\":" + String(observed.firstConfidence, 4);
}

static String numberOrNull(float value, unsigned int digits = 2) {
  return isfinite(value) ? String(value, digits) : "null";
}

static String uint64Text(uint64_t value) {
  char text[24];
  snprintf(text, sizeof(text), "%llu", (unsigned long long)value);
  return String(text);
}

static double distanceM(double lat1, double lon1, double lat2, double lon2) {
  const double p1 = radians(lat1), p2 = radians(lat2);
  const double dp = radians(lat2 - lat1), dl = radians(lon2 - lon1);
  double h = sin(dp / 2) * sin(dp / 2) + cos(p1) * cos(p2) * sin(dl / 2) * sin(dl / 2);
  if (h < 0) h = 0;
  if (h > 1) h = 1;
  return 6371000.0 * 2 * atan2(sqrt(h), sqrt(1 - h));
}

// Minimum distance between a stored hazard and the complete movement segment.
// This prevents a 1 Hz GNSS fix from skipping over a 10 m warning circle.
static double segmentDistanceM(double lat1, double lon1, double lat2, double lon2,
                               double hazardLat, double hazardLon) {
  constexpr double earthRadiusM = 6371000.0;
  const double referenceLat = radians((lat1 + lat2 + hazardLat) / 3.0);
  const double x1 = radians(lon1 - hazardLon) * earthRadiusM * cos(referenceLat);
  const double y1 = radians(lat1 - hazardLat) * earthRadiusM;
  const double x2 = radians(lon2 - hazardLon) * earthRadiusM * cos(referenceLat);
  const double y2 = radians(lat2 - hazardLat) * earthRadiusM;
  const double dx = x2 - x1, dy = y2 - y1;
  const double lengthSquared = dx * dx + dy * dy;
  double t = lengthSquared > 0.0001 ? -(x1 * dx + y1 * dy) / lengthSquared : 0.0;
  if (t < 0) t = 0;
  if (t > 1) t = 1;
  const double x = x1 + t * dx, y = y1 + t * dy;
  return sqrt(x * x + y * y);
}

static bool ecuRuntimeFresh() {
  return ecu.online && ecu.vehicleSpeedValid && ecu.lastRuntimeMs != 0 &&
         (millis() - ecu.lastRuntimeMs <= ECU_RUNTIME_STALE_MS);
}

static bool gnssFixTrustworthy() {
  return gnss.valid && isfinite(gnss.hdop) && gnss.hdop <= GNSS_MAX_HDOP &&
         gnss.satellites >= GNSS_MIN_SATELLITES &&
         isfinite(gnss.lat) && isfinite(gnss.lon) &&
         fabs(gnss.lat) <= 90.0 && fabs(gnss.lon) <= 180.0;
}

static void updateNavigationReadinessOnFix() {
  // Called EVERY loop so a formerly held position expires even with no NMEA.
  const bool usable = gnssFixTrustworthy();
  navigationResumed = navigation::confirmedResume(navigationReady, navigationWasStationary,
    usable, gnss.filterStationary, navigationEpoch != gnss.positionEpoch);
  const bool discontinuity = !usable || navigationEpoch != gnss.positionEpoch;
  if (discontinuity) {
    haveNavigationPoint = false;
    haveTripPoint = false;
    // Never bridge an outage or an anchor adjustment as travelled distance.
    // Preserve a previously observed exit through a normal stop/resume, so
    // stopping before a hazard does not cancel its next approach warning.
    for (size_t i = 0; i < potholeCount; ++i) {
      if (!usable) potholeStates[i].armed = false;
      potholeStates[i].previousDistance = INFINITY;
    }
    for (size_t i = 0; i < speedBumpCount; ++i) {
      if (!usable) speedBumpStates[i].armed = false;
      speedBumpStates[i].previousDistance = INFINITY;
    }
  }
  if (usable && !navigationReady) {
    Serial.printf("[GNSS] READY | filter=%s | SAT=%lu | HDOP=%.1f\n",
                  gnss.filterState, (unsigned long)gnss.satellites, gnss.hdop);
  } else if (!usable && navigationReady) {
    Serial.printf("[GNSS] WAIT | filter=%s | navigation/geofence paused\n", gnss.filterState);
  }
  navigationReady = usable;
  navigationWasStationary = usable && gnss.filterStationary;
  navigationEpoch = gnss.positionEpoch;
}

static String baseJson(const char *type, const directdemo::Snapshot *observedDirect = nullptr) {
  String json;
  // Include the additional SD/audio diagnostics without repeated growth of
  // the main JSON buffer on the small internal heap.
  json.reserve(3584);
  const uint32_t sequence = ++messageSequence;
  const bool navigationFresh = navigationReady && gnssFixTrustworthy();
  const bool ecuSpeedFresh = ecuRuntimeFresh();
  const bool aiFresh = aiReady && ai.valid && millis() - ai.lastUpdateMs <= 3000;
  const CanDiagnostics canStatus = canGetDiagnostics();
  json = "{\"type\":" + quoted(type) + ",\"device_id\":" + quoted(DEVICE_ID) +
         ",\"boot_id\":" + quoted(bootId) + ",\"seq\":" + String(sequence);
  json += ",\"ts\":" + (gnss.timeValid ? quoted(gnss.utc) : String("null")) +
          ",\"uptime_ms\":" + String(millis());
  json += ",\"location\":{\"valid\":" + String(navigationFresh ? "true" : "false") +
          ",\"lat\":" + (navigationFresh ? String(gnss.lat, 7) : "null") +
          ",\"lon\":" + (navigationFresh ? String(gnss.lon, 7) : "null");
  json += ",\"speed_kph\":" + numberOrNull(navigationFresh ? gnss.speedKph : NAN) +
          ",\"satellites\":" + String(gnss.satellites) +
          ",\"hdop\":" + numberOrNull(gnss.hdop) +
          ",\"altitude_m\":" + numberOrNull(gnss.altitudeM) +
          ",\"course_deg\":" + numberOrNull(gnss.courseDeg);
  json += ",\"raw_valid\":" + String(gnss.rawValid ? "true" : "false") +
          ",\"raw_lat\":" + (gnss.rawValid ? String(gnss.rawLat, 7) : "null") +
          ",\"raw_lon\":" + (gnss.rawValid ? String(gnss.rawLon, 7) : "null") +
          ",\"raw_speed_kph\":" + numberOrNull(gnss.rawSpeedKph) +
          ",\"filter\":{\"version\":1,\"state\":" + quoted(gnss.filterState) +
          ",\"stationary\":" + String(navigationFresh && gnss.filterStationary ? "true" : "false") +
          ",\"segment_valid\":" + String(navigationFresh && gnss.filterSegmentValid ? "true" : "false") +
          ",\"fix_seq\":" + String(gnss.fixSequence) +
          ",\"position_epoch\":" + String(gnss.positionEpoch) +
          ",\"rejected_fixes\":" + String(gnss.rejectedFixes) + "}}";
  json += ",\"ecu\":{\"online\":" + String(ecu.online ? "true" : "false") +
          ",\"uptime_s\":" + String(ecu.uptimeSec) + ",\"status\":" + String(ecu.status);
  json += ",\"speed_kph\":" + numberOrNull(ecuSpeedFresh ? ecu.vehicleSpeedKph : NAN) +
          ",\"speed_source\":" + (ecuSpeedFresh ? quoted("potentiometer") : String("null")) +
          ",\"overspeed\":" + String(ecuSpeedFresh && overspeedLatched ? "true" : "false");
  json += ",\"runtime_contract\":" + String(ecu.runtimeContract) +
          ",\"rpm\":" + (ecu.online && ecu.rpmValid ? String(ecu.rpm) : String("null")) +
          ",\"adc_raw\":" + (ecuSpeedFresh ? String(ecu.adcRaw) : String("null"));
  json += ",\"temperature_c\":" + numberOrNull(ecu.online && ecu.temperatureValid ? ecu.temperatureC : NAN) +
          ",\"dtc_code\":" + (ecu.online ? String(ecu.dtcCode) : String("null")) +
          ",\"dtc_severity\":" + (ecu.online ? String(ecu.dtcSeverity) : String("null")) +
          ",\"dtc_active\":" + String(ecu.online && ecu.dtcActive ? "true" : "false") + "}";
  json += ",\"road\":{\"valid\":" + String(aiFresh ? "true" : "false") +
          ",\"label\":" + quoted(ai.label) + ",\"confidence\":" + numberOrNull(ai.confidence, 4) +
          ",\"x_g\":" + numberOrNull(ai.x, 4) + ",\"y_g\":" + numberOrNull(ai.y, 4) +
          ",\"z_g\":" + numberOrNull(ai.z, 4) + ",\"inference_ms\":" + String(ai.inferenceMs);
  json += ",\"scores\":{\"duong_bang_phang\":" + numberOrNull(ai.flatConfidence, 4) +
          ",\"go_giam_toc\":" + numberOrNull(ai.speedBumpConfidence, 4) +
          ",\"o_ga\":" + numberOrNull(ai.potholeConfidence, 4) + "},\"event\":" + roadEventJson() + "}";
  json += ",\"system\":{\"sd_ok\":" + String(storageReady() ? "true" : "false") +
          ",\"sd_state\":" + quoted(storageStateText()) +
          ",\"sd_last_error\":" + quoted(storageLastError()) +
          ",\"sd_recovery_busy\":" + String(storageRecoveryBusy() ? "true" : "false") +
          ",\"sd_frequency_hz\":" + String(storageFrequencyHz()) +
          ",\"sd_card_type\":" + quoted(storageCardTypeText()) +
          ",\"sd_total_bytes\":" + uint64Text(storageTotalBytes()) +
          ",\"sd_used_bytes\":" + uint64Text(storageUsedBytes()) +
          ",\"sd_daily_log_bytes\":" + uint64Text(storageDailyLogBytes()) +
          ",\"sd_daily_log_quota_bytes\":" + uint64Text(storageDailyLogQuotaBytes()) +
          ",\"sd_write_block_reason\":" + quoted(storageWriteBlockReason()) +
          ",\"sd_log_drop_count\":" + String(storageTelemetryLogDropCount()) +
          ",\"sd_log_ram_depth\":" + String(storageLogQueueDepth()) +
          ",\"sd_offline_ram_depth\":" + String(storageOfflineQueueDepth()) +
          ",\"sd_event_ram_depth\":" + String(storageEventRamQueueDepth()) +
          ",\"sd_log_coalesced\":" + String(storageTelemetryCoalescedCount()) +
          ",\"sd_offline_coalesced\":" + String(storageOfflineCoalescedCount()) +
          ",\"sd_queue_alloc_failures\":" + String(storageQueueAllocFailureCount()) +
          ",\"sd_worker_stage\":" + quoted(storageWorkerStage()) +
          ",\"sd_worker_stage_age_ms\":" + String(storageWorkerAgeMs()) +
          ",\"audio_pcm_gain_percent\":" + String(AUDIO_PCM_GAIN_PERCENT) +
          ",\"audio_busy\":" + String(alertsAudioBusy() ? "true" : "false") +
          ",\"wifi_rssi\":" + String(WiFi.status() == WL_CONNECTED ? WiFi.RSSI() : 0) +
          ",\"free_heap\":" + String(ESP.getFreeHeap()) +
          ",\"free_psram\":" + String(ESP.getFreePsram()) +
          ",\"queue_bytes\":" + String(storageQueueBytes()) +
          ",\"navigation_ready\":" + String(navigationFresh ? "true" : "false") +
          ",\"ai_ready\":" + String(aiFresh ? "true" : "false") +
          ",\"ecu_runtime_ready\":" + String(ecuSpeedFresh ? "true" : "false") +
          ",\"adxl_healthy\":" + String(motionSensorHealthy() ? "true" : "false") +
          ",\"adxl_fifo_overruns\":" + String(motionFifoOverrunCount()) +
          ",\"adxl_fifo_services\":" + String(motionFifoServiceCount()) +
          ",\"sd_io_failures\":" + String(storageIoFailureCount()) +
          ",\"sd_remounts\":" + String(storageRemountCount()) +
          ",\"sd_failure_streak\":" + String(storageIoFailureStreak()) +
          ",\"event_queue_bytes\":" + String(storageEventQueueBytes()) +
          ",\"network_last_http\":" + String(networkLastHttpCode()) +
          ",\"network_sent_count\":" + String(networkSentCount()) +
          ",\"network_backoff_ms\":" + String(networkBackoffRemainingMs()) +
          ",\"network_coalesced_telemetry\":" + String(networkCoalescedTelemetryCount()) +
          ",\"network_queue_alloc_failures\":" + String(networkQueueAllocFailureCount()) +
          ",\"firmware_version\":" + quoted(FIRMWARE_VERSION) +
          ",\"model_version\":" + quoted(MODEL_VERSION) +
          ",\"runtime_config\":" + runtimeConfigJson() +
          ",\"can\":{\"installed\":" + String(canStatus.installed ? "true" : "false") +
          ",\"rx_task\":" + String(canStatus.workerRunning ? "true" : "false") +
          ",\"rx_task_responsive\":" + String(canStatus.workerResponsive ? "true" : "false") +
          ",\"service_seen\":" + String(canStatus.serviceSeen ? "true" : "false") +
          ",\"service_cycles\":" + String(canStatus.serviceCycles) +
          ",\"service_age_ms\":" + (canStatus.serviceSeen ? String(canStatus.serviceAgeMs) : String("null")) +
          ",\"status_errors\":" + String(canStatus.statusErrors) +
          ",\"receive_errors\":" + String(canStatus.receiveErrors) +
          ",\"state\":" + String(canStatus.state) +
          ",\"last_error\":" + String(canStatus.lastError) +
          ",\"raw_rx\":" + String(canStatus.rawRx) +
          ",\"rejected_rx\":" + String(canStatus.rejectedRx) +
          ",\"rx_missed\":" + String(canStatus.rxMissed) +
          ",\"rx_overrun\":" + String(canStatus.rxOverrun) +
          ",\"tec\":" + String(canStatus.txErrorCounter) +
          ",\"rec\":" + String(canStatus.rxErrorCounter) +
          ",\"bus_errors\":" + String(canStatus.busErrors) +
          ",\"init_attempts\":" + String(canStatus.initAttempts) +
          ",\"recovery_attempts\":" + String(canStatus.recoveryAttempts) + "}}";
  json += ",\"sd_ok\":" + String(storageReady() ? "true" : "false") +
          ",\"wifi_rssi\":" + String(WiFi.status() == WL_CONNECTED ? WiFi.RSSI() : 0);
  // Root coordinates remain physical GNSS. The server derives a separate
  // virtual device only from this firmware-owned, occurrence-time snapshot.
  json += ",\"direct_demo\":" + (observedDirect ? directDemoSnapshotJson(*observedDirect) : directDemoSnapshotJson());
  return json;
}

static void deliver(const String &kind, const String &json) {
  if (SERIAL_PRINT_RAW_JSON) Serial.printf("[JSON] %s\n", json.c_str());
  // V10.0.1: the daily archive stores full-rate telemetry only. Critical events
  // already have their own dedicated outbox, so duplicating every event into
  // the daily log caused two SD writes at the exact instant ADXL345 detected a
  // pothole/speed bump. Removing that duplicate write materially reduces FIFO
  // overruns without weakening event delivery.
  if (kind == "telemetry") storageAppendLog(json, gnss.timeValid ? gnss.utc : String());
  if (!networkSubmit(kind, json)) Serial.printf("[TXQ ] FAIL | %s not admitted to upload/outbox RAM | check BUF capacity/allocation counters\n", kind.c_str());
}

static void printSystemStatus() {
  const uint32_t now = millis();
  Serial.println("+---------------- GATEWAY STATUS ----------------+");
  if (ecu.online) {
    Serial.printf("[CAN ] OK   | Node ECU -> ESP32-S3 | RX=%lu | ECU uptime=%lu s\n",
                  (unsigned long)ecu.rxFrameCount, (unsigned long)ecu.uptimeSec);
    if (ecuRuntimeFresh()) {
      if (ecu.temperatureValid)
        Serial.printf("      DATA | SPEED(CAN)=%.2f km/h | ADC=%u | TEMP=%.2f C | DTC=0x%02X/%u%s\n",
                      ecu.vehicleSpeedKph, ecu.adcRaw, ecu.temperatureC, ecu.dtcCode,
                      ecu.dtcSeverity, ecu.dtcActive ? " ACTIVE" : "");
      else
        Serial.printf("      DATA | SPEED(CAN)=%.2f km/h | ADC=%u | TEMP=INVALID | DTC=0x%02X/%u%s\n",
                      ecu.vehicleSpeedKph, ecu.adcRaw, ecu.dtcCode, ecu.dtcSeverity,
                      ecu.dtcActive ? " ACTIVE" : "");
      if (ecu.vehicleSpeedKph > runtimeConfigGet().overspeedWarningKph)
        Serial.printf("      WARN | OVERSPEED %.1f km/h > %.0f km/h\n", ecu.vehicleSpeedKph, runtimeConfigGet().overspeedWarningKph);
    } else if (ecu.rpmValid) {
      Serial.printf("      DATA | LEGACY RPM=%u | ADC=%u | reflash Arduino/NODE_ECU for vehicle speed\n",
                    ecu.rpm, ecu.adcRaw);
    } else {
      Serial.println("      DATA | waiting for a valid CAN 0x101 runtime frame");
    }
  } else {
    Serial.println("[CAN ] WAIT | no heartbeat 0x100 from Node ECU");
  }
  canPrintDiagnostics(ecu);
  if (directDemoActive()) {
    const auto &s = directDemoSnapshot();
    Serial.printf("[DIRECT] %s | simulated %.1f/%.1f m | CAN %.1f x %.1f = %.1f km/h | ADXL/TinyML REAL\n",
                  directdemo::stateName(s.state), s.distanceM, s.lengthM,
                  s.inputSpeed, s.multiplier, s.speed);
  }

  if (navigationReady && gnssFixTrustworthy())
    Serial.printf("[GNSS] OK   | %s | SAT=%lu | HDOP=%.1f | %.6f, %.6f | %.1f km/h | raw=%.1f km/h | rejected=%lu\n",
                  gnss.filterState, (unsigned long)gnss.satellites, gnss.hdop,
                  gnss.lat, gnss.lon, gnss.speedKph, gnss.rawSpeedKph, (unsigned long)gnss.rejectedFixes);
  else
    Serial.printf("[GNSS] WAIT | filter=%s | SAT=%lu | HDOP=%.1f\n", gnss.filterState,
                  (unsigned long)gnss.satellites, gnss.hdop);

  const bool aiFresh = aiReady && ai.valid && now - ai.lastUpdateMs <= 3000;
  if (!motionSensorHealthy())
    Serial.printf("[AI  ] FAIL | ADXL345 I2C 0x%02X not ready | check SDA%d/SCL%d, CS=3V3, SDO=GND\n",
                  ADXL345_I2C_ADDRESS, PIN_ADXL_SDA, PIN_ADXL_SCL);
  else if (aiFresh)
    Serial.printf("[AI  ] OK   | %-18s | %.1f%% | XYZ=%.3f,%.3f,%.3f g | %lu ms\n",
                  ai.label.c_str(), ai.confidence * 100.0f, ai.x, ai.y, ai.z,
                  (unsigned long)ai.inferenceMs);
  else
    Serial.printf("[AI  ] WAIT | startup/model windows %u/%u\n", (unsigned)aiSuccessfulInferences, (unsigned)AI_READY_INFERENCES);

  const size_t sdBytes = storageQueueBytes();
  if (storageReady()) {
    const char *writeBlock = storageWriteBlockReason();
    Serial.printf("[SD  ] %s | state=%s | %s | %s | used=%llu/%llu MB | SPI=%.1f MHz | queue=%u B | drops=%lu\n",
                  strcmp(writeBlock,"none")==0?"OK   ":"BLOCK",
                  storageStateText(),storageCardTypeText(),writeBlock,
                  (unsigned long long)(storageUsedBytes()/1048576ULL),
                  (unsigned long long)(storageTotalBytes()/1048576ULL),
                  storageFrequencyHz() / 1000000.0f, (unsigned)sdBytes,
                  (unsigned long)storageTelemetryLogDropCount());
  }
  else if (storageRecoveryBusy())
    Serial.printf("[SD  ] WAIT | state=%s | reason=%s | verification/settling; writes paused\n",
                  storageStateText(), storageLastError());
  else
    Serial.printf("[SD  ] RETRY | state=%s | reason=%s | automatic backoff active (no restart)\n",
                  storageStateText(), storageLastError());

  Serial.printf("[BUF ] RAM  | LOG=%u | OFFLINE=%u | EVENT=%u | worker=%s/%lu ms\n",
                (unsigned)storageLogQueueDepth(), (unsigned)storageOfflineQueueDepth(),
                (unsigned)storageEventRamQueueDepth(), storageWorkerStage(),
                (unsigned long)storageWorkerAgeMs());
  Serial.printf("      LOSS | log_replaced=%lu | offline_replaced=%lu | web_replaced=%lu | alloc_fail SD/WEB=%lu/%lu | heap=%lu B\n",
                (unsigned long)storageTelemetryCoalescedCount(), (unsigned long)storageOfflineCoalescedCount(),
                (unsigned long)networkCoalescedTelemetryCount(), (unsigned long)storageQueueAllocFailureCount(),
                (unsigned long)networkQueueAllocFailureCount(), (unsigned long)ESP.getFreeHeap());
  if (WiFi.status() != WL_CONNECTED)
    Serial.println("[WEB ] WAIT | Wi-Fi disconnected; bounded RAM/outbox pending (RAM is not durable)");
  else if (networkLastSuccessMs() && now - networkLastSuccessMs() <= 10000)
    Serial.printf("[WEB ] OK   | last HTTP 201=%lu ms ago | sent=%lu | RAM queue=%u\n",
                  (unsigned long)(now - networkLastSuccessMs()),
                  (unsigned long)networkSentCount(), (unsigned)networkRamQueueDepth());
  else
    Serial.printf("[WEB ] WAIT | server not confirmed | last HTTP=%d | RAM=%u | backoff=%lu ms | coalesced=%lu\n",
                  networkLastHttpCode(), (unsigned)networkRamQueueDepth(),
                  (unsigned long)networkBackoffRemainingMs(),
                  (unsigned long)networkCoalescedTelemetryCount());
  Serial.println("+------------------------------------------------+\n");
}

static int knownHazardIndex(const HazardPoint *points, size_t count, double lat, double lon, float radius) {
  for (size_t i = 0; i < count; ++i) {
    if (distanceM(lat, lon, points[i].lat, points[i].lon) <= radius) return int(i);
  }
  return -1;
}

static const char *hazardTypeName(HazardKind kind) {
  return kind == HazardKind::Pothole ? "o_ga" : "go_giam_toc";
}

static void emitSimpleEvent(const char *name, const char *severity) {
  Serial.printf("[EVENT] %-20s | severity=%s\n", name, severity);
  const String eventId = makeEventId(name);
  const String json = baseJson("event") + ",\"event\":{\"id\":" + quoted(eventId) +
                      ",\"name\":" + quoted(name) +
                      ",\"severity\":" + quoted(severity) +
                      (directDemoActive() ? String(",\"demo_mode\":\"direct\"") : String()) + "}}";
  deliver("event", json);
}

static void detectedDirectHazardEvent(HazardKind kind, const HazardObservation &observed) {
  bool added = false;
  const int index = directDemoDetectAt(uint8_t(kind), ai.confidence, EVENT_DUPLICATE_RADIUS_M,
                                      observed.directSnapshot, added);
  const bool pointAvailable = index >= 0;
  const char *name = kind == HazardKind::Pothole ? "pothole_detected" : "speed_bump_detected";
  const auto &snapshot = observed.directSnapshot;
  const auto point = pointAvailable ? directDemoHazard(size_t(index)).point : snapshot.point;
  const String eventId = makeEventId(name);
  noteRoadEvent(eventId, kind, pointAvailable, added, added ? "mapped" : pointAvailable ? "duplicate" : "capacity_full");
  const String json = baseJson("event", &snapshot) + ",\"event\":{\"id\":" + quoted(eventId) +
    ",\"name\":" + quoted(name) + ",\"severity\":\"warning\",\"demo_mode\":\"direct\"" +
    ",\"inference_source\":\"adxl345\",\"hazard_type\":" + quoted(hazardTypeName(kind)) +
    ",\"gps_attached\":" + String(pointAvailable ? "true" : "false") +
    ",\"position_source\":\"can_potentiometer_simulated\",\"lat\":" + String(point.lat, 7) +
    ",\"lon\":" + String(point.lon, 7) + ",\"confidence\":" + String(ai.confidence, 4) + roadConfirmationJson(observed) +
    ",\"new_map_point\":" + String(added ? "true" : "false") +
    ",\"saved_to_sd\":false,\"catalog_scope\":\"direct_session\",\"map_capacity_full\":" +
    String(!pointAvailable ? "true" : "false") + "}}";
  // Normal durable event outbox is reused; NEVER write virtual road points to
  // SD_POTHOLE_PATH / SD_SPEED_BUMP_PATH or the physical catalog arrays.
  deliver("event", json);
  Serial.printf("[DIRECT] AI | %s %.1f%% | map=%s | first detection silent; exit %.0f m, reenter %.0f m for voice\n",
                hazardTypeName(kind), ai.confidence * 100.0f,
                added ? "NEW" : pointAvailable ? "KNOWN" : "FULL",
                runtimeConfigGet().geofenceRearmRadiusM, runtimeConfigGet().geofenceWarningRadiusM);
}

static void checkDirectDemoWarnings() {
  static uint32_t lastAttemptMs=0;
  if(millis()-lastAttemptMs<100) return;
  lastAttemptMs=millis();
  int index;
  size_t next=0;
  while ((index = directDemoPendingWarning(next)) >= 0) {
    next=size_t(index)+1;
    const auto &hazard = directDemoHazard(size_t(index));
    const auto &snapshot=directDemoSnapshot();
    const float radius=runtimeConfigGet().geofenceWarningRadiusM;
    const bool current=millis()-hazard.warningAtMs<1500 && directDemoAudioCurrent(
      snapshot.session,snapshot.passIndex,hazard.point.lat,hazard.point.lon,radius);
    const bool queued=current && alertDirectHazard(hazard.kind,snapshot.session,
      snapshot.passIndex,hazard.point.lat,hazard.point.lon,radius);
    const HazardKind kind = HazardKind(hazard.kind);
    const char *name = kind == HazardKind::Pothole ? "pothole_proximity" : "speed_bump_proximity";
    // Emit one proximity event at entry, independently of speaker admission.
    // Queue pressure may retry briefly, never duplicate this event or pretend
    // a queued request proves that the physical speaker has played.
    if(!hazard.warningReported) {
    const String json = baseJson("event") + ",\"event\":{\"id\":" + quoted(makeEventId(name)) +
      ",\"name\":" + quoted(name) + ",\"severity\":\"warning\",\"demo_mode\":\"direct\"" +
      ",\"hazard_type\":" + quoted(hazardTypeName(kind)) + ",\"gps_attached\":true" +
      ",\"position_source\":\"can_potentiometer_simulated\",\"lat\":" + String(hazard.point.lat, 7) +
      ",\"lon\":" + String(hazard.point.lon, 7) + ",\"distance_m\":" + String(hazard.warningDistance, 1) +
      ",\"warning_radius_m\":" + String(radius, 1) +
      ",\"audio_queued\":" + String(queued?"true":"false") + "}}";
    deliver("event", json);
    directDemoReportWarning(size_t(index));
    }
    if(queued || !current) {
      directDemoDismissWarning(size_t(index));
      Serial.printf("[DIRECT] %s | %s | %.1f m <= %.1f m | %s\n",
        queued?"AUDIO QUEUED":"AUDIO SKIP",hazardTypeName(kind),hazard.warningDistance,radius,
        queued?"admitted, wait for [AUDIO] DONE; not playback proof":"stale / outside zone / CAN unavailable");
    }
  }
}

static size_t mergeCatalog(const char *path, HazardPoint *points, GeofenceState *states,
                           size_t count, size_t capacity) {
  constexpr size_t loadCapacity = MAX_POTHOLES > MAX_SPEED_BUMPS ? MAX_POTHOLES : MAX_SPEED_BUMPS;
  static HazardPoint loaded[loadCapacity];
  const size_t loadedCount = storageLoadHazards(path, loaded, loadCapacity);
  for (size_t i = 0; i < loadedCount; ++i) {
    const int existing = knownHazardIndex(points, count, loaded[i].lat, loaded[i].lon,
                                          EVENT_DUPLICATE_RADIUS_M);
    if (existing >= 0) {
      states[existing].persisted = true;
    } else if (count < capacity) {
      points[count] = loaded[i];
      states[count] = GeofenceState{};
      // A reboot inside a known warning circle must stay silent. The first
      // trustworthy fix outside 20 m arms this catalog point for a later entry.
      states[count].armed = false;
      states[count].persisted = true;
      ++count;
    }
  }
  return count;
}

static void saveFirstDirty(const char *path, HazardPoint *points, GeofenceState *states, size_t count) {
  for (size_t i = 0; i < count; ++i) {
    if (!states[i].persisted) {
      states[i].persisted = storageSaveHazard(path, points[i]);
      if (states[i].persisted) Serial.printf("[SD  ] OK   | delayed hazard saved to %s\n", path);
      return;
    }
  }
}

static void reloadHazardCatalogAfterSdChange() {
  if (!storageConsumeHazardCatalogChanged()) return;
  potholeCount = 0; speedBumpCount = 0;
  for (size_t i = 0; i < MAX_POTHOLES; ++i) potholeStates[i] = GeofenceState{};
  for (size_t i = 0; i < MAX_SPEED_BUMPS; ++i) speedBumpStates[i] = GeofenceState{};
  storageSessionLoaded = false;
  catalogSyncPotholeIndex = catalogSyncSpeedBumpIndex = 0;
  catalogSyncComplete = false; lastCatalogSyncMs = 0;
  Serial.println("[MAP ] RELOAD | hazard catalog changed by SD manager");
}

static void maintainHazardPersistence(uint32_t now) {
  if (!storageReady()) {
    storageSessionLoaded = false;
    return;
  }
  if (!storageSessionLoaded) {
    potholeCount = mergeCatalog(SD_POTHOLE_PATH, potholes, potholeStates, potholeCount, MAX_POTHOLES);
    speedBumpCount = mergeCatalog(SD_SPEED_BUMP_PATH, speedBumps, speedBumpStates,
                                  speedBumpCount, MAX_SPEED_BUMPS);
    storageSessionLoaded = true;
    catalogSyncPotholeIndex = 0;
    catalogSyncSpeedBumpIndex = 0;
    catalogSyncComplete = false;
    lastCatalogSyncMs = 0;
    Serial.printf("[MAP ] SYNC | MicroSD catalog: %u potholes, %u speed bumps\n",
                  (unsigned)potholeCount, (unsigned)speedBumpCount);
  }
  if (now - lastHazardPersistence < 1000) return;
  lastHazardPersistence = now;
  saveFirstDirty(SD_POTHOLE_PATH, potholes, potholeStates, potholeCount);
  saveFirstDirty(SD_SPEED_BUMP_PATH, speedBumps, speedBumpStates, speedBumpCount);
}

static void syncHazardCatalogToWeb(uint32_t now) {
  if (!storageSessionLoaded || catalogSyncComplete || !networkOnline() || networkBackoffRemainingMs() > 0) return;
  const size_t syncQueueLimit = (UPLOAD_QUEUE_LENGTH / 2 > 2) ? (UPLOAD_QUEUE_LENGTH / 2) : 2;
  if (networkRamQueueDepth() >= syncQueueLimit) return;
  if (lastCatalogSyncMs != 0 && now - lastCatalogSyncMs < 350) return;

  HazardKind kind;
  HazardPoint *point = nullptr;
  size_t itemNumber = 0, itemTotal = 0;

  if (catalogSyncPotholeIndex < potholeCount) {
    kind = HazardKind::Pothole;
    point = &potholes[catalogSyncPotholeIndex];
    itemNumber = catalogSyncPotholeIndex + 1;
    itemTotal = potholeCount;
  } else if (catalogSyncSpeedBumpIndex < speedBumpCount) {
    kind = HazardKind::SpeedBump;
    point = &speedBumps[catalogSyncSpeedBumpIndex];
    itemNumber = catalogSyncSpeedBumpIndex + 1;
    itemTotal = speedBumpCount;
  } else {
    catalogSyncComplete = true;
    Serial.printf("[MAP ] WEB  | hazard catalog synchronized: %u potholes, %u speed bumps\n",
                  (unsigned)potholeCount, (unsigned)speedBumpCount);
    return;
  }

  const char *eventName = kind == HazardKind::Pothole ? "pothole_catalog_sync" : "speed_bump_catalog_sync";
  const String eventId = makeCatalogEventId(kind, *point);
  const String json = baseJson("event") + ",\"event\":{\"id\":" + quoted(eventId) +
                      ",\"name\":" + quoted(eventName) +
                      ",\"severity\":\"info\",\"gps_attached\":true,\"catalog_sync\":true" +
                      String(",\"lat\":") + String(point->lat, 7) +
                      ",\"lon\":" + String(point->lon, 7) +
                      ",\"confidence\":" + String(point->confidence, 4) +
                      ",\"hazard_epoch\":" + String((unsigned long)point->epoch) + "}}";
  if (!networkSubmit("event", json)) return;

  lastCatalogSyncMs = now;
  if (kind == HazardKind::Pothole) ++catalogSyncPotholeIndex;
  else ++catalogSyncSpeedBumpIndex;
  Serial.printf("[MAP ] WEB  | sync %-13s %u/%u\n", hazardTypeName(kind),
                (unsigned)itemNumber, (unsigned)itemTotal);
}

static void detectedHazardEvent(HazardKind kind, const HazardObservation &observed) {
  if (observed.direct != directDemoActive() || (observed.direct &&
      (strcmp(observed.directSnapshot.session, directDemoSnapshot().session) ||
       observed.directSnapshot.passIndex != directDemoSnapshot().passIndex))) {
    noteRoadEvent(String(), kind, false, false, "session_changed");
    return;
  }
  if (observed.direct) {
    detectedDirectHazardEvent(kind, observed);
    return;
  }
  HazardPoint *points = kind == HazardKind::Pothole ? potholes : speedBumps;
  GeofenceState *states = kind == HazardKind::Pothole ? potholeStates : speedBumpStates;
  size_t &count = kind == HazardKind::Pothole ? potholeCount : speedBumpCount;
  const size_t capacity = kind == HazardKind::Pothole ? MAX_POTHOLES : MAX_SPEED_BUMPS;
  const char *path = kind == HazardKind::Pothole ? SD_POTHOLE_PATH : SD_SPEED_BUMP_PATH;
  const char *eventName = kind == HazardKind::Pothole ? "pothole_detected" : "speed_bump_detected";
  const char *severity = kind == HazardKind::Pothole ? "warning" : "info";

  // Keep the first qualifying inference position, not the later position after
  // temporal confirmation. This is NOT a claim to locate the exact wheel hit.
  const bool currentGpsUsable = observed.currentGpsUsable;
  const bool gpsUsable = observed.gpsUsable;
  const double hazardLat = observed.lat, hazardLon = observed.lon;
  bool added = false, saved = false, capacityFull = false;
  int index = -1;
  if (gpsUsable) {
    index = knownHazardIndex(points, count, hazardLat, hazardLon, EVENT_DUPLICATE_RADIUS_M);
    if (index < 0 && count < capacity) {
      points[count] = HazardPoint{hazardLat, hazardLon, observed.firstInferenceMs, ai.confidence, observed.epoch};
      states[count] = GeofenceState{};
      states[count].armed = false;             // require an observed exit before later proximity voice
      states[count].previousDistance = 0.0f;
      // V7: do NOT perform a second synchronous SD write here. The event itself
      // is immediately persisted by the dedicated durable outbox in
      // networkSubmit(); the hazard CSV is saved by maintainHazardPersistence()
      // on its next pass. ADXL345 now uses a separate I2C bus, while this also
      // avoids unnecessary bursts of writes to the MicroSD card.
      states[count].persisted = false;
      saved = false;
      index = int(count++);
      added = true;
    } else if (index < 0) {
      capacityFull = true;
    }
  }

  const String eventId = makeEventId(eventName);
  const bool pointAvailable = gpsUsable && index >= 0;
  noteRoadEvent(eventId, kind, pointAvailable, added, added ? "mapped" : pointAvailable ? "duplicate" : capacityFull ? "capacity_full" : "no_position");
  const double eventLat = pointAvailable ? points[index].lat : 0.0;
  const double eventLon = pointAvailable ? points[index].lon : 0.0;
  String json = baseJson("event") + ",\"event\":{\"id\":" + quoted(eventId) +
                ",\"name\":" + quoted(eventName) +
                ",\"severity\":" + quoted(severity) +
                ",\"hazard_type\":" + quoted(hazardTypeName(kind)) +
                ",\"gps_attached\":" + String(pointAvailable ? "true" : "false") +
                ",\"lat\":" + (pointAvailable ? String(eventLat, 7) : String("null")) +
                ",\"lon\":" + (pointAvailable ? String(eventLon, 7) : String("null")) +
                ",\"confidence\":" + String(ai.confidence, 4) + roadConfirmationJson(observed) +
                ",\"new_map_point\":" + String(added ? "true" : "false") +
                ",\"saved_to_sd\":" + String(saved ? "true" : "false") +
                ",\"hazard_epoch\":" + String((unsigned long)(pointAvailable ? points[index].epoch : observed.epoch)) +
                ",\"map_capacity_full\":" + String(capacityFull ? "true" : "false") + "}}";
  Serial.printf("[EVENT] %-19s | confidence=%.1f%% | GPS=%s | new map point=%s\n",
                kind == HazardKind::Pothole ? "POTHOLE DETECTED" : "SPEED BUMP DETECTED",
                ai.confidence * 100.0f, gpsUsable ? (currentGpsUsable ? "YES" : "LAST-STABLE") : "NO", added ? "YES" : "NO");
  if(added && !saved) Serial.println("[SD  ] DEFER | hazard catalog CSV write deferred; durable event outbox has priority");
  deliver("event", json);
  // The first TinyML encounter is intentionally silent. Voice belongs only
  // to a subsequent geofence approach after this point has re-armed at 20 m.
  if (added) {
    Serial.printf("[AUDIO] HOLD | %-13s | recorded only; leave %.0f m then re-enter %.0f m for voice\n",
                  hazardTypeName(kind), runtimeConfigGet().geofenceRearmRadiusM, runtimeConfigGet().geofenceWarningRadiusM);
  } else if (gpsUsable && index >= 0) {
    // Preserve the geofence state for a known point. On a return pass the
    // next GNSS fix may be the one that crosses 10 m and must still warn.
    Serial.printf("[AUDIO] HOLD | %-13s | known point; 10 m geofence controls this pass\n",
                  hazardTypeName(kind));
  } else {
    Serial.printf("[AUDIO] HOLD | %-13s | event only; no usable GPS point, no proximity voice yet\n",
                  hazardTypeName(kind));
  }
}

static void checkCatalogGeofence(HazardKind kind, HazardPoint *points, GeofenceState *states,
                                 size_t count, bool segmentUsable, bool allowRearm) {
  for (size_t i = 0; i < count; ++i) {
    const float currentDistance = float(distanceM(gnss.lat, gnss.lon, points[i].lat, points[i].lon));
    const float segmentDistance = segmentUsable
      ? float(segmentDistanceM(lastNavigationLat, lastNavigationLon, gnss.lat, gnss.lon,
                               points[i].lat, points[i].lon))
      : currentDistance;

    if (!states[i].armed) {
      if (allowRearm && currentDistance >= runtimeConfigGet().geofenceRearmRadiusM) {
        const bool observedExit = isfinite(states[i].previousDistance);
        states[i].armed = true;
        // Do not flood Serial at boot when a large catalog is first armed far
        // from the vehicle; log only an exit observed during this runtime.
        if (observedExit) {
          Serial.printf("[GEOF] ARMED | %-13s #%u | distance=%.1f m\n",
                        hazardTypeName(kind), (unsigned)(i + 1), currentDistance);
        }
      }
      states[i].previousDistance = currentDistance;
      continue;
    }

    if (navigation::geofenceShouldWarn(states[i].armed, currentDistance, states[i].previousDistance,
          segmentDistance, segmentUsable, runtimeConfigGet().geofenceWarningRadiusM,
          GEOFENCE_APPROACH_EPSILON_M)) {
      states[i].armed = false;
      const float warningDistance = min(currentDistance, segmentDistance);
      const char *eventName = kind == HazardKind::Pothole ? "pothole_proximity" : "speed_bump_proximity";
      const String eventId = makeEventId(eventName);
      const String json = baseJson("event") + ",\"event\":{\"id\":" + quoted(eventId) +
                          ",\"name\":" + quoted(eventName) +
                          ",\"severity\":\"warning\",\"hazard_type\":" +
                          quoted(hazardTypeName(kind)) + ",\"gps_attached\":true" +
                          ",\"lat\":" + String(points[i].lat, 7) +
                          ",\"lon\":" + String(points[i].lon, 7) +
                          ",\"distance_m\":" + String(warningDistance, 1) + "}}";
      Serial.printf("[GEOF] WARN | %-13s #%u | %.1f m | voice once until vehicle leaves %.0f m\n",
                    hazardTypeName(kind), (unsigned)(i + 1), warningDistance,
                    runtimeConfigGet().geofenceRearmRadiusM);
      // Reserve the speaker/audio critical window before the event enters the
      // SD + HTTP queues. This mirrors overspeed handling and prevents a new
      // transaction from making the one-shot geofence voice time out.
      if (kind == HazardKind::Pothole) alertPothole(); else alertSpeedBump();
      deliver("event", json);
    }
    states[i].previousDistance = currentDistance;
  }
}

static void checkGeofenceOnNewFix() {
  // Physical GNSS still logs normally, but do not play unrelated real-road
  // geofences while the classroom demo owns the warning position.
  if (directDemoActive()) { haveNavigationPoint = false; return; }
  if (!gnss.locationUpdated || !navigationReady || !gnssFixTrustworthy()) return;
  const uint32_t now = millis();
  const float movement = haveNavigationPoint
    ? float(distanceM(lastNavigationLat, lastNavigationLon, gnss.lat, gnss.lon)) : 0.0f;
  const bool segmentUsable = gnss.filterSegmentValid && haveNavigationPoint && now - lastNavigationFixMs <= GEOFENCE_MAX_SEGMENT_GAP_MS &&
                              movement <= GEOFENCE_MAX_SEGMENT_LENGTH_M;
  if (!gnss.filterStationary && segmentUsable) {
    checkCatalogGeofence(HazardKind::Pothole, potholes, potholeStates, potholeCount, true, true);
    checkCatalogGeofence(HazardKind::SpeedBump, speedBumps, speedBumpStates, speedBumpCount, true, true);
  } else if (navigationResumed && !gnss.filterStationary) {
    // Confirmed stop -> motion is not a GPS outage. An already-armed point
    // may be warned at the current fix inside its circle, without connecting
    // the released anchor offset or rearming any newly discovered point.
    checkCatalogGeofence(HazardKind::Pothole, potholes, potholeStates, potholeCount, false, false);
    checkCatalogGeofence(HazardKind::SpeedBump, speedBumps, speedBumpStates, speedBumpCount, false, false);
  } else {
    // Retain a baseline, but do not arm or sound from a held/reacquired point.
    for (size_t i = 0; i < potholeCount; ++i)
      potholeStates[i].previousDistance = float(distanceM(gnss.lat, gnss.lon, potholes[i].lat, potholes[i].lon));
    for (size_t i = 0; i < speedBumpCount; ++i)
      speedBumpStates[i].previousDistance = float(distanceM(gnss.lat, gnss.lon, speedBumps[i].lat, speedBumps[i].lon));
  }
  lastNavigationLat = gnss.lat;
  lastNavigationLon = gnss.lon;
  lastNavigationFixMs = now;
  haveNavigationPoint = true;
}

static void updateTripOnNewFix() {
  if (!gnss.locationUpdated || !navigationReady || !gnssFixTrustworthy()) return;
  if (haveTripPoint && gnss.filterSegmentValid && !gnss.filterStationary) {
    const double step = distanceM(lastTripLat, lastTripLon, gnss.lat, gnss.lon);
    if (isfinite(step) && step >= 0.0 && step <= 500.0) tripKm += step / 1000.0;
  }
  lastTripLat = gnss.lat;
  lastTripLon = gnss.lon;
  haveTripPoint = true;
}

static void checkEcuEvents() {
  if (!ecuStateKnown) {
    if (ecu.online) {
      ecuStateKnown = true;
      lastEcuOnline = true;
      Serial.printf("[CAN ] OK   | Node ECU -> ESP32-S3 established | node=%u | FW=%u.%u | heartbeat 0x100\n",
                    ecu.nodeId, ecu.fwMajor, ecu.fwMinor);
    } else if (millis() >= ecuBootDeadlineMs) {
      ecuStateKnown = true;
      lastEcuOnline = false;
      Serial.println("[CAN ] FAIL | Node ECU heartbeat timeout");
      emitSimpleEvent("ecu_offline", "critical");
    }
  } else if (ecu.online != lastEcuOnline) {
    Serial.printf("[CAN ] %s | Node ECU -> ESP32-S3 %s\n", ecu.online ? "OK  " : "FAIL",
                  ecu.online ? "reconnected" : "disconnected");
    emitSimpleEvent(ecu.online ? "ecu_recovered" : "ecu_offline",
                    ecu.online ? "success" : "critical");
    lastEcuOnline = ecu.online;
  }
  if (ecu.online && ecu.dtcActive && (!lastDtcActive || ecu.dtcCode != lastDtcCode))
    emitSimpleEvent("dtc_active", "critical");
  lastDtcActive = ecu.online && ecu.dtcActive;
  lastDtcCode = ecu.dtcCode;

  // Overspeed is a driving warning, not a DTC. Evaluate each NEW 0x101 frame
  // only once, then require several consecutive frames. This prevents loop()
  // iterations or a single ADC transient from producing a startup warning.
  if (millis() - bootStartedMs < AUDIO_BOOT_INHIBIT_MS) {
    overspeedLatched = false;
    overspeedHighFrames = overspeedClearFrames = 0;
    lastOverspeedRuntimeMs = ecu.lastRuntimeMs;
  } else if (ecuRuntimeFresh() && ecu.lastRuntimeMs != lastOverspeedRuntimeMs) {
    lastOverspeedRuntimeMs = ecu.lastRuntimeMs;
    const bool above = ecu.vehicleSpeedKph > runtimeConfigGet().overspeedWarningKph;
    const bool clear = ecu.vehicleSpeedKph <= runtimeConfigGet().overspeedClearKph;
    if (!overspeedLatched) {
      overspeedClearFrames = 0;
      if (above) {
        if (overspeedHighFrames < 255) ++overspeedHighFrames;
        if (overspeedHighFrames >= OVERSPEED_CONFIRM_FRAMES) {
          overspeedLatched = true;
          overspeedHighFrames = 0;
          Serial.printf("[SPEED] WARN | %.1f km/h > %.0f km/h | voice queued\n",
                        ecu.vehicleSpeedKph, runtimeConfigGet().overspeedWarningKph);
          // Reserve the audio critical window BEFORE queueing the event. The
          // alert call sets its pending flag synchronously, so SD/HTTP workers
          // stop starting new transactions while the event is queued in RAM.
          alertOverspeed();
          emitSimpleEvent("overspeed", "warning");
        }
      } else overspeedHighFrames = 0;
    } else {
      overspeedHighFrames = 0;
      if (clear) {
        if (overspeedClearFrames < 255) ++overspeedClearFrames;
        if (overspeedClearFrames >= OVERSPEED_CONFIRM_FRAMES) {
          overspeedLatched = false;
          overspeedClearFrames = 0;
          Serial.printf("[SPEED] CLEAR | %.1f km/h <= %.0f km/h\n",
                        ecu.vehicleSpeedKph, runtimeConfigGet().overspeedClearKph);
          cancelOverspeedAlert();
          emitSimpleEvent("overspeed_cleared", "success");
        }
      } else overspeedClearFrames = 0;
    }
  } else if (!ecu.online) {
    overspeedLatched = false;
    cancelOverspeedAlert();
    overspeedHighFrames = overspeedClearFrames = 0;
    lastOverspeedRuntimeMs = 0;
  }
}

static void runInference() {
  if (!motionInfer(ai)) return;

  // A 200-sample model window straddling start/stop/repeat must never record a
  // virtual bump into the real catalog (or vice versa). Continue true sensing
  // and telemetry while waiting ONE model window, not a long startup delay.
  if (detectionScopeSettling) {
    const float frequency = motionModelFrequencyHz();
    const uint32_t windowMs = frequency > 0 ? uint32_t(ceilf(motionModelSampleCount() * 1000.0f / frequency)) : 2000;
    if (millis() - detectionScopeChangedMs < windowMs) {
      roadEventDecision = roadEventGate.observe(0, ai.confidence, .8f, aiReady, true, millis());
      return;
    }
    detectionScopeSettling = false;
  }

  if (aiSuccessfulInferences < 255) ++aiSuccessfulInferences;
  const bool graceFinished = millis() - bootStartedMs >= AI_STARTUP_GRACE_MS;
  if (!aiReady && graceFinished && aiSuccessfulInferences >= AI_READY_INFERENCES) {
    aiReady = true;
    Serial.printf("[AI  ] READY | %u valid inference windows; startup transients ignored\n",
                  (unsigned)aiSuccessfulInferences);
  }
  if (!aiReady) {
    roadEventDecision = roadEventGate.observe(0, ai.confidence, .8f, false, false, millis());
    return;
  }

  const uint8_t kind = ai.label == "o_ga" ? uint8_t(HazardKind::Pothole) :
                       ai.label == "go_giam_toc" ? uint8_t(HazardKind::SpeedBump) : 0;
  const float threshold = kind == uint8_t(HazardKind::SpeedBump)
    ? runtimeConfigGet().speedBumpConfidence : runtimeConfigGet().potholeConfidence;
  roadEventDecision = roadEventGate.observe(kind, ai.confidence, threshold, aiReady, false,
    millis(), AI_HAZARD_CONFIRM_WINDOWS, AI_HAZARD_STRONG_SCORE, INFERENCE_PERIOD_MS * 3);
  if (roadEventDecision.firstObservation) {
    roadEventObservation = HazardObservation{};
    roadEventObservation.direct = directDemoActive();
    roadEventObservation.firstInferenceMs = ai.lastUpdateMs;
    roadEventObservation.firstConfidence = ai.confidence;
    roadEventObservation.epoch = gnss.timeValid ? gnss.epoch : 0;
    if (roadEventObservation.direct) {
      roadEventObservation.directSnapshot = directDemoSnapshot();
    } else {
      roadEventObservation.currentGpsUsable = navigationReady && gnssFixTrustworthy();
      const bool recentStableGps = haveNavigationPoint && lastNavigationFixMs != 0 &&
                                   millis() - lastNavigationFixMs <= GNSS_STALE_MS;
      roadEventObservation.gpsUsable = roadEventObservation.currentGpsUsable || recentStableGps;
      roadEventObservation.lat = roadEventObservation.currentGpsUsable ? gnss.lat : lastNavigationLat;
      roadEventObservation.lon = roadEventObservation.currentGpsUsable ? gnss.lon : lastNavigationLon;
    }
  }
  if (roadEventDecision.state == roadevent::State::PendingConfirmation || roadEventDecision.confirmed) {
    Serial.printf("[AI EVT] %s | %-13s | model score %.1f%% | %u/%u | %s\n",
      roadEventDecision.confirmed ? "CONFIRMED" : "CANDIDATE", hazardTypeName(HazardKind(kind)),
      ai.confidence * 100.0f, (unsigned)roadEventDecision.windows,
      (unsigned)roadEventDecision.requiredWindows, roadEventDecision.reason);
  }
  if (roadEventDecision.confirmed) {
    detectedHazardEvent(HazardKind(kind), roadEventObservation);
  }
}

static const char *resetReasonText(esp_reset_reason_t reason) {
  switch (reason) {
    case ESP_RST_POWERON: return "POWER_ON";
    case ESP_RST_EXT: return "EXTERNAL_PIN";
    case ESP_RST_SW: return "SOFTWARE";
    case ESP_RST_PANIC: return "PANIC_EXCEPTION";
    case ESP_RST_INT_WDT: return "INTERRUPT_WDT";
    case ESP_RST_TASK_WDT: return "TASK_WDT";
    case ESP_RST_WDT: return "OTHER_WDT";
    case ESP_RST_DEEPSLEEP: return "DEEP_SLEEP";
    case ESP_RST_BROWNOUT: return "BROWNOUT";
    default: return "UNKNOWN_OTHER";
  }
}

void setup() {
  alertsEarlyMute(); // Silence the amplifier before Serial/NVS/SPI startup.
  Serial.begin(115200);
  bootStartedMs = millis();
  // CAN must be ready to ACK the ECU before NVS/SPI/I2S/SD/network startup.
  // The RX task continues while slower peripheral initialization completes.
  const bool canOk = canBegin();
  delay(200);
  Serial.println("\n============================================================");
  Serial.println("  HE THONG GIAM SAT HANH TRINH - ESP32-S3 GATEWAY");
  Serial.println("============================================================");
  const esp_reset_reason_t resetReason = esp_reset_reason();
  Serial.printf("[BOOT] reset=%s (%d) | free_heap=%u | free_psram=%u\n",
                resetReasonText(resetReason), (int)resetReason,
                (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getFreePsram());
  if (resetReason == ESP_RST_BROWNOUT)
    Serial.println("[BOOT] POWER | brownout detected: check 3.3-V SD rail, bulk capacitor and common ground");
  else if (resetReason == ESP_RST_PANIC || resetReason == ESP_RST_INT_WDT ||
           resetReason == ESP_RST_TASK_WDT || resetReason == ESP_RST_WDT)
    Serial.println("[BOOT] CRASH | preserve the previous backtrace/reset log for diagnosis");
  const uint64_t mac = ESP.getEfuseMac();
  char id[34];
  snprintf(id, sizeof(id), "%08lX%08lX-%08lX", (unsigned long)(mac >> 32),
           (unsigned long)mac, (unsigned long)esp_random());
  bootId = id;
  Serial.printf("[BOOT] device=%s | boot=%s | FW=%s | MODEL=%s\n", DEVICE_ID, bootId.c_str(), FIRMWARE_VERSION, MODEL_VERSION);
  runtimeConfigBegin();

  pinMode(PIN_SD_CS, OUTPUT);
  digitalWrite(PIN_SD_CS, HIGH);
  SPI.begin(PIN_SPI_SCK, PIN_SPI_MISO, PIN_SPI_MOSI);
  const bool sdSpiOk = sharedSpiBegin();
  if (!sdSpiOk) Serial.println("[BOOT] FAIL | SD SPI mutex could not be created");

  const bool alertOk = alertsBegin();
  // Start the real-time inputs before probing/remounting SD. ADXL345 now has a
  // dedicated I2C bus, so its 100 Hz sampler remains independent even if a
  // missing or slow card takes time to initialize.
  const bool gnssOk = gnssBegin(), aiOk = motionBegin();
  const bool sd = storageBegin();
  maintainHazardPersistence(millis());
  ecuBootDeadlineMs = millis() + ECU_BOOT_GRACE_MS;
  networkBegin();
  Serial.printf("[BOOT] SD-SPI=%s | SD=%s | CAN=%s | GNSS-UART=%s | ADXL-I2C/AI=%s | VOICE-I2S=%s | map=%u potholes/%u bumps\n",
                sdSpiOk ? "OK" : "FAIL", sd ? "OK" : storageRecoveryBusy() ? "SETTLING" : "RETRY", canOk ? "OK" : "FAIL", gnssOk ? "OK" : "FAIL",
                aiOk ? "OK" : "FAIL", alertOk ? "OK" : "FAIL",
                (unsigned)potholeCount, (unsigned)speedBumpCount);
  if (String(WIFI_SSID) == "YOUR_WIFI_SSID")
    Serial.println("[BOOT] ACTION REQUIRED: configure WIFI_SSID/WIFI_PASSWORD/SERVER_URL in this sketch's config.h");
  if (AUDIO_BOOT_SELF_TEST) alertAudioSelfTest();
  Serial.println("============================================================\n");
}

void loop() {
  canPoll(ecu);
  gnssPoll(gnss);
  updateNavigationReadinessOnFix();
  networkPoll();
  storagePoll();
  const RuntimeConfig &directConfig = runtimeConfigGet();
  if (directDemoPoll(ecuRuntimeFresh(), ecu.vehicleSpeedKph,
                     directConfig.geofenceWarningRadiusM, directConfig.geofenceRearmRadiusM)) {
    roadEventGate.reset(); roadEventDecision = roadevent::Decision{};
    roadEventDecision.state = roadevent::State::ScopeSettling;
    roadEventDecision.reason = "awaiting_clean_scope_window";
    roadEventObservation = HazardObservation{};
    lastRoadEventId = String(); lastRoadEventLabel = "unknown"; lastRoadEventReason = "scope_changed";
    lastRoadEventMs = 0; lastRoadEventPosition = lastRoadEventNewPoint = false;
    detectionScopeChangedMs = millis();
    detectionScopeSettling = true;
    haveNavigationPoint = false;
    Serial.println("[DIRECT] SCOPE | one physical model window before recording new road detections");
  }
  checkDirectDemoWarnings();
  // A small display-only lane: never append five copies/second to MicroSD.
  // Capture before slower inference/catalog work; the uploader discards stale
  // captures rather than repainting them as newly received vehicle motion.
  if(DIRECT_REALTIME_ENABLED && directDemoActive() && directrealtime::due(millis(),lastDirectRealtime)) {
    lastDirectRealtime=millis();
    const auto &snapshot=directDemoSnapshot();
    const bool fresh=ecuRuntimeFresh();
    const uint32_t age=ecu.lastRuntimeMs ? uint32_t(snapshot.captureMs-ecu.lastRuntimeMs) : UINT32_MAX;
    const String realtime=String("{\"type\":\"direct_realtime\",\"device_id\":")+quoted(DEVICE_ID)+
      ",\"boot_id\":"+quoted(bootId)+",\"seq\":"+String(++directRealtimeSequence)+
      ",\"uptime_ms\":"+String(snapshot.captureMs)+",\"direct_demo\":"+directDemoSnapshotJson()+
      ",\"ecu\":{\"online\":"+String(fresh?"true":"false")+",\"speed_kph\":"+String(fresh?ecu.vehicleSpeedKph:0,3)+
      ",\"adc_raw\":"+String(ecu.adcRaw)+"},\"audio_active\":"+String(alertsAudioBusy()?"true":"false")+"}";
    networkSubmitDirectRealtime(realtime,snapshot.captureMs,age,fresh);
  }
  checkEcuEvents();
  const uint32_t now = millis();
  reloadHazardCatalogAfterSdChange();
  maintainHazardPersistence(now);
  syncHazardCatalogToWeb(now);
  if (gnss.locationUpdated) {
    updateTripOnNewFix();
    checkGeofenceOnNewFix();
  }
  if (now - lastInference >= INFERENCE_PERIOD_MS) {
    lastInference = now;
    runInference();
  }
  if (now - lastSerialStatus >= SERIAL_STATUS_PERIOD_MS) {
    lastSerialStatus = now;
    printSystemStatus();
  }
  if (now - lastTelemetry >= TELEMETRY_PERIOD_MS) {
    lastTelemetry = now;
    const String json = baseJson("telemetry") +
                        ",\"trip\":{\"distance_km\":" + String(tripKm, 3) + "}}";
    deliver("telemetry", json);
  }
  delay(2);
}
