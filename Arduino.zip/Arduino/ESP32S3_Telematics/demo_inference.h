#pragma once
#include <Arduino.h>
// Executes one isolated model window received from the authenticated server.
// The result is sent only through command ACK, never through live hazard/SD.
bool demoInferenceCommand(const String &commandJson,String &resultJson);
