#include <SPI.h>
#include <SD.h>
#include <new>
#include "config.h"
#include "storage.h"
#include "shared_spi.h"
#include "power_arbiter.h"
#include "storage_policy.h"
#include <ctype.h>
#include <string.h>

static volatile bool ready=false;
static SemaphoreHandle_t sdMutex=nullptr;
static QueueHandle_t logQueue=nullptr;
static QueueHandle_t offlineWriteQueue=nullptr;
static QueueHandle_t eventWriteQueue=nullptr;
static TaskHandle_t logTaskHandle=nullptr;
struct LogRecord { String json; String utc; };
struct OfflineRecord { String kind; String json; size_t bytes=0; };
struct EventRecord { String json; size_t bytes=0; uint32_t ticket=0; };
static portMUX_TYPE queueBytesMux=portMUX_INITIALIZER_UNLOCKED;
static portMUX_TYPE eventTicketMux=portMUX_INITIALIZER_UNLOCKED;
static volatile size_t ramOfflineBytes=0,ramEventBytes=0;
static storage_policy::EventTickets<64> eventTickets;
static SemaphoreHandle_t queuePublishMutex=nullptr;
static constexpr size_t MAX_STORAGE_JSON_BYTES=8192;
static volatile uint32_t queueAllocFailures=0,logCoalesced=0,offlineCoalesced=0;
static volatile bool workerLogHeld=false,workerOfflineHeld=false,workerEventHeld=false;
static const char *workerStage="not_started";
static uint32_t workerStageSinceMs=0;
static volatile bool hazardCatalogChanged=false;
enum class SdState : uint8_t { Offline, Verifying, Online };
static volatile SdState sdState=SdState::Offline;
static volatile bool recoveryBusy=false;
static uint32_t lastCardCheck=0;
static uint32_t nextMountAttemptMs=0,mountVerifyAtMs=0,postRemountQuietUntil=0;
static uint32_t remountRetryMs=SD_RETRY_INITIAL_MS,nextWorkerWriteMs=0;
static uint8_t mountVerifyPasses=0;
static bool driverMounted=false;
static uint32_t activeFrequencyHz=0;
static const char* lastError="not_started";
static size_t queueFileBytes=0,queueAckOffset=0,queueNextBytes=0;
static size_t eventQueueFileBytes=0,eventQueueAckOffset=0;
static uint8_t ioFailureStreak=0, cardMissingStreak=0;
static volatile uint32_t totalIoFailures=0,totalRemounts=0;
static String activeLogBase, activeLogPath;
static size_t activeLogBytes=0;
static portMUX_TYPE storageStatsMux=portMUX_INITIALIZER_UNLOCKED;
static volatile uint64_t cardTotalBytes=0,cardUsedBytes=0,dailyLogBytes=0;
static volatile uint32_t telemetryLogDropCount=0;
static volatile bool mediaFull=false,dailyLogQuotaReached=false;
static const char* cardTypeText="none";
static uint32_t lastSpaceRefreshMs=0,lastCapacityWarningMs=0;
static uint32_t nextDailyQuotaCheckMs=0;
// V10.0.2: all SD transactions are quiesced while spoken audio is active.
static volatile bool audioCriticalRequested=false;
// V10.2.3: the amplifier can disturb the shared prototype power rail even
// though its WAV data comes from flash. Keep the card idle after SD/EN goes LOW
// and require one read-only health probe before queued writes resume.
static volatile uint32_t postAudioQuietUntil=0,postAudioVerifyAt=0;
static volatile bool postAudioVerifyPending=false;
static volatile uint8_t postAudioVerifyFailures=0;
static volatile bool queueRecoveryDegraded=false;
static volatile bool queueTrackingReliable=false;

static bool deadlineReached(uint32_t now,uint32_t deadline){return (int32_t)(now-deadline)>=0;}
static uint32_t timeoutRemaining(uint32_t started,uint32_t timeoutMs){
  const uint32_t elapsed=millis()-started;
  return elapsed>=timeoutMs?0:timeoutMs-elapsed;
}
static bool postAudioQuiet(uint32_t now){return postAudioQuietUntil!=0&&!deadlineReached(now,postAudioQuietUntil);}
static bool storageIoPaused(uint32_t now){return audioCriticalRequested||postAudioQuiet(now)||postAudioVerifyPending;}
static void resetMediaStats(){
  portENTER_CRITICAL(&storageStatsMux);
  cardTotalBytes=cardUsedBytes=dailyLogBytes=0;
  mediaFull=false;dailyLogQuotaReached=false;cardTypeText="none";
  portEXIT_CRITICAL(&storageStatsMux);
  lastSpaceRefreshMs=0;lastCapacityWarningMs=0;
  nextDailyQuotaCheckMs=0;
}
static void addSuccessfulWriteBytes(size_t value,bool dailyLog){
  portENTER_CRITICAL(&storageStatsMux);
  cardUsedBytes+=value;
  if(cardTotalBytes&&cardUsedBytes>cardTotalBytes)cardUsedBytes=cardTotalBytes;
  if(dailyLog)dailyLogBytes+=value;
  portEXIT_CRITICAL(&storageStatsMux);
}
static void noteTelemetryLogDropped(){
  portENTER_CRITICAL(&storageStatsMux);++telemetryLogDropCount;portEXIT_CRITICAL(&storageStatsMux);
}
static uint32_t allocateEventTicket(){
  portENTER_CRITICAL(&eventTicketMux);
  const uint32_t ticket=eventTickets.reserve();
  portEXIT_CRITICAL(&eventTicketMux);
  return ticket;
}
static void noteEventDurable(uint32_t ticket){
  if(!ticket)return;
  portENTER_CRITICAL(&eventTicketMux);eventTickets.markDurable(ticket);portEXIT_CRITICAL(&eventTicketMux);
}
static void cancelEventTicket(uint32_t ticket){
  portENTER_CRITICAL(&eventTicketMux);eventTickets.cancel(ticket);portEXIT_CRITICAL(&eventTicketMux);
}
static void setWorkerStage(const char *stage){
  const uint32_t now=millis();
  portENTER_CRITICAL(&queueBytesMux);
  if(strcmp(workerStage,stage)!=0){workerStage=stage;workerStageSinceMs=now;}
  portEXIT_CRITICAL(&queueBytesMux);
}
static void noteAllocationFailure(const char *kind){
  portENTER_CRITICAL(&queueBytesMux);++queueAllocFailures;portEXIT_CRITICAL(&queueBytesMux);
  Serial.printf("[SDQ ] ALLOC | %s RAM allocation/copy failed; not an SD mount error\n",kind);
}
static void noteCoalesced(bool offline){
  portENTER_CRITICAL(&queueBytesMux);
  if(offline)++offlineCoalesced;else ++logCoalesced;
  portEXIT_CRITICAL(&queueBytesMux);
  if(!offline)noteTelemetryLogDropped();
}
struct QueuePublishLock {
  bool locked=false;
  QueuePublishLock(){locked=queuePublishMutex&&xSemaphoreTake(queuePublishMutex,pdMS_TO_TICKS(20))==pdTRUE;}
  ~QueuePublishLock(){if(locked)xSemaphoreGive(queuePublishMutex);}
};
static void resetDiskTracking(){
  queueFileBytes=queueAckOffset=queueNextBytes=0;
  eventQueueFileBytes=eventQueueAckOffset=0;
  activeLogBase="";activeLogPath="";activeLogBytes=0;
  queueTrackingReliable=false;
}
// Caller owns sdMutex + the SD SPI transaction mutex.
static void enterOfflineLocked(const char* reason,bool resetBackoff){
  ready=false;sdState=SdState::Offline;recoveryBusy=false;activeFrequencyHz=0;
  resetDiskTracking();cardMissingStreak=0;mountVerifyPasses=0;
  resetMediaStats();
  postAudioQuietUntil=0;postAudioVerifyAt=0;postAudioVerifyPending=false;postAudioVerifyFailures=0;
  queueRecoveryDegraded=false;
  lastError=reason;
  if(!audioCriticalRequested){SD.end();driverMounted=false;}
  if(resetBackoff)remountRetryMs=SD_RETRY_INITIAL_MS;
  nextMountAttemptMs=millis()+SD_INSERT_SETTLE_MS;
}

// Runtime SD operations can occasionally fail once (slow card, long
// level-shifter wiring, power noise, or a transaction boundary). V6 immediately
// set ready=false on the FIRST failure, which made the card appear to vanish
// exactly when a hazard event caused extra writes. V7 only remounts after a
// short consecutive failure streak; a later successful operation clears it.
static void noteStorageSuccess(){
  ioFailureStreak=0;
  cardMissingStreak=0;
  if(ready)lastError=mediaFull?"storage_full":dailyLogQuotaReached?"daily_log_quota":
                           queueRecoveryDegraded?"queue_recovery_degraded":"none";
}
static void markStorageFault(const char* reason){
  lastError=reason;
  if(ioFailureStreak<255)++ioFailureStreak;
  ++totalIoFailures;
  Serial.printf("[SD  ] WARN | transient I/O failure %u/%u | %s\n",
                (unsigned)ioFailureStreak,(unsigned)SD_IO_FAILURES_BEFORE_REMOUNT,reason);
  if(ioFailureStreak>=SD_IO_FAILURES_BEFORE_REMOUNT){
    enterOfflineLocked(reason,true);
    Serial.println("[SD  ] RETRY | failure threshold reached; remount scheduled");
  }
}
struct SdLock {
  bool locked=false, sdLocked=false, powerLocked=false, spiLocked=false;
  SdLock(uint32_t timeoutMs=1500,bool allowHealthProbe=false) {
    const uint32_t started=millis();
    const uint32_t now=millis();
    if (!sdMutex || audioCriticalRequested || (!allowHealthProbe&&storageIoPaused(now))) return;
    sdLocked = xSemaphoreTake(sdMutex, pdMS_TO_TICKS(timeoutMs)) == pdTRUE;
    // Audio may have requested a quiet window while we were waiting for the
    // mutex.  Release immediately so the amplifier never overlaps a new SD I/O.
    if (sdLocked && (audioCriticalRequested || (!allowHealthProbe&&storageIoPaused(millis())))) {
      xSemaphoreGive(sdMutex); sdLocked=false; return;
    }
    if (!sdLocked) return;
    uint32_t remaining=timeoutRemaining(started,timeoutMs);
    powerLocked=remaining>0&&powerAcquireSd(remaining);
    if(!powerLocked){xSemaphoreGive(sdMutex);sdLocked=false;return;}
    remaining=timeoutRemaining(started,timeoutMs);
    spiLocked = remaining>0&&sharedSpiLock(remaining);
    if (!spiLocked) { powerReleaseSd();powerLocked=false;xSemaphoreGive(sdMutex);sdLocked=false;return; }
    digitalWrite(PIN_SD_CS,HIGH);
    locked=true;
  }
  ~SdLock() {
    // Never touch the SD CS unless this object actually owns the SPI mutex.
    // ADXL345 is on a separate I2C bus in V10.2 and has no firmware-controlled
    // chip-select line.
    if (spiLocked) {
      digitalWrite(PIN_SD_CS,HIGH);
      sharedSpiUnlock();
    }
    if(powerLocked)powerReleaseSd();
    if (sdLocked) xSemaphoreGive(sdMutex);
  }
};
static bool appendLocked(const char*path,const String&s,size_t maxBytes);
static bool rotateForAppendLocked(const char*path,const char*oldPath,size_t bytes,size_t maxBytes);
static bool fileSizeLocked(const char*path,size_t &size);
static bool removeLocked(const char*path);
static bool recoverQueueLocked();
static bool loadQueueStateConservativeLocked();
static void recoverHazardRewriteLocked(){
  const char* paths[2]={SD_POTHOLE_PATH,SD_SPEED_BUMP_PATH};
  for(uint8_t i=0;i<2;++i){
    String tmp=String(paths[i])+".tmp",bak=String(paths[i])+".bak";
    if(!SD.exists(paths[i])&&SD.exists(bak.c_str())){
      // Prefer the pre-delete catalog after an interrupted atomic rewrite.
      if(SD.exists(tmp.c_str()))SD.remove(tmp.c_str());
      SD.rename(bak.c_str(),paths[i]);
    }else if(SD.exists(paths[i])){
      if(SD.exists(tmp.c_str()))SD.remove(tmp.c_str());
      if(SD.exists(bak.c_str()))SD.remove(bak.c_str());
    }else if(SD.exists(tmp.c_str())){
      // No original/backup means the temp file cannot be proven committed.
      SD.remove(tmp.c_str());
    }
  }
}

static void prepareSdBusLocked(){
  // A brownout or removal can leave the ESP32 SPI peripheral and the card in
  // different transaction states. SD is the only SPI slave in V10.2+, so a
  // full bus reset here is safe and much more reliable than SD.end() alone.
  SD.end();driverMounted=false;activeFrequencyHz=0;
  digitalWrite(PIN_SD_CS,HIGH);
  SPI.end();
  delay(8);
  pinMode(PIN_SD_CS,OUTPUT);
  pinMode(PIN_SPI_MISO,INPUT_PULLUP);
  digitalWrite(PIN_SD_CS,HIGH);
  SPI.begin(PIN_SPI_SCK,PIN_SPI_MISO,PIN_SPI_MOSI,PIN_SD_CS);
  // SPI-mode SD cards require at least 74 idle clocks with CS high before CMD0.
  SPI.beginTransaction(SPISettings(400000,MSBFIRST,SPI_MODE0));
  for(uint8_t i=0;i<10;++i)SPI.transfer(0xFF);
  SPI.endTransaction();
  delay(5);
}

static bool mountAtFrequencyLocked(uint32_t frequencyHz){
  // MicroSD is the only SPI slave in V10.2. ADXL345 now runs independently on
  // I2C, so SD remounts can no longer pause or corrupt the AI sampling bus.
  digitalWrite(PIN_SD_CS,HIGH);delay(2);
  if(!SD.begin(PIN_SD_CS,SPI,frequencyHz)){SD.end();driverMounted=false;return false;}
  driverMounted=true;
  if(SD.cardType()==CARD_NONE){SD.end();driverMounted=false;return false;}
  activeFrequencyHz=frequencyHz;return true;
}

static bool verifyMountedCardLocked(){
  if(!driverMounted||SD.cardType()==CARD_NONE)return false;
  // cardType() and opening '/' can succeed from cached metadata after an
  // electrical interruption. Force a real, read-only SPI sector transaction
  // before trusting the mounted card. Never write the partition/boot sector.
  alignas(4) uint8_t sectorProbe[512];
  if(SD.sectorSize()!=sizeof(sectorProbe)||!SD.readRAW(sectorProbe,0))return false;
  File root=SD.open("/",FILE_READ);
  const bool ok=root&&root.isDirectory();
  if(root)root.close();
  return ok;
}

static const char* cardTypeLabel(uint8_t type){
  if(type==CARD_MMC)return "mmc";
  if(type==CARD_SD)return "sdsc";
  if(type==CARD_SDHC)return "sdhc_sdxc";
  if(type==CARD_NONE)return "none";
  return "unknown";
}

static bool refreshCardSpaceLocked(bool force){
  const uint32_t now=millis();
  if(!driverMounted||SD.cardType()==CARD_NONE)return false;
  if(!force&&lastSpaceRefreshMs&&now-lastSpaceRefreshMs<SD_SPACE_REFRESH_MS)return true;
  const uint8_t type=SD.cardType();
  const uint64_t total=SD.totalBytes();
  uint64_t used=SD.usedBytes();
  if(total==0)return false;
  if(used>total)used=total;
  const bool wasFull=mediaFull;
  const bool full=total-used<SD_MIN_FREE_BYTES;
  portENTER_CRITICAL(&storageStatsMux);
  cardTypeText=cardTypeLabel(type);cardTotalBytes=total;cardUsedBytes=used;mediaFull=full;
  portEXIT_CRITICAL(&storageStatsMux);
  lastSpaceRefreshMs=now;
  if(full!=wasFull||(force&&lastCapacityWarningMs==0)){
    Serial.printf("[SD  ] MEDIA | type=%s | used=%llu MB / %llu MB | free=%llu KB | %s\n",
                  cardTypeText,(unsigned long long)(used/1048576ULL),
                  (unsigned long long)(total/1048576ULL),
                  (unsigned long long)((total-used)/1024ULL),full?"WRITE BLOCK: physical full":"space OK");
  }
  if(full){lastError="storage_full";lastCapacityWarningMs=now;}
  else if(wasFull){
    recoverHazardRewriteLocked();
    if(queueRecoveryDegraded){
      bool recovered=recoverQueueLocked();
      if(!recovered)recovered=loadQueueStateConservativeLocked();
      queueRecoveryDegraded=!recovered;
      if(!recovered){resetDiskTracking();lastError="queue_recovery_failed";}
      Serial.printf("[SD  ] %s | deferred outbox recovery after capacity returned\n",
                    queueRecoveryDegraded?"WARN":"OK  ");
    }
    lastError=dailyLogQuotaReached?"daily_log_quota":queueRecoveryDegraded?"queue_recovery_degraded":"none";
    Serial.println("[SD  ] READY | free space recovered; paced logging may resume");
  }
  return true;
}

// Non-critical logging stops at SD_MIN_FREE_BYTES. Critical event/hazard and
// cursor metadata may use the emergency tail, but never cross the smaller
// SD_CRITICAL_FREE_BYTES guard.
static bool criticalCapacityAvailableLocked(size_t incomingBytes=0,bool forceRefresh=false){
  if(forceRefresh)refreshCardSpaceLocked(true);
  uint64_t total=0,used=0;
  portENTER_CRITICAL(&storageStatsMux);total=cardTotalBytes;used=cardUsedBytes;portEXIT_CRITICAL(&storageStatsMux);
  if(!total)return !mediaFull;
  const uint64_t freeBytes=total>used?total-used:0;
  return freeBytes>SD_CRITICAL_FREE_BYTES+(uint64_t)incomingBytes;
}

static bool verifyWritableCardLocked(){
  // Never auto-format. This tiny disposable probe distinguishes a readable FAT
  // volume from a read-only/corrupt one before queues and logs are touched.
  static constexpr char path[]="/.sd_health.tmp";
  static constexpr char expected[]="SDOK\n";
  if(SD.exists(path)&&!SD.remove(path))return false;
  File out=SD.open(path,FILE_WRITE);
  if(!out)return false;
  const size_t wanted=sizeof(expected)-1,written=out.write((const uint8_t*)expected,wanted);
  out.flush();out.close();
  if(written!=wanted)return false;
  File in=SD.open(path,FILE_READ);
  if(!in)return false;
  char actual[sizeof(expected)]={0};
  const size_t got=in.readBytes(actual,wanted);in.close();
  const bool ok=got==wanted&&memcmp(actual,expected,wanted)==0;
  if(!SD.remove(path))return false;
  return ok;
}

static bool remountForWriteProbeLocked(const char *&failureReason){
  prepareSdBusLocked();
  bool mounted=mountAtFrequencyLocked(SD_SPI_FALLBACK_FREQUENCY_HZ);
  if(!mounted&&SD_SPI_FREQUENCY_HZ!=SD_SPI_FALLBACK_FREQUENCY_HZ){
    delay(10);prepareSdBusLocked();mounted=mountAtFrequencyLocked(SD_SPI_FREQUENCY_HZ);
  }
  if(!mounted){failureReason="write_probe_remount_failed";return false;}
  if(!verifyMountedCardLocked()){failureReason="write_probe_root_failed";return false;}
  return true;
}

static bool verifyWritableCardReliablyLocked(const char *&failureReason){
  failureReason="write_probe_failed";
  for(uint8_t attempt=0;attempt<SD_WRITE_PROBE_ATTEMPTS;++attempt){
    if(attempt>0){
      delay(SD_WRITE_PROBE_RETRY_MS);
      if(!remountForWriteProbeLocked(failureReason)){
        Serial.printf("[SD  ] HOLD | write probe recovery %u/%u | %s\n",
                      (unsigned)(attempt+1),(unsigned)SD_WRITE_PROBE_ATTEMPTS,failureReason);
        continue;
      }
    }
    if(verifyWritableCardLocked()){
      if(attempt>0)Serial.printf("[SD  ] OK   | write probe recovered on attempt %u/%u\n",
                                 (unsigned)(attempt+1),(unsigned)SD_WRITE_PROBE_ATTEMPTS);
      return true;
    }
    // A readable volume with less than the reserved free space is not an
    // electrical I/O failure. Keep it mounted so logs can be exported/deleted.
    if(refreshCardSpaceLocked(true)&&mediaFull){
      failureReason="storage_full";
      Serial.println("[SD  ] FULL | write probe blocked by capacity; card stays mounted for management");
      return true;
    }
    failureReason="write_probe_failed";
    Serial.printf("[SD  ] HOLD | write probe %u/%u failed; card remains under verification\n",
                  (unsigned)(attempt+1),(unsigned)SD_WRITE_PROBE_ATTEMPTS);
  }
  return false;
}

static bool loadQueueStateConservativeLocked(){
  // A stale cursor/temp file must never make a physically healthy card look
  // absent. Preserve every outbox file, replay from offset zero (server event
  // IDs deduplicate duplicates), and let later ACKs rewrite cursor metadata.
  resetDiskTracking();
  if(!SD.exists(SD_QUEUE_PATH)&&SD.exists(SD_QUEUE_BACKUP_PATH)){
    if(!SD.rename(SD_QUEUE_BACKUP_PATH,SD_QUEUE_PATH))return false;
  }else if(SD.exists(SD_QUEUE_PATH)&&SD.exists(SD_QUEUE_BACKUP_PATH)){
    // The backup is an older duplicate once the primary exists. This matches
    // the normal recovery rule but does not depend on rewriting cursor metadata.
    if(!SD.remove(SD_QUEUE_BACKUP_PATH))return false;
  }
  if(!fileSizeLocked(SD_QUEUE_PATH,queueFileBytes)||
     !fileSizeLocked(SD_QUEUE_NEXT_PATH,queueNextBytes)||
     !fileSizeLocked(SD_EVENT_QUEUE_PATH,eventQueueFileBytes))return false;
  if(queueFileBytes==0&&queueNextBytes>0){
    // Never leave pending.next as the only outbox: storageFlushQueue reads the
    // primary path. Promotion failure keeps the card in recovery instead of
    // declaring it ready with an unsendable queue.
    if(!removeLocked(SD_QUEUE_PATH)||!SD.rename(SD_QUEUE_NEXT_PATH,SD_QUEUE_PATH))return false;
    queueFileBytes=queueNextBytes;queueNextBytes=0;
  }
  queueAckOffset=0;eventQueueAckOffset=0;queueTrackingReliable=true;
  return true;
}

static bool loadQueueStateReadOnlyLocked(){
  // A capacity-constrained card must stay mounted for export/deletion. Do not
  // create cursors, rename, promote, or remove anything during this boot path;
  // replay from offset zero is safe because the backend deduplicates records.
  resetDiskTracking();
  if(!fileSizeLocked(SD_QUEUE_PATH,queueFileBytes)||
     !fileSizeLocked(SD_QUEUE_NEXT_PATH,queueNextBytes)||
     !fileSizeLocked(SD_EVENT_QUEUE_PATH,eventQueueFileBytes))return false;
  queueAckOffset=0;eventQueueAckOffset=0;queueTrackingReliable=true;
  return true;
}

static bool finishMountLocked(bool automaticRemount){
  resetDiskTracking();
  refreshCardSpaceLocked(true);
  if(!mediaFull)recoverHazardRewriteLocked();
  const bool readOnlyQueueStateOk=mediaFull?loadQueueStateReadOnlyLocked():true;
  queueRecoveryDegraded=mediaFull?true:!recoverQueueLocked();
  if(queueRecoveryDegraded){
    if(mediaFull){
      // Even unreadable queue metadata does not justify unmounting a readable,
      // full FAT volume. Management/export remains available so the user can
      // make space without a restart/remount storm.
      if(!readOnlyQueueStateOk)resetDiskTracking();
      Serial.printf("[SD  ] FULL | queue recovery deferred (%s); card stays mounted for export/delete\n",
                    readOnlyQueueStateOk?"read-only state loaded":"metadata unreadable");
    }else if(!loadQueueStateConservativeLocked()){
      lastError="queue_recovery_failed";
      Serial.println("[SD  ] HOLD | outbox recovery incomplete; files preserved and mount will retry");
      return false;
    }else Serial.println("[SD  ] WARN | stale outbox metadata preserved; replay starts safely at offset zero");
  }
  sdState=SdState::Online;
  ioFailureStreak=0;cardMissingStreak=0;remountRetryMs=SD_RETRY_INITIAL_MS;
  lastCardCheck=millis();
  if(automaticRemount)++totalRemounts;
  // A cold mount needs the same verified quiet window as a reinsertion.
  // This gates queue writes/HTTP; it does NOT switch or measure card power.
  postRemountQuietUntil=millis()+SD_POST_REMOUNT_QUIET_MS;
  recoveryBusy=true;ready=false;lastError="post_mount_settle";
  Serial.printf("[SD  ] OK   | CS=%d | SPI=%.1f MHz | %s\n",PIN_SD_CS,
                activeFrequencyHz/1000000.0f,automaticRemount?"card remounted; settling before queue drain":"card mounted; settling before queue drain");
  return true;
}

static bool mountInitialCardLocked(){
  ready=false;recoveryBusy=true;sdState=SdState::Offline;resetDiskTracking();
  prepareSdBusLocked();
  // Start cold boot at 1 MHz. This is ample for a 1 Hz logger and tolerant of
  // prototype wiring. This build also keeps retries at 1 MHz.
  if(!mountAtFrequencyLocked(SD_SPI_FALLBACK_FREQUENCY_HZ)){
    delay(10);
    prepareSdBusLocked();
    if(SD_SPI_FALLBACK_FREQUENCY_HZ==SD_SPI_FREQUENCY_HZ||!mountAtFrequencyLocked(SD_SPI_FREQUENCY_HZ)){
      enterOfflineLocked("mount_failed",true);return false;
    }
  }
  for(uint8_t pass=0;pass<SD_BOOT_VERIFY_PASSES;++pass){
    if(!verifyMountedCardLocked()){
      enterOfflineLocked("root_verify_failed",true);return false;
    }
    if(pass+1<SD_BOOT_VERIFY_PASSES)delay(SD_BOOT_VERIFY_PERIOD_MS);
  }
  const char *probeFailure="write_probe_failed";
  if(!verifyWritableCardReliablyLocked(probeFailure)){
    enterOfflineLocked(probeFailure,true);return false;
  }
  if(!finishMountLocked(false)){
    const char *reason=lastError;enterOfflineLocked(reason,true);return false;
  }
  return true;
}

static bool fileSizeLocked(const char*path,size_t &size){
  size=0;if(!SD.exists(path))return true;File f=SD.open(path,FILE_READ);if(!f)return false;size=f.size();f.close();return true;
}
static bool removeLocked(const char*path){return !SD.exists(path)||SD.remove(path);}
static bool writeCursorLocked(size_t offset){
  if(!removeLocked(SD_QUEUE_CURSOR_TMP_PATH))return false;
  File f=SD.open(SD_QUEUE_CURSOR_TMP_PATH,FILE_WRITE);if(!f)return false;
  char text[32];int length=snprintf(text,sizeof(text),"%lu\n",(unsigned long)offset);
  bool wrote=length>0&&length<(int)sizeof(text)&&f.write((const uint8_t*)text,length)==(size_t)length;f.close();
  if(!wrote||!removeLocked(SD_QUEUE_CURSOR_PATH))return false;
  return SD.rename(SD_QUEUE_CURSOR_TMP_PATH,SD_QUEUE_CURSOR_PATH);
}

static bool writeEventCursorLocked(size_t offset){
  if(!removeLocked(SD_EVENT_CURSOR_TMP_PATH))return false;
  File f=SD.open(SD_EVENT_CURSOR_TMP_PATH,FILE_WRITE);if(!f)return false;
  char text[32];int length=snprintf(text,sizeof(text),"%lu\n",(unsigned long)offset);
  bool wrote=length>0&&length<(int)sizeof(text)&&f.write((const uint8_t*)text,length)==(size_t)length;f.close();
  if(!wrote||!removeLocked(SD_EVENT_CURSOR_PATH))return false;
  return SD.rename(SD_EVENT_CURSOR_TMP_PATH,SD_EVENT_CURSOR_PATH);
}

static bool loadEventQueueStateLocked(){
  if(!fileSizeLocked(SD_EVENT_QUEUE_PATH,eventQueueFileBytes))return false;
  eventQueueAckOffset=0;
  File cursor=SD.open(SD_EVENT_CURSOR_PATH,FILE_READ);
  if(cursor){eventQueueAckOffset=(size_t)cursor.parseInt();cursor.close();}
  if(eventQueueAckOffset>eventQueueFileBytes){
    eventQueueAckOffset=0;
    if(!writeEventCursorLocked(0))return false;
  }
  if(eventQueueFileBytes==0){removeLocked(SD_EVENT_QUEUE_PATH);removeLocked(SD_EVENT_CURSOR_PATH);eventQueueAckOffset=0;}
  else if(eventQueueAckOffset==eventQueueFileBytes){
    // Everything was acknowledged before the previous reset. It is safe to
    // delete both files. If power fails here, the worst case is a duplicate
    // resend, which the server deduplicates by event.id.
    if(!removeLocked(SD_EVENT_QUEUE_PATH)||!removeLocked(SD_EVENT_CURSOR_PATH))return false;
    eventQueueFileBytes=eventQueueAckOffset=0;
  }
  return true;
}

// New records roll into pending.next when the current append-only file contains
// a large acknowledged prefix. Once the primary is fully acknowledged, this
// atomic promotion avoids a multi-megabyte copy and a long SD transaction.
static bool finishPrimaryLocked(){
  size_t nextBytes=0;if(!fileSizeLocked(SD_QUEUE_NEXT_PATH,nextBytes))return false;
  // Removing the cursor first requires no new cluster and works even when the
  // card is full. A power cut after this point only replays duplicates, which
  // the server already deduplicates by boot_id/sequence or event id.
  if(!removeLocked(SD_QUEUE_CURSOR_PATH))return false;
  if(!removeLocked(SD_QUEUE_PATH))return false;
  queueFileBytes=queueAckOffset=0;
  if(nextBytes){
    if(!SD.rename(SD_QUEUE_NEXT_PATH,SD_QUEUE_PATH))return false;
    queueFileBytes=nextBytes;queueNextBytes=0;
  }else{
    queueNextBytes=0;removeLocked(SD_QUEUE_NEXT_PATH);
    // A cursor containing zero is harmless if deletion fails.
    removeLocked(SD_QUEUE_CURSOR_PATH);
  }
  return true;
}

static bool loadQueueStateLocked(){
  if(!fileSizeLocked(SD_QUEUE_PATH,queueFileBytes)||!fileSizeLocked(SD_QUEUE_NEXT_PATH,queueNextBytes))return false;
  queueAckOffset=0;
  File cursor=SD.open(SD_QUEUE_CURSOR_PATH,FILE_READ);if(cursor){queueAckOffset=(size_t)cursor.parseInt();cursor.close();}
  if(queueAckOffset>queueFileBytes){queueAckOffset=0;if(!writeCursorLocked(0))return false;}
  if(queueFileBytes==0&&queueNextBytes>0)return finishPrimaryLocked();
  if(queueFileBytes>0&&queueAckOffset==queueFileBytes&&!finishPrimaryLocked())return false;
  return true;
}
static bool recoverQueueLocked(){
  queueTrackingReliable=false;
  // Recover files left by an older compaction implementation. Starting at
  // cursor zero can resend records, but boot_id+sequence makes that idempotent.
  if(!SD.exists(SD_QUEUE_PATH)&&SD.exists(SD_QUEUE_BACKUP_PATH)){
    if(!writeCursorLocked(0)||!SD.rename(SD_QUEUE_BACKUP_PATH,SD_QUEUE_PATH))return false;
  }else if(SD.exists(SD_QUEUE_PATH)&&SD.exists(SD_QUEUE_BACKUP_PATH)){
    if(!writeCursorLocked(0)||!removeLocked(SD_QUEUE_BACKUP_PATH))return false;
  }
  if(!SD.exists(SD_QUEUE_PATH)&&SD.exists(SD_QUEUE_NEXT_PATH)){
    if(!writeCursorLocked(0)||!SD.rename(SD_QUEUE_NEXT_PATH,SD_QUEUE_PATH))return false;
  }
  removeLocked(SD_QUEUE_TMP_PATH);removeLocked(SD_QUEUE_CURSOR_TMP_PATH);removeLocked(SD_EVENT_CURSOR_TMP_PATH);
  const bool ok=loadQueueStateLocked()&&loadEventQueueStateLocked();
  queueTrackingReliable=ok;return ok;
}

// Calendar helpers used only for log filenames. Logs use the configured local
// civil date while hazard timestamps remain UTC epoch seconds.
static int64_t daysFromCivil(int year,unsigned month,unsigned day){
  year-=month<=2;const int era=(year>=0?year:year-399)/400;
  const unsigned yoe=(unsigned)(year-era*400);
  const unsigned doy=(153*(month+(month>2?-3:9))+2)/5+day-1;
  const unsigned doe=yoe*365+yoe/4-yoe/100+doy;
  return (int64_t)era*146097+(int64_t)doe-719468;
}
static void civilFromDays(int64_t z,int &year,unsigned &month,unsigned &day){
  z+=719468;const int era=(z>=0?z:z-146096)/146097;
  const unsigned doe=(unsigned)(z-(int64_t)era*146097);
  const unsigned yoe=(doe-doe/1460+doe/36524-doe/146096)/365;
  year=(int)yoe+era*400;const unsigned doy=doe-(365*yoe+yoe/4-yoe/100);
  const unsigned mp=(5*doy+2)/153;day=doy-(153*mp+2)/5+1;
  month=mp+(mp<10?3:-9);year+=month<=2;
}
static bool parseIsoUtcEpoch(const String&utc,uint32_t &epoch){
  epoch=0;if(utc.length()<19)return false;
  int y=0,mo=0,d=0,h=0,mi=0,se=0;
  if(sscanf(utc.c_str(),"%d-%d-%dT%d:%d:%d",&y,&mo,&d,&h,&mi,&se)!=6)return false;
  if(y<1970||mo<1||mo>12||d<1||d>31||h<0||h>23||mi<0||mi>59||se<0||se>60)return false;
  int64_t value=daysFromCivil(y,(unsigned)mo,(unsigned)d)*86400LL+h*3600LL+mi*60LL+se;
  if(value<=0||value>0xFFFFFFFFLL)return false;epoch=(uint32_t)value;return true;
}
static String localDateFromUtc(const String&utc){
  uint32_t epoch=0;if(!parseIsoUtcEpoch(utc,epoch))return String();
  int64_t local=(int64_t)epoch+(int64_t)LOG_TIMEZONE_OFFSET_MINUTES*60LL;
  int64_t days=local/86400LL;if(local<0&&local%86400LL)days--;
  int y;unsigned mo,d;civilFromDays(days,y,mo,d);
  char text[11];snprintf(text,sizeof(text),"%04d-%02u-%02u",y,mo,d);return String(text);
}
static bool ensureLogDirLocked(){return SD.exists(SD_LOG_DIR)||SD.mkdir(SD_LOG_DIR);}
enum class LogSelectResult : uint8_t { Ready, DayQuota, MediaFull, IoError };
enum class LogAppendResult : uint8_t { Written, DroppedCapacity, RetryableIo };

static void printCapacityDropLocked(const char*reason){
  const uint32_t now=millis();
  if(lastCapacityWarningMs&&now-lastCapacityWarningMs<SD_CAPACITY_WARNING_PERIOD_MS)return;
  lastCapacityWarningMs=now;
  uint64_t total=0,used=0,daily=0;
  portENTER_CRITICAL(&storageStatsMux);
  total=cardTotalBytes;used=cardUsedBytes;daily=dailyLogBytes;
  portEXIT_CRITICAL(&storageStatsMux);
  Serial.printf("[SD  ] BLOCK | %s | used=%llu/%llu MB | daily=%llu/%llu MB | logs preserved; no auto-delete\n",
                reason,(unsigned long long)(used/1048576ULL),(unsigned long long)(total/1048576ULL),
                (unsigned long long)(daily/1048576ULL),
                (unsigned long long)(((uint64_t)MAX_DAILY_LOG_SEGMENTS*MAX_LOG_BYTES)/1048576ULL));
}

static void noteCapacityOrStorageFaultLocked(const char*ioReason,const char*capacityReason){
  refreshCardSpaceLocked(true);
  if(mediaFull){
    lastError=capacityReason;
    printCapacityDropLocked(capacityReason);
    return;
  }
  markStorageFault(ioReason);
}

static LogSelectResult selectLogPathLocked(const String&utc,size_t incomingBytes,String &path){
  refreshCardSpaceLocked(false);
  if(mediaFull)return LogSelectResult::MediaFull;
  if(!ensureLogDirLocked()){
    refreshCardSpaceLocked(true);
    if(mediaFull)return LogSelectResult::MediaFull;
    markStorageFault("daily_log_dir_failed");
    return LogSelectResult::IoError;
  }
  String base=localDateFromUtc(utc);if(!base.length())base=SD_UNDATED_LOG_BASE;
  if(activeLogBase!=base){
    portENTER_CRITICAL(&storageStatsMux);dailyLogQuotaReached=false;dailyLogBytes=0;portEXIT_CRITICAL(&storageStatsMux);
    nextDailyQuotaCheckMs=0;
  }
  if(activeLogBase==base&&dailyLogQuotaReached&&!deadlineReached(millis(),nextDailyQuotaCheckMs))
    return LogSelectResult::DayQuota;

  // Fast path: the common 1 Hz telemetry write performs ZERO directory scans
  // and ZERO file-stat opens. This materially shortens the SD transaction.
  if(activeLogBase==base&&activeLogPath.length()&&activeLogBytes+incomingBytes<=MAX_LOG_BYTES){
    path=activeLogPath;
    return LogSelectResult::Ready;
  }

  uint64_t scannedBytes=0;
  for(uint16_t segment=0;segment<MAX_DAILY_LOG_SEGMENTS;++segment){
    char suffix[8];snprintf(suffix,sizeof(suffix),"_%02u",(unsigned)segment);
    path=String(SD_LOG_DIR)+"/"+base+suffix+".ndjson";
    size_t size=0;
    if(!fileSizeLocked(path.c_str(),size)){
      refreshCardSpaceLocked(true);
      if(mediaFull)return LogSelectResult::MediaFull;
      markStorageFault("daily_log_stat_failed");return LogSelectResult::IoError;
    }
    scannedBytes+=size;
    if(size+incomingBytes<=MAX_LOG_BYTES){
      activeLogBase=base;activeLogPath=path;activeLogBytes=size;
      portENTER_CRITICAL(&storageStatsMux);dailyLogBytes=scannedBytes;dailyLogQuotaReached=false;portEXIT_CRITICAL(&storageStatsMux);
      nextDailyQuotaCheckMs=0;
      return LogSelectResult::Ready;
    }
  }
  portENTER_CRITICAL(&storageStatsMux);dailyLogBytes=scannedBytes;dailyLogQuotaReached=true;portEXIT_CRITICAL(&storageStatsMux);
  activeLogBase=base;activeLogPath="";activeLogBytes=0;
  nextDailyQuotaCheckMs=millis()+SD_SPACE_REFRESH_MS;
  lastError="daily_log_quota";
  return LogSelectResult::DayQuota;
}
static LogAppendResult appendTelemetryLocked(const String&json,const String&utc){
  const size_t expected=json.length()+2;
  String path;
  const LogSelectResult selected=selectLogPathLocked(utc,expected,path);
  if(selected==LogSelectResult::DayQuota){
    noteTelemetryLogDropped();printCapacityDropLocked("daily_log_quota");return LogAppendResult::DroppedCapacity;
  }
  if(selected==LogSelectResult::MediaFull){
    noteTelemetryLogDropped();printCapacityDropLocked("physical_full");return LogAppendResult::DroppedCapacity;
  }
  if(selected!=LogSelectResult::Ready)return LogAppendResult::RetryableIo;
  File f=SD.open(path.c_str(),FILE_APPEND);
  if(!f){
    activeLogPath="";activeLogBytes=0;refreshCardSpaceLocked(true);
    if(mediaFull){noteTelemetryLogDropped();printCapacityDropLocked("physical_full");return LogAppendResult::DroppedCapacity;}
    markStorageFault("daily_log_open_failed");return LogAppendResult::RetryableIo;
  }
  const size_t written=f.println(json);f.close();
  if(written!=expected){
    activeLogPath="";activeLogBytes=0;refreshCardSpaceLocked(true);
    if(mediaFull){noteTelemetryLogDropped();printCapacityDropLocked("physical_full");return LogAppendResult::DroppedCapacity;}
    markStorageFault("daily_log_write_failed");return LogAppendResult::RetryableIo;
  }
  activeLogBytes+=written;addSuccessfulWriteBytes(written,true);noteStorageSuccess();
  return LogAppendResult::Written;
}

enum class PersistResult : uint8_t { Written, CapacityBlocked, RecoveryBlocked, RetryableIo };

static PersistResult persistOfflineRecordLocked(const OfflineRecord &record){
  if(!ready)return PersistResult::RetryableIo;
  if(!queueTrackingReliable||(queueRecoveryDegraded&&!mediaFull))return PersistResult::RecoveryBlocked;
  if(mediaFull)return PersistResult::CapacityBlocked;
  String line=record.kind+"\t"+record.json;
  const size_t bytes=record.bytes?record.bytes:line.length()+2;
  size_t unacked=(queueFileBytes>=queueAckOffset?queueFileBytes-queueAckOffset:0)+queueNextBytes;
  if(unacked+bytes>MAX_QUEUE_BYTES){Serial.println("WARN: offline queue logical limit reached");return PersistResult::CapacityBlocked;}
  bool useNext=queueNextBytes>0||(queueFileBytes>0&&queueFileBytes+bytes>MAX_QUEUE_BYTES);
  const char*path=useNext?SD_QUEUE_NEXT_PATH:SD_QUEUE_PATH;
  size_t &tracked=useNext?queueNextBytes:queueFileBytes;
  if(appendLocked(path,line,MAX_QUEUE_BYTES)){tracked+=bytes;return PersistResult::Written;}
  return mediaFull?PersistResult::CapacityBlocked:PersistResult::RetryableIo;
}

static PersistResult persistEventRecordLocked(const EventRecord &record){
  if(!ready)return PersistResult::RetryableIo;
  if(!queueTrackingReliable||(queueRecoveryDegraded&&!mediaFull))return PersistResult::RecoveryBlocked;
  const size_t bytes=record.bytes?record.bytes:record.json.length()+2;
  if(mediaFull&&!criticalCapacityAvailableLocked(bytes,true)){
    lastError="critical_capacity_full";
    printCapacityDropLocked("critical_event_reserve_exhausted");
    return PersistResult::CapacityBlocked;
  }
  // The forced capacity refresh above can transition full -> writable and run
  // deferred queue recovery. If both recovery paths fail they deliberately
  // clear the byte/cursor accounting. Never append using that cleared state;
  // retain this critical event in RAM until tracking is reliable again.
  if(!queueTrackingReliable||(queueRecoveryDegraded&&!mediaFull))return PersistResult::RecoveryBlocked;
  const size_t unacked=eventQueueFileBytes>=eventQueueAckOffset?eventQueueFileBytes-eventQueueAckOffset:0;
  if(unacked+bytes>MAX_EVENT_QUEUE_BYTES){
    lastError="event_outbox_quota";
    Serial.println("ERROR: durable event outbox capacity reached");
    return PersistResult::CapacityBlocked;
  }
  File f=SD.open(SD_EVENT_QUEUE_PATH,FILE_APPEND);
  if(!f){
    refreshCardSpaceLocked(true);
    if(mediaFull&&!criticalCapacityAvailableLocked(bytes)){
      lastError="critical_capacity_full";return PersistResult::CapacityBlocked;
    }
    markStorageFault("event_outbox_open_failed");
    return PersistResult::RetryableIo;
  }
  const size_t expected=record.json.length()+2,written=f.println(record.json);f.close();
  if(written!=expected){
    refreshCardSpaceLocked(true);
    if(mediaFull&&!criticalCapacityAvailableLocked(bytes)){
      lastError="critical_capacity_full";return PersistResult::CapacityBlocked;
    }
    markStorageFault("event_outbox_write_failed");
    return PersistResult::RetryableIo;
  }
  eventQueueFileBytes+=written;addSuccessfulWriteBytes(written,false);noteEventDurable(record.ticket);noteStorageSuccess();
  return PersistResult::Written;
}

static void adjustRamBytes(volatile size_t &counter,int32_t delta){
  portENTER_CRITICAL(&queueBytesMux);
  if(delta>=0)counter+=(size_t)delta;
  else{size_t d=(size_t)(-delta);counter=counter>d?counter-d:0;}
  portEXIT_CRITICAL(&queueBytesMux);
}
static size_t readRamBytes(volatile size_t &counter){
  portENTER_CRITICAL(&queueBytesMux);const size_t value=counter;portEXIT_CRITICAL(&queueBytesMux);return value;
}

static void automaticMountFailedLocked(const char*reason){
  ready=false;sdState=SdState::Offline;recoveryBusy=false;activeFrequencyHz=0;
  resetDiskTracking();resetMediaStats();mountVerifyPasses=0;queueRecoveryDegraded=false;lastError=reason;
  SD.end();driverMounted=false;
  const uint32_t waitMs=remountRetryMs;
  nextMountAttemptMs=millis()+waitMs;
  if(remountRetryMs<SD_RETRY_MAX_MS)
    remountRetryMs=remountRetryMs>SD_RETRY_MAX_MS/2?SD_RETRY_MAX_MS:remountRetryMs*2;
  Serial.printf("[SD  ] WAIT | %s | next safe remount in %lu ms\n",reason,(unsigned long)waitMs);
}

static void startAutomaticMountLocked(){
  ready=false;recoveryBusy=true;sdState=SdState::Offline;activeFrequencyHz=0;
  resetDiskTracking();mountVerifyPasses=0;queueRecoveryDegraded=false;
  prepareSdBusLocked();

  // A hot-inserted card starts at the conservative clock. 1 MHz is ample for
  // this 1 Hz logger and is much more tolerant of socket bounce/long wiring.
  bool mounted=mountAtFrequencyLocked(SD_SPI_FALLBACK_FREQUENCY_HZ);
  if(!mounted&&SD_SPI_FREQUENCY_HZ!=SD_SPI_FALLBACK_FREQUENCY_HZ){
    delay(10);prepareSdBusLocked();mounted=mountAtFrequencyLocked(SD_SPI_FREQUENCY_HZ);
  }
  if(!mounted){automaticMountFailedLocked("mount_failed");return;}

  sdState=SdState::Verifying;
  lastError="verifying_card";
  mountVerifyAtMs=millis()+SD_REMOUNT_VERIFY_PERIOD_MS;
  Serial.printf("[SD  ] CHECK | card detected at %.1f MHz | verifying %u passes before recovery\n",
                activeFrequencyHz/1000000.0f,(unsigned)SD_REMOUNT_VERIFY_PASSES);
}

static void maintainCard(){
  const uint32_t now=millis();
  if(audioCriticalRequested||postAudioQuiet(now))return;

  if(postAudioVerifyPending){
    if(!deadlineReached(now,postAudioVerifyAt))return;
    // This is the only operation allowed while the post-audio write gate is
    // active. It reads a physical sector and root directory without writes.
    SdLock lock(250,true);
    if(!lock.locked){postAudioVerifyAt=now+SD_POST_AUDIO_VERIFY_GAP_MS;return;}
    if(sdState==SdState::Online&&ready&&driverMounted&&verifyMountedCardLocked()){
      postAudioVerifyPending=false;postAudioQuietUntil=0;postAudioVerifyAt=0;
      postAudioVerifyFailures=0;
      noteStorageSuccess();lastCardCheck=now;
      nextWorkerWriteMs=now+SD_WORKER_WRITE_GAP_MS;
      Serial.println("[SD  ] OK   | post-audio read-only health check passed; paced writes resumed");
    }else{
      if(ready&&sdState==SdState::Online){
        if(postAudioVerifyFailures<255)++postAudioVerifyFailures;
        if(postAudioVerifyFailures<SD_POST_AUDIO_VERIFY_ATTEMPTS){
          postAudioVerifyPending=true;postAudioVerifyAt=now+SD_POST_AUDIO_VERIFY_RETRY_MS;
          lastError="post_audio_verify_retry";
          Serial.printf("[SD  ] HOLD | post-audio read probe %u/%u; retrying without unmount\n",
                        (unsigned)postAudioVerifyFailures,(unsigned)SD_POST_AUDIO_VERIFY_ATTEMPTS);
        }else{
          // Never resume writes on a card that repeatedly failed verification.
          // Close this driver session and let the normal verified remount path
          // recover. This is a software bus reset, not a physical power-cycle.
          ++totalIoFailures;
          enterOfflineLocked("post_audio_verify_failed",true);
          Serial.println("[SD  ] FAIL | repeated post-audio verification failure; writes held until verified remount");
        }
      }else{
        postAudioVerifyPending=false;postAudioQuietUntil=0;postAudioVerifyAt=0;postAudioVerifyFailures=0;
      }
    }
    return;
  }

  if(sdState==SdState::Offline){
    if(!deadlineReached(now,nextMountAttemptMs))return;
    recoveryBusy=true;  // Gate new network/power bursts before taking SPI.
    SdLock lock(500);
    if(!lock.locked){
      recoveryBusy=false;nextMountAttemptMs=now+250;
      return;
    }
    startAutomaticMountLocked();
    return;
  }

  if(sdState==SdState::Verifying){
    if(!deadlineReached(now,mountVerifyAtMs))return;
    SdLock lock(600);
    if(!lock.locked){mountVerifyAtMs=now+100;return;}
    if(!verifyMountedCardLocked()){
      automaticMountFailedLocked("root_verify_failed");return;
    }
    if(mountVerifyPasses<255)++mountVerifyPasses;
    if(mountVerifyPasses<SD_REMOUNT_VERIFY_PASSES){
      mountVerifyAtMs=millis()+SD_REMOUNT_VERIFY_PERIOD_MS;
      return;
    }
    const char *probeFailure="write_probe_failed";
    if(!verifyWritableCardReliablyLocked(probeFailure)){
      automaticMountFailedLocked(probeFailure);return;
    }
    if(!finishMountLocked(true)){
      automaticMountFailedLocked(lastError);return;
    }
    return;
  }

  if(recoveryBusy){
    if(!deadlineReached(now,postRemountQuietUntil))return;
    ready=true;recoveryBusy=false;lastError=mediaFull?"storage_full":dailyLogQuotaReached?"daily_log_quota":
                                                queueRecoveryDegraded?"queue_recovery_degraded":"none";
    lastCardCheck=now;
    Serial.println("[SD  ] READY | post-remount quiet window complete; paced writes/resend allowed");
  }
  if(now-lastCardCheck<SD_CARD_CHECK_PERIOD_MS)return;
  lastCardCheck=now;
  SdLock lock(220);if(!lock.locked||sdState!=SdState::Online||!ready)return;
  if(SD.cardType()==CARD_NONE){
    if(cardMissingStreak<255)++cardMissingStreak;
    Serial.printf("[SD  ] WARN | card probe missing %u/%u\n",(unsigned)cardMissingStreak,(unsigned)SD_CARD_MISSING_CONFIRMATIONS);
    if(cardMissingStreak>=SD_CARD_MISSING_CONFIRMATIONS){
      enterOfflineLocked("card_removed",true);
      Serial.println("[SD  ] FAIL | card confirmed unavailable; debounced automatic retry active");
    }
  }else{
    cardMissingStreak=0;
    if(queueRecoveryDegraded&&!mediaFull){
      bool recovered=recoverQueueLocked();
      if(!recovered)recovered=loadQueueStateConservativeLocked();
      queueRecoveryDegraded=!recovered;
      if(recovered){
        noteStorageSuccess();Serial.println("[SDQ ] OK   | periodic queue tracking recovery completed");
      }else{
        resetDiskTracking();markStorageFault("queue_recovery_retry_failed");
        if(!ready)return;
      }
    }
    refreshCardSpaceLocked(false);
    if(ioFailureStreak==0)lastError=mediaFull?"storage_full":dailyLogQuotaReached?"daily_log_quota":
                                             queueRecoveryDegraded?"queue_recovery_degraded":"none";
  }
}
static void loggerTask(void*){
  LogRecord* logRecord=nullptr;
  OfflineRecord* offlineRecord=nullptr;
  EventRecord* eventRecord=nullptr;
  uint8_t laneCursor=0;
  uint32_t retryAt[3]={0,0,0};
  for(;;){
    const uint32_t loopNow=millis();
    if(audioCriticalRequested||postAudioQuiet(loopNow)){
      setWorkerStage("audio_hold");vTaskDelay(pdMS_TO_TICKS(20));continue;
    }
    if(postAudioVerifyPending){
      setWorkerStage("audio_verify");maintainCard();vTaskDelay(pdMS_TO_TICKS(20));continue;
    }
    // Keep one pending head per lane. A blocked durable event remains here,
    // but cannot prevent the other lanes from using later paced write slots.
    if(!eventRecord && eventWriteQueue)xQueueReceive(eventWriteQueue,&eventRecord,0);
    if(!offlineRecord && offlineWriteQueue)xQueueReceive(offlineWriteQueue,&offlineRecord,0);
    if(!logRecord && logQueue)xQueueReceive(logQueue,&logRecord,0);
    portENTER_CRITICAL(&queueBytesMux);
    workerEventHeld=eventRecord!=nullptr;workerOfflineHeld=offlineRecord!=nullptr;workerLogHeld=logRecord!=nullptr;
    portEXIT_CRITICAL(&queueBytesMux);
    const uint32_t now=millis();
    const bool writeSlot=ready&&!recoveryBusy&&deadlineReached(now,nextWorkerWriteMs);
    if(writeSlot){
      const bool eligible[3]={eventRecord&&deadlineReached(now,retryAt[0]),
                              offlineRecord&&deadlineReached(now,retryAt[1]),
                              logRecord&&deadlineReached(now,retryAt[2])};
      const int lane=storage_policy::chooseLane(laneCursor,eligible);
      bool succeeded=false,capacityBlocked=false;
      if(lane==0){
        setWorkerStage("event_write");
        if(mediaFull&&!criticalCapacityAvailableLocked(eventRecord->bytes,false)){
          capacityBlocked=true;lastError="critical_capacity_full";
          printCapacityDropLocked("critical_event_retained_in_ram");
        }else{
          SdLock lock(120);
          if(lock.locked){
            const PersistResult result=persistEventRecordLocked(*eventRecord);
            if(result==PersistResult::Written){
              succeeded=true;
              adjustRamBytes(ramEventBytes,-(int32_t)eventRecord->bytes);
              delete eventRecord;eventRecord=nullptr;
            }else if(result==PersistResult::CapacityBlocked||result==PersistResult::RecoveryBlocked){
              capacityBlocked=true;printCapacityDropLocked(result==PersistResult::RecoveryBlocked?
                                                           "event_waiting_for_queue_recovery":"critical_event_retained_in_ram");
            }
          }
        }
      }else if(lane==1){
        setWorkerStage("offline_write");
        if(mediaFull&&offlineRecord->kind=="telemetry"){
          noteCoalesced(true);printCapacityDropLocked("physical_full_offline_telemetry_dropped");
          succeeded=true;
          adjustRamBytes(ramOfflineBytes,-(int32_t)offlineRecord->bytes);
          delete offlineRecord;offlineRecord=nullptr;
        }else{
          SdLock lock(100);
          if(lock.locked){
            const PersistResult result=persistOfflineRecordLocked(*offlineRecord);
            if(result==PersistResult::Written){
              succeeded=true;
              adjustRamBytes(ramOfflineBytes,-(int32_t)offlineRecord->bytes);
              delete offlineRecord;offlineRecord=nullptr;
            }else if(result==PersistResult::CapacityBlocked||result==PersistResult::RecoveryBlocked){
              capacityBlocked=true;
              if(offlineRecord->kind=="telemetry"){
                noteCoalesced(true);
                printCapacityDropLocked(result==PersistResult::RecoveryBlocked?
                                        "offline_queue_recovery_pending":"offline_telemetry_capacity_dropped");
                succeeded=true;adjustRamBytes(ramOfflineBytes,-(int32_t)offlineRecord->bytes);
                delete offlineRecord;offlineRecord=nullptr;
              }
            }
          }
        }
      }else if(lane==2){
        setWorkerStage("log_write");
        SdLock lock(80);
        if(lock.locked&&ready){
          const LogAppendResult result=appendTelemetryLocked(logRecord->json,logRecord->utc);
          succeeded=result!=LogAppendResult::RetryableIo;
          if(succeeded){delete logRecord;logRecord=nullptr;}
        }
      }
      if(lane>=0){
        // Backoff is lane-local. Other lanes still get fair opportunities.
        const uint32_t completed=millis();
        retryAt[lane]=completed+(succeeded?0:capacityBlocked?SD_CAPACITY_WARNING_PERIOD_MS:SD_WORKER_FAILURE_GAP_MS);
        nextWorkerWriteMs=completed+SD_WORKER_WRITE_GAP_MS;
      }
    }
    portENTER_CRITICAL(&queueBytesMux);
    workerEventHeld=eventRecord!=nullptr;workerOfflineHeld=offlineRecord!=nullptr;workerLogHeld=logRecord!=nullptr;
    portEXIT_CRITICAL(&queueBytesMux);
    setWorkerStage(!ready?(recoveryBusy?"sd_recovery":"sd_offline"):"maintenance");
    maintainCard();
    setWorkerStage(!ready?(recoveryBusy?"sd_recovery":"sd_offline"):
                   (eventRecord||offlineRecord||logRecord)?"paced_wait":"idle");
    vTaskDelay(pdMS_TO_TICKS(20));
  }
}


bool storageBegin(){
  if(!powerArbiterBegin()){lastError="power_mutex_failed";return false;}
  if(!sharedSpiBegin()){lastError="spi_mutex_failed";return false;}
  if(!sdMutex)sdMutex=xSemaphoreCreateMutex();
  if(!sdMutex){lastError="mutex_failed";return false;}
  if(!queuePublishMutex)queuePublishMutex=xSemaphoreCreateMutex();
  if(!queuePublishMutex){lastError="queue_mutex_failed";return false;}
  ready=false;sdState=SdState::Offline;recoveryBusy=true;lastError="boot_settling";
  pinMode(PIN_SD_CS,OUTPUT);digitalWrite(PIN_SD_CS,HIGH);
  Serial.printf("[SD  ] WAIT | cold-boot power settle %lu ms | amplifier remains muted\n",
                (unsigned long)SD_BOOT_POWER_SETTLE_MS);
  delay(SD_BOOT_POWER_SETTLE_MS);
  {
    SdLock lock(1500);
    if(!lock.locked){
      lastError="mutex_timeout";recoveryBusy=false;nextMountAttemptMs=millis()+SD_INSERT_SETTLE_MS;
    }else if(!mountInitialCardLocked())
      Serial.printf("[SD  ] RETRY | CS=%d | tried %.1f/%.1f MHz | reason=%s | no restart/auto-format\n",
                    PIN_SD_CS,SD_SPI_FALLBACK_FREQUENCY_HZ/1000000.0f,
                    SD_SPI_FREQUENCY_HZ/1000000.0f,lastError);
  }
  if(!logQueue)logQueue=xQueueCreate(LOG_QUEUE_LENGTH,sizeof(LogRecord*));
  if(!offlineWriteQueue)offlineWriteQueue=xQueueCreate(SD_OFFLINE_WRITE_QUEUE_LENGTH,sizeof(OfflineRecord*));
  if(!eventWriteQueue)eventWriteQueue=xQueueCreate(SD_EVENT_WRITE_QUEUE_LENGTH,sizeof(EventRecord*));
  if(!logTaskHandle && logQueue && offlineWriteQueue && eventWriteQueue){
    if(xTaskCreatePinnedToCore(loggerTask,"sdIoWorker",6144,nullptr,2,&logTaskHandle,0)!=pdPASS){
      logTaskHandle=nullptr;setWorkerStage("worker_start_failed");Serial.println("[SDQ ] ERROR | SD worker not started; asynchronous submissions disabled");
    }
  }
  if(!logTaskHandle)setWorkerStage("worker_start_failed");
  return ready;
}
bool storageReady(){return ready;}
bool storageRecoveryBusy(){return recoveryBusy||storageIoPaused(millis());}
uint32_t storageFrequencyHz(){return ready?activeFrequencyHz:0;}
const char* storageStateText(){
  const uint32_t now=millis();
  if(audioCriticalRequested)return "audio_hold";
  if(postAudioQuiet(now))return "post_audio_settle";
  if(postAudioVerifyPending)return "post_audio_verify";
  if(sdState==SdState::Verifying)return "verifying";
  if(sdState==SdState::Online){
    if(recoveryBusy)return "post_mount_settle";
    if(mediaFull)return "full";
    if(dailyLogQuotaReached)return "log_quota";
    return queueRecoveryDegraded?"degraded":"online";
  }
  if(recoveryBusy)return strcmp(lastError,"boot_settling")==0?"boot_settling":"mounting";
  return "retry_wait";
}
const char* storageLastError(){return lastError;}
const char* storageCardTypeText(){
  const char* value;portENTER_CRITICAL(&storageStatsMux);value=cardTypeText;portEXIT_CRITICAL(&storageStatsMux);return value;
}
uint64_t storageTotalBytes(){uint64_t value;portENTER_CRITICAL(&storageStatsMux);value=cardTotalBytes;portEXIT_CRITICAL(&storageStatsMux);return value;}
uint64_t storageUsedBytes(){uint64_t value;portENTER_CRITICAL(&storageStatsMux);value=cardUsedBytes;portEXIT_CRITICAL(&storageStatsMux);return value;}
uint64_t storageDailyLogBytes(){uint64_t value;portENTER_CRITICAL(&storageStatsMux);value=dailyLogBytes;portEXIT_CRITICAL(&storageStatsMux);return value;}
uint64_t storageDailyLogQuotaBytes(){return (uint64_t)MAX_DAILY_LOG_SEGMENTS*(uint64_t)MAX_LOG_BYTES;}
const char* storageWriteBlockReason(){
  if(mediaFull)return "physical_full";
  if(dailyLogQuotaReached)return "daily_log_quota";
  if(ioFailureStreak>0)return "io_error";
  return "none";
}
uint32_t storageTelemetryLogDropCount(){uint32_t value;portENTER_CRITICAL(&storageStatsMux);value=telemetryLogDropCount;portEXIT_CRITICAL(&storageStatsMux);return value;}
uint32_t storageTelemetryCoalescedCount(){uint32_t value;portENTER_CRITICAL(&queueBytesMux);value=logCoalesced;portEXIT_CRITICAL(&queueBytesMux);return value;}
uint32_t storageOfflineCoalescedCount(){uint32_t value;portENTER_CRITICAL(&queueBytesMux);value=offlineCoalesced;portEXIT_CRITICAL(&queueBytesMux);return value;}
uint32_t storageQueueAllocFailureCount(){uint32_t value;portENTER_CRITICAL(&queueBytesMux);value=queueAllocFailures;portEXIT_CRITICAL(&queueBytesMux);return value;}
size_t storageLogQueueDepth(){bool held;portENTER_CRITICAL(&queueBytesMux);held=workerLogHeld;portEXIT_CRITICAL(&queueBytesMux);return (logQueue?uxQueueMessagesWaiting(logQueue):0)+(held?1:0);}
size_t storageOfflineQueueDepth(){bool held;portENTER_CRITICAL(&queueBytesMux);held=workerOfflineHeld;portEXIT_CRITICAL(&queueBytesMux);return (offlineWriteQueue?uxQueueMessagesWaiting(offlineWriteQueue):0)+(held?1:0);}
size_t storageEventRamQueueDepth(){bool held;portENTER_CRITICAL(&queueBytesMux);held=workerEventHeld;portEXIT_CRITICAL(&queueBytesMux);return (eventWriteQueue?uxQueueMessagesWaiting(eventWriteQueue):0)+(held?1:0);}
const char *storageWorkerStage(){const char *value;portENTER_CRITICAL(&queueBytesMux);value=workerStage;portEXIT_CRITICAL(&queueBytesMux);return value;}
uint32_t storageWorkerAgeMs(){uint32_t started;portENTER_CRITICAL(&queueBytesMux);started=workerStageSinceMs;portEXIT_CRITICAL(&queueBytesMux);return millis()-started;}
static TaskHandle_t publicStorageOwner=nullptr;
static bool publicStoragePowerLocked=false;
bool storageLock(uint32_t timeoutMs){
  const uint32_t started=millis();
  if(storageIoPaused(millis())||!ready||!sdMutex)return false;
  if(xSemaphoreTake(sdMutex,pdMS_TO_TICKS(timeoutMs))!=pdTRUE)return false;
  if(storageIoPaused(millis())){xSemaphoreGive(sdMutex);return false;}
  uint32_t remaining=timeoutRemaining(started,timeoutMs);
  if(!remaining||!powerAcquireSd(remaining)){xSemaphoreGive(sdMutex);return false;}
  publicStoragePowerLocked=true;
  remaining=timeoutRemaining(started,timeoutMs);
  if(!remaining||!sharedSpiLock(remaining)){powerReleaseSd();publicStoragePowerLocked=false;xSemaphoreGive(sdMutex);return false;}
  if(!ready){sharedSpiUnlock();powerReleaseSd();publicStoragePowerLocked=false;xSemaphoreGive(sdMutex);return false;}
  publicStorageOwner=xTaskGetCurrentTaskHandle();return true;
}
void storageUnlock(){
  if(publicStorageOwner!=xTaskGetCurrentTaskHandle())return;
  digitalWrite(PIN_SD_CS,HIGH);
  publicStorageOwner=nullptr;sharedSpiUnlock();
  if(publicStoragePowerLocked){powerReleaseSd();publicStoragePowerLocked=false;}
  xSemaphoreGive(sdMutex);
}

bool storageEnterAudioCritical(uint32_t timeoutMs){
  const uint32_t started=millis();
  for(;;){
    // A voice must never overlap either the previous audio health check or an
    // automatic mount/verification/settle cycle. Wait boundedly; if recovery
    // takes too long the alert is skipped without disturbing the card.
    while(postAudioQuiet(millis())||postAudioVerifyPending||recoveryBusy||sdState==SdState::Verifying){
      if(millis()-started>=timeoutMs){
        Serial.printf("[SD  ] HOLD | SD recovery still active after %lu ms; speaker remains muted\n",
                      (unsigned long)timeoutMs);
        return false;
      }
      vTaskDelay(pdMS_TO_TICKS(10));
    }

    // Gate NEW SD operations first, then wait until any transaction that began
    // just before the gate has released sdMutex.
    audioCriticalRequested=true;
    if(!sdMutex){
      if(recoveryBusy||sdState==SdState::Verifying){audioCriticalRequested=false;continue;}
      return true;
    }
    const uint32_t elapsed=millis()-started;
    if(elapsed>=timeoutMs){audioCriticalRequested=false;return false;}
    const TickType_t ticks=pdMS_TO_TICKS(timeoutMs-elapsed);
    if(xSemaphoreTake(sdMutex,ticks)!=pdTRUE){
      Serial.printf("[SD  ] HOLD | audio requested; waiting transaction exceeded %lu ms\n",(unsigned long)timeoutMs);
      audioCriticalRequested=false;
      return false;
    }
    const bool recoveryWonRace=recoveryBusy||sdState==SdState::Verifying;
    xSemaphoreGive(sdMutex);
    if(recoveryWonRace){
      audioCriticalRequested=false;
      if(millis()-started>=timeoutMs)return false;
      vTaskDelay(pdMS_TO_TICKS(10));
      continue;
    }
    return true;
  }
}

void storageExitAudioCritical(bool amplifierWasEnabled){
  // storageEnterAudioCritical() can reject a new voice while the previous
  // recovery is still active. In that case no gate was acquired and no audio
  // power pulse occurred, so leave the existing recovery deadline untouched.
  if(!audioCriticalRequested)return;
  if(!amplifierWasEnabled){audioCriticalRequested=false;return;}
  // Publish the quiet deadline before opening the audio gate; SdLock therefore
  // never sees an unprotected gap between "audio active" and "power recovery".
  const uint32_t now=millis();
  postAudioQuietUntil=now+SD_POST_AUDIO_QUIET_MS;
  postAudioVerifyAt=postAudioQuietUntil;
  postAudioVerifyPending=driverMounted&&sdState==SdState::Online&&ready;
  postAudioVerifyFailures=0;
  audioCriticalRequested=false;
}
bool storageAudioCritical(){return audioCriticalRequested;}

void storagePoll(){
  // Normal maintenance belongs to loggerTask so SD timeouts do not delay the
  // real-time loop. Fall back to polling here only if that task could not start.
  if(!logTaskHandle)maintainCard();
}

static bool appendLocked(const char*path,const String&s,size_t maxBytes){
  refreshCardSpaceLocked(false);
  if(mediaFull)return false;
  const bool offlinePath=strcmp(path,SD_QUEUE_PATH)==0||strcmp(path,SD_QUEUE_NEXT_PATH)==0;
  const char*statError=offlinePath?"offline_queue_stat_failed":"file_stat_failed";
  const char*openError=offlinePath?"offline_queue_open_failed":"file_open_failed";
  const char*writeError=offlinePath?"offline_queue_write_failed":"file_write_failed";
  size_t size=0;
  if(!fileSizeLocked(path,size)){
    refreshCardSpaceLocked(true);if(!mediaFull)markStorageFault(statError);return false;
  }
  if(size+s.length()+2>maxBytes)return false;
  File f=SD.open(path,FILE_APPEND);
  if(!f){refreshCardSpaceLocked(true);if(!mediaFull)markStorageFault(openError);return false;}
  const size_t expected=s.length()+2,written=f.println(s);f.close();
  if(written!=expected){refreshCardSpaceLocked(true);if(!mediaFull)markStorageFault(writeError);return false;}
  addSuccessfulWriteBytes(written,false);noteStorageSuccess();return true;
}
static bool rotateForAppendLocked(const char*path,const char*oldPath,size_t bytes,size_t maxBytes){
  size_t size=0;if(!fileSizeLocked(path,size)){noteCapacityOrStorageFaultLocked("file_stat_failed","rotation_capacity_hold");return false;}if(size+bytes<=maxBytes)return true;
  if(!removeLocked(oldPath)){noteCapacityOrStorageFaultLocked("file_rotate_remove_failed","rotation_capacity_hold");return false;}
  if(SD.exists(path)&&!SD.rename(path,oldPath)){noteCapacityOrStorageFaultLocked("file_rotate_rename_failed","rotation_capacity_hold");return false;}
  return true;
}

void storageAppendLog(const String&json,const String&utc){
  // Bounded newest-wins telemetry buffer. Events never use this queue.
  // Do not fall back to a blocking producer-side file write after worker failure.
  if(!logTaskHandle||!logQueue){noteTelemetryLogDropped();return;}
  if(json.length()<2||json.length()>MAX_STORAGE_JSON_BYTES||utc.length()>40){
    noteTelemetryLogDropped();Serial.println("[SDQ ] REJECT | log record size invalid");return;
  }
  QueuePublishLock publication;
  if(!publication.locked){noteTelemetryLogDropped();Serial.println("[SDQ ] BUSY | log publisher timeout; sample dropped");return;}
  LogRecord* record=new(std::nothrow) LogRecord{json,utc};
  if(!record||record->json.length()!=json.length()||record->utc.length()!=utc.length()){
    delete record;noteAllocationFailure("log");noteTelemetryLogDropped();return;
  }
  if(xQueueSend(logQueue,&record,0)==pdTRUE)return;
  LogRecord *oldest=nullptr;
  if(xQueueReceive(logQueue,&oldest,0)==pdTRUE){delete oldest;noteCoalesced(false);}
  if(xQueueSend(logQueue,&record,0)==pdTRUE)return;
  delete record;noteTelemetryLogDropped();
  Serial.println("[SDQ ] FULL | log queue could not accept replacement; sample dropped");
}

// Caller holds queuePublishMutex. Worker only removes entries, so returning
// a non-telemetry entry after removing it always has a free queue slot.
static bool removeOldestOfflineTelemetry(){
  const size_t count=uxQueueMessagesWaiting(offlineWriteQueue);
  for(size_t i=0;i<count;++i){
    OfflineRecord *candidate=nullptr;
    if(xQueueReceive(offlineWriteQueue,&candidate,0)!=pdTRUE)break;
    if(candidate->kind=="telemetry"){
      adjustRamBytes(ramOfflineBytes,-(int32_t)candidate->bytes);
      delete candidate;noteCoalesced(true);return true;
    }
    // No competing producer can fill the released slot while publication is
    // locked. Preserve every legacy event rather than evicting important data.
    xQueueSend(offlineWriteQueue,&candidate,0);
  }
  return false;
}

bool storageQueue(const String&kind,const String&json){
  if(!logTaskHandle||!offlineWriteQueue||json.length()<2||json.length()>MAX_STORAGE_JSON_BYTES||
     (kind!="telemetry"&&kind!="event")||json[0]!='{'||json[json.length()-1]!='}')return false;
  if(mediaFull&&kind=="telemetry"){
    noteCoalesced(true);printCapacityDropLocked("physical_full_offline_telemetry_not_queued");
    return true; // Explicitly coalesced/dropped, NOT acknowledged as written.
  }
  QueuePublishLock publication;if(!publication.locked)return false;
  const size_t bytes=kind.length()+1+json.length()+2;
  const size_t diskNormal=ready&&queueFileBytes>=queueAckOffset?(queueFileBytes-queueAckOffset)+queueNextBytes:0;
  if(diskNormal+readRamBytes(ramOfflineBytes)+bytes>MAX_QUEUE_BYTES){
    if(kind=="telemetry"){
      noteCoalesced(true);
      if(!lastCapacityWarningMs||millis()-lastCapacityWarningMs>=SD_CAPACITY_WARNING_PERIOD_MS){
        lastCapacityWarningMs=millis();
        Serial.println("[SDQ ] FULL | offline telemetry outbox quota reached; sample coalesced, events preserved");
      }
      return true;
    }
    return false;
  }
  OfflineRecord* record=new(std::nothrow) OfflineRecord{kind,json,bytes};
  if(!record||record->kind.length()!=kind.length()||record->json.length()!=json.length()){
    delete record;noteAllocationFailure("offline");return false;
  }
  // Account BEFORE publishing. Otherwise a preempting consumer can subtract
  // first, leaving phantom bytes after the queue is empty.
  adjustRamBytes(ramOfflineBytes,(int32_t)bytes);
  if(xQueueSend(offlineWriteQueue,&record,0)==pdTRUE)return true;
  adjustRamBytes(ramOfflineBytes,-(int32_t)bytes);
  if(kind=="telemetry"&&removeOldestOfflineTelemetry()){
    adjustRamBytes(ramOfflineBytes,(int32_t)bytes);
    if(xQueueSend(offlineWriteQueue,&record,0)==pdTRUE)return true;
    adjustRamBytes(ramOfflineBytes,-(int32_t)bytes);
  }
  delete record;return false;
}


// Critical events have a dedicated append-only outbox. This API admits to RAM;
// only storageEventTicketDurable confirms a completed SD append. An abrupt
// power loss before HTTP acceptance or SD append can still lose RAM records.
uint32_t storageQueueEvent(const String&json){
  if(!logTaskHandle||!eventWriteQueue||json.length()<2||json.length()>MAX_STORAGE_JSON_BYTES||json[0]!='{'||json[json.length()-1]!='}')return 0;
  QueuePublishLock publication;if(!publication.locked)return 0;
  const size_t bytes=json.length()+2;
  if(storageEventQueueBytes()+bytes>MAX_EVENT_QUEUE_BYTES)return 0;
  const uint32_t ticket=allocateEventTicket();
  if(!ticket){Serial.println("[EVQ ] HOLD | exact ACK tracker full; keep event in uploader RAM");return 0;}
  EventRecord* record=new(std::nothrow) EventRecord{json,bytes,ticket};
  if(!record||record->json.length()!=json.length()){
    delete record;cancelEventTicket(ticket);noteAllocationFailure("event");return 0;
  }
  adjustRamBytes(ramEventBytes,(int32_t)bytes);
  if(xQueueSend(eventWriteQueue,&record,0)!=pdTRUE){
    adjustRamBytes(ramEventBytes,-(int32_t)bytes);delete record;cancelEventTicket(ticket);return 0;
  }
  return ticket;
}

bool storageEventTicketDurable(uint32_t ticket){
  if(!ticket)return false;
  portENTER_CRITICAL(&eventTicketMux);const bool durable=eventTickets.durable(ticket);portEXIT_CRITICAL(&eventTicketMux);
  return durable;
}
void storageReleaseEventTicket(uint32_t ticket){
  if(!ticket)return;
  portENTER_CRITICAL(&eventTicketMux);eventTickets.release(ticket);portEXIT_CRITICAL(&eventTicketMux);
}


bool storageDeadLetter(const String&kind,const String&json,const char*reason){
  if(!ready){Serial.println("WARN: rejected record could not be saved");return false;}
  String line=String(millis())+"\t"+reason+"\t"+kind+"\t"+json;SdLock lock;if(!lock.locked||!ready)return false;
  bool ok=rotateForAppendLocked(SD_REJECTED_PATH,SD_REJECTED_OLD_PATH,line.length()+2,MAX_REJECTED_BYTES)&&appendLocked(SD_REJECTED_PATH,line,MAX_REJECTED_BYTES);
  if(!ok)Serial.println("WARN: rejected record log failed");return ok;
}

size_t storageEventQueueBytes(){
  const size_t disk=ready&&eventQueueFileBytes>=eventQueueAckOffset?eventQueueFileBytes-eventQueueAckOffset:0;
  return disk+readRamBytes(ramEventBytes);
}
size_t storageQueueBytes(){
  const size_t normal=ready&&queueFileBytes>=queueAckOffset?(queueFileBytes-queueAckOffset)+queueNextBytes:0;
  return normal+readRamBytes(ramOfflineBytes)+storageEventQueueBytes();
}

static bool validQueuedRecord(const String&kind,const String&payload){
  return (kind=="telemetry"||kind=="event")&&payload.length()>=2&&payload[0]=='{'&&payload[payload.length()-1]=='}';
}

void storageFlushQueue(SendResult (*sender)(const String&,const String&),size_t maxRecords){
  if(!ready||maxRecords==0)return;const size_t cap=maxRecords>8?8:maxRecords;
  if(queueRecoveryDegraded&&!mediaFull){
    SdLock recoveryLock;
    if(!recoveryLock.locked||!ready)return;
    bool recovered=recoverQueueLocked();
    if(!recovered)recovered=loadQueueStateConservativeLocked();
    if(recovered){
      queueRecoveryDegraded=false;noteStorageSuccess();
      Serial.println("[SDQ ] OK   | deferred offline queue promotion recovered");
    }else{
      resetDiskTracking();markStorageFault("queue_recovery_retry_failed");
    }
    return;
  }
  if(!queueTrackingReliable)return;
  String kinds[8],payloads[8];size_t offsets[8],count=0,startOffset=0;bool valid[8]{};
  {
    SdLock lock;if(!lock.locked||!ready||!SD.exists(SD_QUEUE_PATH))return;startOffset=queueAckOffset;
    File in=SD.open(SD_QUEUE_PATH,FILE_READ);if(!in||!in.seek(startOffset)){if(in)in.close();return;}
    while(in.available()&&count<cap){
      String line=in.readStringUntil('\n');size_t next=in.position();line.trim();int tab=line.indexOf('\t');
      if(tab>0){kinds[count]=line.substring(0,tab);payloads[count]=line.substring(tab+1);payloads[count].trim();valid[count]=validQueuedRecord(kinds[count],payloads[count]);}
      else{payloads[count]=line;valid[count]=false;}
      offsets[count]=next;count++;
    }
    in.close();
  }
  size_t acknowledged=startOffset;
  for(size_t i=0;i<count;i++){
    if(!valid[i]){if(!storageDeadLetter(kinds[i],payloads[i],"malformed_queue_line"))break;acknowledged=offsets[i];continue;}
    SendResult result=sender(kinds[i],payloads[i]);if(result==SendResult::Retry)break;
    if(result==SendResult::Discard&&!storageDeadLetter(kinds[i],payloads[i],"http_rejected"))break;
    acknowledged=offsets[i];
  }
  if(acknowledged==queueAckOffset)return;SdLock lock;if(!lock.locked||!ready)return;
  if(acknowledged>queueAckOffset&&acknowledged<=queueFileBytes){
    if(acknowledged==queueFileBytes){
      const size_t previousAck=queueAckOffset;
      queueAckOffset=acknowledged;
      if(!finishPrimaryLocked()){
        // If the primary still exists, roll back so the next attempt can resend
        // safely instead of seeking EOF forever. If it was already removed,
        // recovery promotes pending.next on the next eligible pass.
        if(SD.exists(SD_QUEUE_PATH))queueAckOffset=previousAck;
        else queueFileBytes=queueAckOffset=0;
        queueRecoveryDegraded=true;
        noteCapacityOrStorageFaultLocked("queue_promotion_failed","offline_cursor_capacity_hold");
        Serial.println("WARN: queue promotion deferred; no remount while capacity is constrained");
        return;
      }
      refreshCardSpaceLocked(true);noteStorageSuccess();return;
    }
    if(!writeCursorLocked(acknowledged)){
      refreshCardSpaceLocked(true);
      if(mediaFull){
        // Keep the ACK in RAM. A reset may resend duplicates, but the backend
        // deduplicates them and the healthy full card is never unmounted.
        queueAckOffset=acknowledged;lastError="offline_cursor_capacity_hold";
        printCapacityDropLocked("offline_cursor_capacity_hold");return;
      }
      markStorageFault("cursor_write_failed");return;
    }
    queueAckOffset=acknowledged;noteStorageSuccess();
  }
}


void storageFlushEventQueue(SendResult (*sender)(const String&,const String&),size_t maxRecords){
  if(!ready||!queueTrackingReliable||maxRecords==0||eventQueueFileBytes<=eventQueueAckOffset)return;
  const size_t cap=maxRecords>8?8:maxRecords;
  String payloads[8];size_t offsets[8],count=0,startOffset=0;bool valid[8]{};
  {
    SdLock lock;if(!lock.locked||!ready||!SD.exists(SD_EVENT_QUEUE_PATH))return;
    startOffset=eventQueueAckOffset;
    File in=SD.open(SD_EVENT_QUEUE_PATH,FILE_READ);
    if(!in||!in.seek(startOffset)){if(in)in.close();return;}
    while(in.available()&&count<cap){
      String line=in.readStringUntil('\n');size_t next=in.position();line.trim();
      payloads[count]=line;valid[count]=line.length()>=2&&line[0]=='{'&&line[line.length()-1]=='}';
      offsets[count]=next;++count;
    }
    in.close();
  }
  size_t acknowledged=startOffset;
  for(size_t i=0;i<count;++i){
    if(!valid[i]){
      if(!storageDeadLetter("event",payloads[i],"malformed_event_outbox_line"))break;
      acknowledged=offsets[i];continue;
    }
    const SendResult result=sender("event",payloads[i]);
    if(result==SendResult::Retry)break;
    if(result==SendResult::Discard&&!storageDeadLetter("event",payloads[i],"http_rejected"))break;
    acknowledged=offsets[i];
  }
  if(acknowledged==eventQueueAckOffset)return;
  SdLock lock;if(!lock.locked||!ready)return;
  if(acknowledged>eventQueueAckOffset&&acknowledged<=eventQueueFileBytes){
    // Check the current tracked size after reacquiring the lock. New events may
    // have been appended while HTTP was in progress; never delete those.
    if(acknowledged==eventQueueFileBytes){
      if(!removeLocked(SD_EVENT_QUEUE_PATH)){
        noteCapacityOrStorageFaultLocked("event_outbox_delete_failed","event_delete_capacity_hold");return;
      }
      removeLocked(SD_EVENT_CURSOR_PATH);
      eventQueueFileBytes=eventQueueAckOffset=0;
      refreshCardSpaceLocked(true);noteStorageSuccess();return;
    }
    if(!writeEventCursorLocked(acknowledged)){
      refreshCardSpaceLocked(true);
      if(mediaFull){
        eventQueueAckOffset=acknowledged;lastError="event_cursor_capacity_hold";
        printCapacityDropLocked("event_cursor_capacity_hold");return;
      }
      markStorageFault("event_cursor_write_failed");return;
    }
    eventQueueAckOffset=acknowledged;noteStorageSuccess();
  }
}

static bool parseHazardLine(const String&s,HazardPoint &point){
  double a=0,b=0;unsigned long seen=0,epoch=0;float c=0;
  int fields=sscanf(s.c_str(),"%lf,%lf,%lu,%f,%lu",&a,&b,&seen,&c,&epoch);
  if(fields<4)return false;point.lat=a;point.lon=b;point.seen=(uint32_t)seen;point.confidence=c;point.epoch=fields>=5?(uint32_t)epoch:0;return true;
}
size_t storageLoadHazards(const char*path,HazardPoint*out,size_t cap){
  if(!ready||!path||!out||cap==0)return 0;SdLock lock;if(!lock.locked||!ready)return 0;
  File f=SD.open(path);size_t n=0;
  while(f&&f.available()&&n<cap){String line=f.readStringUntil('\n');HazardPoint p;if(parseHazardLine(line,p))out[n++]=p;}
  if(f)f.close();return n;
}

bool storageSaveHazard(const char*path,const HazardPoint&p){
  if(!ready||!path)return false;SdLock lock;if(!lock.locked||!ready)return false;
  char line[128];int length=snprintf(line,sizeof(line),"%.7f,%.7f,%lu,%.3f,%lu\n",p.lat,p.lon,(unsigned long)p.seen,p.confidence,(unsigned long)p.epoch);
  if(length<=0||length>=(int)sizeof(line))return false;
  if(mediaFull&&!criticalCapacityAvailableLocked((size_t)length,true)){
    lastError="critical_capacity_full";printCapacityDropLocked("hazard_catalog_retained_in_ram");return false;
  }
  File f=SD.open(path,FILE_APPEND);
  if(!f){noteCapacityOrStorageFaultLocked("hazard_open_failed","hazard_capacity_hold");return false;}
  bool ok=length>0&&length<(int)sizeof(line)&&f.write((const uint8_t*)line,length)==(size_t)length;f.close();
  if(!ok){noteCapacityOrStorageFaultLocked("hazard_write_failed","hazard_capacity_hold");return false;}
  addSuccessfulWriteBytes((size_t)length,false);noteStorageSuccess();return true;
}

size_t storageLoadPotholes(PotholePoint*out,size_t cap){return storageLoadHazards(SD_POTHOLE_PATH,out,cap);}
bool storageSavePothole(const PotholePoint&p){return storageSaveHazard(SD_POTHOLE_PATH,p);}

// ===== V6: MicroSD daily-log manager ======================================
static String u64String(uint64_t value){char text[24];snprintf(text,sizeof(text),"%llu",(unsigned long long)value);return String(text);}
static String jsonEscapeStorage(const String &value){
  String out;out.reserve(value.length()+8);
  for(size_t i=0;i<value.length();++i){
    const char c=value[i];
    if(c=='\\'||c=='"'){out+='\\';out+=c;}
    else if(c=='\n')out+="\\n";
    else if(c=='\r')out+="\\r";
    else if(c=='\t')out+="\\t";
    else if((uint8_t)c>=0x20)out+=c;
  }
  return out;
}
static bool validLogFileName(const String &name){
  if(!name.length()||name.indexOf("..")>=0||name.indexOf('/')>=0||name.indexOf('\\')>=0)return false;
  for(size_t i=0;i<name.length();++i){char c=name[i];if(!(isalnum((unsigned char)c)||c=='-'||c=='_'||c=='.'))return false;}
  return name.endsWith(".ndjson");
}
static bool isDatePrefix(const String &name,String &date){
  if(name.length()<10)return false;
  for(int i=0;i<10;++i){const char c=name[i];if(i==4||i==7){if(c!='-')return false;}else if(c<'0'||c>'9')return false;}
  date=name.substring(0,10);return true;
}
static String baseNameOnly(const String &path){int slash=path.lastIndexOf('/');return slash>=0?path.substring(slash+1):path;}

bool storageBuildLogListJson(String &outJson){
  outJson="{}";if(!ready)return false;SdLock lock(3000);if(!lock.locked||!ready)return false;
  if(!ensureLogDirLocked())return false;
  refreshCardSpaceLocked(true);
  uint64_t total=SD.totalBytes(),used=SD.usedBytes();
  outJson="{\"card_total_bytes\":"+u64String(total)+",\"card_used_bytes\":"+u64String(used)+",\"files\":[";
  bool first=true;size_t count=0;
  File root=SD.open(SD_LOG_DIR);
  if(root&&root.isDirectory()){
    File f=root.openNextFile();
    while(f&&count<SD_LOG_LIST_MAX_FILES){
      if(!f.isDirectory()){
        String name=baseNameOnly(String(f.name()));
        if(validLogFileName(name)){
          String date;const bool dated=isDatePrefix(name,date);
          if(!first)outJson+=',';first=false;
          outJson+="{\"name\":\""+jsonEscapeStorage(name)+"\",\"size\":"+String((unsigned long)f.size())+
                   ",\"date\":"+(dated?(String("\"")+date+"\""):String("null"))+",\"legacy\":false}";
          ++count;
        }
      }
      f.close();f=root.openNextFile();
    }
    root.close();
  }
  const char* legacyPaths[2]={SD_LEGACY_LOG_PATH,SD_LEGACY_LOG_OLD_PATH};
  for(uint8_t i=0;i<2&&count<SD_LOG_LIST_MAX_FILES;++i){
    if(!SD.exists(legacyPaths[i]))continue;File f=SD.open(legacyPaths[i],FILE_READ);if(!f)continue;
    String name=baseNameOnly(String(legacyPaths[i]));
    if(!first)outJson+=',';first=false;
    outJson+="{\"name\":\""+name+"\",\"size\":"+String((unsigned long)f.size())+",\"date\":null,\"legacy\":true}";
    f.close();++count;
  }
  outJson+="] ,\"file_count\":"+String((unsigned)count)+"}";
  return true;
}

bool storageReadLogTailJson(const String &fileName,size_t maxLines,String &outJson){
  outJson="{}";if(!ready||!validLogFileName(fileName))return false;
  if(maxLines==0)maxLines=1;if(maxLines>SD_LOG_VIEW_MAX_LINES)maxLines=SD_LOG_VIEW_MAX_LINES;
  String path;
  if(fileName==baseNameOnly(String(SD_LEGACY_LOG_PATH)))path=SD_LEGACY_LOG_PATH;
  else if(fileName==baseNameOnly(String(SD_LEGACY_LOG_OLD_PATH)))path=SD_LEGACY_LOG_OLD_PATH;
  else path=String(SD_LOG_DIR)+"/"+fileName;
  SdLock lock(4000);if(!lock.locked||!ready||!SD.exists(path.c_str()))return false;
  File f=SD.open(path.c_str(),FILE_READ);if(!f)return false;
  const size_t size=f.size();constexpr size_t TAIL_BYTES=32768;
  size_t start=size>TAIL_BYTES?size-TAIL_BYTES:0;
  if(start>0){f.seek(start);f.readStringUntil('\n');}
  String ring[SD_LOG_VIEW_MAX_LINES];size_t n=0,totalLines=0;
  while(f.available()){
    String line=f.readStringUntil('\n');line.trim();if(!line.length())continue;
    ring[totalLines%maxLines]=line;++totalLines;if(n<maxLines)++n;
  }
  f.close();
  outJson="{\"name\":\""+jsonEscapeStorage(fileName)+"\",\"size\":"+String((unsigned long)size)+",\"lines\":[";
  const size_t firstIndex=totalLines>n?totalLines-n:0;
  for(size_t i=0;i<n;++i){if(i)outJson+=',';const String &line=ring[(firstIndex+i)%maxLines];outJson+="\""+jsonEscapeStorage(line)+"\"";}
  outJson+="]}";return true;
}

// V8 project-folder export. The caller intentionally asks for small slices.
// Opening the file for each slice costs a little throughput, but keeps Web
// export responsive and prevents one long SD transaction from blocking logging.
bool storageReadLogChunk(const String &fileName,size_t offset,size_t maxBytes,
                         String &outData,size_t &totalSize){
  outData="";totalSize=0;
  if(!ready||!validLogFileName(fileName))return false;
  if(maxBytes==0||maxBytes>SD_EXPORT_READ_SLICE_BYTES)maxBytes=SD_EXPORT_READ_SLICE_BYTES;
  String path;
  if(fileName==baseNameOnly(String(SD_LEGACY_LOG_PATH)))path=SD_LEGACY_LOG_PATH;
  else if(fileName==baseNameOnly(String(SD_LEGACY_LOG_OLD_PATH)))path=SD_LEGACY_LOG_OLD_PATH;
  else path=String(SD_LOG_DIR)+"/"+fileName;
  SdLock lock(2500);if(!lock.locked||!ready||!SD.exists(path.c_str()))return false;
  File f=SD.open(path.c_str(),FILE_READ);if(!f){markStorageFault("log_export_open_failed");return false;}
  totalSize=f.size();
  if(offset>totalSize){f.close();return false;}
  if(offset==totalSize){f.close();noteStorageSuccess();return true;}
  if(!f.seek(offset)){f.close();markStorageFault("log_export_seek_failed");return false;}
  const size_t wanted=min(maxBytes,totalSize-offset);
  outData.reserve(wanted);
  char buffer[257];size_t remaining=wanted;
  while(remaining){
    const size_t request=min(remaining,sizeof(buffer)-1);
    const size_t got=f.read((uint8_t*)buffer,request);
    if(!got)break;buffer[got]='\0';outData.concat(buffer,(unsigned int)got);remaining-=got;
  }
  f.close();
  if(outData.length()!=wanted){markStorageFault("log_export_short_read");return false;}
  noteStorageSuccess();return true;
}

static bool rewriteHazardFileLocked(const char*path,bool deleteAll,uint32_t fromEpoch,uint32_t toEpoch,size_t &deleted){
  deleted=0;if(!SD.exists(path))return true;
  String tmp=String(path)+".tmp";String bak=String(path)+".bak";
  removeLocked(tmp.c_str());removeLocked(bak.c_str());
  File in=SD.open(path,FILE_READ);if(!in)return false;File out=SD.open(tmp.c_str(),FILE_WRITE);if(!out){in.close();return false;}
  bool ok=true;
  while(in.available()){
    String line=in.readStringUntil('\n');HazardPoint p;const bool parsed=parseHazardLine(line,p);
    bool remove=false;
    if(parsed){remove=deleteAll||(p.epoch!=0&&p.epoch>=fromEpoch&&p.epoch<=toEpoch);}
    if(remove){++deleted;continue;}
    if(line.length()&&out.println(line)!=line.length()+2){ok=false;break;}
  }
  in.close();out.close();if(!ok){removeLocked(tmp.c_str());return false;}
  if(!SD.rename(path,bak.c_str())){removeLocked(tmp.c_str());return false;}
  if(!SD.rename(tmp.c_str(),path)){SD.rename(bak.c_str(),path);return false;}
  removeLocked(bak.c_str());return true;
}

bool storageDeleteLogs(const String &fromDate,const String &toDate,bool deleteAll,
                       bool deleteHazards,uint32_t fromEpoch,uint32_t toEpoch,String &outJson){
  outJson="{}";if(!ready)return false;
  if(!deleteAll){if(fromDate.length()!=10||toDate.length()!=10||fromDate>toDate)return false;}
  SdLock lock(8000);if(!lock.locked||!ready)return false;if(!ensureLogDirLocked())return false;
  size_t deletedFiles=0;uint64_t deletedBytes=0;
  // Delete in repeated single-file passes instead of collecting a bounded
  // target array. This guarantees that date-range / delete-all operations
  // remove every matching archive even when more than SD_LOG_LIST_MAX_FILES
  // daily segments exist on the card.
  for(;;){
    String target;size_t targetBytes=0;
    File root=SD.open(SD_LOG_DIR);
    if(!root||!root.isDirectory()){if(root)root.close();break;}
    File f=root.openNextFile();
    while(f){
      if(!f.isDirectory()){
        String name=baseNameOnly(String(f.name()));String date;
        const bool dated=isDatePrefix(name,date);
        const bool match=validLogFileName(name)&&(deleteAll||(dated&&date>=fromDate&&date<=toDate));
        if(match){target=name;targetBytes=f.size();f.close();break;}
      }
      f.close();f=root.openNextFile();
    }
    root.close();
    if(!target.length())break;
    String path=String(SD_LOG_DIR)+"/"+target;
    if(SD.remove(path.c_str())){++deletedFiles;deletedBytes+=targetBytes;}
    else return false;
  }
  if(deleteAll){
    const char* legacy[2]={SD_LEGACY_LOG_PATH,SD_LEGACY_LOG_OLD_PATH};
    for(uint8_t i=0;i<2;++i)if(SD.exists(legacy[i])){File f=SD.open(legacy[i],FILE_READ);size_t bytes=f?f.size():0;if(f)f.close();if(SD.remove(legacy[i])){++deletedFiles;deletedBytes+=bytes;}}
  }
  size_t deletedPotholes=0,deletedBumps=0;
  if(deleteHazards){
    if(!rewriteHazardFileLocked(SD_POTHOLE_PATH,deleteAll,fromEpoch,toEpoch,deletedPotholes))return false;
    if(!rewriteHazardFileLocked(SD_SPEED_BUMP_PATH,deleteAll,fromEpoch,toEpoch,deletedBumps))return false;
    if(deletedPotholes||deletedBumps)hazardCatalogChanged=true;
  }
  activeLogBase="";activeLogPath="";activeLogBytes=0;
  portENTER_CRITICAL(&storageStatsMux);dailyLogBytes=0;dailyLogQuotaReached=false;portEXIT_CRITICAL(&storageStatsMux);
  nextDailyQuotaCheckMs=0;
  refreshCardSpaceLocked(true);
  lastCapacityWarningMs=0;noteStorageSuccess();
  outJson="{\"deleted_files\":"+String((unsigned)deletedFiles)+",\"deleted_bytes\":"+u64String(deletedBytes)+
          ",\"deleted_potholes\":"+String((unsigned)deletedPotholes)+",\"deleted_speed_bumps\":"+String((unsigned)deletedBumps)+
          ",\"outbox_preserved\":true}";
  return true;
}


static double hazardDistanceMeters(double lat1,double lon1,double lat2,double lon2){
  const double k=0.017453292519943295;const double earth=6371000.0;
  const double p1=lat1*k,p2=lat2*k,dp=(lat2-lat1)*k,dl=(lon2-lon1)*k;
  const double a=sin(dp/2)*sin(dp/2)+cos(p1)*cos(p2)*sin(dl/2)*sin(dl/2);
  return earth*2.0*atan2(sqrt(a),sqrt(max(0.0,1.0-a)));
}
static bool rewriteSingleHazardLocked(const char*path,double lat,double lon,float radiusM,size_t &deleted){
  deleted=0;if(!SD.exists(path))return true;String tmp=String(path)+".tmp",bak=String(path)+".bak";removeLocked(tmp.c_str());removeLocked(bak.c_str());
  File in=SD.open(path,FILE_READ);if(!in)return false;File out=SD.open(tmp.c_str(),FILE_WRITE);if(!out){in.close();return false;}bool ok=true;
  while(in.available()){String line=in.readStringUntil('\n');HazardPoint p;const bool parsed=parseHazardLine(line,p);const bool remove=parsed&&hazardDistanceMeters(lat,lon,p.lat,p.lon)<=radiusM;if(remove){++deleted;continue;}if(line.length()&&out.println(line)!=line.length()+2){ok=false;break;}}
  in.close();out.close();if(!ok){removeLocked(tmp.c_str());return false;}if(!SD.rename(path,bak.c_str())){removeLocked(tmp.c_str());return false;}if(!SD.rename(tmp.c_str(),path)){SD.rename(bak.c_str(),path);return false;}removeLocked(bak.c_str());return true;
}
bool storageDeleteHazardPoint(const String &kind,double lat,double lon,float radiusM,String &outJson){
  outJson="{}";if(!ready||!isfinite(lat)||!isfinite(lon)||lat<-90||lat>90||lon<-180||lon>180)return false;radiusM=constrain(radiusM,3.0f,30.0f);
  const char*path=kind=="pothole"?SD_POTHOLE_PATH:kind=="speed_bump"?SD_SPEED_BUMP_PATH:nullptr;if(!path)return false;SdLock lock(8000);if(!lock.locked||!ready)return false;size_t deleted=0;if(!rewriteSingleHazardLocked(path,lat,lon,radiusM,deleted)){noteCapacityOrStorageFaultLocked("hazard_point_delete_failed","hazard_rewrite_capacity_hold");return false;}if(deleted)hazardCatalogChanged=true;refreshCardSpaceLocked(true);noteStorageSuccess();
  outJson="{\"kind\":\""+kind+"\",\"deleted\":"+String((unsigned)deleted)+",\"lat\":"+String(lat,7)+",\"lon\":"+String(lon,7)+",\"radius_m\":"+String(radiusM,1)+"}";return true;
}

bool storageConsumeHazardCatalogChanged(){
  if(!hazardCatalogChanged)return false;hazardCatalogChanged=false;return true;
}

uint32_t storageIoFailureCount(){return totalIoFailures;}
uint32_t storageRemountCount(){return totalRemounts;}
uint8_t storageIoFailureStreak(){return ioFailureStreak;}
