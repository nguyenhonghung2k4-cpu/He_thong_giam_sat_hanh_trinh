#pragma once
#include <Arduino.h>

struct RuntimeConfig {
  float overspeedWarningKph;
  float overspeedClearKph;
  float geofenceWarningRadiusM;
  float geofenceRearmRadiusM;
  float potholeConfidence;
  float speedBumpConfidence;
};

bool runtimeConfigBegin();
const RuntimeConfig &runtimeConfigGet();
String runtimeConfigJson();
bool runtimeConfigUpdate(float overspeedWarningKph, float overspeedClearKph,
                         float geofenceWarningRadiusM, float geofenceRearmRadiusM,
                         float potholeConfidence, float speedBumpConfidence,
                         String &resultJson);
