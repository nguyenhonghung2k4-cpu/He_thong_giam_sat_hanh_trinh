@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo Chua tim thay Node.js. Can Node.js 22.16 tro len: https://nodejs.org/
  pause
  exit /b 1
)
node -e "const [a,b]=process.versions.node.split('.').map(Number);process.exit(a>22||(a===22&&b>=16)?0:1)"
if errorlevel 1 (
  echo Can Node.js 22.16 tro len.
  pause
  exit /b 1
)
echo Mo web co dinh. Giu cua so nay mo trong khi su dung.
node "tools\start-online.mjs"
if errorlevel 1 pause
