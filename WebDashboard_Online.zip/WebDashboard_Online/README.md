# Dashboard Online V11.6.0

Hướng dẫn chính: [README project](../README.md).

Mở `../START_ONLINE.bat`, chờ xác nhận rồi truy cập:
<https://giam-sat-hanh-trinh-hh-2026.pleasantgoldfish16.chatgpt.site>

Điện thoại không phải cùng Wi-Fi với PC. Không có mật khẩu; mọi người biết link đều có quyền xem, điều khiển và xóa. PC phải bật, có Internet; ESP32-S3 tiếp tục gửi tới IP LAN của PC. Không cần nạp lại firmware trong bản web này.

Không chia sẻ `online.private.json`, `config.local.json`, database hoặc log chứa vị trí. Khóa connector không phải mật khẩu của khách. Bộ chạy dùng cloudflared tạo đường hầm bên dưới cổng cố định; không nhập địa chỉ đường hầm tạm vào điện thoại.

`npm start` chạy Online; `npm run stop` dừng phiên do bộ chạy sở hữu. Các kiểm thử dữ liệu tạm không thay cho kiểm chứng phần cứng. Xem `../VALIDATION.md`.
