// Read-only, bounded browser transport. This never writes telemetry, routes,
// events or device commands; it only exposes the latest accepted live snapshot.
import { randomUUID } from 'node:crypto';

const LABELS = new Set(['duong_bang_phang', 'go_giam_toc', 'o_ga']);
const finite = value => value !== null && value !== undefined && value !== '' && Number.isFinite(Number(value));
const flag = value => value === true || value === 1;
const score = value => finite(value) && Number(value) >= 0 && Number(value) <= 1 ? Number(value) : null;
const eventStates = new Set(['warmup','scope_settling','flat','below_threshold','pending_confirmation','confirmed','latched']);
function roadEvent(latest) {
  let input=latest?.road_event_json;
  try { if(typeof input==='string')input=JSON.parse(input); } catch { return null; }
  if(!input || typeof input!=='object' || !eventStates.has(input.state))return null;
  const result={state:input.state};
  for(const key of ['reason','last_event_id','last_event_label','last_event_reason'])
    if(typeof input[key]==='string')result[key]=input[key].slice(0,180);
  for(const key of ['threshold','strong_threshold','candidate_windows','required_windows','last_event_uptime_ms'])
    if(finite(input[key]))result[key]=Number(input[key]);
  for(const key of ['last_event_position_attached','last_event_new_map_point'])
    if(typeof input[key]==='boolean')result[key]=input[key];
  return result;
}

export function buildRoadCurrent(latest, now = Date.now()) {
  const event=roadEvent(latest);
  const source = !latest ? 'unknown' : String(latest.device_id || '').endsWith('-auto-demo')
    ? 'auto_demo' : String(latest.device_id || '').endsWith('-demo') && !String(latest.device_id || '').endsWith('-direct-demo')
      ? 'sample_demo' : 'adxl345';
  const age = latest && finite(latest.ingested_at) ? now - Number(latest.ingested_at) : null;
  const result = { valid: false, source, window_ms: 2000, age_ms: age !== null && age >= 0 ? age : null,
    sample_time_ms: null, reason: 'missing', label: null, confidence: null,
    scores: { duong_bang_phang: null, go_giam_toc: null, o_ga: null },
    x_g: null, y_g: null, z_g: null, inference_ms: null, ...(event?{event}:{}) };
  if (!latest) return result;
  if (age === null || age < 0 || age > 3000 || flag(latest.is_resend)) return { ...result, reason: 'gateway_offline' };
  if (!flag(latest.ai_ready)) return { ...result, reason: 'ai_not_ready' };
  if (!flag(latest.road_valid) || !LABELS.has(latest.road_label) || score(latest.confidence) === null ||
      (source === 'adxl345' && !flag(latest.adxl_healthy))) return { ...result, reason: 'ai_stale' };
  // age_ms is the server snapshot age, not a fabricated physical sample time.
  return { ...result, valid: true, reason: 'fresh', label: latest.road_label,
    confidence: score(latest.confidence), scores: { duong_bang_phang: score(latest.flat_confidence),
      go_giam_toc: score(latest.speed_bump_confidence), o_ga: score(latest.pothole_confidence) },
    x_g: finite(latest.x_g) ? Number(latest.x_g) : null,
    y_g: finite(latest.y_g) ? Number(latest.y_g) : null,
    z_g: finite(latest.z_g) ? Number(latest.z_g) : null,
    inference_ms: finite(latest.inference_ms) ? Number(latest.inference_ms) : null };
}

export function createUpdateFeed({ capacity = 128, now = Date.now } = {}) {
  const epoch = randomUUID(); let sequence = 0; const rows = [];
  const cursor = () => `${epoch}:${sequence}`;
  return {
    publish(device, kind, extra = {}) {
      // Motion and periodic telemetry are replaceable snapshots, not an outbox.
      if (kind === 'direct_realtime' || kind === 'telemetry') return;
      const { event, ...rest } = extra;
      const { raw_json, ...safeEvent } = event || {};
      rows.push({ n: ++sequence, device_id: String(device || '') || null, kind,
        received_at: new Date(now()).toISOString(), ...rest, ...(event ? { event: safeEvent } : {}) });
      if (rows.length > capacity) rows.splice(0, rows.length - capacity);
    },
    read(device, after = '') {
      const match = String(after).match(/^([a-f0-9-]+):(\d+)$/);
      const n = match && match[1] === epoch ? Number(match[2]) : null;
      const reset = n === null || !Number.isSafeInteger(n) || n > sequence ||
        (rows.length > 0 && n < rows[0].n - 1);
      const updates = reset ? [] : rows.filter(row => row.n > n && (!device || !row.device_id || row.device_id === device));
      return { cursor: cursor(), refresh_required: reset, updates: updates.map(({ n: ignored, ...row }) => row) };
    },
  };
}
