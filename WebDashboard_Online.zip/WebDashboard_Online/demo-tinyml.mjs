// Raw input contracts are shared by the server and tests. No prediction is
// computed here: only the authenticated ESP32-S3 command result is authoritative.
import { readFileSync } from 'node:fs';

export const DEMO_INFERENCE_TTL_MS = 45000;
export const DEMO_MODEL = Object.freeze({ frequency_hz: 100, frame_samples: 200, axes: 3, units: 'g' });

export function loadDemoSamples(path) {
  const manifest = JSON.parse(readFileSync(path, 'utf8'));
  for (const key of Object.keys(DEMO_MODEL)) {
    if (manifest.model?.[key] !== DEMO_MODEL[key]) throw new Error(`Sample model mismatch: ${key}`);
  }
  const ids = new Set();
  if (!Array.isArray(manifest.samples) || manifest.samples.length < 2) throw new Error('Missing raw demo samples');
  for (const sample of manifest.samples) {
    if (!['pothole', 'speed_bump'].includes(sample.id) || ids.has(sample.id)) throw new Error('Invalid sample ID');
    ids.add(sample.id);
    if (sample.frequency_hz !== DEMO_MODEL.frequency_hz || sample.frame_samples !== DEMO_MODEL.frame_samples ||
        sample.units !== 'g' || !Array.isArray(sample.values) || sample.values.length !== DEMO_MODEL.frame_samples * 3 ||
        !sample.values.every(v => typeof v === 'number' && Number.isFinite(v) && Math.abs(v) <= 16)) {
      throw new Error(`Invalid raw XYZ window: ${sample.id}`);
    }
  }
  return manifest;
}

export function normalizeInferenceResult(result) {
  if (result?.inference_ok !== true || result.frame_samples !== DEMO_MODEL.frame_samples ||
      result.frequency_hz !== DEMO_MODEL.frequency_hz || result.units !== 'g' ||
      result.model_version !== 'telematics-ei-1.0.1' || !Number.isInteger(result.inference_ms) || result.inference_ms < 0) {
    throw new Error('ESP inference/model contract mismatch');
  }
  const labels = ['duong_bang_phang', 'go_giam_toc', 'o_ga'];
  if (!labels.includes(result.label) || typeof result.confidence !== 'number' ||
      !Number.isFinite(result.confidence) || result.confidence < 0 || result.confidence > 1) {
    throw new Error('Invalid ESP classification');
  }
  const scores = {};
  for (const label of labels) {
    const value = result.scores?.[label];
    if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > 1) throw new Error('Invalid ESP score');
    scores[label] = value;
  }
  if (Math.abs(scores[result.label] - result.confidence) > 0.02 ||
      labels.some(label => scores[label] > result.confidence + 0.02)) throw new Error('Inconsistent ESP prediction');
  return {
    valid: true, label: result.label, confidence: result.confidence, scores,
    inference_ms: Number.isFinite(result.inference_ms) ? result.inference_ms : null,
    x_g: Number.isFinite(result.x_g) ? result.x_g : null,
    y_g: Number.isFinite(result.y_g) ? result.y_g : null,
    z_g: Number.isFinite(result.z_g) ? result.z_g : null,
    source: 'esp32s3_raw_sample_inference',
    hazard_accepted: result.hazard_accepted === true && result.label !== 'duong_bang_phang',
  };
}
