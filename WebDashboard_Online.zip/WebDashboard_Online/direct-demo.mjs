// Direct demo: only the ESP32-S3 integrates motion and performs TinyML.
// This module never generates an acceleration sample, inference or hazard.
import { randomUUID } from 'node:crypto';
import { listDemoPresets, getDemoPreset, DEMO_PRESET_ATTRIBUTION, DEMO_ROAD_PROVENANCE } from './direct-demo-presets.mjs';

export const DIRECT_SUFFIX = '-direct-demo';
const TERMINAL = new Set(['stopped', 'failed', 'interrupted']);
const STATES = new Set(['running', 'paused', 'can_stale', 'completed', 'stopped']);
const DIRECT_ACTIONS = new Set(['direct_demo_start', 'direct_demo_control']);
const EXPECTED = { start: ['running', 'paused', 'can_stale', 'completed'], pause: ['paused'],
  resume: ['running', 'can_stale', 'completed'], repeat: ['running', 'can_stale', 'completed'], stop: ['stopped'] };
const FRESH_MS = 10000, COMMAND_TTL = 15000;
const REALTIME_FRESH_MS = 1500, REALTIME_MIN_INTERVAL_MS = 100;
const finite = n => typeof n === 'number' && Number.isFinite(n);
const uint32 = n => Number.isInteger(n) && n >= 0 && n <= 4294967295;
const newer32 = (a, b) => uint32(a) && uint32(b) && ((a - b) >>> 0) > 0 && ((a - b) >>> 0) < 0x80000000;
const coords = p => Array.isArray(p) && p.length === 2 && p.every(finite) && Math.abs(p[0]) <= 85 && Math.abs(p[1]) <= 180;
export const isDirectDevice = id => typeof id === 'string' && id.endsWith(DIRECT_SUFFIX);
export function distanceM(a, b) {
  const r = Math.PI / 180, dlat = (b[0] - a[0]) * r, dlon = (b[1] - a[1]) * r;
  const h = Math.sin(dlat / 2) ** 2 + Math.cos(a[0] * r) * Math.cos(b[0] * r) * Math.sin(dlon / 2) ** 2;
  return 6371000 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(Math.max(0, 1 - h)));
}
export const routeLength = points => points.slice(1).reduce((sum, p, i) => sum + distanceM(points[i], p), 0);
function pointAtDistance(points, distance) {
  for (let i = 1; i < points.length; i++) {
    const length = distanceM(points[i - 1], points[i]);
    if (distance <= length) { const t = length > 0 ? distance / length : 0;
      return [points[i - 1][0] + t * (points[i][0] - points[i - 1][0]), points[i - 1][1] + t * (points[i][1] - points[i - 1][1])]; }
    distance -= length;
  }
  return points.at(-1);
}
function distanceToRoute(point, points) {
  const k = Math.cos(point[0] * Math.PI / 180), scale = 111195;
  const xy = p => [(p[1] - point[1]) * k * scale, (p[0] - point[0]) * scale];
  let best = Infinity;
  for (let i = 1; i < points.length; i++) {
    const a = xy(points[i - 1]), b = xy(points[i]), dx = b[0] - a[0], dy = b[1] - a[1];
    const t = Math.min(1, Math.max(0, -(a[0] * dx + a[1] * dy) / (dx * dx + dy * dy || 1)));
    best = Math.min(best, Math.hypot(a[0] + t * dx, a[1] + t * dy));
  }
  return best;
}

export function createDirectDemo({ db, HttpError, queueCommand, insertTelemetry, startRoute, endRoute,
  broadcast, autoActive, now = Date.now }) {
  db.exec(`CREATE TABLE IF NOT EXISTS direct_demo_sessions (
    session_id TEXT PRIMARY KEY, device_id TEXT NOT NULL, state TEXT NOT NULL,
    updated_at INTEGER NOT NULL, data_json TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_direct_demo_session_time ON direct_demo_sessions(updated_at DESC);
    CREATE TABLE IF NOT EXISTS direct_demo_road_cache (
    device_id TEXT PRIMARY KEY, fetched_at INTEGER NOT NULL, lat REAL NOT NULL, lon REAL NOT NULL, roads_json TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS direct_demo_passes (
    session_id TEXT NOT NULL, pass_index INTEGER NOT NULL, route_id INTEGER NOT NULL,
    PRIMARY KEY(session_id,pass_index));
    CREATE TABLE IF NOT EXISTS direct_demo_revision (
    singleton INTEGER PRIMARY KEY CHECK(singleton=1), revision INTEGER NOT NULL);
    INSERT OR IGNORE INTO direct_demo_revision VALUES(1,0);`);
  // Persist ordering across HTTP responses, sessions and server restarts.
  // Wall-clock updated_at can tie or move backwards; it is not a version.
  // Existing databases keep every session/route; old JSON defaults to revision 0.
  const revisionOf = s => Number.isSafeInteger(s?.revision) && s.revision >= 0 ? s.revision : 0;
  const maxStoredRevision = db.prepare('SELECT data_json FROM direct_demo_sessions').all()
    .reduce((maximum, row) => Math.max(maximum, revisionOf(JSON.parse(row.data_json))), 0);
  db.prepare('UPDATE direct_demo_revision SET revision=MAX(revision,?) WHERE singleton=1').run(maxStoredRevision);
  const nextRevision = db.prepare('UPDATE direct_demo_revision SET revision=revision+1 WHERE singleton=1 RETURNING revision');
  // Keep the legacy road-cache table intact for nondestructive upgrades. New
  // starts use only the prepared catalog; already-running sessions retain their
  // persisted route geometry and all existing control/replay behavior.
  // One active direct session, one volatile latest frame. Never an outbox,
  // telemetry row, route point, event or input to the inference/hazard paths.
  let realtimeSlot = null;
  const fail = (status, message, code) => { throw new HttpError(status, message, code); };
  const parse = row => { if (!row) return null; const s = JSON.parse(row.data_json); return { ...s, revision: revisionOf(s) }; };
  const latest = () => parse(db.prepare('SELECT * FROM direct_demo_sessions ORDER BY updated_at DESC,rowid DESC LIMIT 1').get());
  const find = id => parse(db.prepare('SELECT * FROM direct_demo_sessions WHERE session_id=?').get(id));
  const save = session => { session.revision = nextRevision.get().revision; session.updated_at = now(); db.prepare(`INSERT INTO direct_demo_sessions VALUES(?,?,?,?,?)
    ON CONFLICT(session_id) DO UPDATE SET state=excluded.state,updated_at=excluded.updated_at,data_json=excluded.data_json`)
    .run(session.session_id, session.device_id, session.state, session.updated_at, JSON.stringify(session)); return session; };
  const active = () => parse(db.prepare("SELECT * FROM direct_demo_sessions WHERE state NOT IN ('stopped','failed','interrupted') ORDER BY updated_at DESC,rowid DESC LIMIT 1").get());
  const publish = s => { broadcast(s.device_id, 'direct_demo', { session: publicSession(s) }); broadcast(s.virtual_device_id, 'direct_demo', { session: publicSession(s) }); };
  const publicSession = s => s ? { ...s, realtime: realtimeFor(s), stale: !s.last_telemetry || now() - s.last_telemetry > FRESH_MS,
    source_label: 'Tọa độ mô phỏng – AI thực' } : null;
  function realtimeFor(s) {
    const frame = realtimeSlot?.frame;
    if (!s || !frame || TERMINAL.has(s.state) || frame.direct_demo.session_id !== s.session_id ||
        frame.boot_id !== s.physical_boot_id || frame.direct_demo.pass_index !== s.pass_index ||
        now() - frame.received_at_ms > REALTIME_FRESH_MS ||
        (uint32(s.last_snapshot?.capture_ms) && !newer32(frame.uptime_ms, s.last_snapshot.capture_ms))) return null;
    return frame;
  }
  function realtime(payload, isResend = false) {
    if (isResend) fail(422, 'Kênh trực tiếp không nhận dữ liệu gửi lại', 'direct_realtime_resend_forbidden');
    if (payload.type !== 'direct_realtime' || typeof payload.device_id !== 'string' ||
        !/^[A-Za-z0-9_.:-]{1,180}$/.test(payload.device_id) || isDirectDevice(payload.device_id) ||
        payload.device_id.endsWith('-auto-demo') || typeof payload.boot_id !== 'string' ||
        !payload.boot_id.length || payload.boot_id.length > 180 || !uint32(payload.seq) || !uint32(payload.uptime_ms) ||
        typeof payload.direct_demo?.session_id !== 'string' || !/^[A-Za-z0-9-]{1,48}$/.test(payload.direct_demo.session_id)) {
      fail(422, 'Gói vị trí trực tiếp không hợp lệ', 'invalid_direct_realtime');
    }
    const s = find(payload.direct_demo?.session_id);
    if (!s || TERMINAL.has(s.state) || s.device_id !== payload.device_id || s.physical_boot_id !== payload.boot_id) {
      fail(409, 'Gói trực tiếp không thuộc phiên Gateway đang hoạt động', 'direct_realtime_session_mismatch');
    }
    const snapshot = validateSnapshot(s, payload.direct_demo);
    if (!snapshot || !uint32(snapshot.capture_ms) || snapshot.capture_ms !== payload.uptime_ms) {
      fail(422, 'Snapshot vị trí trực tiếp không hợp lệ', 'invalid_direct_realtime_snapshot');
    }
    // Only durable telemetry/command ACK may establish a pass or lifecycle.
    if (snapshot.pass_index !== s.pass_index) return { accepted: false, reason: 'direct_realtime_pass_mismatch' };
    if (uint32(s.last_snapshot?.capture_ms) && !newer32(snapshot.capture_ms, s.last_snapshot.capture_ms)) {
      return { accepted: false, reason: 'older_than_durable_snapshot' };
    }
    const previous = realtimeSlot?.session_id === s.session_id ? realtimeSlot : null;
    if (previous && (!newer32(payload.seq, previous.sequence) || !newer32(payload.uptime_ms, previous.uptime_ms))) {
      return { accepted: false, reason: 'old_direct_realtime_sequence' };
    }
    if (previous && now() - previous.frame.received_at_ms < REALTIME_MIN_INTERVAL_MS) {
      return { accepted: false, reason: 'direct_realtime_rate_limited' };
    }
    let ecu;
    if (payload.ecu !== undefined) {
      const e = payload.ecu;
      if (!e || typeof e !== 'object' || typeof e.online !== 'boolean' || !finite(e.speed_kph) ||
          e.speed_kph < 0 || e.speed_kph > 180 || !Number.isInteger(e.adc_raw) || e.adc_raw < 0 || e.adc_raw > 65535) {
        fail(422, 'Trạng thái ECU trực tiếp không hợp lệ', 'invalid_direct_realtime_ecu');
      }
      ecu = { online: e.online, speed_kph: e.speed_kph, adc_raw: e.adc_raw };
    }
    if (payload.audio_active !== undefined && typeof payload.audio_active !== 'boolean') {
      fail(422, 'Trạng thái âm thanh không hợp lệ', 'invalid_direct_realtime_audio');
    }
    const frame = { device_id: s.virtual_device_id, kind: 'direct_realtime', source_device_id: s.device_id,
      boot_id: s.physical_boot_id, sequence: payload.seq, uptime_ms: payload.uptime_ms, received_at_ms: now(),
      direct_demo: Object.fromEntries(['session_id', 'active', 'state', 'pass_index', 'lat', 'lon', 'distance_m',
        'route_length_m', 'speed_kph', 'input_speed_kph', 'speed_multiplier', 'capture_ms'].map(key => [key, snapshot[key]])),
      ...(ecu ? { ecu } : {}), ...(payload.audio_active === undefined ? {} : { audio_active: payload.audio_active }) };
    realtimeSlot = { session_id: s.session_id, sequence: payload.seq, uptime_ms: payload.uptime_ms, frame };
    broadcast(s.virtual_device_id, 'direct_realtime', frame);
    return { accepted: true, received_at_ms: frame.received_at_ms };
  }
  function gateway(deviceId) {
    if (typeof deviceId !== 'string' || !/^[A-Za-z0-9_.:-]{1,180}$/.test(deviceId) || isDirectDevice(deviceId) || deviceId.endsWith('-auto-demo')) fail(422, 'Chọn Gateway vật lý', 'physical_gateway_required');
    const row = db.prepare('SELECT * FROM telemetry WHERE device_id=? AND is_resend=0 ORDER BY ingested_at DESC,id DESC LIMIT 1').get(deviceId);
    if (!row || now() - Number(row.ingested_at) > FRESH_MS) fail(409, 'Gateway chưa có telemetry mới trong 10 giây', 'gateway_offline');
    if (!/^11\.(?:5|6)\./.test(String(row.firmware_version || ''))) fail(409, 'Nạp firmware V11.5 hoặc V11.6 hỗ trợ demo trực tiếp trước', 'direct_firmware_required');
    if (row.ecu_online !== 1 && row.ecu_online !== true) fail(409, 'Node ECU/CAN chưa kết nối; cần tốc độ biến trở thật để chạy demo', 'direct_can_required');
    return row;
  }
  async function roads() {
    return { roads: listDemoPresets(), source: 'osm_road', synthetic: false,
      requires_gps: false, requires_network: false, attribution: DEMO_PRESET_ATTRIBUTION,
      provenance: DEMO_ROAD_PROVENANCE };
  }
  function expire() {
    const s = active(); if (!s?.command_id) return;
    const command = db.prepare('SELECT * FROM device_commands WHERE id=?').get(s.command_id);
    if (!command || command.status !== 'pending') return;
    const params = JSON.parse(command.params_json);
    if (now() <= params.expires_at_ms) return;
    db.prepare("UPDATE device_commands SET status='failed',completed_at=?,result_json=? WHERE id=? AND status='pending'")
      .run(now(), JSON.stringify({ error: 'direct_command_expired' }), command.id);
    // Delivery may have succeeded with a lost ACK. Never silently release the
    // mutual-exclusion lock in that uncertain case; wait for fresh firmware.
    s.error = 'Chưa nhận xác nhận từ ESP32-S3; kiểm tra kết nối và gửi Dừng nếu cần.';
    s.state = !s.command_delivered_at && command.action === 'direct_demo_start' ? 'failed' : 'unknown';
    s.pending_operation = null; save(s); publish(s);
  }
  const assertIdle = () => { expire(); if (active()) fail(409, 'Dừng và xác nhận demo trực tiếp trước', 'direct_demo_active'); };
  function start(input) {
    expire();
    if (autoActive()) fail(409, 'Dừng demo tự động trước', 'automatic_demo_active');
    const previous = active();
    if (previous) {
      if (previous.device_id === input.device_id && previous.route.id === input.road_id && previous.speed_multiplier === (input.speed_multiplier ?? 2) && previous.state === 'starting') return { session: publicSession(previous), command_id: previous.command_id, duplicate: true };
      fail(409, 'Demo trực tiếp đang hoạt động hoặc chờ xác nhận', 'direct_demo_active');
    }
    const row = gateway(input.device_id), multiplier = input.speed_multiplier ?? 2;
    if (!finite(multiplier) || multiplier < .5 || multiplier > 5) fail(422, 'Hệ số tốc độ phải từ 0.5 đến 5', 'invalid_speed_multiplier');
    const road = getDemoPreset(input.road_id);
    if (!road) fail(422, 'Chọn một đường có trong danh sách máy chủ', 'unknown_road');
    const s = { session_id: randomUUID(), device_id: input.device_id, virtual_device_id: input.device_id + DIRECT_SUFFIX,
      physical_boot_id: row.boot_id, state: 'starting', route: road, speed_multiplier: multiplier,
      created_at: now(), last_telemetry: null, last_snapshot: null, last_sequence: -1,
      pass_index: 0, route_id: null, error: '', pending_operation: 'start', command_delivered_at: null };
    // Old demo commands must not unexpectedly start audio/sample inference in
    // the gap before firmware enters direct mode.
    db.prepare("UPDATE device_commands SET status='failed',completed_at=?,result_json=? WHERE device_id=? AND status='pending' AND action IN ('demo_infer','audio_play')")
      .run(now(), JSON.stringify({ error: 'direct_demo_starting' }), s.device_id);
    const cmd = queueCommand(s.device_id, 'direct_demo_start', { session_id: s.session_id,
      route_points: road.points.flat(), speed_multiplier: multiplier, expires_at_ms: now() + COMMAND_TTL });
    s.command_id = Number(cmd.id); save(s); publish(s); return { session: publicSession(s), command_id: s.command_id };
  }
  function control(input) {
    expire(); const s = find(input.session_id);
    if (!s || TERMINAL.has(s.state)) fail(409, 'Phiên demo đã kết thúc', 'direct_session_inactive');
    const operation = input.operation;
    if (!['pause', 'resume', 'repeat', 'stop'].includes(operation)) fail(422, 'Lệnh demo không hợp lệ', 'invalid_direct_control');
    const pending = db.prepare("SELECT * FROM device_commands WHERE id=? AND status='pending'").get(s.command_id);
    if (pending) {
      if (s.pending_operation === operation) return { session: publicSession(s), command_id: s.command_id, duplicate: true };
      if (operation !== 'stop') fail(409, 'Đợi lệnh trước được xác nhận', 'direct_command_pending');
      db.prepare("UPDATE device_commands SET status='failed',completed_at=?,result_json=? WHERE id=?")
        .run(now(), JSON.stringify({ error: 'superseded_by_stop' }), pending.id);
    }
    if (operation === 'repeat' && !['paused', 'completed'].includes(s.state)) fail(409, 'Tạm dừng hoặc đi hết đường trước khi chạy lại', 'repeat_requires_pause');
    if (operation === 'resume' && s.state !== 'paused') fail(409, 'Chỉ tiếp tục khi đang tạm dừng', 'resume_requires_pause');
    const cmd = queueCommand(s.device_id, 'direct_demo_control', { session_id: s.session_id, operation, expires_at_ms: now() + COMMAND_TTL });
    s.command_id = Number(cmd.id); s.command_delivered_at = null; s.pending_operation = operation; s.error = '';
    save(s); publish(s); return { session: publicSession(s), command_id: s.command_id };
  }
  function validateSnapshot(s, snapshot) {
    if (!snapshot || snapshot.session_id !== s.session_id || !STATES.has(snapshot.state) ||
        (snapshot.capture_ms !== undefined && !uint32(snapshot.capture_ms)) ||
        !Number.isSafeInteger(snapshot.pass_index) || snapshot.pass_index < 1 || snapshot.pass_index > 4294967295 ||
        !coords([snapshot.lat, snapshot.lon]) || !finite(snapshot.distance_m) || snapshot.distance_m < 0 ||
        snapshot.distance_m > s.route.length_m + 3 || !finite(snapshot.route_length_m) || Math.abs(snapshot.route_length_m - s.route.length_m) > 3 ||
        !finite(snapshot.speed_kph) || snapshot.speed_kph < 0 || snapshot.speed_kph > 901 ||
        !finite(snapshot.input_speed_kph) || snapshot.input_speed_kph < 0 || snapshot.input_speed_kph > 181 ||
        !finite(snapshot.speed_multiplier) || Math.abs(snapshot.speed_multiplier - s.speed_multiplier) > .001 ||
        (snapshot.state !== 'running' && snapshot.speed_kph !== 0) ||
        snapshot.active !== (snapshot.state !== 'stopped') || distanceToRoute([snapshot.lat, snapshot.lon], s.route.points) > 6 ||
        distanceM([snapshot.lat, snapshot.lon], pointAtDistance(s.route.points, snapshot.distance_m)) > 6) return null;
    return { ...snapshot };
  }
  function updateSnapshot(s, snapshot, { telemetry = false, sequence = null } = {}) {
    const repeated = s.last_snapshot && snapshot.pass_index > s.pass_index;
    const confirmsPending = s.pending_operation && EXPECTED[s.pending_operation]?.includes(snapshot.state) &&
      (s.pending_operation !== 'repeat' || snapshot.pass_index > s.pass_index);
    if (repeated) { endRoute(s.virtual_device_id); s.route_id = null; }
    s.pass_index = snapshot.pass_index;
    s.state = snapshot.state; s.last_snapshot = snapshot; s.error = '';
    if (telemetry) { s.last_telemetry = now(); s.last_sequence = sequence; }
    if (confirmsPending) {
      const command = db.prepare('SELECT * FROM device_commands WHERE id=?').get(s.command_id);
      if (command?.status === 'pending') db.prepare("UPDATE device_commands SET status='done',completed_at=?,result_json=? WHERE id=?")
        .run(now(), JSON.stringify({ direct_demo: snapshot, confirmed_by_telemetry: telemetry }), command.id);
      s.pending_operation = null;
    }
    if (snapshot.active && !s.route_id) {
      s.route_id = startRoute(s.virtual_device_id, false).route.id;
      db.prepare('INSERT OR IGNORE INTO direct_demo_passes VALUES(?,?,?)').run(s.session_id,s.pass_index,s.route_id);
    }
    save(s);
  }
  function ack(row, ok, result) {
    const params = JSON.parse(row.params_json), s = find(params.session_id);
    if (row.status !== 'pending') return { status: row.status, result: JSON.parse(row.result_json || '{}'), duplicate_ack: true };
    if (!s || s.device_id !== row.device_id || TERMINAL.has(s.state) || s.command_id !== Number(row.id)) return { status: 'failed', result: { error: 'direct_session_inactive' } };
    const operation = row.action === 'direct_demo_start' ? 'start' : params.operation;
    // A start might expire before the main loop ever applies it. A subsequent
    // stop ACK explicitly reporting no session safely releases the lock; do
    // not force a hardware reboot just to dismiss an unapplied request.
    const confirmsNoActiveSession = result.direct_demo === null ||
      (result.direct_demo?.active === false && result.direct_demo.state === 'stopped');
    if (operation === 'stop' && !ok && result.error === 'session_mismatch' && confirmsNoActiveSession) {
      s.state = 'stopped'; s.pending_operation = null; s.error = '';
      save(s); endRoute(s.virtual_device_id); publish(s);
      return { status: 'done', result: { ...result, confirmed_no_active_session: true } };
    }
    const snapshot = ok && result.applied === true && validateSnapshot(s, result.direct_demo);
    if (!snapshot || !EXPECTED[operation]?.includes(snapshot.state) || snapshot.pass_index < s.pass_index ||
        (operation === 'repeat' && snapshot.pass_index <= s.pass_index)) {
      s.error = String(result.error || 'ESP32-S3 chưa xác nhận trạng thái áp dụng hợp lệ').slice(0, 200);
      s.pending_operation = null;
      if (row.action === 'direct_demo_start') s.state = ok || s.command_delivered_at ? 'unknown' : 'failed';
      save(s); publish(s); return { status: 'failed', result: { ...result, error: s.error } };
    }
    updateSnapshot(s, snapshot);
    if (['completed', 'stopped'].includes(s.state)) endRoute(s.virtual_device_id);
    publish(s); return { status: 'done', result: { ...result, direct_demo: snapshot } };
  }
  function delivered(row) {
    if (!DIRECT_ACTIONS.has(row.action)) return;
    const s = find(JSON.parse(row.params_json).session_id);
    if (s && s.command_id === Number(row.id) && !s.command_delivered_at) { s.command_delivered_at = now(); save(s); }
  }
  function virtualPayload(payload, s, snapshot) {
    const moving = snapshot.state === 'running' && snapshot.speed_kph > 0;
    return { ...payload, device_id: s.virtual_device_id, boot_id: s.session_id,
      demo_mode: 'direct', source_device_id: s.device_id, physical_boot_id: payload.boot_id,
      physical_location: payload.location, direct_demo: snapshot,
      location: { valid: true, lat: snapshot.lat, lon: snapshot.lon, speed_kph: snapshot.speed_kph,
        satellites: payload.location?.satellites, hdop: payload.location?.hdop, course_deg: null,
        filter: { version: 1, state: moving ? 'moving' : 'stationary', stationary: !moving,
          segment_valid: true, fix_seq: payload.seq, position_epoch: snapshot.pass_index } },
      system: { ...payload.system, navigation_ready: true, physical_navigation_ready: payload.system?.navigation_ready },
      trip: { ...payload.trip, distance_km: snapshot.distance_m / 1000 } };
  }
  function telemetry(payload, isResend) {
    const sessionId = payload.direct_demo?.session_id, s = sessionId ? find(sessionId) : active();
    if (!s || s.device_id !== payload.device_id) return null;
    if (!isResend && !TERMINAL.has(s.state) && payload.boot_id !== s.physical_boot_id) {
      // Old boot messages already in the database are not a fresh restart.
      const prior = db.prepare('SELECT MIN(ingested_at) AS first_seen FROM telemetry WHERE device_id=? AND boot_id=?').get(payload.device_id, payload.boot_id);
      if (!prior?.first_seen || prior.first_seen >= s.created_at) {
        s.state = 'interrupted'; s.error = 'Gateway đã khởi động lại; demo không tự tiếp tục.'; s.pending_operation = null;
        db.prepare("UPDATE device_commands SET status='failed',completed_at=?,result_json=? WHERE device_id=? AND status='pending' AND action LIKE 'direct_demo_%'")
          .run(now(), JSON.stringify({ error: 'gateway_restarted' }), s.device_id);
        save(s); endRoute(s.virtual_device_id); publish(s);
      }
      return null;
    }
    if (payload.boot_id !== s.physical_boot_id) return null;
    const snapshot = validateSnapshot(s, payload.direct_demo); if (!snapshot) return null;
    const olderCapture = uint32(snapshot.capture_ms) && uint32(s.last_snapshot?.capture_ms) &&
      snapshot.capture_ms !== s.last_snapshot.capture_ms && !newer32(snapshot.capture_ms, s.last_snapshot.capture_ms);
    const old = isResend || TERMINAL.has(s.state) || snapshot.pass_index < s.pass_index || Number(payload.seq) <= s.last_sequence || olderCapture;
    if (!old) updateSnapshot(s, snapshot, { telemetry: true, sequence: Number(payload.seq) });
    const virtual = virtualPayload(payload, s, snapshot);
    // Terminal/stale/resent snapshots can be historical rows only. They must
    // never steal the active map, append a current route, or reopen a session.
    insertTelemetry(virtual, old);
    if (!old) { if (['completed', 'stopped'].includes(s.state)) endRoute(s.virtual_device_id); publish(s); broadcast(s.virtual_device_id, 'telemetry', { sequence: payload.seq }); }
    return virtual;
  }
  function event(payload) {
    if (payload.event?.demo_mode !== 'direct') return null;
    const s = find(payload.direct_demo?.session_id), snapshot = s && validateSnapshot(s, payload.direct_demo);
    if (!s || s.device_id !== payload.device_id || s.physical_boot_id !== payload.boot_id || !snapshot) fail(422, 'Sự kiện demo thiếu phiên/vị trí ESP32-S3 hợp lệ', 'invalid_direct_event');
    if (/^(pothole|speed_bump)_detected$/.test(payload.event?.name) &&
        (payload.event.detection_confirmed === false ||
         (payload.event.inference_source !== undefined && payload.event.inference_source !== 'adxl345'))) {
      fail(422, 'Điểm demo phải là sự kiện đã xác nhận từ ADXL345 trên Gateway', 'unconfirmed_direct_event');
    }
    const out = virtualPayload(payload, s, snapshot);
    // The immutable occurrence snapshot survives offline outbox replay. Never
    // move a detection to the most recently displayed/received vehicle point.
    const evt = { ...payload.event };
    if (evt.lat !== undefined || evt.lon !== undefined) {
      if (!coords([evt.lat, evt.lon]) || distanceToRoute([evt.lat, evt.lon], s.route.points) > 6) fail(422, 'Tọa độ cảnh báo demo ngoài đường đã chọn', 'invalid_direct_event');
    }
    out.event = { ...evt, gps_attached: true }; return out;
  }
  return { roads, start, control, ack, delivered, telemetry, realtime, event, assertIdle, expire,
    isCommand: row => DIRECT_ACTIONS.has(row.action), busy: () => Boolean(active()),
    activeFor: id => active()?.device_id === id,
    state: () => { expire(); return { session: publicSession(active() || latest()) }; },
    target: id => isDirectDevice(id) ? id.slice(0, -DIRECT_SUFFIX.length) : id,
    snapshotFor: row => { if (!row || !isDirectDevice(row.device_id)) return null;
      const raw = db.prepare('SELECT raw_json FROM telemetry WHERE id=?').get(row.id); return raw ? JSON.parse(raw.raw_json).direct_demo || null : null; },
    sessionForDevice: id => publicSession(parse(db.prepare('SELECT * FROM direct_demo_sessions WHERE device_id=? ORDER BY updated_at DESC,rowid DESC LIMIT 1').get(isDirectDevice(id) ? id.slice(0, -DIRECT_SUFFIX.length) : id))),
    routeMetadata: routeId => db.prepare('SELECT session_id,pass_index FROM direct_demo_passes WHERE route_id=?').get(routeId) || null,
  };
}
