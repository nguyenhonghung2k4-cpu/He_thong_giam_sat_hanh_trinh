# Kiểm tra bản vá V11.5.4

Ngày: 15/11/2026. Môi trường PC Windows, Node.js 26.7.0. Chỉ dùng cấu hình kiểm thử và dữ liệu tổng hợp; không dùng GPS, cơ sở dữ liệu hoặc mật khẩu thật của người dùng để thử truy cập công khai.

## Đã đạt

- Toàn bộ bộ kiểm thử `npm run verify`: chức năng web cũ, demo tự động, direct demo, chuyển động realtime, lộ trình, giao diện, Internet và các tuyến có sẵn.
- Cú pháp các module mới và module thay đổi.
- Đăng nhập, băm mật khẩu, giới hạn thử mật khẩu, hết hạn/đăng xuất, kiểm tra nguồn yêu cầu và chặn endpoint thiết bị qua bridge. Không lưu mật khẩu rõ trong cấu hình.
- Server thật và bridge trên loopback: tiếp nhận telemetry tổng hợp qua LAN, xem Dashboard sau đăng nhập, lệnh điều khiển và ACK theo luồng cũ.
- 80 lượt đọc luồng mới không tạo lần ghi/commit SQLite; chuyển động nhanh không thêm bản ghi lộ trình hoặc làm mới kết quả TinyML cũ.
- Cập nhật HTTP không chồng yêu cầu; tách chuyển động tối đa 5 Hz khỏi snapshot cảm biến 1 Hz; tự thử lại khi lỗi khám phá kết nối, bỏ phản hồi nguồn cũ, dừng khi hết phiên.
- TinyML: kiểm tra cửa sổ mới, cảm biến sẵn sàng, nguồn thật/demo, dữ liệu gửi lại, sai lệch giờ điện thoại và tuổi dữ liệu qua mạng. Không tự tạo thời điểm lấy mẫu cảm biến.
- Catalog tuyến mô phỏng 400/800/1200/1600/2000 m: không cần GNSS/Overpass, chiều dài đo từ hình học, tối đa 64 đỉnh và không vượt 2 km, hướng trái–phải. Không cho dữ liệu client ghi đè hình học whitelist. Giữ kiểm tra Gateway/firmware/CAN và vòng đời ACK, phiên cũ, tạm dừng/chạy lại.
- Xem giao diện bằng trình duyệt với dữ liệu tổng hợp: thẻ TinyML đứng đầu cột cạnh bản đồ; đăng nhập, nhãn INTERNET/HTTP và đăng xuất hoạt động. Không dùng dữ liệu thật cho kiểm tra này.
- Kiểm tra kích thước màn hình điện thoại 390 × 844 trong trình duyệt: không tràn ngang trang, bản đồ và các bảng vừa khung; tải đủ năm tuyến khi không có GPS, chọn được tuyến 2 km. Đây là kiểm tra kích thước hiển thị, không phải điện thoại vật lý.
- Bộ áp dụng bản vá: kiểm tra checksum trước khi ghi, sao lưu file bị thay đổi, áp dụng/lặp lại thành công, giữ nguyên cấu hình/database/firmware và từ chối khi phát hiện file người dùng đã sửa ngoài bản gốc đối chiếu. Chỉ thử trên bản sao tổng hợp.

Các con số 1 Hz/5 Hz là nhịp yêu cầu mục tiêu khi mạng đáp ứng, không phải cam kết độ trễ hoặc độ mượt trên mọi mạng.

## Chưa xác nhận bằng thử nghiệm thực

- Chưa tạo public URL/tunnel hoặc chia sẻ vị trí xe thật; chưa tải/chạy cloudflared trong quá trình kiểm thử gói.
- Chưa thử kết nối thực từ điện thoại qua 4G/5G. Giao diện web và đăng nhập được thiết kế cho trình duyệt điện thoại; cần kiểm tra trên máy của bạn sau khi chạy START.
- Chưa nạp/chạy lại ESP32-S3 và Node ECU, chưa đo CAN, MicroSD, loa hoặc AI trên mô hình vật lý. Bản vá không thay firmware và không cần nạp lại board.
- Không kiểm định an toàn, SLA, bảo mật triển khai sản xuất hoặc độ chính xác AI mới. Kết quả kiểm thử PC không thay cho kiểm thử tích hợp phần cứng.

## Thử nhanh sau khi áp dụng

1. Giữ nguyên kết nối ESP và địa chỉ server LAN, mở Dashboard và xác nhận dữ liệu thật/CAN bình thường.
2. Mở START_INTERNET_DASHBOARD, đăng nhập URL trên điện thoại bằng 4G hoặc Wi-Fi khác; kiểm tra đọc dữ liệu, đổi cấu hình và lệnh xác nhận.
3. Khi GNSS chưa có fix, kiểm tra vẫn tải được năm tuyến; chọn 400 m, đưa biến trở về 0, bắt đầu và chờ ESP xác nhận.
4. Tác động mặt đường thật lên mô hình, kiểm tra AI/sự kiện và cảnh báo khi chạy lại; sau đó thử tuyến 2 km.
5. Tắt mạng ngắn rồi mở lại: không tự chạy bằng dữ liệu cũ; dừng phiên Internet sau buổi demo.
