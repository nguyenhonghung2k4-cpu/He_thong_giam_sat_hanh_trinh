# Mẫu gia tốc demo — dữ liệu thật, không ép kết quả AI

Hai cửa sổ dưới đây được trích nguyên 200 dòng liên tiếp (XYZ, đơn vị g) từ các CSV hiện có của người dùng. Không tạo dạng sóng giả, không sửa giá trị, không xóa dòng lỗi để nối hai khoảng thời gian khác nhau. `source_start_row` và `source_end_row` là số dòng vật lý trong file gốc, đếm từ 1; hai file được chọn không có header. Bản trích giữ thứ tự `x,y,z`.

| Nút demo | File nguồn | Dòng gốc | Kết quả chạy model trên máy tính |
| --- | --- | --- | --- |
| Ổ gà (V11.4.2) | `o_ga_2banh_phai.csv` | 233201–233400 | `o_ga`, 99,609375% |
| Gờ giảm tốc | `go_giam_toc.csv` | 58551–58750 | `go_giam_toc`, 99,609375% |

Đây chỉ là kết quả tham chiếu được kiểm tra bằng `run_classifier()` của thư viện EON gốc trên Windows x64 (Zig 0.14.1, C++17, không thay model). Server không được dùng `host_validation` để tạo sự kiện. Kết quả thực sự khi demo phải do ESP32-S3 suy luận và trả về. Nhãn có thể khác nếu thay model; nút gửi dữ liệu đầu vào, không gửi nhãn phải nhận được.

### Cách chọn mẫu V11.4.2 và giới hạn

Đã quét 6 file `o_ga*.csv` với bước 200 dòng: 10.023 cửa sổ, loại 1.902 cửa sổ có dữ liệu không hợp lệ, chạy classifier gốc cho 8.121 cửa sổ; 2.836 cửa sổ trả `o_ga >= 0,99`. Chọn cửa sổ có tổng bình phương dao động quanh trung bình lớn nhất trong nhóm đạt ngưỡng. Kiểm tra lại cửa sổ đã chọn bằng một lần chạy classifier riêng. Chi tiết và scores: `selection_v11_4_2.json`; công cụ tái lập: `tests/select_demo_pothole_sample.mjs`.

**Đây là lựa chọn thiên về mẫu dễ được model nhận diện, không phải phép đo accuracy.** Ngay cả cửa sổ được chọn cũng chỉ có độ lệch đỉnh quanh trung bình khoảng 0,037 g. File được đặt tên nhóm ổ gà nhưng không có timestamp/video để xác thực cửa sổ này là lúc bánh xe va vào ổ gà. Không chỉnh dạng sóng để tăng biên độ hoặc gán nhãn/điểm giả. Khi bảo vệ, chỉ trình bày đây là mẫu CSV chọn lọc để minh họa suy luận và giao tiếp; không lấy confidence 99,61% làm bằng chứng độ chính xác thực địa.

## Nguồn và thông số

- Thư viện: `ei-telematics-arduino-1.0.1-impulse-1.zip` trong thư mục `Libraries` của project.
- Metadata đã đối chiếu với ZIP: 100 Hz; 200 mẫu; 3 trục; 600 giá trị; interval 10 ms; nhãn `duong_bang_phang`, `go_giam_toc`, `o_ga`.
- Mã recorder gốc: `code_lay_mau/lay_mau/lay_mau.ino`; ADXL345 full-resolution ±16 g, `G_PER_LSB=0.0039`, chu kỳ 10000 µs, output XYZ theo g.
- CSV không có timestamp: 100 Hz là tốc độ danh định theo recorder, không có bằng chứng timestamp từng mẫu để đo jitter của lần thu đó.
- SHA-256 của file nguồn đầy đủ, bản trích, ZIP model và metadata được lưu trong `manifest.json`.
- Các CSV có thể đã được dùng train. Các mẫu này phục vụ trình diễn inference và đường truyền, **không phải tập kiểm thử độc lập** và không chứng minh độ chính xác thực địa.
- Khi khảo sát dữ liệu, gặp dòng `-0.253.25350` không phải số hợp lệ trong file khác và giá trị khoảng 30 g vượt dải cảm biến trong một số cửa sổ. Các cửa sổ đó không được dùng và không được tự sửa.

## Kiểm tra

Từ thư mục `WebDashboard_Localhost`:

```powershell
node ../tests/demo_samples_test.mjs
```

Kiểm tra này chạy không cần ESP32 hoặc thư viện ngoài: kiểm tra 600 giá trị hữu hạn, đúng trục, đúng SHA bản trích và trùng từng giá trị CSV; xác nhận parser từ chối dòng lỗi. Nếu còn toàn bộ CSV gốc, đặt `DEMO_ORIGINAL_CSV_DIR` để kiểm tra thêm SHA file gốc và vị trí từng dòng.

Kiểm tra host inference là tùy chọn, không cần để chạy dashboard hoặc nạp Arduino IDE. Nếu đã có Zig và thư viện model đã giải nén, chạy:

```powershell
../tests/run_demo_samples_host.ps1 -ModelSourceDir "C:/duong-dan/telematics_inferencing/src" -ZigPath "C:/duong-dan/zig.exe"
```

Script chỉ tạo build/cache trong `tests/.host-demo-inference`, không sửa thư viện. Không có compiler hoặc phần cứng thì không được coi các kiểm tra đó là đã chạy. Kiểm tra host không thay thế kiểm thử firmware trên ESP32-S3, cảm biến, CAN, SD, loa và phản hồi trực tiếp trên web.
