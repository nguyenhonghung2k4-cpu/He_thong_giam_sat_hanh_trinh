import { createServer } from "node:http";
import { timingSafeEqual, randomUUID } from "node:crypto";
import { loadDemoSamples, normalizeInferenceResult, DEMO_INFERENCE_TTL_MS } from './demo-tinyml.mjs';
import { createDirectDemo, isDirectDevice, DIRECT_SUFFIX } from './direct-demo.mjs';
import { buildRoadCurrent, createUpdateFeed } from './live-feed.mjs';
import { spawn } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, statSync, writeFileSync, appendFileSync,
  renameSync, unlinkSync, readdirSync } from "node:fs";
import { readFile } from "node:fs/promises";
import { networkInterfaces } from "node:os";
import { dirname, extname, join, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";

const ROOT = dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = join(ROOT, "public");
const PROJECT_ROOT = resolve(ROOT, "..");
const SD_EXPORT_DIR = join(PROJECT_ROOT, "SD_Logs");
mkdirSync(SD_EXPORT_DIR, { recursive: true });
const DEFAULT_CONFIG = {
  host: "0.0.0.0",
  port: 3000,
  ingestApiKey: "local_HHT_2026_R8mK4vQ2pL7xN5cT9sD3",
  databaseFile: "data/telematics.db",
  telemetryRetentionDays: 7,
  eventRetentionDays: 180,
  maxBodyBytes: 65536,
  demoSpeakerEnabled: false,
  demoSpeakerDeviceId: "",
  demoSpeakerFreshMs: 10000,
  demoSpeakerCommandTtlMs: 12000,
};

function loadConfig() {
  const path = join(ROOT, "config.local.json");
  let local = {};
  if (existsSync(path)) {
    try { local = JSON.parse(readFileSync(path, "utf8")); }
    catch (error) { console.error("config.local.json không hợp lệ:", error.message); process.exit(1); }
  }
  const config = { ...DEFAULT_CONFIG, ...local };
  config.ingestApiKey = process.env.INGEST_API_KEY || String(config.ingestApiKey || "");
  config.host = process.env.HOST || String(config.host || "0.0.0.0");
  config.port = Math.min(65535, Math.max(1, Number(process.env.PORT ?? config.port) || 3000));
  config.databaseFile = process.env.DATABASE_FILE || String(config.databaseFile || DEFAULT_CONFIG.databaseFile);
  config.maxBodyBytes = Math.min(1024 * 1024, Math.max(1024, Number(config.maxBodyBytes) || 65536));
  config.telemetryRetentionDays = Math.max(1, Number(config.telemetryRetentionDays) || 7);
  config.eventRetentionDays = Math.max(1, Number(config.eventRetentionDays) || 180);
  const speakerEnabledEnv = process.env.DEMO_SPEAKER_ENABLED;
  config.demoSpeakerEnabled = speakerEnabledEnv === undefined
    ? Boolean(config.demoSpeakerEnabled)
    : /^(1|true|yes|on)$/i.test(String(speakerEnabledEnv));
  config.demoSpeakerDeviceId = String(process.env.DEMO_SPEAKER_DEVICE_ID ?? config.demoSpeakerDeviceId ?? "").trim().slice(0, 256);
  config.demoSpeakerFreshMs = Math.min(30000, Math.max(3000, Number(config.demoSpeakerFreshMs) || 10000));
  config.demoSpeakerCommandTtlMs = Math.min(30000, Math.max(5000, Number(config.demoSpeakerCommandTtlMs) || 12000));
  if (!config.ingestApiKey) { console.error("Thiếu ingestApiKey trong config.local.json"); process.exit(1); }
  return config;
}

const config = loadConfig();
const dbPath = resolve(ROOT, config.databaseFile);
mkdirSync(dirname(dbPath), { recursive: true });
const db = new DatabaseSync(dbPath);
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA synchronous = FULL;
  PRAGMA busy_timeout = 5000;
  PRAGMA foreign_keys = ON;
  CREATE TABLE IF NOT EXISTS telemetry (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id TEXT NOT NULL, boot_id TEXT, sequence INTEGER,
    recorded_at TEXT NOT NULL, ingested_at INTEGER NOT NULL, uptime_ms INTEGER,
    location_valid INTEGER NOT NULL, lat REAL, lon REAL, speed_kph REAL,
    satellites INTEGER, hdop REAL, altitude_m REAL, course_deg REAL,
    ecu_online INTEGER NOT NULL, ecu_uptime_s INTEGER, ecu_status INTEGER,
    ecu_speed_kph REAL, overspeed INTEGER, rpm INTEGER, adc_raw INTEGER, temperature_c REAL, dtc_code INTEGER,
    dtc_severity INTEGER, dtc_active INTEGER, road_valid INTEGER,
    road_label TEXT, confidence REAL, flat_confidence REAL,
    speed_bump_confidence REAL, pothole_confidence REAL, inference_ms INTEGER,
    x_g REAL, y_g REAL, z_g REAL, sd_ok INTEGER, wifi_rssi INTEGER,
    free_heap INTEGER, free_psram INTEGER, queue_bytes INTEGER,
    navigation_ready INTEGER, ai_ready INTEGER, ecu_runtime_ready INTEGER,
    adxl_healthy INTEGER, adxl_fifo_overruns INTEGER, adxl_fifo_services INTEGER,
    sd_io_failures INTEGER, sd_remounts INTEGER, sd_failure_streak INTEGER,
    sd_state TEXT, sd_last_error TEXT, sd_recovery_busy INTEGER, sd_frequency_hz INTEGER,
    sd_card_type TEXT, sd_total_bytes INTEGER, sd_used_bytes INTEGER,
    sd_daily_log_bytes INTEGER, sd_daily_log_quota_bytes INTEGER,
    sd_write_block_reason TEXT, sd_log_drop_count INTEGER,
    event_queue_bytes INTEGER, network_last_http INTEGER, network_sent_count INTEGER,
    firmware_version TEXT, model_version TEXT,
    trip_distance_km REAL, is_resend INTEGER NOT NULL DEFAULT 0, raw_json TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id TEXT NOT NULL, boot_id TEXT, sequence INTEGER,
    recorded_at TEXT NOT NULL, ingested_at INTEGER NOT NULL, uptime_ms INTEGER,
    event_uid TEXT, name TEXT NOT NULL, severity TEXT, distance_m REAL, lat REAL, lon REAL,
    gps_attached INTEGER, new_map_point INTEGER, confidence REAL, hazard_epoch INTEGER, road_label TEXT,
    dtc_code INTEGER, dtc_severity INTEGER, saved_to_sd INTEGER,
    map_capacity_full INTEGER, is_resend INTEGER NOT NULL DEFAULT 0, raw_json TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_telemetry_device_time ON telemetry(device_id, ingested_at DESC);
  CREATE INDEX IF NOT EXISTS idx_telemetry_device_boot_time ON telemetry(device_id, boot_id, ingested_at DESC);
  CREATE INDEX IF NOT EXISTS idx_events_device_time ON events(device_id, ingested_at DESC);
  CREATE INDEX IF NOT EXISTS idx_events_device_name_time ON events(device_id, name, ingested_at DESC);
  CREATE INDEX IF NOT EXISTS idx_events_name_time ON events(name, ingested_at DESC);
  CREATE UNIQUE INDEX IF NOT EXISTS uq_telemetry_message ON telemetry(device_id, boot_id, sequence);

  CREATE TABLE IF NOT EXISTS device_commands (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id TEXT NOT NULL,
    action TEXT NOT NULL,
    params_json TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','done','failed')),
    created_at INTEGER NOT NULL,
    completed_at INTEGER,
    result_json TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_device_commands_pending ON device_commands(device_id,status,id);
  CREATE TABLE IF NOT EXISTS hazard_deletions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id TEXT NOT NULL,
    from_epoch INTEGER NOT NULL,
    to_epoch INTEGER NOT NULL,
    created_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_hazard_deletions_device_range ON hazard_deletions(device_id,from_epoch,to_epoch);
  CREATE TABLE IF NOT EXISTS log_deletions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id TEXT NOT NULL,
    from_epoch INTEGER NOT NULL,
    to_epoch INTEGER NOT NULL,
    delete_all INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_log_deletions_device_range ON log_deletions(device_id,from_epoch,to_epoch);
  CREATE TABLE IF NOT EXISTS hazard_point_deletions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id TEXT NOT NULL, kind TEXT NOT NULL,
    lat REAL NOT NULL, lon REAL NOT NULL, radius_m REAL NOT NULL DEFAULT 8,
    created_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_hazard_point_deletions_device_kind ON hazard_point_deletions(device_id,kind,id DESC);

  CREATE TABLE IF NOT EXISTS routes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id TEXT NOT NULL,
    route_no INTEGER,
    status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','completed')),
    started_at INTEGER NOT NULL,
    ended_at INTEGER,
    distance_km REAL NOT NULL DEFAULT 0,
    point_count INTEGER NOT NULL DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS route_counters (
    device_id TEXT PRIMARY KEY,
    last_no INTEGER NOT NULL DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS route_points (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    route_id INTEGER NOT NULL REFERENCES routes(id) ON DELETE CASCADE,
    telemetry_id INTEGER,
    recorded_at TEXT NOT NULL,
    ingested_at INTEGER NOT NULL,
    lat REAL NOT NULL,
    lon REAL NOT NULL,
    speed_kph REAL,
    UNIQUE(route_id, telemetry_id)
  );
  CREATE UNIQUE INDEX IF NOT EXISTS uq_routes_active_device ON routes(device_id) WHERE status='active';
  CREATE UNIQUE INDEX IF NOT EXISTS uq_routes_number_device ON routes(device_id, route_no) WHERE route_no IS NOT NULL;
  CREATE INDEX IF NOT EXISTS idx_routes_device_status ON routes(device_id, status, id DESC);
  CREATE INDEX IF NOT EXISTS idx_routes_device_end ON routes(device_id, status, ended_at DESC);
  CREATE INDEX IF NOT EXISTS idx_route_points_route ON route_points(route_id, id);
  CREATE TABLE IF NOT EXISTS device_settings (
    device_id TEXT PRIMARY KEY,
    overspeed_warning_kph REAL NOT NULL DEFAULT 120,
    overspeed_clear_kph REAL NOT NULL DEFAULT 115,
    geofence_warning_m REAL NOT NULL DEFAULT 10,
    geofence_rearm_m REAL NOT NULL DEFAULT 20,
    pothole_confidence REAL NOT NULL DEFAULT 0.80,
    speed_bump_confidence REAL NOT NULL DEFAULT 0.80,
    updated_at INTEGER NOT NULL DEFAULT 0,
    source TEXT NOT NULL DEFAULT 'default'
  );
  PRAGMA optimize;
`);

// Keep route numbering monotonic even after a completed route is deleted.
// This also initializes the counter correctly if a database is upgraded from
// an earlier route-enabled build.
db.exec(`
  INSERT INTO route_counters(device_id,last_no)
  SELECT device_id,MAX(route_no) FROM routes WHERE route_no IS NOT NULL GROUP BY device_id
  ON CONFLICT(device_id) DO UPDATE SET last_no=MAX(route_counters.last_no,excluded.last_no);
`);

// Backward-compatible migration for databases created before CAN speed was added.
const telemetryColumnNames = new Set(db.prepare("PRAGMA table_info(telemetry)").all().map(column => String(column.name)));
if (!telemetryColumnNames.has("ecu_speed_kph")) db.exec("ALTER TABLE telemetry ADD COLUMN ecu_speed_kph REAL");
if (!telemetryColumnNames.has("overspeed")) db.exec("ALTER TABLE telemetry ADD COLUMN overspeed INTEGER DEFAULT 0");
if (!telemetryColumnNames.has("is_resend")) db.exec("ALTER TABLE telemetry ADD COLUMN is_resend INTEGER NOT NULL DEFAULT 0");
for (const [name,type] of [["navigation_ready","INTEGER"],["ai_ready","INTEGER"],["ecu_runtime_ready","INTEGER"],["adxl_healthy","INTEGER"],["adxl_fifo_overruns","INTEGER"],["adxl_fifo_services","INTEGER"],["sd_io_failures","INTEGER"],["sd_remounts","INTEGER"],["sd_failure_streak","INTEGER"],["sd_state","TEXT"],["sd_last_error","TEXT"],["sd_recovery_busy","INTEGER"],["sd_frequency_hz","INTEGER"],["sd_card_type","TEXT"],["sd_total_bytes","INTEGER"],["sd_used_bytes","INTEGER"],["sd_daily_log_bytes","INTEGER"],["sd_daily_log_quota_bytes","INTEGER"],["sd_write_block_reason","TEXT"],["sd_log_drop_count","INTEGER"],["event_queue_bytes","INTEGER"],["network_last_http","INTEGER"],["network_sent_count","INTEGER"],["firmware_version","TEXT"],["model_version","TEXT"]]) if(!telemetryColumnNames.has(name)) db.exec(`ALTER TABLE telemetry ADD COLUMN ${name} ${type}`);

// Event reliability migration: sequence is diagnostic metadata, not the event
// identity. event.id is scoped to one device; two gateways are allowed to use
// the same local event id without either event being discarded.
const eventColumnNames = new Set(db.prepare("PRAGMA table_info(events)").all().map(column => String(column.name)));
if (!eventColumnNames.has("event_uid")) db.exec("ALTER TABLE events ADD COLUMN event_uid TEXT");
if (!eventColumnNames.has("hazard_epoch")) db.exec("ALTER TABLE events ADD COLUMN hazard_epoch INTEGER");
if (!eventColumnNames.has("is_resend")) db.exec("ALTER TABLE events ADD COLUMN is_resend INTEGER NOT NULL DEFAULT 0");
db.exec(`
  DROP INDEX IF EXISTS uq_events_message;
  DROP INDEX IF EXISTS uq_events_uid;
  CREATE UNIQUE INDEX IF NOT EXISTS uq_events_device_uid ON events(device_id,event_uid) WHERE event_uid IS NOT NULL;
  CREATE INDEX IF NOT EXISTS idx_events_message_diag ON events(device_id, boot_id, sequence);
  CREATE INDEX IF NOT EXISTS idx_telemetry_live_time ON telemetry(device_id, is_resend, ingested_at DESC);
`);

// V11.3.9: nullable additive fields preserve old telemetry and demo payloads.
const GNSS_COLUMNS = [
  ["gnss_filter_version", "INTEGER"], ["gnss_filter_state", "TEXT"],
  ["gnss_stationary", "INTEGER"], ["gnss_segment_valid", "INTEGER"],
  ["gnss_fix_seq", "INTEGER"], ["gnss_position_epoch", "INTEGER"],
  ["gnss_raw_lat", "REAL"], ["gnss_raw_lon", "REAL"],
  ["gnss_raw_speed_kph", "REAL"], ["gnss_rejected_fixes", "INTEGER"],
];
for (const [name, type] of GNSS_COLUMNS) {
  if (!telemetryColumnNames.has(name)) db.exec(`ALTER TABLE telemetry ADD COLUMN ${name} ${type}`);
}
const routePointColumns = new Set(db.prepare("PRAGMA table_info(route_points)").all().map(column => String(column.name)));
if (!routePointColumns.has("segment_start")) db.exec("ALTER TABLE route_points ADD COLUMN segment_start INTEGER NOT NULL DEFAULT 0");
// Persist the cursor so a server restart cannot join points across an invalid fix.
db.exec(`CREATE TABLE IF NOT EXISTS route_navigation_state (
  route_id INTEGER PRIMARY KEY REFERENCES routes(id) ON DELETE CASCADE,
  gap_pending INTEGER NOT NULL DEFAULT 1,
  filter_version INTEGER, boot_id TEXT, fix_seq INTEGER, position_epoch INTEGER,
  stationary INTEGER, ingested_at INTEGER
)`);

const telemetryInsert = db.prepare(`INSERT OR IGNORE INTO telemetry (
  device_id,boot_id,sequence,recorded_at,ingested_at,uptime_ms,
  location_valid,lat,lon,speed_kph,satellites,hdop,altitude_m,course_deg,
  ecu_online,ecu_uptime_s,ecu_status,ecu_speed_kph,overspeed,rpm,adc_raw,temperature_c,dtc_code,dtc_severity,dtc_active,
  road_valid,road_label,confidence,flat_confidence,speed_bump_confidence,pothole_confidence,inference_ms,x_g,y_g,z_g,
  sd_ok,wifi_rssi,free_heap,free_psram,queue_bytes,navigation_ready,ai_ready,ecu_runtime_ready,
  adxl_healthy,adxl_fifo_overruns,adxl_fifo_services,sd_io_failures,sd_remounts,sd_failure_streak,
  sd_state,sd_last_error,sd_recovery_busy,sd_frequency_hz,
  sd_card_type,sd_total_bytes,sd_used_bytes,sd_daily_log_bytes,sd_daily_log_quota_bytes,sd_write_block_reason,sd_log_drop_count,
  event_queue_bytes,network_last_http,network_sent_count,firmware_version,model_version,trip_distance_km,is_resend,raw_json,
  ${GNSS_COLUMNS.map(([name]) => name).join(",")}
) VALUES (
  $device_id,$boot_id,$sequence,$recorded_at,$ingested_at,$uptime_ms,
  $location_valid,$lat,$lon,$speed_kph,$satellites,$hdop,$altitude_m,$course_deg,
  $ecu_online,$ecu_uptime_s,$ecu_status,$ecu_speed_kph,$overspeed,$rpm,$adc_raw,$temperature_c,$dtc_code,$dtc_severity,$dtc_active,
  $road_valid,$road_label,$confidence,$flat_confidence,$speed_bump_confidence,$pothole_confidence,$inference_ms,$x_g,$y_g,$z_g,
  $sd_ok,$wifi_rssi,$free_heap,$free_psram,$queue_bytes,$navigation_ready,$ai_ready,$ecu_runtime_ready,
  $adxl_healthy,$adxl_fifo_overruns,$adxl_fifo_services,$sd_io_failures,$sd_remounts,$sd_failure_streak,
  $sd_state,$sd_last_error,$sd_recovery_busy,$sd_frequency_hz,
  $sd_card_type,$sd_total_bytes,$sd_used_bytes,$sd_daily_log_bytes,$sd_daily_log_quota_bytes,$sd_write_block_reason,$sd_log_drop_count,
  $event_queue_bytes,$network_last_http,$network_sent_count,$firmware_version,$model_version,$trip_distance_km,$is_resend,$raw_json,
  ${GNSS_COLUMNS.map(([name]) => `$${name}`).join(",")}
)`);

const eventInsert = db.prepare(`INSERT INTO events (
  device_id,boot_id,sequence,recorded_at,ingested_at,uptime_ms,event_uid,name,severity,distance_m,
  lat,lon,gps_attached,new_map_point,confidence,hazard_epoch,road_label,dtc_code,dtc_severity,
  saved_to_sd,map_capacity_full,is_resend,raw_json
) VALUES (
  $device_id,$boot_id,$sequence,$recorded_at,$ingested_at,$uptime_ms,$event_uid,$name,$severity,$distance_m,
  $lat,$lon,$gps_attached,$new_map_point,$confidence,$hazard_epoch,$road_label,$dtc_code,$dtc_severity,
  $saved_to_sd,$map_capacity_full,$is_resend,$raw_json
)`);

const routePointInsert = db.prepare(`INSERT OR IGNORE INTO route_points (
  route_id,telemetry_id,recorded_at,ingested_at,lat,lon,speed_kph,segment_start
) VALUES ($route_id,$telemetry_id,$recorded_at,$ingested_at,$lat,$lon,$speed_kph,$segment_start)`);

const navigationStateUpdate = db.prepare(`INSERT INTO route_navigation_state
  (route_id,gap_pending,filter_version,boot_id,fix_seq,position_epoch,stationary,ingested_at)
  VALUES ($route_id,$gap_pending,$filter_version,$boot_id,$fix_seq,$position_epoch,$stationary,$ingested_at)
  ON CONFLICT(route_id) DO UPDATE SET gap_pending=excluded.gap_pending,
  filter_version=excluded.filter_version,boot_id=excluded.boot_id,fix_seq=excluded.fix_seq,
  position_epoch=excluded.position_epoch,stationary=excluded.stationary,ingested_at=excluded.ingested_at`);

const routePointStatsUpdate = db.prepare(`UPDATE routes SET
  distance_km = distance_km + $distance_km, point_count = point_count + 1
  WHERE id = $route_id AND status='active'`);

const TELEMETRY_COLUMNS = `id,device_id,boot_id,sequence,recorded_at,ingested_at,uptime_ms,
  location_valid,lat,lon,speed_kph,satellites,hdop,altitude_m,course_deg,
  ecu_online,ecu_uptime_s,ecu_status,ecu_speed_kph,overspeed,rpm,adc_raw,temperature_c,dtc_code,dtc_severity,dtc_active,
  road_valid,road_label,confidence,flat_confidence,speed_bump_confidence,pothole_confidence,inference_ms,
  x_g,y_g,z_g,sd_ok,wifi_rssi,free_heap,free_psram,queue_bytes,navigation_ready,ai_ready,ecu_runtime_ready,
  adxl_healthy,adxl_fifo_overruns,adxl_fifo_services,sd_io_failures,sd_remounts,sd_failure_streak,
  sd_state,sd_last_error,sd_recovery_busy,sd_frequency_hz,
  sd_card_type,sd_total_bytes,sd_used_bytes,sd_daily_log_bytes,sd_daily_log_quota_bytes,sd_write_block_reason,sd_log_drop_count,
  event_queue_bytes,network_last_http,network_sent_count,firmware_version,model_version,trip_distance_km,is_resend,
  ${GNSS_COLUMNS.map(([name]) => name).join(",")},json_extract(raw_json,'$.road.event') AS road_event_json`;
const EVENT_COLUMNS = `id,device_id,boot_id,sequence,recorded_at,ingested_at,uptime_ms,event_uid,name,severity,
  distance_m,lat,lon,gps_attached,new_map_point,confidence,hazard_epoch,road_label,dtc_code,dtc_severity,saved_to_sd,map_capacity_full,is_resend`;
const EVENT_TIME_MS_SQL = "COALESCE(NULLIF(hazard_epoch,0)*1000,CAST(strftime('%s',recorded_at) AS INTEGER)*1000,ingested_at)";
const eventByUidSelect = db.prepare(`SELECT ${EVENT_COLUMNS},${EVENT_TIME_MS_SQL} AS event_time_ms FROM events WHERE device_id=? AND event_uid=? LIMIT 1`);

const obj = value => value && typeof value === "object" && !Array.isArray(value) ? value : {};
const num = value => value === null || value === undefined || value === "" ? null : Number.isFinite(Number(value)) ? Number(value) : null;
const flag = value => value === true || value === 1 || value === "1" ? 1 : 0;
const text = (value, fallback = "") => typeof value === "string" && value.length ? value.slice(0, 256) : fallback;

function haversineKm(lat1, lon1, lat2, lon2) {
  const rad = value => Number(value) * Math.PI / 180;
  const p1 = rad(lat1), p2 = rad(lat2);
  const dp = rad(Number(lat2) - Number(lat1));
  const dl = rad(Number(lon2) - Number(lon1));
  const h = Math.sin(dp / 2) ** 2 + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(Math.max(0, 1 - h)));
}

function validCoords(lat, lon) {
  return num(lat) !== null && num(lon) !== null &&
    Number(lat) >= -90 && Number(lat) <= 90 && Number(lon) >= -180 && Number(lon) <= 180;
}

function appendRoutePoint(routeId, telemetryRow) {
  if (!routeId || !telemetryRow || telemetryRow.is_resend) return false;
  const previous = db.prepare("SELECT * FROM route_navigation_state WHERE route_id=?").get(routeId);
  const version = num(telemetryRow.gnss_filter_version);
  const filtered = version !== null;
  const fixSeq = num(telemetryRow.gnss_fix_seq), epoch = num(telemetryRow.gnss_position_epoch);
  const bootId = text(telemetryRow.boot_id) || null;
  const stationary = filtered ? flag(telemetryRow.gnss_stationary) : null;
  const valid = telemetryRow.location_valid && validCoords(telemetryRow.lat, telemetryRow.lon) &&
    (!filtered || (version === 1 && fixSeq !== null && epoch !== null &&
      ["stationary", "moving"].includes(telemetryRow.gnss_filter_state)));
  const sameSource = previous && previous.boot_id === bootId &&
    previous.filter_version === version && previous.position_epoch === epoch;
  const stateValues = {
    $route_id: routeId, $gap_pending: valid ? 0 : 1, $filter_version: version,
    $boot_id: bootId, $fix_seq: fixSeq, $position_epoch: epoch, $stationary: stationary,
    $ingested_at: num(telemetryRow.ingested_at) ?? Date.now(),
  };
  if (!valid) { navigationStateUpdate.run(stateValues); return false; }
  // Multiple telemetry packets may refer to the same 1 Hz source GNSS fix.
  // Keep telemetry fresh, but never count that source fix twice in a route.
  if (filtered && sameSource && previous.fix_seq !== null && fixSeq <= previous.fix_seq) {
    if (fixSeq < previous.fix_seq) db.prepare("UPDATE route_navigation_state SET gap_pending=1 WHERE route_id=?").run(routeId);
    return false;
  }
  const last = db.prepare(`SELECT lat,lon FROM route_points WHERE route_id=? ORDER BY id DESC LIMIT 1`).get(routeId);
  const gap = !last || !previous || previous.gap_pending || !sameSource ||
    Number(telemetryRow.ingested_at) - Number(previous.ingested_at) > 10000 ||
    (filtered && !telemetryRow.gnss_segment_valid);
  navigationStateUpdate.run(stateValues);
  const distance = last ? haversineKm(last.lat, last.lon, telemetryRow.lat, telemetryRow.lon) : 0;
  // The potentiometer/CAN value is simulated speed, NOT movement evidence.
  // Preserve the first point and a moving->stationary endpoint; omit duplicates
  // while held stationary. A reacquired fix always starts a new visible segment.
  if (filtered && last && !gap && ((stationary && previous.stationary) || distance < 1e-8)) return false;
  const segmentStart = gap || !Number.isFinite(distance) || distance > 2;
  const speed = isDirectDevice(telemetryRow.device_id) ? num(telemetryRow.speed_kph) : num(telemetryRow.ecu_speed_kph) ?? num(telemetryRow.speed_kph);
  const result = routePointInsert.run({
    $route_id: routeId,
    $telemetry_id: num(telemetryRow.id),
    $recorded_at: text(telemetryRow.recorded_at, new Date(Number(telemetryRow.ingested_at) || Date.now()).toISOString()),
    $ingested_at: num(telemetryRow.ingested_at) ?? Date.now(),
    $lat: Number(telemetryRow.lat), $lon: Number(telemetryRow.lon), $speed_kph: speed,
    $segment_start: segmentStart ? 1 : 0,
  });
  if (Number(result.changes) === 0) return false;
  const safeDistance = segmentStart ? 0 : distance;
  routePointStatsUpdate.run({ $distance_km: safeDistance, $route_id: routeId });
  return true;
}

function appendTelemetryToActiveRoute(telemetryId) {
  const row = db.prepare(`SELECT ${TELEMETRY_COLUMNS} FROM telemetry WHERE id=?`).get(telemetryId);
  if (!row || row.is_resend) return;
  const active = db.prepare(`SELECT id,started_at FROM routes WHERE device_id=? AND status='active' LIMIT 1`).get(row.device_id);
  if (!active || Number(row.ingested_at) < Number(active.started_at)) return;
  appendRoutePoint(active.id, row);
}

function routeSummary(row) {
  if (!row) return null;
  return {
    id: Number(row.id), device_id: String(row.device_id),
    route_no: row.route_no === null || row.route_no === undefined ? null : Number(row.route_no),
    status: String(row.status), started_at: Number(row.started_at),
    ended_at: row.ended_at === null || row.ended_at === undefined ? null : Number(row.ended_at),
    distance_km: Number(row.distance_km || 0), point_count: Number(row.point_count || 0),
  };
}

function listRoutes(deviceId) {
  const rows = db.prepare(`SELECT id,device_id,route_no,status,started_at,ended_at,distance_km,point_count
    FROM routes WHERE device_id=?
    ORDER BY CASE WHEN status='active' THEN 0 ELSE 1 END, COALESCE(route_no,0) DESC, id DESC LIMIT 200`).all(deviceId);
  return rows.map(routeSummary);
}

function routeDetail(routeId, deviceId = "") {
  const route=deviceId?db.prepare(`SELECT id,device_id,route_no,status,started_at,ended_at,distance_km,point_count FROM routes WHERE id=? AND device_id=?`).get(routeId,deviceId):db.prepare(`SELECT id,device_id,route_no,status,started_at,ended_at,distance_km,point_count FROM routes WHERE id=?`).get(routeId);
  if(!route)return null;
  const points=db.prepare(`SELECT id,recorded_at,ingested_at,lat,lon,speed_kph,segment_start FROM route_points WHERE route_id=? ORDER BY id ASC LIMIT 50000`).all(routeId);
  const endTime=route.ended_at??Date.now();
  const directPass = isDirectDevice(route.device_id) ? directDemo.routeMetadata(route.id) : null;
  const routeEvents=directPass
    ? db.prepare(`SELECT ${EVENT_COLUMNS} FROM events WHERE device_id=? AND boot_id=? AND json_extract(raw_json,'$.direct_demo.pass_index')=? ORDER BY sequence ASC,id ASC LIMIT 5000`).all(route.device_id,directPass.session_id,directPass.pass_index)
    : db.prepare(`SELECT ${EVENT_COLUMNS} FROM events WHERE device_id=? AND ingested_at BETWEEN ? AND ? AND name NOT IN ('pothole_catalog_sync','speed_bump_catalog_sync') ORDER BY ingested_at ASC LIMIT 5000`).all(route.device_id,route.started_at,endTime);
  // Use version metadata captured during this route. Falling back to the latest
  // packet in the report would attach a newer firmware/model to an older trip.
  const versionRow=db.prepare(`SELECT firmware_version,model_version,ingested_at
    FROM telemetry
    WHERE device_id=? AND ingested_at BETWEEN ? AND ?
      AND (firmware_version IS NOT NULL OR model_version IS NOT NULL)
    ORDER BY ABS(ingested_at-?) ASC,id ASC LIMIT 1`).get(route.device_id,route.started_at,endTime,route.started_at)||null;
  const speeds=points.map(r=>num(r.speed_kph)).filter(v=>v!==null&&v>=0);
  const stats={duration_s:Math.max(0,Math.round((Number(endTime)-Number(route.started_at))/1000)),avg_speed_kph:speeds.length?speeds.reduce((a,b)=>a+b,0)/speeds.length:0,max_speed_kph:speeds.length?Math.max(...speeds):0,overspeed_events:routeEvents.filter(e=>e.name==='overspeed').length,pothole_events:routeEvents.filter(e=>e.name==='pothole_detected').length,speed_bump_events:routeEvents.filter(e=>e.name==='speed_bump_detected').length,dtc_events:routeEvents.filter(e=>e.name==='dtc_active').length};
  return {route:routeSummary(route),points,events:routeEvents,stats,...(directPass?{demo_mode:'direct',source_label:'Tọa độ mô phỏng – AI thực',direct_demo:directPass}:{}),version:versionRow?{firmware_version:versionRow.firmware_version||null,model_version:versionRow.model_version||null,captured_at:Number(versionRow.ingested_at)}:null};
}

function startRoute(deviceId, seedCurrent = true) {
  const existing = db.prepare(`SELECT id,device_id,route_no,status,started_at,ended_at,distance_km,point_count FROM routes WHERE device_id=? AND status='active' LIMIT 1`).get(deviceId);
  if (existing) return { route: routeSummary(existing), already_active: true };
  const now = Date.now();
  const result = db.prepare(`INSERT INTO routes(device_id,status,started_at,distance_km,point_count) VALUES(?,'active',?,0,0)`).run(deviceId, now);
  const routeId = Number(result.lastInsertRowid);
  // Capture the current valid position as the first route point so the line begins
  // where the user pressed "Bắt đầu lộ trình" rather than one packet later.
  const latest = db.prepare(`SELECT ${TELEMETRY_COLUMNS} FROM telemetry WHERE device_id=? AND is_resend=0 ORDER BY ingested_at DESC,id DESC LIMIT 1`).get(deviceId);
  if (seedCurrent && latest && now - Number(latest.ingested_at) <= 10000) appendRoutePoint(routeId, latest);
  return { route: routeSummary(db.prepare(`SELECT * FROM routes WHERE id=?`).get(routeId)), already_active: false };
}

function endRoute(deviceId, requestedRouteId = null) {
  const active = requestedRouteId
    ? db.prepare(`SELECT * FROM routes WHERE id=? AND device_id=? AND status='active' LIMIT 1`).get(requestedRouteId, deviceId)
    : db.prepare(`SELECT * FROM routes WHERE device_id=? AND status='active' LIMIT 1`).get(deviceId);
  if (!active) return null;
  const now = Date.now();
  const latest = db.prepare(`SELECT ${TELEMETRY_COLUMNS} FROM telemetry WHERE device_id=? AND is_resend=0 ORDER BY ingested_at DESC,id DESC LIMIT 1`).get(deviceId);
  if (latest && now - Number(latest.ingested_at) <= 10000) appendRoutePoint(active.id, latest);
  db.exec('BEGIN IMMEDIATE');
  try {
    db.prepare(`INSERT INTO route_counters(device_id,last_no) VALUES(?,0) ON CONFLICT(device_id) DO NOTHING`).run(deviceId);
    db.prepare(`UPDATE route_counters SET last_no=last_no+1 WHERE device_id=?`).run(deviceId);
    const next = Number(db.prepare(`SELECT last_no FROM route_counters WHERE device_id=?`).get(deviceId).last_no);
    db.prepare(`UPDATE routes SET status='completed',route_no=?,ended_at=? WHERE id=? AND status='active'`).run(next, now, active.id);
    db.exec('COMMIT');
  } catch (error) { db.exec('ROLLBACK'); throw error; }
  return routeSummary(db.prepare(`SELECT * FROM routes WHERE id=?`).get(active.id));
}

function deleteRoute(routeId, deviceId = "") {
  const route = deviceId ? db.prepare(`SELECT * FROM routes WHERE id=? AND device_id=?`).get(routeId, deviceId) : db.prepare(`SELECT * FROM routes WHERE id=?`).get(routeId);
  if (!route) return { deleted: false, reason: 'not_found' };
  if (route.status === 'active') return { deleted: false, reason: 'active' };
  db.prepare(`DELETE FROM routes WHERE id=?`).run(routeId);
  return { deleted: true, route: routeSummary(route) };
}

function insertTelemetry(payload, isResend = false) {
  const location = obj(payload.location), ecu = obj(payload.ecu), road = obj(payload.road);
  const filter = obj(location.filter), hasFilter = num(filter.version) !== null;
  // Fail closed for a contradictory/new filter contract. Raw JSON remains
  // available for diagnosis, but stale/rejected coordinates are never a live fix.
  const locationValid = flag(location.valid) && validCoords(location.lat, location.lon) &&
    (!hasFilter || (num(filter.version) === 1 && ["stationary", "moving"].includes(filter.state) &&
      Number.isSafeInteger(num(filter.fix_seq)) && num(filter.fix_seq) >= 0 &&
      Number.isSafeInteger(num(filter.position_epoch)) && num(filter.position_epoch) >= 0));
  const scores = obj(road.scores), system = obj(payload.system), trip = obj(payload.trip);
  const now = Date.now();
  const result = telemetryInsert.run({
    $device_id: text(payload.device_id, "unknown"), $boot_id: text(payload.boot_id) || null,
    $sequence: num(payload.seq), $recorded_at: text(payload.ts, new Date(now).toISOString()),
    $ingested_at: now, $uptime_ms: num(payload.uptime_ms), $location_valid: locationValid ? 1 : 0,
    $lat: num(location.lat), $lon: num(location.lon), $speed_kph: num(location.speed_kph),
    $satellites: num(location.satellites), $hdop: num(location.hdop), $altitude_m: num(location.altitude_m),
    $course_deg: num(location.course_deg), $ecu_online: flag(ecu.online), $ecu_uptime_s: num(ecu.uptime_s),
    $ecu_status: num(ecu.status), $ecu_speed_kph: num(ecu.speed_kph), $overspeed: flag(ecu.overspeed), $rpm: num(ecu.rpm), $adc_raw: num(ecu.adc_raw),
    $temperature_c: num(ecu.temperature_c), $dtc_code: num(ecu.dtc_code),
    $dtc_severity: num(ecu.dtc_severity), $dtc_active: flag(ecu.dtc_active),
    $road_valid: flag(road.valid), $road_label: text(road.label, "unknown"),
    $confidence: num(road.confidence), $flat_confidence: num(scores.duong_bang_phang),
    $speed_bump_confidence: num(scores.go_giam_toc), $pothole_confidence: num(scores.o_ga),
    $inference_ms: num(road.inference_ms), $x_g: num(road.x_g), $y_g: num(road.y_g), $z_g: num(road.z_g),
    $sd_ok: flag(system.sd_ok ?? payload.sd_ok), $wifi_rssi: num(system.wifi_rssi ?? payload.wifi_rssi),
    $free_heap: num(system.free_heap), $free_psram: num(system.free_psram), $queue_bytes: num(system.queue_bytes),
    $navigation_ready: flag(system.navigation_ready), $ai_ready: flag(system.ai_ready), $ecu_runtime_ready: flag(system.ecu_runtime_ready),
    $adxl_healthy: flag(system.adxl_healthy), $adxl_fifo_overruns: num(system.adxl_fifo_overruns), $adxl_fifo_services: num(system.adxl_fifo_services),
    $sd_io_failures: num(system.sd_io_failures), $sd_remounts: num(system.sd_remounts), $sd_failure_streak: num(system.sd_failure_streak),
    $sd_state: text(system.sd_state) || null, $sd_last_error: text(system.sd_last_error) || null,
    $sd_recovery_busy: flag(system.sd_recovery_busy), $sd_frequency_hz: num(system.sd_frequency_hz),
    $sd_card_type: text(system.sd_card_type) || null, $sd_total_bytes: num(system.sd_total_bytes), $sd_used_bytes: num(system.sd_used_bytes),
    $sd_daily_log_bytes: num(system.sd_daily_log_bytes), $sd_daily_log_quota_bytes: num(system.sd_daily_log_quota_bytes),
    $sd_write_block_reason: text(system.sd_write_block_reason) || null, $sd_log_drop_count: num(system.sd_log_drop_count),
    $event_queue_bytes: num(system.event_queue_bytes), $network_last_http: num(system.network_last_http), $network_sent_count: num(system.network_sent_count),
    $firmware_version: text(system.firmware_version) || null, $model_version: text(system.model_version) || null,
    $trip_distance_km: num(trip.distance_km), $is_resend: isResend ? 1 : 0,
    $raw_json: JSON.stringify(payload),
    $gnss_filter_version: num(filter.version), $gnss_filter_state: text(filter.state) || null,
    $gnss_stationary: hasFilter ? flag(filter.stationary) : null,
    $gnss_segment_valid: hasFilter ? flag(filter.segment_valid) : null,
    $gnss_fix_seq: num(filter.fix_seq), $gnss_position_epoch: num(filter.position_epoch),
    $gnss_raw_lat: num(location.raw_lat), $gnss_raw_lon: num(location.raw_lon),
    $gnss_raw_speed_kph: num(location.raw_speed_kph), $gnss_rejected_fixes: num(filter.rejected_fixes),
  });
  // Replayed SD rows remain available as history, but must not be appended at
  // the end of an active route: their capture time precedes the newest point
  // and would make the route jump backwards/forwards while backlog drains.
  if (!isResend && Number(result.changes) > 0) appendTelemetryToActiveRoute(Number(result.lastInsertRowid));
  cleanup(now);
  return Number(result.changes) === 0;
}


function eventCaptureEpoch(event, payload) {
  const hazardEpoch = num(event.hazard_epoch);
  if (hazardEpoch !== null && hazardEpoch > 0) return { epoch: Math.floor(hazardEpoch), reliable: true };
  const parsed = Date.parse(String(payload.ts || ""));
  if (Number.isFinite(parsed)) return { epoch: Math.floor(parsed / 1000), reliable: true };
  return { epoch: 0, reliable: false };
}

function hazardEventSuppressed(deviceId, eventName, event, payload, isResend = false) {
  if (!["pothole_detected","pothole_catalog_sync","speed_bump_detected","speed_bump_catalog_sync"].includes(eventName)) return false;
  const capture = eventCaptureEpoch(event, payload);
  const epoch = capture.epoch;
  const liveDetection = !isResend && (eventName === "pothole_detected" || eventName === "speed_bump_detected");
  const predatesTombstone = createdAt => {
    if (!capture.reliable) return !liveDetection;
    const deletionEpoch = Math.floor(Number(createdAt || 0) / 1000);
    return epoch < deletionEpoch || (epoch === deletionEpoch && !liveDetection);
  };
  if (epoch) {
    const rangeTombstone = db.prepare("SELECT created_at FROM hazard_deletions WHERE device_id=? AND ? BETWEEN from_epoch AND to_epoch ORDER BY created_at DESC LIMIT 1").get(deviceId, epoch);
    if (rangeTombstone && predatesTombstone(rangeTombstone.created_at)) return true;
  }
  const location=obj(payload.location), lat=num(event.lat ?? location.lat), lon=num(event.lon ?? location.lon);
  if(!validCoords(lat,lon)) return false;
  const kind=eventName.startsWith("pothole")?"pothole":"speed_bump";
  const tombstones=db.prepare("SELECT lat,lon,radius_m,created_at FROM hazard_point_deletions WHERE device_id=? AND kind=? ORDER BY id DESC LIMIT 500").all(deviceId,kind);
  return tombstones.some(t=>{
    if(haversineKm(lat,lon,t.lat,t.lon)*1000>Number(t.radius_m||8))return false;
    // A point tombstone prevents an old queued SD row from resurrecting a
    // marker. It must never swallow a genuinely new TinyML detection made
    // after the deletion. Unknown-time RESEND rows stay suppressed; an
    // unknown-time LIVE row is treated as a new detection.
    return predatesTombstone(t.created_at);
  });
}

function insertEvent(payload, isResend = false) {
  const location = obj(payload.location), road = obj(payload.road), ecu = obj(payload.ecu), event = obj(payload.event);
  const now = Date.now();
  const deviceId = text(payload.device_id, "unknown"), bootId = text(payload.boot_id) || null;
  const sequence = num(payload.seq), eventName = text(event.name, "unknown");
  const explicitUid = text(event.id);
  const eventUid = explicitUid || `legacy:${deviceId}:${bootId || "no-boot"}:${sequence}:${eventName}:${num(payload.uptime_ms) ?? "na"}`;
  if (hazardEventSuppressed(deviceId, eventName, event, payload, isResend)) {
    return { duplicate: true, enriched: false, eventUid, suppressed: true, event: null };
  }
  const pointEvent = /^(pothole|speed_bump)_(detected|catalog_sync)$/.test(eventName);
  const eventLat = num(event.lat ?? location.lat), eventLon = num(event.lon ?? location.lon);
  const hasExplicitPoint = event.lat !== undefined || event.lon !== undefined;
  const attachedPoint = flag(event.gps_attached) && validCoords(eventLat,eventLon) &&
    (hasExplicitPoint || flag(location.valid));
  const values = {
    $device_id: deviceId, $boot_id: bootId, $sequence: sequence,
    $recorded_at: text(payload.ts, new Date(now).toISOString()), $ingested_at: now,
    $uptime_ms: num(payload.uptime_ms), $event_uid: eventUid, $name: eventName,
    $severity: text(event.severity, "info"), $distance_m: num(event.distance_m),
    // A confirmed detection without an attached position is still an event,
    // not a marker at a stale physical fix left in the telemetry envelope.
    $lat: pointEvent && !attachedPoint ? null : eventLat,
    $lon: pointEvent && !attachedPoint ? null : eventLon, $gps_attached: flag(event.gps_attached),
    $new_map_point: flag(event.new_map_point), $confidence: num(event.confidence ?? road.confidence),
    $hazard_epoch: num(event.hazard_epoch), $road_label: text(road.label, "unknown"), $dtc_code: num(ecu.dtc_code),
    $dtc_severity: num(ecu.dtc_severity), $saved_to_sd: flag(event.saved_to_sd),
    $map_capacity_full: flag(event.map_capacity_full), $is_resend: isResend ? 1 : 0,
    $raw_json: JSON.stringify(payload),
  };

  const existing = db.prepare("SELECT id,lat,lon,gps_attached,new_map_point,saved_to_sd,hazard_epoch,is_resend FROM events WHERE device_id=? AND event_uid=? LIMIT 1").get(deviceId,eventUid);
  if (!existing) {
    eventInsert.run(values);
    cleanup(now);
    return { duplicate: false, enriched: false, eventUid, event: eventByUidSelect.get(deviceId,eventUid) || null };
  }

  // A retry may contain better GPS/storage information than the first copy.
  // Enrich the existing row instead of silently discarding that information.
  const hasBetterGps = (existing.lat === null || existing.lon === null) &&
    values.$lat !== null && values.$lon !== null &&
    Number.isFinite(Number(values.$lat)) && Number.isFinite(Number(values.$lon));
  const enrich = Boolean(hasBetterGps || (!existing.gps_attached && values.$gps_attached) ||
    (!existing.new_map_point && values.$new_map_point) || (!existing.saved_to_sd && values.$saved_to_sd) ||
    ((existing.hazard_epoch === null || existing.hazard_epoch === 0) && values.$hazard_epoch));
  // The durable SD outbox can arrive before the immediate RAM copy. When the
  // later identical LIVE copy arrives, promote the existing row even if it has
  // no richer GPS fields; otherwise the event would remain hidden as resend.
  const promoteLive = Boolean(existing.is_resend && !isResend);
  if (enrich || promoteLive) {
    db.prepare(`UPDATE events SET
      ingested_at=CASE WHEN $is_resend=0 THEN $ingested_at ELSE ingested_at END,
      lat=COALESCE(lat,$lat), lon=COALESCE(lon,$lon),
      gps_attached=MAX(COALESCE(gps_attached,0),$gps_attached),
      new_map_point=MAX(COALESCE(new_map_point,0),$new_map_point),
      saved_to_sd=MAX(COALESCE(saved_to_sd,0),$saved_to_sd),
      hazard_epoch=COALESCE(NULLIF(hazard_epoch,0),$hazard_epoch),
      confidence=COALESCE($confidence,confidence),
      is_resend=MIN(COALESCE(is_resend,1),$is_resend), raw_json=$raw_json
      WHERE device_id=$device_id AND event_uid=$event_uid`).run({
        $ingested_at: values.$ingested_at, $lat: values.$lat, $lon: values.$lon,
        $gps_attached: values.$gps_attached, $new_map_point: values.$new_map_point,
        $saved_to_sd: values.$saved_to_sd, $hazard_epoch: values.$hazard_epoch, $confidence: values.$confidence,
        $is_resend: values.$is_resend, $raw_json: values.$raw_json,
        $device_id: values.$device_id, $event_uid: values.$event_uid,
      });
  }
  cleanup(now);
  return { duplicate: true, enriched: enrich, promotedLive: promoteLive, eventUid, event: eventByUidSelect.get(deviceId,eventUid) || null };
}

let lastCleanup = 0;
function cleanup(now = Date.now()) {
  if (now - lastCleanup < 15 * 60 * 1000) return;
  lastCleanup = now;
  db.prepare("DELETE FROM telemetry WHERE ingested_at < ?")
    .run(now - config.telemetryRetentionDays * 86400000);
  db.prepare("DELETE FROM events WHERE ingested_at < ?").run(now - config.eventRetentionDays * 86400000);
  // Completed SD-management commands are only operational history. Keep them
  // for 30 days so a long-running dashboard database does not grow forever.
  db.prepare("DELETE FROM device_commands WHERE status!='pending' AND completed_at IS NOT NULL AND completed_at < ?")
    .run(now - 30 * 86400000);
  // Saved routes are user-managed and are never removed by telemetry retention.
}

function dashboardData(requestedDeviceId) {
  const requested = typeof requestedDeviceId === "string" ? requestedDeviceId.trim().slice(0, 256) : "";
  let deviceId = requested;
  if (!deviceId) {
    // A physical Gateway and Auto Demo may publish at the same time. Prefer a
    // fresh real device in automatic mode so the map never alternates between
    // two vehicles. The demo is shown only through an explicit device_id.
    const latestRealTelemetry = db.prepare("SELECT device_id,ingested_at FROM telemetry WHERE is_resend=0 AND device_id<>? AND device_id NOT LIKE '%-direct-demo' ORDER BY ingested_at DESC LIMIT 1").get(AUTO_DEMO_DEVICE_ID);
    if (latestRealTelemetry && Date.now() - Number(latestRealTelemetry.ingested_at || 0) <= 15000) {
      deviceId = String(latestRealTelemetry.device_id);
    }
  }
  if (!deviceId) {
    const latestTelemetryDevice = db.prepare("SELECT device_id,ingested_at FROM telemetry WHERE is_resend=0 ORDER BY ingested_at DESC LIMIT 1").get();
    const latestEventDevice = db.prepare("SELECT device_id,ingested_at FROM events ORDER BY ingested_at DESC LIMIT 1").get();
    if (latestTelemetryDevice || latestEventDevice) {
      const telemetryIsLive = latestTelemetryDevice && Date.now() - Number(latestTelemetryDevice.ingested_at || 0) <= 15000;
      deviceId = String(telemetryIsLive || !latestEventDevice || (latestTelemetryDevice && latestTelemetryDevice.ingested_at >= latestEventDevice.ingested_at)
        ? latestTelemetryDevice.device_id : latestEventDevice.device_id);
    }
  }
  if (!deviceId) return { device_id: null, latest: null, server_now: Date.now(), road_current: buildRoadCurrent(null), telemetry: [], events: [], potholes: [], speed_bumps: [] };

  const latestAny = db.prepare(`SELECT ${TELEMETRY_COLUMNS} FROM telemetry WHERE device_id=? AND is_resend=0 ORDER BY ingested_at DESC,id DESC LIMIT 1`).get(deviceId) || null;
  const bootId = latestAny?.boot_id ? String(latestAny.boot_id) : "";
  const directSession = isDirectDevice(deviceId) ? directDemo.sessionForDevice(deviceId) : null;
  const displayBootId = deviceId === AUTO_DEMO_DEVICE_ID && autoDemoState.running ? autoDemoState.session_id : directSession?.session_id || bootId;
  const demoBootClause = (deviceId === AUTO_DEMO_DEVICE_ID || isDirectDevice(deviceId)) && displayBootId ? ' AND boot_id=?' : '';
  const eventArgs = demoBootClause ? [deviceId, displayBootId] : [deviceId];
  const telemetry = latestAny ? (bootId
    ? db.prepare(`SELECT * FROM (SELECT ${TELEMETRY_COLUMNS} FROM telemetry WHERE device_id=? AND boot_id=? ORDER BY sequence DESC,id DESC LIMIT 72) ORDER BY sequence ASC,id ASC`).all(deviceId, bootId)
    : db.prepare(`SELECT * FROM (SELECT ${TELEMETRY_COLUMNS} FROM telemetry WHERE device_id=? ORDER BY ingested_at DESC LIMIT 72) ORDER BY ingested_at ASC,id ASC`).all(deviceId)
  ) : [];

  // Events are independent from telemetry. Never hide a real event simply
  // because the newest telemetry packet has not arrived yet.
  const events = db.prepare(`SELECT ${EVENT_COLUMNS} FROM events WHERE device_id=? ${demoBootClause}
    AND name NOT IN ('pothole_catalog_sync','speed_bump_catalog_sync')
    ORDER BY id DESC LIMIT 60`).all(...eventArgs);

  const distanceMeters = (a, b) => {
    const rad = value => value * Math.PI / 180;
    const p1 = rad(Number(a.lat)), p2 = rad(Number(b.lat));
    const dp = rad(Number(b.lat) - Number(a.lat)), dl = rad(Number(b.lon) - Number(a.lon));
    const h = Math.sin(dp / 2) ** 2 + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2;
    return 6371000 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(Math.max(0, 1 - h)));
  };
  const uniqueHazards = rows => {
    const unique = [];
    for (const row of rows) {
      if (unique.some(existing => distanceMeters(existing, row) <= 8.0)) continue;
      unique.push(row);
      if (unique.length >= 200) break;
    }
    return unique;
  };

  const potholes = uniqueHazards(db.prepare(`SELECT ${EVENT_COLUMNS} FROM events WHERE device_id=? ${demoBootClause}
    AND name IN ('pothole_detected','pothole_catalog_sync')
    AND lat IS NOT NULL AND lon IS NOT NULL
    ORDER BY CASE WHEN name='pothole_catalog_sync' THEN 0 ELSE 1 END, id ASC LIMIT 1000`).all(...eventArgs));
  const speedBumps = uniqueHazards(db.prepare(`SELECT ${EVENT_COLUMNS} FROM events WHERE device_id=? ${demoBootClause}
    AND name IN ('speed_bump_detected','speed_bump_catalog_sync')
    AND lat IS NOT NULL AND lon IS NOT NULL
    ORDER BY CASE WHEN name='speed_bump_catalog_sync' THEN 0 ELSE 1 END, id ASC LIMIT 1000`).all(...eventArgs));
  if (latestAny && isDirectDevice(deviceId)) latestAny.direct_demo = directDemo.snapshotFor(latestAny);
  return { device_id: deviceId, latest: latestAny, telemetry, events, potholes, speed_bumps: speedBumps,
    server_now: Date.now(), road_current: buildRoadCurrent(latestAny),
    ...(directSession ? { direct_demo: directSession, source_device_id: directSession.device_id, demo_mode: 'direct' } : {}),
    device_config: publicDeviceSettings(deviceId) };
}


function hazardCatalog(deviceId) {
  if(!deviceId)return[];
  const raw=db.prepare(`SELECT ${EVENT_COLUMNS} FROM events WHERE device_id=? AND name IN ('pothole_detected','pothole_catalog_sync','speed_bump_detected','speed_bump_catalog_sync') AND lat IS NOT NULL AND lon IS NOT NULL ORDER BY id ASC LIMIT 5000`).all(deviceId);
  const groups=[];
  for(const row of raw){
    const kind=String(row.name).startsWith('pothole')?'pothole':'speed_bump';
    let group=groups.find(g=>g.kind===kind&&haversineKm(g.lat,g.lon,row.lat,row.lon)*1000<=8);
    if(!group){group={key:`${kind}:${row.id}`,kind,lat:Number(row.lat),lon:Number(row.lon),first_seen:Number(row.ingested_at),last_seen:Number(row.ingested_at),detection_count:0,max_confidence:0,last_event_id:Number(row.id),hazard_epoch:Number(row.hazard_epoch||0)};groups.push(group);}
    group.first_seen=Math.min(group.first_seen,Number(row.ingested_at));group.last_seen=Math.max(group.last_seen,Number(row.ingested_at));group.last_event_id=Math.max(group.last_event_id,Number(row.id));group.max_confidence=Math.max(group.max_confidence,Number(row.confidence||0));if(String(row.name).endsWith('_detected'))group.detection_count++;
    if(!group.hazard_epoch&&row.hazard_epoch)group.hazard_epoch=Number(row.hazard_epoch);
  }
  return groups.sort((a,b)=>b.last_seen-a.last_seen).slice(0,500);
}

function analyticsSummary(deviceId, days=14){
  if(!deviceId)return{summary:{},daily:[]};
  days=Math.min(31,Math.max(7,Number(days)||14));
  const routes=db.prepare("SELECT COUNT(*) AS count,COALESCE(SUM(distance_km),0) AS km FROM routes WHERE device_id=? AND status='completed'").get(deviceId);
  const maxSpeed=db.prepare("SELECT MAX(COALESCE(ecu_speed_kph,speed_kph)) AS v FROM telemetry WHERE device_id=?").get(deviceId)?.v||0;
  const ev=db.prepare(`SELECT
    SUM(CASE WHEN name='overspeed' THEN 1 ELSE 0 END) AS overspeed,
    SUM(CASE WHEN name='pothole_detected' THEN 1 ELSE 0 END) AS potholes,
    SUM(CASE WHEN name='speed_bump_detected' THEN 1 ELSE 0 END) AS bumps,
    SUM(CASE WHEN name='dtc_active' THEN 1 ELSE 0 END) AS dtc
    FROM events WHERE device_id=?`).get(deviceId)||{};
  const hazards=hazardCatalog(deviceId), uniquePotholes=hazards.filter(h=>h.kind==='pothole').length, uniqueBumps=hazards.filter(h=>h.kind==='speed_bump').length;

  // V10.0.1: aggregate each table ONCE for the whole window instead of doing
  // 3 * days synchronous SQLite queries (42 queries for a 14-day chart).
  const today=new Date();
  const first=new Date(today.getFullYear(),today.getMonth(),today.getDate()-(days-1));
  const fromMs=first.getTime();
  const routeRows=db.prepare(`SELECT strftime('%Y-%m-%d',ended_at/1000,'unixepoch','localtime') AS day,
      COALESCE(SUM(distance_km),0) AS km,COUNT(*) AS n
      FROM routes WHERE device_id=? AND status='completed' AND ended_at>=? GROUP BY day`).all(deviceId,fromMs);
  const eventRows=db.prepare(`SELECT strftime('%Y-%m-%d',ingested_at/1000,'unixepoch','localtime') AS day,
      SUM(CASE WHEN name='pothole_detected' THEN 1 ELSE 0 END) AS p,
      SUM(CASE WHEN name='speed_bump_detected' THEN 1 ELSE 0 END) AS b,
      SUM(CASE WHEN name='overspeed' THEN 1 ELSE 0 END) AS o
      FROM events WHERE device_id=? AND ingested_at>=? GROUP BY day`).all(deviceId,fromMs);
  const speedRows=db.prepare(`SELECT strftime('%Y-%m-%d',ingested_at/1000,'unixepoch','localtime') AS day,
      MAX(COALESCE(ecu_speed_kph,speed_kph)) AS v
      FROM telemetry WHERE device_id=? AND ingested_at>=? GROUP BY day`).all(deviceId,fromMs);
  const routesBy=new Map(routeRows.map(r=>[r.day,r])),eventsBy=new Map(eventRows.map(r=>[r.day,r])),speedBy=new Map(speedRows.map(r=>[r.day,r]));
  const daily=[];
  for(let i=0;i<days;i++){
    const d=new Date(first.getFullYear(),first.getMonth(),first.getDate()+i),day=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
    const r=routesBy.get(day)||{},e=eventsBy.get(day)||{},m=speedBy.get(day)||{};
    daily.push({date:day,distance_km:Number(r.km||0),routes:Number(r.n||0),road_events:Number(e.p||0)+Number(e.b||0),overspeed:Number(e.o||0),max_speed_kph:Number(m.v||0)});
  }
  return{summary:{total_distance_km:Number(routes?.km||0),total_routes:Number(routes?.count||0),max_speed_kph:Number(maxSpeed||0),overspeed_events:Number(ev.overspeed||0),pothole_events:Number(ev.potholes||0),speed_bump_events:Number(ev.bumps||0),dtc_events:Number(ev.dtc||0),unique_potholes:uniquePotholes,unique_speed_bumps:uniqueBumps},daily};
}


function roadQualityData(deviceId,routeId=null){
  if(!deviceId)return[];let from=0,to=Date.now();
  if(Number.isSafeInteger(Number(routeId))&&Number(routeId)>0){const r=db.prepare("SELECT started_at,COALESCE(ended_at,?) AS ended_at FROM routes WHERE id=? AND device_id=?").get(Date.now(),Number(routeId),deviceId);if(!r)return[];from=Number(r.started_at);to=Number(r.ended_at);}
  else from=Date.now()-24*3600*1000;
  // The coloured trail is derived from SD-log telemetry, so deleting a log
  // must hide the matching road-quality samples even when the user keeps the
  // hazard catalogue. Telemetry itself remains available for the latest vehicle
  // position and health cards. The durable range tombstone prevents a delayed
  // MicroSD resend from painting the deleted trail again after refresh.
  const rows=db.prepare(`SELECT t.id,t.recorded_at,t.ingested_at,t.lat,t.lon,t.road_label,t.confidence,t.flat_confidence,t.speed_bump_confidence,t.pothole_confidence
    FROM telemetry t
    WHERE t.device_id=? AND t.ingested_at BETWEEN ? AND ?
      AND t.location_valid=1 AND t.road_valid=1 AND t.lat IS NOT NULL AND t.lon IS NOT NULL
      AND NOT EXISTS (
        SELECT 1 FROM log_deletions d
        WHERE d.device_id=t.device_id
          AND (
            COALESCE(CAST(strftime('%s',t.recorded_at) AS INTEGER),CAST(t.ingested_at/1000 AS INTEGER))
                BETWEEN d.from_epoch AND d.to_epoch
            OR (d.delete_all=1 AND t.is_resend=1 AND t.ingested_at>=d.created_at)
          )
      )
    ORDER BY t.ingested_at ASC LIMIT 5000`).all(deviceId,from,to);

  // Deleting one warning point creates a spatial tombstone. Hide only the
  // matching red/orange AI samples near that point; normal green road samples
  // and unrelated hazards remain visible.
  const pointTombstones=db.prepare(`SELECT kind,lat,lon,radius_m FROM hazard_point_deletions
    WHERE device_id=? ORDER BY id DESC LIMIT 500`).all(deviceId);
  const visible=pointTombstones.length?rows.filter(row=>{
    const kind=String(row.road_label)==='o_ga'?'pothole':String(row.road_label)==='go_giam_toc'?'speed_bump':'';
    if(!kind)return true;
    return !pointTombstones.some(point=>String(point.kind)===kind&&
      haversineKm(Number(row.lat),Number(row.lon),Number(point.lat),Number(point.lon))*1000<=Number(point.radius_m||8));
  }):rows;
  if(visible.length<=700)return visible;const step=Math.ceil(visible.length/700);return visible.filter((_,i)=>i%step===0||i===visible.length-1);
}

function deleteServerHazardPoint(deviceId,params){
  const kind=String(params.kind||''),lat=Number(params.lat),lon=Number(params.lon),radius=Math.min(30,Math.max(3,Number(params.radius_m)||8));
  if(!['pothole','speed_bump'].includes(kind)||!validCoords(lat,lon))return 0;
  const names=kind==='pothole'?['pothole_detected','pothole_catalog_sync']:['speed_bump_detected','speed_bump_catalog_sync'];
  const rows=db.prepare(`SELECT id,lat,lon FROM events WHERE device_id=? AND name IN (?,?) AND lat IS NOT NULL AND lon IS NOT NULL`).all(deviceId,...names);
  const ids=rows.filter(r=>haversineKm(lat,lon,r.lat,r.lon)*1000<=radius).map(r=>Number(r.id));
  db.exec('BEGIN IMMEDIATE');try{
    db.prepare('INSERT INTO hazard_point_deletions(device_id,kind,lat,lon,radius_m,created_at) VALUES(?,?,?,?,?,?)').run(deviceId,kind,lat,lon,radius,Date.now());
    const del=db.prepare('DELETE FROM events WHERE id=?');for(const id of ids)del.run(id);db.exec('COMMIT');
  }catch(e){db.exec('ROLLBACK');throw e;}return ids.length;
}


function parseCommandParams(row) {
  try { const value = JSON.parse(String(row?.params_json || "{}")); return value && typeof value === "object" && !Array.isArray(value) ? value : {}; }
  catch { return {}; }
}
function commandPublicRow(row) {
  if (!row) return null;
  let result = null;
  try { result = row.result_json ? JSON.parse(row.result_json) : null; } catch { result = null; }
  return { id: Number(row.id), device_id: String(row.device_id), action: String(row.action), status: String(row.status),
    created_at: Number(row.created_at), completed_at: row.completed_at === null ? null : Number(row.completed_at),
    params: parseCommandParams(row), result };
}
function deleteServerHazardsForCommand(deviceId, params) {
  const names = ["pothole_detected","pothole_catalog_sync","speed_bump_detected","speed_bump_catalog_sync"];
  const placeholders = names.map(() => "?").join(",");
  const nowEpoch = Math.floor(Date.now() / 1000);
  const tombstoneFrom = params.delete_all ? 0 : Number(params.from_epoch);
  const tombstoneTo = params.delete_all ? nowEpoch : Number(params.to_epoch);
  if (!Number.isFinite(tombstoneFrom) || !Number.isFinite(tombstoneTo) || tombstoneFrom > tombstoneTo) return 0;
  db.prepare("INSERT INTO hazard_deletions(device_id,from_epoch,to_epoch,created_at) VALUES(?,?,?,?)").run(deviceId, tombstoneFrom, tombstoneTo, Date.now());
  if (params.delete_all) {
    const result = db.prepare(`DELETE FROM events WHERE device_id=? AND name IN (${placeholders})`).run(deviceId, ...names);
    return Number(result.changes || 0);
  }
  const fromEpoch = Number(params.from_epoch), toEpoch = Number(params.to_epoch);
  // Date-range deletion is applied only to hazards with an explicit epoch.
  // Legacy 4-column CSV rows have epoch=0, so their creation date is unknown;
  // they are intentionally preserved unless the user chooses "Xóa tất cả".
  const result = db.prepare(`DELETE FROM events WHERE device_id=? AND name IN (${placeholders})
    AND hazard_epoch IS NOT NULL AND hazard_epoch>0 AND hazard_epoch BETWEEN ? AND ?`).run(deviceId, ...names, fromEpoch, toEpoch);
  return Number(result.changes || 0);
}

function recordServerLogDeletion(deviceId, params) {
  const now = Date.now(), nowEpoch = Math.floor(now / 1000);
  const deleteAll = Boolean(params.delete_all);
  const fromEpoch = deleteAll ? 0 : Number(params.from_epoch);
  // A broad client sentinel (4294967295) must not hide telemetry created after
  // the command ACK. Freeze "all" at ACK time so new live samples remain visible.
  const toEpoch = deleteAll ? nowEpoch : Number(params.to_epoch);
  if (!Number.isFinite(fromEpoch) || !Number.isFinite(toEpoch) || fromEpoch > toEpoch) return null;
  // One delete-all tombstone supersedes every older range for this device.
  if (deleteAll) db.prepare("DELETE FROM log_deletions WHERE device_id=?").run(deviceId);
  db.prepare(`INSERT INTO log_deletions(device_id,from_epoch,to_epoch,delete_all,created_at)
    VALUES(?,?,?,?,?)`).run(deviceId, Math.floor(fromEpoch), Math.floor(toEpoch), deleteAll ? 1 : 0, now);
  return { from_epoch: Math.floor(fromEpoch), to_epoch: Math.floor(toEpoch), delete_all: deleteAll };
}

function validateSdCommand(payload) {
  const deviceId = text(payload.device_id);
  const action = text(payload.action);
  if (!deviceId || !["sd_list","sd_read","sd_export","sd_delete"].includes(action)) throw new HttpError(422, "Lệnh MicroSD không hợp lệ", "invalid_payload");
  const params = {};
  if (action === "sd_read" || action === "sd_export") {
    const file = text(payload.file);
    if (!file || file.includes("/") || file.includes("\\") || file.includes("..") || !/^[A-Za-z0-9._-]+\.ndjson$/.test(file)) throw new HttpError(422, "Tên file log không hợp lệ", "invalid_payload");
    params.file = file;
    if (action === "sd_read") params.max_lines = Math.min(12, Math.max(1, Number(payload.max_lines) || 12));
  }
  if (action === "sd_delete") {
    params.delete_all = Boolean(payload.delete_all);
    params.delete_hazards = Boolean(payload.delete_hazards);
    params.from_date = text(payload.from_date);
    params.to_date = text(payload.to_date);
    params.from_epoch = Math.max(0, Math.floor(Number(payload.from_epoch) || 0));
    params.to_epoch = Math.max(0, Math.floor(Number(payload.to_epoch) || 0));
    if (!params.delete_all && (!/^\d{4}-\d{2}-\d{2}$/.test(params.from_date) || !/^\d{4}-\d{2}-\d{2}$/.test(params.to_date) || params.from_date > params.to_date || params.from_epoch > params.to_epoch)) {
      throw new HttpError(422, "Khoảng ngày xóa log không hợp lệ", "invalid_payload");
    }
  }
  return { deviceId, action, params };
}


function safePathSegment(value, fallback="device") {
  const clean = String(value || "").replace(/[^A-Za-z0-9._-]/g, "_").replace(/^\.+/, "").slice(0, 96);
  return clean || fallback;
}
function validExportFileName(value) {
  const file = String(value || "");
  return /^[A-Za-z0-9._-]+\.ndjson$/.test(file) && !file.includes("..") && !file.includes("/") && !file.includes("\\");
}
function localSdLogDirectory(deviceId) {
  const dir = join(SD_EXPORT_DIR, safePathSegment(deviceId)); mkdirSync(dir, { recursive: true }); return dir;
}
function listLocalSdLogs(deviceId) {
  if (!deviceId) return { relative_dir: "SD_Logs", files: [] };
  const dir = localSdLogDirectory(deviceId); const files = [];
  for (const name of readdirSync(dir)) {
    if (!validExportFileName(name)) continue;
    const full = join(dir, name); let st; try { st = statSync(full); } catch { continue; }
    if (!st.isFile()) continue;
    files.push({ name, size: st.size, modified_at: st.mtimeMs, relative_path: `SD_Logs/${safePathSegment(deviceId)}/${name}` });
  }
  files.sort((a,b)=>b.modified_at-a.modified_at);
  return { relative_dir: `SD_Logs/${safePathSegment(deviceId)}`, files };
}
function saveSdExportChunk(payload) {
  const deviceId = text(payload.device_id), file = text(payload.file);
  const offset = Math.floor(Number(payload.offset)), totalSize = Math.floor(Number(payload.total_size));
  const eof = Boolean(payload.eof), dataB64 = String(payload.data_b64 || "");
  if (!deviceId || !validExportFileName(file) || !Number.isSafeInteger(offset) || offset < 0 ||
      !Number.isSafeInteger(totalSize) || totalSize < 0 || offset > totalSize || dataB64.length > 50000) {
    throw new HttpError(422, "Chunk export MicroSD không hợp lệ", "invalid_payload");
  }
  if (dataB64 && !/^[A-Za-z0-9+/]*={0,2}$/.test(dataB64)) throw new HttpError(422, "Base64 không hợp lệ", "invalid_payload");
  const chunk = Buffer.from(dataB64, "base64");
  if (offset + chunk.length > totalSize) throw new HttpError(422, "Chunk vượt kích thước snapshot", "invalid_payload");
  const dir = localSdLogDirectory(deviceId), finalPath = join(dir, file), partPath = `${finalPath}.part`;
  if (offset === 0) writeFileSync(partPath, chunk);
  else {
    if (!existsSync(partPath)) throw new HttpError(409, "Thiếu file tạm; hãy xuất lại từ đầu", "export_offset_mismatch");
    const current = statSync(partPath).size;
    if (current !== offset) throw new HttpError(409, `Sai offset, server đang có ${current}`, "export_offset_mismatch");
    appendFileSync(partPath, chunk);
  }
  const written = offset + chunk.length;
  if (eof) {
    if (written !== totalSize) throw new HttpError(409, "EOF nhưng kích thước chưa đủ", "export_size_mismatch");
    if (existsSync(finalPath)) unlinkSync(finalPath);
    renameSync(partPath, finalPath);
  }
  return { written, complete: eof, relative_path: `SD_Logs/${safePathSegment(deviceId)}/${file}` };
}


const DEFAULT_DEVICE_SETTINGS=Object.freeze({overspeed_warning_kph:120,overspeed_clear_kph:115,geofence_warning_m:10,geofence_rearm_m:20,pothole_confidence:.80,speed_bump_confidence:.80});
const runtimeSettingsProgress = new Map();
function normalizeDeviceSettings(input){const v={...DEFAULT_DEVICE_SETTINGS,...(input||{})},o={overspeed_warning_kph:Number(v.overspeed_warning_kph),overspeed_clear_kph:Number(v.overspeed_clear_kph),geofence_warning_m:Number(v.geofence_warning_m),geofence_rearm_m:Number(v.geofence_rearm_m),pothole_confidence:Number(v.pothole_confidence),speed_bump_confidence:Number(v.speed_bump_confidence)};if(!Number.isFinite(o.overspeed_warning_kph)||o.overspeed_warning_kph<30||o.overspeed_warning_kph>180)throw new HttpError(422,'Ngưỡng quá tốc phải 30–180 km/h','invalid_config');if(!Number.isFinite(o.overspeed_clear_kph)||o.overspeed_clear_kph<20||o.overspeed_clear_kph>=o.overspeed_warning_kph||o.overspeed_warning_kph-o.overspeed_clear_kph<1)throw new HttpError(422,'Ngưỡng reset quá tốc không hợp lệ','invalid_config');if(!Number.isFinite(o.geofence_warning_m)||o.geofence_warning_m<3||o.geofence_warning_m>50||!Number.isFinite(o.geofence_rearm_m)||o.geofence_rearm_m<o.geofence_warning_m+2||o.geofence_rearm_m>100)throw new HttpError(422,'Geofence không hợp lệ','invalid_config');if(!Number.isFinite(o.pothole_confidence)||o.pothole_confidence<.5||o.pothole_confidence>.99||!Number.isFinite(o.speed_bump_confidence)||o.speed_bump_confidence<.5||o.speed_bump_confidence>.99)throw new HttpError(422,'Confidence phải 0.50–0.99','invalid_config');return o;}
function getDeviceSettings(deviceId){const row=deviceId?db.prepare('SELECT * FROM device_settings WHERE device_id=?').get(deviceId):null;return {...DEFAULT_DEVICE_SETTINGS,...(row||{}),device_id:deviceId||null};}
function settingsTarget(deviceId = '') {
  if (isDirectDevice(deviceId)) return deviceId.slice(0, -DIRECT_SUFFIX.length);
  if (deviceId && deviceId !== AUTO_DEMO_DEVICE_ID) return deviceId;
  return (autoDemoState.running && autoDemoState.gateway_device_id) ||
    (config.demoSpeakerDeviceId !== AUTO_DEMO_DEVICE_ID && config.demoSpeakerDeviceId) ||
    db.prepare("SELECT device_id FROM telemetry WHERE is_resend=0 AND device_id<>? AND device_id NOT LIKE '%-direct-demo' ORDER BY ingested_at DESC,id DESC LIMIT 1").get(AUTO_DEMO_DEVICE_ID)?.device_id || '';
}
function publicDeviceSettings(viewDeviceId = '') {
  const target = settingsTarget(viewDeviceId), effective = getDeviceSettings(target);
  const pending = target ? db.prepare("SELECT * FROM device_commands WHERE device_id=? AND action IN ('config_get','config_set') AND status='pending' ORDER BY id DESC LIMIT 1").get(target) : null;
  return { ...effective, view_device_id: viewDeviceId || target || null, target_device_id: target || null,
    confirmed: Boolean(effective.updated_at), pending_command: pending ? commandPublicRow(pending) : null };
}
function announceDeviceSettings(deviceId) {
  broadcastUpdate(deviceId, 'device_config', { device_config: publicDeviceSettings(deviceId) });
  broadcastUpdate(deviceId + DIRECT_SUFFIX, 'device_config', { device_config: publicDeviceSettings(deviceId + DIRECT_SUFFIX) });
  if (deviceId === settingsTarget(AUTO_DEMO_DEVICE_ID)) {
    broadcastUpdate(AUTO_DEMO_DEVICE_ID, 'device_config', { device_config: publicDeviceSettings(AUTO_DEMO_DEVICE_ID) });
  }
}
function ingestRuntimeSettings(payload, isResend) {
  if (isResend || payload.device_id === AUTO_DEMO_DEVICE_ID) return;
  const snapshot = obj(obj(payload.system).runtime_config);
  if (!Object.keys(DEFAULT_DEVICE_SETTINGS).every(key => Object.hasOwn(snapshot, key))) return;
  const latest = runtimeSettingsProgress.get(payload.device_id) || db.prepare('SELECT boot_id,sequence FROM telemetry WHERE device_id=? AND is_resend=0 ORDER BY ingested_at DESC,id DESC LIMIT 1').get(payload.device_id);
  if (latest?.boot_id === payload.boot_id && Number(payload.seq) <= Number(latest.sequence)) return;
  // An old boot replay must not overwrite the configuration of the new boot.
  if (latest?.boot_id && latest.boot_id !== payload.boot_id && db.prepare('SELECT id FROM telemetry WHERE device_id=? AND boot_id=? LIMIT 1').get(payload.device_id, payload.boot_id)) return;
  let normalized;
  try { normalized = normalizeDeviceSettings(snapshot); } catch { return; }
  runtimeSettingsProgress.set(payload.device_id, { boot_id: payload.boot_id, sequence: Number(payload.seq) });
  const previous = getDeviceSettings(payload.device_id);
  if (previous.updated_at && Object.keys(DEFAULT_DEVICE_SETTINGS).every(key => normalized[key] === Number(previous[key]))) return;
  saveDeviceSettings(payload.device_id, normalized, 'runtime_snapshot');
  announceDeviceSettings(payload.device_id);
}
function saveDeviceSettings(deviceId,input,source='device'){const v=normalizeDeviceSettings(input),now=Date.now();db.prepare(`INSERT INTO device_settings(device_id,overspeed_warning_kph,overspeed_clear_kph,geofence_warning_m,geofence_rearm_m,pothole_confidence,speed_bump_confidence,updated_at,source) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(device_id) DO UPDATE SET overspeed_warning_kph=excluded.overspeed_warning_kph,overspeed_clear_kph=excluded.overspeed_clear_kph,geofence_warning_m=excluded.geofence_warning_m,geofence_rearm_m=excluded.geofence_rearm_m,pothole_confidence=excluded.pothole_confidence,speed_bump_confidence=excluded.speed_bump_confidence,updated_at=excluded.updated_at,source=excluded.source`).run(deviceId,v.overspeed_warning_kph,v.overspeed_clear_kph,v.geofence_warning_m,v.geofence_rearm_m,v.pothole_confidence,v.speed_bump_confidence,now,source);return getDeviceSettings(deviceId);}
function queueDeviceCommand(deviceId,action,params={}){const now=Date.now();if(action==='config_get')db.prepare("UPDATE device_commands SET status='failed',completed_at=?,result_json=? WHERE device_id=? AND action='config_get' AND status='pending'").run(now,JSON.stringify({error:'superseded'}),deviceId);const r=db.prepare("INSERT INTO device_commands(device_id,action,params_json,status,created_at) VALUES(?,?,?,'pending',?)").run(deviceId,action,JSON.stringify(params),now);return db.prepare('SELECT * FROM device_commands WHERE id=?').get(Number(r.lastInsertRowid));}

function expireDemoAudioCommands(deviceId = "") {
  const now = Date.now(), cutoff = now - config.demoSpeakerCommandTtlMs;
  const reason = JSON.stringify({ error: "audio_command_expired", speaker_played: false });
  const statement = deviceId
    ? db.prepare("UPDATE device_commands SET status='failed',completed_at=?,result_json=? WHERE device_id=? AND action='audio_play' AND status='pending' AND created_at<?")
    : db.prepare("UPDATE device_commands SET status='failed',completed_at=?,result_json=? WHERE action='audio_play' AND status='pending' AND created_at<?");
  const result = deviceId ? statement.run(now, reason, deviceId, cutoff) : statement.run(now, reason, cutoff);
  return Number(result.changes || 0);
}

function cancelPendingDemoAudioCommands(reason = "demo_stopped") {
  const deviceId = settingsTarget(AUTO_DEMO_DEVICE_ID);
  if (!deviceId) return 0;
  const now = Date.now();
  const result = db.prepare("UPDATE device_commands SET status='failed',completed_at=?,result_json=? WHERE device_id=? AND action='audio_play' AND status='pending'")
    .run(now, JSON.stringify({ error: reason, speaker_played: false }), deviceId);
  return Number(result.changes || 0);
}

function queueDemoSpeakerAlert(payload) {
  directDemo.assertIdle();
  const sound = text(payload.sound), sourceEventUid = text(payload.source_event_uid);
  if (!['pothole','speed_bump'].includes(sound) || !sourceEventUid) {
    throw new HttpError(422, "Cảnh báo loa demo không hợp lệ", "invalid_demo_audio");
  }
  if (!config.demoSpeakerEnabled) return { queued: false, reason: "speaker_demo_disabled", device_id: null };
  const deviceId = settingsTarget(AUTO_DEMO_DEVICE_ID);
  if (!deviceId || deviceId === AUTO_DEMO_DEVICE_ID) {
    return { queued: false, reason: "speaker_device_not_configured", device_id: deviceId || null };
  }
  const latest = db.prepare("SELECT ingested_at FROM telemetry WHERE device_id=? AND is_resend=0 ORDER BY ingested_at DESC LIMIT 1").get(deviceId);
  const ageMs = latest ? Date.now() - Number(latest.ingested_at || 0) : Number.POSITIVE_INFINITY;
  if (!Number.isFinite(ageMs) || ageMs < 0 || ageMs > config.demoSpeakerFreshMs) {
    return { queued: false, reason: "speaker_gateway_offline", device_id: deviceId, age_ms: Number.isFinite(ageMs) ? ageMs : null };
  }

  expireDemoAudioCommands(deviceId);
  const recent = db.prepare("SELECT * FROM device_commands WHERE device_id=? AND action='audio_play' ORDER BY id DESC LIMIT 100").all(deviceId);
  const duplicate = recent.find(row => parseCommandParams(row).source_event_uid === sourceEventUid);
  if (duplicate) return { queued: false, duplicate: true, reason: "speaker_event_already_queued", device_id: deviceId, command: commandPublicRow(duplicate) };

  const row = queueDeviceCommand(deviceId, "audio_play", {
    sound,
    source: "auto_demo",
    source_event_uid: sourceEventUid,
    expires_at_ms: Date.now() + config.demoSpeakerCommandTtlMs,
    ...(payload.proximity ? { demo_session_id: autoDemoState.session_id, proximity: payload.proximity,
      // The browser interpolates the received positions. Allow its current
      // segment to paint before releasing audio, then validate the CURRENT
      // position/radius again at command delivery rather than trust old state.
      not_before_ms: Date.now() + (demoDisplayPosition ? 0 : 750) } : {}),
  });
  console.log(`[AUDIO] QUEUE | device=${deviceId} | id=${row.id} | sound=${sound} | source=${sourceEventUid}`);
  return { queued: true, duplicate: false, device_id: deviceId, command: commandPublicRow(row) };
}
function demoAudioDeliveryState(row) {
  const params = parseCommandParams(row);
  if (row.action !== 'audio_play') return 'ready';
  if (params.expires_at_ms && Date.now() >= Number(params.expires_at_ms)) return 'audio_command_expired';
  if (!params.proximity) return 'ready';
  if (!autoDemoState.running || autoDemoState.stopping || params.demo_session_id !== autoDemoState.session_id) return 'demo_session_ended';
  const point = params.proximity;
  if (!db.prepare('SELECT id FROM events WHERE id=?').get(Number(point.event_id))) return 'demo_hazard_deleted';
  const car = demoDisplayPosition || db.prepare('SELECT lat,lon,ingested_at,boot_id FROM telemetry WHERE device_id=? AND is_resend=0 ORDER BY ingested_at DESC,id DESC LIMIT 1').get(AUTO_DEMO_DEVICE_ID);
  if (!car || car.boot_id !== params.demo_session_id || Date.now() - Number(car.ingested_at) > 1500 || !validCoords(car.lat, car.lon)) return 'wait';
  const settings = getDeviceSettings(row.device_id);
  if (haversineKm(car.lat, car.lon, point.lat, point.lon) * 1000 > settings.geofence_warning_m) return 'outside_current_warning_radius';
  return Date.now() < Number(params.not_before_ms || 0) ? 'wait' : 'ready';
}
function selfTestData(deviceId){
  const latest=deviceId?db.prepare(`SELECT ${TELEMETRY_COLUMNS} FROM telemetry WHERE device_id=? AND is_resend=0 ORDER BY ingested_at DESC LIMIT 1`).get(deviceId):null;
  const now=Date.now(),fresh=latest&&now-Number(latest.ingested_at||0)<=10000,checks=[];
  const simulatedDevice=deviceId===AUTO_DEMO_DEVICE_ID;
  const add=(key,label,status,detail)=>checks.push({key,label,status,detail});
  add('server','Local server','pass','SQLite + HTTP OK');
  add('gateway','ESP32-S3 Gateway',fresh?'pass':'fail',fresh?'Telemetry mới':'Không có telemetry <10 s');
  add('can','CAN / ECU',fresh&&latest.ecu_online&&latest.ecu_runtime_ready?'pass':fresh?'wait':'fail',fresh?(latest.ecu_online?'ECU online':'Mất heartbeat'):'Gateway offline');
  add('gnss','GNSS M10',fresh&&latest.navigation_ready?'pass':fresh?'wait':'fail',fresh?(latest.navigation_ready?`${latest.satellites||0} vệ tinh · HDOP ${latest.hdop??'—'}`:'Chờ fix'):'Gateway offline');
  add('ai','ADXL345 I²C + TinyML',fresh&&latest.ai_ready&&latest.adxl_healthy?'pass':fresh?'wait':'fail',fresh?`FIFO overrun ${latest.adxl_fifo_overruns||0}`:'Gateway offline');
  const sdState=String(latest?.sd_state||''),sdError=String(latest?.sd_last_error||'unknown');
  const sdTransient=new Set(['boot_settling','mounting','verifying','post_mount_settle','post_audio_settle','post_audio_verify']);
  const sdRetryGrace=sdState==='retry_wait'&&Number(latest?.uptime_ms||0)<30000;
  const sdBlock=String(latest?.sd_write_block_reason||'none');
  const sdPhysicalFull=fresh&&sdBlock==='physical_full',sdQuota=fresh&&sdBlock==='daily_log_quota';
  const sdWait=fresh&&(sdTransient.has(sdState)||Boolean(latest?.sd_recovery_busy)||sdRetryGrace);
  if(simulatedDevice) add('sd','MicroSD','wait','N/A · Auto Demo không kiểm tra phần cứng thật');
  else if(!fresh) add('sd','MicroSD','fail','Gateway offline');
  else if(sdPhysicalFull) add('sd','MicroSD','fail',`Thẻ đầy vật lý · đã dùng ${latest.sd_used_bytes??'—'} / ${latest.sd_total_bytes??'—'} bytes`);
  else if(sdQuota) add('sd','MicroSD','wait',`Đạt hạn mức log ngày · thẻ vẫn mount · drops ${latest.sd_log_drop_count||0}`);
  else add('sd','MicroSD',sdWait?'wait':latest.sd_ok?'pass':'fail',sdWait?`${sdState||'initializing'} · ${sdError}`:latest.sd_ok?`${sdState||'online'} · ${Number(latest.sd_frequency_hz||0)/1000000} MHz · remount ${latest.sd_remounts||0}`:`Không mount được · ${sdError}`);
  add('wifi','Wi‑Fi / Server',fresh&&Number(latest.wifi_rssi)<0?'pass':fresh?'wait':'fail',fresh?`RSSI ${latest.wifi_rssi??'—'} · HTTP ${latest.network_last_http??'—'}`:'Gateway offline');
  add('memory','Heap / PSRAM',fresh&&Number(latest.free_heap||0)>=80000?'pass':fresh?'warn':'fail',fresh?`${latest.free_heap||0} / ${latest.free_psram||0} bytes`:'Gateway offline');
  const fail=checks.some(c=>c.status==='fail'),wait=checks.some(c=>c.status==='wait'||c.status==='warn');
  return {device_id:deviceId||null,generated_at:now,overall:fail?'fail':wait?'waiting':'ready',latest,checks};
}
function searchEvents(deviceId,params){
  const limit=Math.min(500,Math.max(1,Math.floor(Number(params.get('limit'))||200)));
  const offset=Math.min(10000000,Math.max(0,Math.floor(Number(params.get('offset'))||0)));
  if(!deviceId)return{events:[],total:0,limit,offset,has_more:false,next_offset:null};
  const eventTimeMs=EVENT_TIME_MS_SQL;
  const where=['device_id=?',"name NOT IN ('pothole_catalog_sync','speed_bump_catalog_sync')"],values=[deviceId];
  const groups={pothole:['pothole_detected','pothole_proximity'],bump:['speed_bump_detected','speed_bump_proximity'],overspeed:['overspeed','overspeed_cleared'],dtc:['dtc_active'],system:['ecu_offline','ecu_recovered']};
  const cat=String(params.get('category')||'all');
  if(groups[cat]){where.push(`name IN (${groups[cat].map(()=>'?').join(',')})`);values.push(...groups[cat]);}
  const fromText=String(params.get('from')||''),toText=String(params.get('to')||'');
  const from=fromText?Date.parse(`${fromText}T00:00:00`):NaN,to=toText?Date.parse(`${toText}T23:59:59.999`):NaN;
  if(Number.isFinite(from)){where.push(`${eventTimeMs}>=?`);values.push(from);}
  if(Number.isFinite(to)){where.push(`${eventTimeMs}<=?`);values.push(to);}
  const q=String(params.get('q')||'').trim().slice(0,80);
  if(q){where.push('(name LIKE ? OR severity LIKE ? OR event_uid LIKE ? OR COALESCE(road_label,\'\') LIKE ? OR COALESCE(boot_id,\'\') LIKE ?)');const like=`%${q}%`;values.push(like,like,like,like,like);}
  const clause=where.join(' AND ');
  const total=Number(db.prepare(`SELECT COUNT(*) AS total FROM events WHERE ${clause}`).get(...values)?.total||0);
  const events=db.prepare(`SELECT ${EVENT_COLUMNS},${eventTimeMs} AS event_time_ms FROM events WHERE ${clause} ORDER BY event_time_ms DESC,id DESC LIMIT ${limit} OFFSET ${offset}`).all(...values);
  const nextOffset=offset+events.length,hasMore=nextOffset<total;
  return{events,total,limit,offset,has_more:hasMore,next_offset:hasMore?nextOffset:null};
}

class HttpError extends Error {
  constructor(status, message, code) { super(message); this.status = status; this.code = code; }
}

async function readJson(request, maxBodyBytes = config.maxBodyBytes) {
  const contentType = String(request.headers["content-type"] || "").toLowerCase();
  if (!contentType.startsWith("application/json")) throw new HttpError(415, "Content-Type phải là application/json", "unsupported_media_type");
  const chunks = []; let total = 0;
  for await (const chunk of request) {
    total += chunk.length;
    if (total > maxBodyBytes) throw new HttpError(413, "Payload quá lớn", "payload_too_large");
    chunks.push(chunk);
  }
  let value;
  try { value = JSON.parse(Buffer.concat(chunks).toString("utf8")); }
  catch { throw new HttpError(400, "JSON không hợp lệ", "invalid_json"); }
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new HttpError(422, "Cần một JSON object", "invalid_payload");
  return value;
}

function secureEqual(left, right) {
  const a = Buffer.from(String(left)), b = Buffer.from(String(right));
  return a.length === b.length && timingSafeEqual(a, b);
}

function authorized(request) {
  const header = String(request.headers.authorization || "");
  return header.startsWith("Bearer ") && secureEqual(header.slice(7), config.ingestApiKey);
}

function validatePayload(payload, kind) {
  const sequence = num(payload.seq);
  if (!text(payload.device_id) || !text(payload.boot_id) || !Number.isSafeInteger(sequence) || sequence < 0) {
    throw new HttpError(422, "Thiếu device_id, boot_id hoặc seq hợp lệ", "invalid_payload");
  }
  if (kind === "event" && !text(obj(payload.event).name)) {
    throw new HttpError(422, "Thiếu event.name", "invalid_payload");
  }
  if (payload.type !== undefined && payload.type !== kind) {
    throw new HttpError(422, "Trường type không khớp endpoint", "invalid_payload");
  }
}

function apiHeaders() {
  return {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Telematics-Resend, OAI-Sites-Authorization",
    "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
    "X-Content-Type-Options": "nosniff",
  };
}

function sendJson(response, status, body) {
  response.writeHead(status, apiHeaders());
  response.end(JSON.stringify(body));
}

const sseClients = new Set();
const liveUpdates = createUpdateFeed();
let sseEventSequence = 0;

function liveSnapshot(requestedDeviceId, after = '', motionOnly = false) {
  const now = Date.now();
  let deviceId = text(requestedDeviceId || '');
  if (!deviceId) {
    const real = db.prepare("SELECT device_id,ingested_at FROM telemetry WHERE is_resend=0 AND device_id<>? AND device_id NOT LIKE '%-direct-demo' ORDER BY ingested_at DESC,id DESC LIMIT 1").get(AUTO_DEMO_DEVICE_ID);
    const any = real && now - Number(real.ingested_at) <= 15000 ? real :
      db.prepare('SELECT device_id FROM telemetry WHERE is_resend=0 ORDER BY ingested_at DESC,id DESC LIMIT 1').get();
    deviceId = any?.device_id || '';
  }
  const direct = isDirectDevice(deviceId) ? directDemo.sessionForDevice(deviceId) : null;
  const result = { ok: true, server_now: now, device_id: deviceId || null,
    ...liveUpdates.read(deviceId, after), direct_realtime: direct?.realtime || null,
    direct_active: Boolean(direct && !['stopped','failed','interrupted'].includes(direct.state)) };
  if (motionOnly) return result;
  const latest = deviceId ? db.prepare(`SELECT ${TELEMETRY_COLUMNS} FROM telemetry WHERE device_id=? AND is_resend=0 ORDER BY ingested_at DESC,id DESC LIMIT 1`).get(deviceId) || null : null;
  if (latest && direct) latest.direct_demo = directDemo.snapshotFor(latest);
  return { ...result, latest, road_current: buildRoadCurrent(latest, now),
    ...(direct ? { direct_demo: direct, source_device_id: direct.device_id, demo_mode: 'direct' } : {}) };
}

function writeSse(client, eventName, payload) {
  if (client.response.destroyed || client.response.writableEnded) {
    sseClients.delete(client);
    return false;
  }
  // Fast display frames are replaceable. A slow/disconnected browser must not
  // accumulate old vehicle positions in Node's socket buffer.
  if (client.response.writableLength > 65536) {
    sseClients.delete(client);
    client.pendingRealtime = null;
    client.response.destroy();
    return false;
  }
  if (eventName === 'update' && payload.kind === 'direct_realtime' && client.response.writableNeedDrain) {
    client.pendingRealtime = payload;
    return true;
  }
  try {
    const id = `${Date.now()}-${++sseEventSequence}`;
    client.response.write(`id: ${id}\nevent: ${eventName}\ndata: ${JSON.stringify(payload)}\n\n`);
    return true;
  } catch {
    sseClients.delete(client);
    try { client.response.end(); } catch {}
    return false;
  }
}

function openSse(request, response, deviceValue) {
  const deviceId = text(deviceValue || "");
  response.writeHead(200, {
    "Content-Type": "text/event-stream; charset=utf-8",
    "Cache-Control": "no-cache, no-store, must-revalidate, no-transform",
    "Connection": "keep-alive",
    "Content-Encoding": "identity",
    "Access-Control-Allow-Origin": "*",
    "X-Accel-Buffering": "no",
    "X-Content-Type-Options": "nosniff",
  });
  response.flushHeaders?.();
  response.write("retry: 1500\n\n");
  const client = { response, deviceId, pendingRealtime: null };
  sseClients.add(client);
  writeSse(client, "connected", {
    device_id: deviceId || null, kind: "connected", received_at: new Date().toISOString(),
  });
  const cleanupClient = () => { client.pendingRealtime = null; sseClients.delete(client); };
  response.on('drain', () => {
    const pending = client.pendingRealtime; client.pendingRealtime = null;
    if (pending && Date.now() - pending.received_at_ms <= 1500) writeSse(client, 'update', pending);
  });
  request.on("aborted", cleanupClient);
  response.on("close", cleanupClient);
  response.on("error", cleanupClient);
}

function broadcastUpdate(deviceValue, kind, extra = {}) {
  const deviceId = text(deviceValue || "");
  const payload = { device_id: deviceId || null, kind, received_at: new Date().toISOString(), ...extra };
  liveUpdates.publish(deviceId, kind, extra);
  for (const client of sseClients) {
    if (!client.deviceId || client.deviceId === deviceId) writeSse(client, "update", payload);
  }
}

const sseHeartbeatTimer = setInterval(() => {
  const payload = { kind: "heartbeat", received_at: new Date().toISOString() };
  for (const client of sseClients) writeSse(client, "heartbeat", { ...payload, device_id: client.deviceId || null });
}, 15000);
sseHeartbeatTimer.unref?.();

const mimeTypes = {
  ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8", ".json": "application/json; charset=utf-8",
  ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".ico": "image/x-icon",
};

async function serveStatic(pathname, response) {
  let relative;
  try { relative = decodeURIComponent(pathname === "/" ? "index.html" : pathname.replace(/^\/+/, "")); }
  catch { return false; }
  const filePath = resolve(PUBLIC_DIR, relative);
  if (filePath !== PUBLIC_DIR && !filePath.startsWith(PUBLIC_DIR + sep)) return false;
  let stat;
  try { stat = statSync(filePath); } catch { return false; }
  if (!stat.isFile()) return false;
  const body = await readFile(filePath);
  response.writeHead(200, {
    "Content-Type": mimeTypes[extname(filePath).toLowerCase()] || "application/octet-stream",
    // Localhost development must reflect HTML/CSS/JS edits immediately after
    // refresh. Cache only immutable images and other binary assets.
    "Cache-Control": [".html", ".css", ".js"].includes(extname(filePath).toLowerCase()) ? "no-store" : "public, max-age=300",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Content-Security-Policy": "default-src 'self'; script-src 'self' https://unpkg.com; style-src 'self' 'unsafe-inline' https://unpkg.com; img-src 'self' data: https://unpkg.com https://tile.openstreetmap.org https://*.tile.openstreetmap.org; connect-src 'self'; font-src 'self'",
  });
  response.end(body);
  return true;
}

const startedAt = Date.now();
const AUTO_DEMO_DEVICE_ID = "blackbox-esp32s3-auto-demo";
const AUTO_DEMO_SCRIPT = join(ROOT, "tools", "auto-demo.mjs");
let autoDemoProcess = null;
let autoDemoState = {
  running: false, completed: false, stopping: false, device_id: AUTO_DEMO_DEVICE_ID,
  session_id: null,
  started_at: null, ended_at: null, exit_code: null, last_line: "", error: "",
};

let demoRawSamples = null;
let demoRoadResult = null;
let demoHazardSequence = 1000000000;
let demoInferenceHazards = [];
let demoDisplayPosition = null;

function rawDemoSamples() {
  if (!demoRawSamples) demoRawSamples = loadDemoSamples(join(ROOT, 'demo_samples', 'manifest.json'));
  return demoRawSamples;
}

function demoGatewayStatus() {
  let deviceId = (autoDemoState.running && autoDemoState.gateway_device_id) || config.demoSpeakerDeviceId;
  if (!deviceId || deviceId === AUTO_DEMO_DEVICE_ID) {
    deviceId = db.prepare('SELECT device_id FROM telemetry WHERE is_resend=0 AND device_id<>? ORDER BY ingested_at DESC,id DESC LIMIT 1').get(AUTO_DEMO_DEVICE_ID)?.device_id || '';
  }
  const row = deviceId ? db.prepare('SELECT ingested_at,firmware_version FROM telemetry WHERE device_id=? AND is_resend=0 ORDER BY ingested_at DESC,id DESC LIMIT 1').get(deviceId) : null;
  const ageMs = row ? Date.now() - Number(row.ingested_at) : Infinity;
  return { device_id: deviceId || null, online: ageMs >= 0 && ageMs <= 10000,
    age_ms: Number.isFinite(ageMs) ? ageMs : null, firmware_version: row?.firmware_version || null };
}

function expireDemoInferenceCommands(reason = '') {
  const rows = db.prepare("SELECT * FROM device_commands WHERE action='demo_infer' AND status='pending'").all();
  for (const row of rows) {
    const params = parseCommandParams(row);
    const expired = Date.now() >= Number(params.expires_at_ms || 0);
    if (reason || expired || params.demo_session_id !== autoDemoState.session_id || !autoDemoState.running) {
      db.prepare("UPDATE device_commands SET status='failed',completed_at=?,result_json=? WHERE id=? AND status='pending'")
        .run(Date.now(), JSON.stringify({ error: reason || (expired ? 'demo_inference_expired' : 'demo_session_ended'), inference_ok: false }), row.id);
    }
  }
}

function queueDemoInference(payload) {
  directDemo.assertIdle();
  const session = text(payload.session_id);
  if (!autoDemoState.running || autoDemoState.stopping || !session || session !== autoDemoState.session_id) {
    throw new HttpError(409, 'Hãy chạy demo trước khi gửi mẫu gia tốc', 'demo_not_running');
  }
  const sample = rawDemoSamples().samples.find(item => item.id === payload.sample_id);
  if (!sample) throw new HttpError(422, 'Mẫu gia tốc không hợp lệ', 'invalid_demo_sample');
  const gateway = demoGatewayStatus();
  if (!gateway.online) throw new HttpError(409, 'ESP32-S3 đang offline; không tạo điểm cảnh báo giả', 'gateway_offline');
  const position = obj(payload.position), lat = num(position.lat), lon = num(position.lon);
  const car = db.prepare('SELECT lat,lon,ingested_at,boot_id FROM telemetry WHERE device_id=? AND is_resend=0 ORDER BY ingested_at DESC,id DESC LIMIT 1').get(AUTO_DEMO_DEVICE_ID);
  if (!validCoords(lat, lon) || !car || car.boot_id !== session || Date.now() - Number(car.ingested_at) > 3000 ||
      haversineKm(lat, lon, car.lat, car.lon) * 1000 > 20) {
    throw new HttpError(422, 'Vị trí xe demo đã cũ hoặc không hợp lệ', 'invalid_demo_capture');
  }
  expireDemoInferenceCommands();
  if (db.prepare("SELECT id FROM device_commands WHERE device_id=? AND action='demo_infer' AND status='pending' LIMIT 1").get(gateway.device_id)) {
    throw new HttpError(409, 'ESP32-S3 đang xử lý mẫu trước; hãy đợi kết quả', 'demo_inference_busy');
  }
  const now = Date.now();
  const params = { source: 'auto_demo_tinyml', sample_id: sample.id, sample_rate_hz: sample.frequency_hz,
    units: sample.units, frames: sample.frame_samples, values: sample.values,
    demo_device_id: AUTO_DEMO_DEVICE_ID, demo_session_id: session,
    captured_lat: lat, captured_lon: lon, captured_at: new Date(now).toISOString(), expires_at_ms: now + DEMO_INFERENCE_TTL_MS };
  const row = queueDeviceCommand(gateway.device_id, 'demo_infer', params);
  broadcastUpdate(AUTO_DEMO_DEVICE_ID, 'demo_inference', { command_id: Number(row.id), status: 'pending' });
  return { command: commandPublicRow(row), captured_position: { lat, lon, ts: params.captured_at } };
}

function acceptDemoInference(row, ok, resultObj) {
  const params = parseCommandParams(row);
  if (row.status !== 'pending') return { ...(commandPublicRow(row).result || {}), duplicate_ack: true };
  if (!ok) return { ...resultObj, inference_ok: false, map_point_created: false };
  if (!autoDemoState.running || autoDemoState.stopping || params.demo_session_id !== autoDemoState.session_id ||
      Date.now() >= Number(params.expires_at_ms || 0)) {
    return { error: 'demo_session_ended_or_expired', inference_ok: false, map_point_created: false };
  }
  let road;
  try { road = normalizeInferenceResult(resultObj); }
  catch (error) { return { error: String(error.message), inference_ok: false, map_point_created: false }; }
  const settings = getDeviceSettings(row.device_id);
  const threshold = road.label === 'o_ga' ? settings.pothole_confidence : settings.speed_bump_confidence;
  road.hazard_accepted = road.hazard_accepted && road.confidence >= threshold;
  const sample = rawDemoSamples().samples.find(item => item.id === params.sample_id);
  if (sample) {
    road.x_g = sample.values.at(-3); road.y_g = sample.values.at(-2); road.z_g = sample.values.at(-1);
  }
  demoRoadResult = road;
  const hazardKind = road.label === 'o_ga' ? 'pothole' : 'speed_bump';
  let inserted = null;
  if (road.hazard_accepted) {
    const position = { lat: Number(params.captured_lat), lon: Number(params.captured_lon) };
    const existing = demoInferenceHazards.find(h => h.kind === hazardKind && haversineKm(h.lat, h.lon, position.lat, position.lon) * 1000 <= 8);
    const captureAt = String(params.captured_at);
    const eventPayload = { type: 'event', device_id: AUTO_DEMO_DEVICE_ID, boot_id: params.demo_session_id,
      seq: ++demoHazardSequence, ts: captureAt, road,
      location: { valid: true, ...position },
      event: { id: `demo-infer:${params.demo_session_id}:${row.id}`, name: `${hazardKind}_detected`,
        severity: 'warning', gps_attached: true, new_map_point: !existing, saved_to_sd: false,
        confidence: road.confidence, hazard_epoch: Math.floor(Date.parse(captureAt) / 1000),
        source: 'esp32s3_raw_sample_inference', source_command_id: Number(row.id), source_sample_id: params.sample_id } };
    inserted = insertEvent(eventPayload);
    if (!inserted.suppressed && !existing) demoInferenceHazards.push({ ...position, kind: hazardKind, road,
      event_uid: inserted.eventUid, armed: false, approach: 0, event_id: Number(inserted.event?.id) });
    if (!inserted.suppressed) broadcastUpdate(AUTO_DEMO_DEVICE_ID, 'event', { event: inserted.event, inserted: !inserted.duplicate });
  }
  const finalResult = { ...resultObj, hazard_accepted: road.hazard_accepted, map_point_created: Boolean(inserted && !inserted.suppressed),
    captured_position: { lat: params.captured_lat, lon: params.captured_lon, ts: params.captured_at },
    demo_session_id: params.demo_session_id, sample_id: params.sample_id };
  broadcastUpdate(AUTO_DEMO_DEVICE_ID, 'demo_inference', { command_id: Number(row.id), status: 'done', result: finalResult });
  return finalResult;
}

function processDemoTelemetry(payload) {
  directDemo.assertIdle();
  const session = text(payload.boot_id);
  const active = db.prepare("SELECT id FROM routes WHERE device_id=? AND status='active' LIMIT 1").get(AUTO_DEMO_DEVICE_ID);
  if (!active) return;
  // Standalone AUTO_DEMO.bat is also supported; its first authenticated packet
  // registers the session, but cannot steal a server-managed session.
  if (!autoDemoProcess && (!autoDemoState.running || autoDemoState.session_id !== session)) {
    expireDemoInferenceCommands('demo_session_replaced');
    demoInferenceHazards = []; demoRoadResult = null; demoDisplayPosition = null;
    autoDemoState = { ...autoDemoState, running: true, completed: false, stopping: false,
      session_id: session, gateway_device_id: settingsTarget(''), started_at: Date.now(), ended_at: null, external: true, error: '' };
  }
  if (!autoDemoState.running || autoDemoState.stopping || session !== autoDemoState.session_id) return;
  // Show the actual ESP prediction; dense demo ticks never overwrite it with a
  // guessed label/confidence. Real-device telemetry remains completely separate.
  if (demoRoadResult) {
    payload.road = { ...demoRoadResult };
    payload.system = { ...obj(payload.system), ai_ready: true, model_version: 'telematics-ei-1.0.1' };
  }
  const location = obj(payload.location);
  if (!flag(location.valid) || !validCoords(location.lat, location.lon)) return;
  if (!demoDisplayPosition) processDemoProximity(session, location);
}

function processDemoProximity(session, location) {
  const settings = getDeviceSettings(settingsTarget(AUTO_DEMO_DEVICE_ID));
  for (const hazard of demoInferenceHazards) {
    if (!db.prepare('SELECT id FROM events WHERE id=?').get(hazard.event_id)) continue;
    const distance = haversineKm(location.lat, location.lon, hazard.lat, hazard.lon) * 1000;
    const warningM = Number(settings.geofence_warning_m);
    const rearmM = Number(settings.geofence_rearm_m);
    if (distance >= rearmM) hazard.armed = true;
    if (!hazard.armed || distance > warningM) continue;
    hazard.armed = false; hazard.approach += 1;
    const uid = `demo-proximity:${session}:${hazard.event_id}:${hazard.approach}`;
    const eventPayload = { type: 'event', device_id: AUTO_DEMO_DEVICE_ID, boot_id: session,
      seq: ++demoHazardSequence, ts: new Date().toISOString(), road: hazard.road,
      location: { valid: true, lat: Number(location.lat), lon: Number(location.lon) },
      event: { id: uid, name: `${hazard.kind}_proximity`, severity: 'warning', distance_m: distance,
        gps_attached: true, new_map_point: false, saved_to_sd: false, lat: hazard.lat, lon: hazard.lon,
        warning_radius_m: warningM, rearm_radius_m: rearmM, settings_device_id: settings.device_id,
        position_source: demoDisplayPosition ? 'displayed_marker' : 'headless_demo' } };
    const saved = insertEvent(eventPayload);
    broadcastUpdate(AUTO_DEMO_DEVICE_ID, 'event', { event: saved.event, inserted: !saved.duplicate });
    const speaker = queueDemoSpeakerAlert({ sound: hazard.kind, source_event_uid: uid,
      proximity: { lat: hazard.lat, lon: hazard.lon, event_id: hazard.event_id } });
    console.log(`[DEMO] PROXIMITY | ${hazard.kind} | ${distance.toFixed(1)} m | speaker=${speaker.queued ? 'queued' : speaker.reason}`);
  }
}

function acceptDemoDisplayPosition(payload) {
  if (!autoDemoState.running || autoDemoState.stopping || payload.session_id !== autoDemoState.session_id) throw new HttpError(409, 'Phiên demo đã thay đổi', 'demo_not_running');
  const clientId = text(payload.client_id), sequence = Number(payload.sequence), position = obj(payload.position);
  if (!clientId || clientId.length > 100 || !Number.isSafeInteger(sequence) || sequence < 1 || !validCoords(position.lat, position.lon)) throw new HttpError(422, 'Vị trí hiển thị không hợp lệ', 'invalid_demo_display_position');
  const now = Date.now(), car = db.prepare('SELECT lat,lon,ingested_at,boot_id FROM telemetry WHERE device_id=? AND is_resend=0 ORDER BY ingested_at DESC,id DESC LIMIT 1').get(AUTO_DEMO_DEVICE_ID);
  if (!car || car.boot_id !== payload.session_id || now - Number(car.ingested_at) > 3000 || !validCoords(car.lat, car.lon) || haversineKm(car.lat, car.lon, position.lat, position.lon) * 1000 > 20) throw new HttpError(422, 'Vị trí hiển thị quá cũ', 'invalid_demo_display_position');
  if (demoDisplayPosition?.client_id === clientId && sequence <= demoDisplayPosition.sequence) return { accepted: false, reason: 'old_display_sequence' };
  if (demoDisplayPosition && demoDisplayPosition.client_id !== clientId && now - demoDisplayPosition.ingested_at <= 1500) return { accepted: false, reason: 'another_demo_view_is_active' };
  demoDisplayPosition = { client_id: clientId, sequence, lat: Number(position.lat), lon: Number(position.lon), boot_id: payload.session_id, ingested_at: now };
  // Once a browser has observed this session, only its painted positions can
  // trigger demo warnings. A hidden/stalled tab cannot silently fall back to
  // the server car running ahead; a fresh tab can acquire the expired lease.
  processDemoProximity(payload.session_id, demoDisplayPosition);
  return { accepted: true };
}

function publicAutoDemoState() {
  expireDemoInferenceCommands();
  return { ...autoDemoState, pid: autoDemoProcess?.pid || null, device_config: publicDeviceSettings(AUTO_DEMO_DEVICE_ID),
    warning_position_source: demoDisplayPosition ? 'displayed_marker' : 'headless_demo' };
}

function updateAutoDemoOutput(chunk, isError = false) {
  const lines = String(chunk || "").split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  if (!lines.length) return;
  autoDemoState.last_line = lines.at(-1).slice(0, 300);
  if (isError) autoDemoState.error = autoDemoState.last_line;
  broadcastUpdate(AUTO_DEMO_DEVICE_ID, "demo", { running: autoDemoState.running, last_line: autoDemoState.last_line });
}

function closeAutoDemoRoute() {
  const active = db.prepare("SELECT id FROM routes WHERE device_id=? AND status='active' LIMIT 1").get(AUTO_DEMO_DEVICE_ID);
  if (!active) return null;
  try {
    const route = endRoute(AUTO_DEMO_DEVICE_ID, Number(active.id));
    if (route) {
      console.log(`[DEMO] Đã đóng lộ trình mô phỏng #${route.route_no ?? route.id}.`);
      broadcastUpdate(AUTO_DEMO_DEVICE_ID, "route", { action: "ended", route_id: Number(route.id), route_no: route.route_no });
    }
    return route;
  } catch (error) {
    console.error("[DEMO] Không thể đóng lộ trình mô phỏng:", error.message);
    return null;
  }
}

function startAutoDemo() {
  directDemo.assertIdle();
  if (autoDemoState.running) throw new HttpError(409, "Demo đang chạy", "demo_already_running");
  if (!existsSync(AUTO_DEMO_SCRIPT)) throw new HttpError(500, "Thiếu tools/auto-demo.mjs", "demo_script_missing");
  expireDemoInferenceCommands('demo_session_replaced');
  demoInferenceHazards = []; demoRoadResult = null; demoDisplayPosition = null;
  const gatewayDeviceId = settingsTarget('');
  autoDemoState = {
    running: true, completed: false, stopping: false, device_id: AUTO_DEMO_DEVICE_ID,
    session_id: randomUUID(), gateway_device_id: gatewayDeviceId, external: false,
    started_at: Date.now(), ended_at: null, exit_code: null, last_line: "Đang khởi động demo tự động...", error: "",
  };
  const child = spawn(process.execPath, [AUTO_DEMO_SCRIPT, "--speed", process.env.DEMO_SPEED || "1"], {
    cwd: ROOT, windowsHide: true, stdio: ["ignore", "pipe", "pipe"],
    env: { ...process.env, DEMO_SESSION_ID: autoDemoState.session_id },
  });
  autoDemoProcess = child;
  child.stdout.setEncoding("utf8");
  child.stderr.setEncoding("utf8");
  child.stdout.on("data", chunk => updateAutoDemoOutput(chunk, false));
  child.stderr.on("data", chunk => updateAutoDemoOutput(chunk, true));
  child.once("error", error => {
    autoDemoState.running = false;
    autoDemoState.completed = false;
    autoDemoState.ended_at = Date.now();
    autoDemoState.error = String(error.message || error).slice(0, 300);
    expireDemoInferenceCommands('demo_start_failed');
    autoDemoState.last_line = `Không thể chạy demo: ${autoDemoState.error}`;
    autoDemoProcess = null;
    broadcastUpdate(AUTO_DEMO_DEVICE_ID, "demo", publicAutoDemoState());
  });
  child.once("close", code => {
    const wasStopping = autoDemoState.stopping;
    // SIGTERM stops the child before its own catch/finally can always call the
    // route API. The parent owns the same SQLite database, so close any leaked
    // demo route here before reporting a terminal state.
    closeAutoDemoRoute();
    autoDemoState.running = false;
    autoDemoState.stopping = false;
    expireDemoInferenceCommands('demo_session_ended');
    autoDemoState.completed = Number(code) === 0 && !wasStopping;
    autoDemoState.ended_at = Date.now();
    autoDemoState.exit_code = Number.isInteger(code) ? code : null;
    if (wasStopping) {
      autoDemoState.error = "";
      autoDemoState.last_line = "Demo đã được dừng và lộ trình mô phỏng đã đóng.";
    } else if (Number(code) === 0) {
      autoDemoState.error = "";
      autoDemoState.last_line = "Demo hai chiều hoàn tất. Điểm cảnh báo chỉ được tạo từ kết quả TinyML trên ESP32-S3 khi gửi mẫu.";
    } else if (!autoDemoState.error) {
      autoDemoState.error = wasStopping ? "demo_stopped" : `demo_exit_${code}`;
      autoDemoState.last_line = wasStopping ? "Demo đã được dừng." : `Demo kết thúc với mã lỗi ${code}.`;
    }
    autoDemoProcess = null;
    broadcastUpdate(AUTO_DEMO_DEVICE_ID, "demo", publicAutoDemoState());
  });
  broadcastUpdate(AUTO_DEMO_DEVICE_ID, "demo", publicAutoDemoState());
  return publicAutoDemoState();
}

function stopAutoDemo() {
  if (!autoDemoState.running) return publicAutoDemoState();
  autoDemoState.stopping = true;
  autoDemoState.last_line = "Đang dừng demo...";
  cancelPendingDemoAudioCommands("demo_stopped");
  expireDemoInferenceCommands('demo_stopped');
  if (!autoDemoProcess) {
    closeAutoDemoRoute(); autoDemoState.running = false; autoDemoState.stopping = false;
    autoDemoState.ended_at = Date.now();
    return publicAutoDemoState();
  }
  try { autoDemoProcess.kill(); }
  catch (error) { autoDemoState.error = String(error.message || error).slice(0, 300); }
  broadcastUpdate(AUTO_DEMO_DEVICE_ID, "demo", publicAutoDemoState());
  return publicAutoDemoState();
}

const directDemo = createDirectDemo({ db, HttpError, queueCommand: queueDeviceCommand,
  insertTelemetry, startRoute, endRoute, broadcast: broadcastUpdate,
  autoActive: () => Boolean(autoDemoState.running || autoDemoProcess) });

const server = createServer(async (request, response) => {
  const url = new URL(request.url || "/", `http://${request.headers.host || "localhost"}`);
  try {
    if (request.method === 'GET' && url.pathname === '/api/internet-capabilities') {
      sendJson(response, 200, { ok: true, service: 'telematics-dashboard', patch_version: '11.6.1', live_poll: true, deployment: 'fixed-online-portal' }); return;
    }
    if (request.method === 'GET' && url.pathname === '/api/access-status') {
      sendJson(response, 200, { ok: true, mode: 'local', transport: 'sse', authenticated: true }); return;
    }
    if (request.method === 'GET' && url.pathname === '/api/live') {
      sendJson(response, 200, liveSnapshot(url.searchParams.get('device_id'), url.searchParams.get('cursor'), url.searchParams.get('motion_only') === '1')); return;
    }
    if (request.method === 'POST' && url.pathname === '/api/direct-demo/realtime') {
      if (!authorized(request)) { sendJson(response, 401, { ok: false, error: 'unauthorized' }); return; }
      const payload = await readJson(request, Math.min(config.maxBodyBytes, 4096));
      const isResend = request.headers['x-telematics-resend'] === '1';
      sendJson(response, 200, { ok: true, ...directDemo.realtime(payload, isResend) }); return;
    }
    if (url.pathname.startsWith('/api/direct-demo/')) {
      const origin = String(request.headers.origin || '');
      if ((origin && origin !== `http://${request.headers.host}` && origin !== `https://${request.headers.host}`) || request.headers['sec-fetch-site'] === 'cross-site') throw new HttpError(403, 'Dashboard phải cùng máy chủ', 'cross_origin_control_denied');
      if (request.method === 'GET' && url.pathname === '/api/direct-demo/state') { sendJson(response, 200, { ok: true, ...directDemo.state() }); return; }
      if (request.method === 'GET' && url.pathname === '/api/direct-demo/roads') { sendJson(response, 200, { ok: true, ...await directDemo.roads(text(url.searchParams.get('device_id'))) }); return; }
      if (request.method === 'POST' && url.pathname === '/api/direct-demo/start') { sendJson(response, 202, { ok: true, ...directDemo.start(await readJson(request)) }); return; }
      if (request.method === 'POST' && url.pathname === '/api/direct-demo/control') { sendJson(response, 202, { ok: true, ...directDemo.control(await readJson(request)) }); return; }
    }
    if (request.method === "OPTIONS" && url.pathname.startsWith("/api/")) { response.writeHead(204, apiHeaders()); response.end(); return; }
    if (request.method === "GET" && url.pathname === "/api/stream") {
      openSse(request, response, url.searchParams.get("device_id")); return;
    }
    if (request.method === "GET" && url.pathname === "/api/demo/status") {
      sendJson(response, 200, { ok: true, demo: publicAutoDemoState() }); return;
    }
    if (request.method === 'GET' && url.pathname === '/api/demo/tinyml') {
      const samples = rawDemoSamples();
      sendJson(response, 200, { ok: true, demo: publicAutoDemoState(), gateway: demoGatewayStatus(),
        model: samples.model, samples: samples.samples }); return;
    }
    if (request.method === 'POST' && url.pathname === '/api/demo/tinyml') {
      const origin = String(request.headers.origin || '');
      if (origin && origin !== `http://${request.headers.host}` && origin !== `https://${request.headers.host}`) {
        throw new HttpError(403, 'Chỉ gửi mẫu từ dashboard cùng máy chủ', 'cross_origin_control_denied');
      }
      const queued = queueDemoInference(await readJson(request));
      sendJson(response, 201, { ok: true, ...queued }); return;
    }
    if (request.method === 'POST' && url.pathname === '/api/demo/display-position') {
      const origin = String(request.headers.origin || '');
      if (origin && origin !== `http://${request.headers.host}` && origin !== `https://${request.headers.host}`) throw new HttpError(403, 'Dashboard phải cùng máy chủ', 'cross_origin_control_denied');
      sendJson(response, 200, { ok: true, ...acceptDemoDisplayPosition(await readJson(request)) }); return;
    }
    if (request.method === "POST" && url.pathname === "/api/demo/speaker-alert") {
      if (!authorized(request)) { sendJson(response, 401, { ok: false, error: "unauthorized" }); return; }
      const result = queueDemoSpeakerAlert(await readJson(request));
      sendJson(response, result.queued ? 201 : 202, { ok: true, ...result }); return;
    }
    if (request.method === "POST" && url.pathname === "/api/demo/start") {
      sendJson(response, 202, { ok: true, demo: startAutoDemo() }); return;
    }
    if (request.method === "POST" && url.pathname === "/api/demo/stop") {
      sendJson(response, 200, { ok: true, demo: stopAutoDemo() }); return;
    }
    if (request.method === "GET" && url.pathname === "/api/health") {
      const telemetryCount = db.prepare("SELECT COUNT(*) AS count FROM telemetry").get().count;
      const eventCount = db.prepare("SELECT COUNT(*) AS count FROM events").get().count;
      const routeCount = db.prepare("SELECT COUNT(*) AS count FROM routes").get().count;
      sendJson(response, 200, { ok: true, service: "telematics-online", uptime_ms: Date.now() - startedAt, telemetry_count: telemetryCount, event_count: eventCount, route_count: routeCount }); return;
    }
    if (request.method === "GET" && url.pathname === "/api/devices") {
      const devices = db.prepare(`SELECT device_id,MAX(last_seen) AS last_seen,SUM(telemetry_count) AS telemetry_count,SUM(event_count) AS event_count FROM (
        SELECT device_id,MAX(ingested_at) AS last_seen,COUNT(*) AS telemetry_count,0 AS event_count FROM telemetry WHERE is_resend=0 GROUP BY device_id
        UNION ALL
        SELECT device_id,MAX(ingested_at) AS last_seen,0 AS telemetry_count,COUNT(*) AS event_count FROM events GROUP BY device_id
      ) GROUP BY device_id ORDER BY last_seen DESC`).all();
      sendJson(response, 200, { ok: true, devices }); return;
    }
    if (request.method === "GET" && url.pathname === "/api/self-test") { let deviceId=text(url.searchParams.get("device_id")||"");if(!deviceId){const r=db.prepare("SELECT device_id FROM telemetry WHERE is_resend=0 ORDER BY ingested_at DESC LIMIT 1").get();deviceId=r?String(r.device_id):"";}sendJson(response,200,{ok:true,...selfTestData(deviceId)});return; }
    if (request.method === "GET" && url.pathname === "/api/events/search") { let deviceId=text(url.searchParams.get("device_id")||"");if(!deviceId){const r=db.prepare("SELECT device_id FROM events ORDER BY ingested_at DESC LIMIT 1").get();deviceId=r?String(r.device_id):"";}sendJson(response,200,{ok:true,device_id:deviceId||null,...searchEvents(deviceId,url.searchParams)});return; }
    if (request.method === "GET" && url.pathname === "/api/device-config") { sendJson(response,200,{ok:true,config:publicDeviceSettings(text(url.searchParams.get("device_id")||""))});return; }
    if (request.method === "POST" && url.pathname === "/api/device-config/read") { const payload=await readJson(request),deviceId=settingsTarget(text(payload.device_id));if(!deviceId)throw new HttpError(422,"Chưa có Gateway thật để đọc cấu hình","invalid_payload");const row=queueDeviceCommand(deviceId,"config_get",{});announceDeviceSettings(deviceId);sendJson(response,201,{ok:true,command:commandPublicRow(row)});return; }
    if (request.method === "POST" && url.pathname === "/api/device-config") { const payload=await readJson(request),deviceId=settingsTarget(text(payload.device_id));if(!deviceId)throw new HttpError(422,"Chưa có Gateway thật để lưu cấu hình","invalid_payload");const settings=normalizeDeviceSettings(payload),row=queueDeviceCommand(deviceId,"config_set",settings);announceDeviceSettings(deviceId);sendJson(response,201,{ok:true,command:commandPublicRow(row),requested:settings});return; }
    if (request.method === "GET" && url.pathname === "/api/sd/local-files") {
      const deviceId = text(url.searchParams.get("device_id") || "");
      sendJson(response, 200, { ok: true, device_id: deviceId || null, ...listLocalSdLogs(deviceId) }); return;
    }
    if (request.method === "POST" && url.pathname === "/api/sd/export-chunk") {
      if (!authorized(request)) { sendJson(response, 401, { ok: false, error: "unauthorized" }); return; }
      const payload = await readJson(request); const saved = saveSdExportChunk(payload);
      if (saved.complete) console.log(`[SDEX] SAVED | device=${text(payload.device_id)} | ${saved.relative_path} | ${saved.written} bytes`);
      sendJson(response, saved.complete ? 201 : 200, { ok: true, ...saved }); return;
    }
    if (request.method === "POST" && url.pathname === "/api/sd/commands") {
      const payload = await readJson(request);
      const { deviceId, action, params } = validateSdCommand(payload);
      const now = Date.now();
      // Repeated read/list clicks while a device is offline should not create an
      // arbitrarily long queue. Destructive sd_delete commands are NEVER superseded.
      if (action === "sd_list" || action === "sd_read") {
        db.prepare("UPDATE device_commands SET status='failed',completed_at=?,result_json=? WHERE device_id=? AND action=? AND status='pending'")
          .run(now, JSON.stringify({ error: "superseded_by_newer_command" }), deviceId, action);
      }
      const result = db.prepare("INSERT INTO device_commands(device_id,action,params_json,status,created_at) VALUES(?,?,?,'pending',?)").run(deviceId, action, JSON.stringify(params), now);
      const row = db.prepare("SELECT * FROM device_commands WHERE id=?").get(Number(result.lastInsertRowid));
      console.log(`[SDUI] QUEUE | device=${deviceId} | id=${row.id} | ${action}`);
      sendJson(response, 201, { ok: true, command: commandPublicRow(row) }); return;
    }
    const genericCommandMatch=url.pathname.match(/^\/api\/device-commands\/(\d+)$/);if(request.method==="GET"&&genericCommandMatch){const row=db.prepare("SELECT * FROM device_commands WHERE id=?").get(Number(genericCommandMatch[1]));if(!row){sendJson(response,404,{ok:false,error:"command_not_found"});return;}sendJson(response,200,{ok:true,command:commandPublicRow(row)});return;}
    const sdCommandMatch = url.pathname.match(/^\/api\/sd\/commands\/(\d+)$/);
    if (request.method === "GET" && sdCommandMatch) {
      const row = db.prepare("SELECT * FROM device_commands WHERE id=?").get(Number(sdCommandMatch[1]));
      if (!row) { sendJson(response, 404, { ok: false, error: "command_not_found" }); return; }
      sendJson(response, 200, { ok: true, command: commandPublicRow(row) }); return;
    }
    if (request.method === "GET" && url.pathname === "/api/device-commands/next") {
      if (!authorized(request)) { sendJson(response, 401, { ok: false, error: "unauthorized" }); return; }
      const deviceId = text(url.searchParams.get("device_id") || "");
      if (!deviceId) throw new HttpError(422, "Thiếu device_id", "invalid_payload");
      directDemo.expire();
      const demoActive = (autoDemoState.running && !autoDemoState.stopping && deviceId === settingsTarget(AUTO_DEMO_DEVICE_ID)) || directDemo.activeFor(deviceId);
      const pollHint = { demo_active: Boolean(demoActive), next_poll_ms: demoActive ? 500 : 3000 };
      expireDemoAudioCommands(deviceId);
      expireDemoInferenceCommands();
      let row = null;
      for (const pending of db.prepare("SELECT * FROM device_commands WHERE device_id=? AND status='pending' ORDER BY id ASC LIMIT 100").all(deviceId)) {
        const delivery = demoAudioDeliveryState(pending);
        if (delivery === 'wait') continue;
        if (delivery !== 'ready') {
          db.prepare("UPDATE device_commands SET status='failed',completed_at=?,result_json=? WHERE id=? AND status='pending'").run(Date.now(), JSON.stringify({ error: delivery, speaker_played: false }), pending.id);
          continue;
        }
        row = pending; break;
      }
      if (!row) { sendJson(response, 200, { ok: true, ...pollHint, command: null }); return; }
      const params = parseCommandParams(row);
      directDemo.delivered(row);
      sendJson(response, 200, { ok: true, ...pollHint, command: { id: Number(row.id), action: String(row.action), ...params,
        ...(row.action === 'demo_infer' || directDemo.isCommand(row) ? { expires_in_ms: Math.max(0, Number(params.expires_at_ms) - Date.now()), server_now_ms: Date.now() } : {}) } }); return;
    }
    if (request.method === "POST" && url.pathname === "/api/device-commands/result") {
      if (!authorized(request)) { sendJson(response, 401, { ok: false, error: "unauthorized" }); return; }
      const payload = await readJson(request);
      const deviceId = text(payload.device_id), commandId = num(payload.command_id), ok = Boolean(payload.ok), resultObj = obj(payload.result);
      if (!deviceId || !Number.isSafeInteger(commandId)) throw new HttpError(422, "Kết quả command không hợp lệ", "invalid_payload");
      const row = db.prepare("SELECT * FROM device_commands WHERE id=? AND device_id=?").get(commandId, deviceId);
      if (!row) { sendJson(response, 404, { ok: false, error: "command_not_found" }); return; }
      if (directDemo.isCommand(row)) {
        const accepted = directDemo.ack(row, ok, resultObj);
        db.prepare("UPDATE device_commands SET status=?,completed_at=?,result_json=? WHERE id=? AND status='pending'").run(accepted.status, Date.now(), JSON.stringify(accepted.result), commandId);
        broadcastUpdate(deviceId, 'command_ack', { command_id: commandId });
        sendJson(response, 200, { ok: true, ...accepted }); return;
      }
      if (row.action === 'demo_infer' && row.status !== 'pending') {
        const previous = commandPublicRow(row);
        sendJson(response, 200, { ok: true, status: previous.status, result: previous.result, duplicate_ack: true }); return;
      }
      if (row.action === 'audio_play' && row.status !== 'pending') {
        const previous = commandPublicRow(row);
        // A lost HTTP response may retry an already accepted ACK. Firmware
        // remembers the last played command id, so a valid retry can recover
        // the first playback without resurrecting a cancelled command.
        const playAudio = ok && row.status === 'done' && demoAudioDeliveryState(row) === 'ready';
        sendJson(response, 200, { ok: true, status: previous.status, result: previous.result,
          duplicate_ack: true, play_audio: playAudio }); return;
      }
      let status = ok ? "done" : "failed";
      let serverHazardsDeleted = 0;
      let roadQualityDeletion = null;
      const params = parseCommandParams(row);
      if (ok && row.action === "sd_delete") {
        roadQualityDeletion = recordServerLogDeletion(deviceId, params);
        if (params.delete_hazards) serverHazardsDeleted = deleteServerHazardsForCommand(deviceId, params);
      }
      if (ok && row.action === "hazard_delete") serverHazardsDeleted = deleteServerHazardPoint(deviceId, params);
      let result = { ...resultObj, server_hazards_deleted: serverHazardsDeleted,
        road_quality_cleared: Boolean(roadQualityDeletion), road_quality_range: roadQualityDeletion };
      if (row.action === 'demo_infer') {
        result = acceptDemoInference(row, ok, resultObj);
        status = result.inference_ok === true ? 'done' : 'failed';
      }
      let playAudio = false;
      if (row.action === 'audio_play') {
        const delivery = demoAudioDeliveryState(row);
        playAudio = ok && delivery === 'ready';
        status = playAudio ? 'done' : 'failed';
        if (!playAudio) result = { ...result, error: ok ? delivery : 'device_rejected_audio', speaker_played: false };
      }
      if(ok&&(row.action==="config_get"||row.action==="config_set")){const cfg=obj(resultObj.config);if(Object.keys(cfg).length)saveDeviceSettings(deviceId,cfg,row.action==="config_set"?"NVS":"device");}
      db.prepare("UPDATE device_commands SET status=?,completed_at=?,result_json=? WHERE id=?").run(status, Date.now(), JSON.stringify(result), commandId);
      if (row.action === 'config_get' || row.action === 'config_set') announceDeviceSettings(deviceId);
      console.log(`[SDUI] ACK   | device=${deviceId} | id=${commandId} | ${row.action} | ${status} | map_deleted=${serverHazardsDeleted}`);
      broadcastUpdate(deviceId, "command_ack", { command_id: commandId });
      if (row.action === 'demo_infer') broadcastUpdate(AUTO_DEMO_DEVICE_ID, 'demo_inference', { command_id: commandId, status, result });
      sendJson(response, 200, { ok: true, status, result, ...(row.action === 'audio_play' ? { play_audio: playAudio } : {}) }); return;
    }
    if (request.method === "GET" && url.pathname === "/api/analytics") {
      let deviceId=text(url.searchParams.get("device_id")||"");if(!deviceId){const r=db.prepare("SELECT device_id FROM telemetry WHERE is_resend=0 ORDER BY ingested_at DESC LIMIT 1").get();deviceId=r?String(r.device_id):"";}
      sendJson(response,200,{ok:true,device_id:deviceId||null,...analyticsSummary(deviceId,Number(url.searchParams.get('days'))||14)});return;
    }
    if (request.method === "GET" && url.pathname === "/api/road-quality") {
      const deviceId=text(url.searchParams.get("device_id")||"");const routeId=num(url.searchParams.get("route_id"));
      sendJson(response,200,{ok:true,device_id:deviceId||null,points:roadQualityData(deviceId,Number.isSafeInteger(routeId)?routeId:null)});return;
    }
    if (request.method === "GET" && url.pathname === "/api/hazards") {
      const deviceId=text(url.searchParams.get("device_id")||"");sendJson(response,200,{ok:true,device_id:deviceId||null,hazards:hazardCatalog(deviceId)});return;
    }
    if (request.method === "POST" && url.pathname === "/api/hazards/delete") {
      const payload=await readJson(request),deviceId=text(payload.device_id),kind=text(payload.kind),lat=num(payload.lat),lon=num(payload.lon),radius=Math.min(30,Math.max(3,num(payload.radius_m)||8));
      if(!deviceId||!['pothole','speed_bump'].includes(kind)||!validCoords(lat,lon))throw new HttpError(422,'Điểm cảnh báo không hợp lệ','invalid_hazard');
      if(isDirectDevice(deviceId))throw new HttpError(409,'Điểm demo thuộc phiên riêng, không phải danh mục SD thật. Kết thúc phiên và bắt đầu phiên mới để làm lại.','direct_hazard_session_scoped');
      const now=Date.now(),params={kind,lat,lon,radius_m:radius};const result=db.prepare("INSERT INTO device_commands(device_id,action,params_json,status,created_at) VALUES(?, 'hazard_delete', ?, 'pending', ?)").run(deviceId,JSON.stringify(params),now);const row=db.prepare("SELECT * FROM device_commands WHERE id=?").get(Number(result.lastInsertRowid));
      sendJson(response,201,{ok:true,command:commandPublicRow(row)});return;
    }
    if (request.method === "GET" && url.pathname === "/api/routes") {
      let deviceId = text(url.searchParams.get("device_id") || "");
      if (!deviceId) {
        const latest = db.prepare(`SELECT device_id,MAX(last_seen) AS last_seen FROM (
          SELECT device_id,MAX(ingested_at) AS last_seen FROM telemetry GROUP BY device_id
          UNION ALL SELECT device_id,MAX(ingested_at) AS last_seen FROM events GROUP BY device_id
          UNION ALL SELECT device_id,MAX(started_at) AS last_seen FROM routes GROUP BY device_id
        ) GROUP BY device_id ORDER BY last_seen DESC LIMIT 1`).get();
        deviceId = latest ? String(latest.device_id) : "";
      }
      const routes = deviceId ? listRoutes(deviceId) : [];
      sendJson(response, 200, { ok: true, device_id: deviceId || null, active_route: routes.find(item => item.status === 'active') || null, routes }); return;
    }
    const routeMatch = url.pathname.match(/^\/api\/routes\/(\d+)$/);
    if (request.method === "GET" && routeMatch) {
      const detail = routeDetail(Number(routeMatch[1]), text(url.searchParams.get("device_id") || ""));
      if (!detail) { sendJson(response, 404, { ok: false, error: "route_not_found" }); return; }
      sendJson(response, 200, { ok: true, ...detail }); return;
    }
    if (request.method === "POST" && url.pathname === "/api/routes/start") {
      const payload = await readJson(request);
      const deviceId = text(payload.device_id);
      if (!deviceId) throw new HttpError(422, "Thiếu device_id", "invalid_payload");
      if (deviceId === AUTO_DEMO_DEVICE_ID) directDemo.assertIdle();
      if (isDirectDevice(deviceId)) throw new HttpError(409, 'Điều khiển lộ trình bằng bảng Demo trực tiếp', 'direct_route_managed');
      const result = startRoute(deviceId);
      console.log(`[ROUTE] START | device=${deviceId} | route_id=${result.route.id}`);
      sendJson(response, 201, { ok: true, ...result }); return;
    }
    if (request.method === "POST" && url.pathname === "/api/routes/end") {
      const payload = await readJson(request);
      const deviceId = text(payload.device_id);
      const routeId = num(payload.route_id);
      if (!deviceId) throw new HttpError(422, "Thiếu device_id", "invalid_payload");
      if (isDirectDevice(deviceId)) throw new HttpError(409, 'Dừng demo qua bảng Demo trực tiếp để ESP32-S3 xác nhận', 'direct_route_managed');
      const route = endRoute(deviceId, Number.isSafeInteger(routeId) ? routeId : null);
      if (deviceId === AUTO_DEMO_DEVICE_ID && !autoDemoProcess) {
        autoDemoState.running = false; autoDemoState.completed = true; autoDemoState.ended_at = Date.now();
        expireDemoInferenceCommands('demo_session_ended'); cancelPendingDemoAudioCommands('demo_session_ended');
      }
      if (!route) { sendJson(response, 409, { ok: false, error: "no_active_route" }); return; }
      console.log(`[ROUTE] END   | device=${deviceId} | route=${route.route_no} | km=${route.distance_km.toFixed(3)} | points=${route.point_count}`);
      sendJson(response, 200, { ok: true, route }); return;
    }
    if (request.method === "DELETE" && routeMatch) {
      const result = deleteRoute(Number(routeMatch[1]), text(url.searchParams.get("device_id") || ""));
      if (!result.deleted && result.reason === 'active') { sendJson(response, 409, { ok: false, error: "active_route_must_be_ended_first" }); return; }
      if (!result.deleted) { sendJson(response, 404, { ok: false, error: "route_not_found" }); return; }
      console.log(`[ROUTE] DELETE | device=${result.route.device_id} | route=${result.route.route_no}`);
      sendJson(response, 200, { ok: true, deleted_route: result.route }); return;
    }
    if (request.method === "GET" && url.pathname === "/api/dashboard") {
      sendJson(response, 200, { ok: true, ...dashboardData(url.searchParams.get("device_id")) }); return;
    }
    if (request.method === "POST" && (url.pathname === "/api/telemetry" || url.pathname === "/api/events")) {
      if (!authorized(request)) { sendJson(response, 401, { ok: false, error: "unauthorized" }); return; }
      let payload = await readJson(request);
      const kind = url.pathname === "/api/telemetry" ? "telemetry" : "event";
      validatePayload(payload, kind);
      if (isDirectDevice(payload.device_id)) throw new HttpError(422, 'Dữ liệu demo trực tiếp phải do Gateway vật lý gửi snapshot', 'direct_virtual_ingest_forbidden');
      const isResend = String(request.headers["x-telematics-resend"] || "") === "1";
      if (kind === 'telemetry') ingestRuntimeSettings(payload, isResend);
      if (kind === 'telemetry' && !isResend && payload.device_id === AUTO_DEMO_DEVICE_ID) processDemoTelemetry(payload);
      if (kind === 'event' && payload.event?.demo_mode === 'direct') payload = directDemo.event(payload);
      if (kind === 'event' && payload.device_id === AUTO_DEMO_DEVICE_ID &&
          /^(pothole|speed_bump)_(detected|catalog_sync|proximity)$/.test(text(obj(payload.event).name))) {
        throw new HttpError(422, 'Điểm demo phải đến từ kết quả suy luận ESP32-S3', 'automatic_demo_hazard_forbidden');
      }
      const result = kind === "telemetry" ? { duplicate: insertTelemetry(payload, isResend), enriched: false, eventUid: null } : insertEvent(payload, isResend);
      if (kind === 'telemetry' && !result.duplicate) directDemo.telemetry(payload, isResend);
      const eventName = kind === "event" ? ` | event=${text(obj(payload.event).name) || "unknown"} | id=${result.eventUid || "legacy"}` : "";
      const action = result.suppressed ? "SUPPRESSED" : result.enriched ? "ENRICHED" : result.duplicate ? "DUPLICATE" : "SAVED";
      console.log(`[RX ] ${action} | ${isResend ? "RESEND" : "LIVE"} ${kind} | device=${text(payload.device_id)} | seq=${num(payload.seq)}${eventName}`);
      if (!result.suppressed) broadcastUpdate(text(payload.device_id), kind, {
        sequence: num(payload.seq),
        ...(kind === "event" ? { event: result.event, inserted: !result.duplicate, duplicate: result.duplicate, enriched: Boolean(result.enriched) } : {}),
      });
      sendJson(response, 201, { ok: true, duplicate: result.duplicate, enriched: result.enriched, suppressed: Boolean(result.suppressed), event_id: result.eventUid, received_at: new Date().toISOString() }); return;
    }
    if (url.pathname.startsWith("/api/")) { sendJson(response, 404, { ok: false, error: "not_found" }); return; }
    if (request.method === "GET" && await serveStatic(url.pathname, response)) return;
    response.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" }); response.end("Không tìm thấy");
  } catch (error) {
    if (error instanceof HttpError) sendJson(response, error.status, { ok: false, error: error.message, code: error.code });
    else { console.error("Lỗi xử lý request:", error); sendJson(response, 500, { ok: false, error: "database_or_server_error" }); }
  }
});

server.on("error", error => {
  console.error(`Không thể mở cổng ${config.port}:`, error.message);
  process.exitCode = 1;
});

server.listen(config.port, config.host, () => {
  console.log("\n============================================================");
  console.log("  HỆ THỐNG GIÁM SÁT HÀNH TRÌNH - ONLINE GATEWAY");
  console.log("============================================================");
  console.log(`  Dịch vụ nội bộ nhận ESP: cổng ${config.port}. Chạy START_ONLINE.bat để mở địa chỉ Internet cố định.`);
  const addresses = [];
  for (const interfaces of Object.values(networkInterfaces())) for (const item of interfaces || []) if (item.family === "IPv4" && !item.internal) addresses.push(item.address);
  for (const address of [...new Set(addresses)]) console.log(`  ESP32 LAN : http://${address}:${config.port}`);
  console.log(`  Database  : ${dbPath}`);
  console.log("  Dừng server bằng Ctrl+C\n");
});

let shuttingDown = false;
function shutdown() {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log("\nĐang đóng database...");
  if (autoDemoProcess && autoDemoState.running) {
    closeAutoDemoRoute();
    try { autoDemoProcess.kill(); } catch {}
  }
  clearInterval(sseHeartbeatTimer);
  for (const client of sseClients) {
    try { client.response.end(); } catch {}
  }
  sseClients.clear();
  server.close(() => {
    try { db.exec("PRAGMA wal_checkpoint(TRUNCATE); PRAGMA optimize;"); db.close(); } catch {}
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 3000).unref();
}
// The Internet launcher may stop only the child processes it owns. Close WAL
// and active connections before its bounded termination fallback is used.
process.on('message', message => { if (message?.type === 'telematics:shutdown') shutdown(); });
const isDirectRun = process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectRun) {
  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);
}

// Exports make automated local smoke tests possible without changing normal startup.
export { server, db, config, dashboardData, listRoutes, routeDetail, startRoute, endRoute, deleteRoute, analyticsSummary, hazardCatalog, roadQualityData, broadcastUpdate };
