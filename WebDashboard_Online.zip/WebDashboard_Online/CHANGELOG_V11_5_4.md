# V11.5.4 – Dashboard Internet, TinyML hiện tại, tuyến demo có sẵn

- Thêm bridge đăng nhập chỉ lắng nghe loopback để đưa Dashboard qua HTTPS Quick Tunnel. Giữ Node/SQLite trên máy tính hiện tại, không chuyển cơ sở dữ liệu lên dịch vụ khác.
- Thêm bộ cài cloudflared có kiểm tra SHA-256, bộ khởi chạy và dừng đúng các tiến trình do phiên sở hữu. Không tự mở Internet khi chỉ áp dụng bản vá.
- Tách đường truy cập trình duyệt khỏi đường truyền thiết bị. Mật khẩu được băm; phiên đăng nhập có hạn, đăng xuất và kiểm tra nguồn yêu cầu. Endpoint telemetry/ACK/chunk dành cho thiết bị không mở công khai.
- LAN vẫn dùng SSE; Internet dùng snapshot HTTP nhẹ khoảng 1 lần/giây, chuyển động demo trực tiếp tối đa 5 lần/giây nếu mạng đáp ứng. Một yêu cầu đang chạy tại một thời điểm; có timeout, gửi thưa khi lỗi, tự kết nối lại và loại phản hồi nguồn cũ.
- Không tăng tần suất tải toàn bộ lịch sử/bản đồ để đạt 5 Hz. Poll đọc không ghi thêm telemetry, sự kiện hoặc điểm lộ trình vào SQLite.
- Đưa TinyML lên đầu cột cạnh bản đồ. Chỉ hiển thị suy luận cảm biến thật còn hợp lệ; kiểm tra độ mới riêng, không để gói chuyển động làm tươi kết quả AI. Độ trễ truyền được tính bảo thủ vào tuổi dữ liệu; không giả mạo thời điểm lấy mẫu.
- Demo trực tiếp chuyển từ tìm đường quanh GPS sang catalog cố định 400/800/1200/1600/2000 m. Không cần GNSS để tải/chọn tuyến hoặc khởi động demo. Vẫn kiểm tra Gateway/firmware/CAN và chờ xác nhận lệnh. Tuyến mô phỏng được ghi nhãn rõ, không tạo sẵn điểm nguy hiểm.
- Giữ các cơ chế quản lý lộ trình, phát lại, báo cáo, cấu hình, sự kiện, MicroSD, suy luận thật và cảnh báo theo firmware hiện có. Không sửa Arduino, TinyML library, chân CAN hay dữ liệu riêng của người dùng.

Giới hạn: Internet có độ trễ, không phải kênh an toàn thời gian thực được chứng nhận; cảnh báo cục bộ vẫn do ESP thực hiện. Đây không phải plugin Google Maps hoặc bổ sung mới dẫn đường từng chặng. Xem VALIDATION để phân biệt kiểm thử trên PC với kiểm thử thiết bị thực.
