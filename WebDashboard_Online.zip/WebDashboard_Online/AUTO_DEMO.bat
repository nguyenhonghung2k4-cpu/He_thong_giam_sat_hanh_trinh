@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

where node >nul 2>&1
if errorlevel 1 (
  echo.
  echo Chưa tìm thấy Node.js. Hãy cài Node.js 22.16 trở lên rồi chạy lại.
  echo https://nodejs.org/
  echo.
  pause
  exit /b 1
)

node -e "const [major,minor]=process.versions.node.split('.').map(Number); process.exit(major > 22 || (major === 22 && minor >= 16) ? 0 : 1)"
if errorlevel 1 (
  echo Cần Node.js 22.16 trở lên. Phiên bản hiện tại:
  node --version
  pause
  exit /b 1
)

node "tools\auto-demo.mjs" %*
set "DEMO_EXIT=%ERRORLEVEL%"

echo.
if not "%DEMO_EXIT%"=="0" echo Demo chưa hoàn thành. Xem thông báo lỗi phía trên.
pause
exit /b %DEMO_EXIT%
