# Hướng dẫn cũ đã được thay thế

Bản V11.6.0 không dùng mật khẩu/địa chỉ đường hầm thay đổi của V11.5.4 nữa. Không chạy hướng dẫn đăng nhập, tạo hay reset mật khẩu cũ.

Mở `../START_ONLINE.bat` và làm theo [README V11.6.0](../README.md). Link cố định:
<https://giam-sat-hanh-trinh-hh-2026.pleasantgoldfish16.chatgpt.site>

PC vẫn phải bật và có Internet. Theo yêu cầu, mọi người biết link đều được dùng các chức năng quản trị; không chia sẻ khóa connector hoặc cấu hình riêng của thiết bị.
