@echo off
call "%~dp0START_ONLINE.bat"
