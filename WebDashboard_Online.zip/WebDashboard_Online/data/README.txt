Database telematics.db sẽ được tạo tự động trong thư mục này khi server chạy lần đầu.
Không sửa trực tiếp file database khi dashboard đang chạy.
