@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Lenh nay chi tai cloudflared chinh thuc vao tools\bin va kiem tra SHA-256.
echo Khong cai dich vu Windows, khong tu mo duong ham Internet.
node "tools\install-cloudflared.mjs"
pause
