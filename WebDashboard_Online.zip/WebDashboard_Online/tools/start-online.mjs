import { spawn } from 'node:child_process';
import { createServer } from 'node:http';
import { createConnection } from 'node:net';
import { randomBytes,timingSafeEqual } from 'node:crypto';
import { existsSync,readFileSync,mkdirSync,writeFileSync,renameSync,unlinkSync,statSync } from 'node:fs';
import { dirname,join,resolve,delimiter,isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';
import { signRelay,sha256Hex } from '../../CloudPortal/worker/protocol.js';
import { validPublicOrigin,validateSecret } from '../online-bridge.mjs';

export const ROOT=resolve(dirname(fileURLToPath(import.meta.url)),'..');
export const VERSION='11.6.1';
const RUNTIME_DIR=join(ROOT,'.runtime'),STATE_FILE=join(RUNTIME_DIR,'online-run.json');
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
export function validPort(value,label='Cổng'){const n=Number(value);if(!Number.isInteger(n)||n<1||n>65535)throw new Error(`${label} phải từ 1 đến 65535.`);return n;}
export function readOnlineSettings(root=ROOT,env=process.env){
  let local={},online,privateConfig;
  try{local=JSON.parse(readFileSync(join(root,'config.local.json'),'utf8'));}catch(error){if(error.code!=='ENOENT')throw new Error('config.local.json không hợp lệ.');}
  try{online=JSON.parse(readFileSync(join(root,'online.config.json'),'utf8'));privateConfig=JSON.parse(readFileSync(join(root,'online.private.json'),'utf8'));}
  catch{throw new Error('Thiếu online.config.json hoặc online.private.json hợp lệ. Không chia sẻ tệp khóa riêng.');}
  const targetPort=validPort(env.PORT??local.port??3000,'Cổng máy chủ');
  const bridgePort=validPort(env.ONLINE_BRIDGE_PORT??env.INTERNET_ACCESS_PORT??(targetPort===3001?3002:3001),'Cổng bridge');
  if(targetPort===bridgePort)throw new Error('Cổng máy chủ và bridge phải khác nhau.');
  return {targetPort,bridgePort,publicUrl:validPublicOrigin(online.publicUrl),connectorSecret:validateSecret(privateConfig.connectorSecret)};
}
export function findCloudflared(root=ROOT,env=process.env){
  if(env.CLOUDFLARED_PATH){if(!isAbsolute(env.CLOUDFLARED_PATH)||!existsSync(env.CLOUDFLARED_PATH)||!statSync(env.CLOUDFLARED_PATH).isFile())throw new Error('CLOUDFLARED_PATH phải trỏ tới tệp thực thi có thật bằng đường dẫn đầy đủ.');return env.CLOUDFLARED_PATH;}
  const binary=process.platform==='win32'?'cloudflared.exe':'cloudflared';
  return [join(root,'tools','bin',binary),...String(env.PATH||'').split(delimiter).filter(Boolean).map(dir=>join(dir,binary))].find(path=>existsSync(path)&&statSync(path).isFile())||null;
}
export function extractTunnelUrl(line){return String(line).match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com(?=$|[\s|"'<>])/i)?.[0]||null;}
export function tunnelConnectionReady(line){return /\bRegistered tunnel connection\b/i.test(String(line));}
export function maskTunnelUrls(line){return String(line).replace(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/gi,'[đường hầm nội bộ]');}
export function runWasReplaced(error){return error?.status===409&&['stale_run','retired_run'].includes(error.code);}
export function retryDelayMs(attempt){return Math.min(5000,1000*2**Math.min(3,Math.max(0,attempt-1)));}
export function compatibleMain(marker){return marker?.ok===true&&marker.service==='telematics-dashboard'&&marker.patch_version===VERSION&&marker.live_poll===true;}
export function compatibleBridge(marker,runId){return marker?.ok===true&&marker.service==='telematics-pc-bridge'&&marker.version===VERSION&&marker.run_id===runId;}
export function compatiblePortal(marker,runId){return marker?.ok===true&&marker.service==='telematics-online-bridge'&&marker.version===VERSION&&marker.run_id===runId&&marker.requires_login===false&&marker.access_mode==='public';}
export async function getMarker(port,path,timeout=1000,headers={}){try{const response=await fetch(`http://127.0.0.1:${port}${path}`,{headers,redirect:'error',signal:AbortSignal.timeout(timeout)});return response.ok?await response.json():null;}catch{return null;}}
export async function portInUse(port){return new Promise(resolve=>{const socket=createConnection({host:'127.0.0.1',port});let done=false;const finish=value=>{if(done)return;done=true;socket.destroy();resolve(value);};socket.setTimeout(600,()=>finish(false));socket.once('connect',()=>finish(true));socket.once('error',()=>finish(false));});}
export async function signedHealthHeaders(settings,runId,now=Date.now()){
  const timestamp=String(now),path='/__relay/health',bodyHash=await sha256Hex(new Uint8Array());
  return {'x-hht-relay-time':timestamp,'x-hht-relay-run':runId,'x-hht-relay-origin':settings.publicUrl,
    'x-hht-relay-signature':await signRelay(settings.connectorSecret,{purpose:'health',method:'GET',path,origin:settings.publicUrl,runId,timestamp,bodyHash})};
}
export async function portalRequest(settings,path,body,{fetcher=fetch,timeout=10000}={}){
  let response;
  try{response=await fetcher(settings.publicUrl+path,{method:'POST',redirect:'error',headers:{Authorization:`Bearer ${settings.connectorSecret}`,'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(timeout)});}
  catch{const e=new Error('Không liên lạc được với cổng web cố định.');e.code='portal_unreachable';throw e;}
  let data;try{data=await response.json();}catch{const e=new Error(`Cổng web không trả JSON hợp lệ (HTTP ${response.status}).`);e.code='invalid_portal_response';throw e;}
  if(!response.ok||data?.ok!==true){const e=new Error(`Cổng web từ chối kết nối (HTTP ${response.status}, ${String(data?.code||'request_failed').replace(/[^a-z0-9_-]/gi,'').slice(0,80)}).`);e.status=response.status;e.code=data?.code||'portal_request_failed';throw e;}
  return data;
}
export async function registerAndVerify(settings,runId,upstream,{fetcher=fetch,wait=sleep,now=Date.now,deadlineMs=120000,isStopping=()=>false,onRetry=()=>{},onRegistered=()=>{}}={}){
  const deadline=now()+deadlineMs;let last,registeredUntil=0,attempt=0;
  while(!isStopping()&&now()<deadline){
    try{
      // Once registration succeeded, only retry the public round trip. A
      // transient GET failure must not repeatedly rewrite R2 and force probes.
      if(registeredUntil<=now()){
        const registered=await portalRequest(settings,'/__relay/register',{upstream,run_id:runId},{fetcher,timeout:10000});
        registeredUntil=Number.isSafeInteger(registered.lease_expires_at)?registered.lease_expires_at:now()+180000;
        onRegistered();
      }
      if(isStopping())throw new Error('Phiên đang dừng.');
      const response=await fetcher(settings.publicUrl+'/api/access-status',{cache:'no-store',redirect:'error',signal:AbortSignal.timeout(10000)});
      let marker;try{marker=await response.json();}catch{}
      if(response.ok&&compatiblePortal(marker,runId))return marker;
      const error=new Error('Chưa xác nhận được đường đi qua địa chỉ cố định.');
      error.status=response.status;error.code=marker?.code||'waiting_for_fixed_portal';
      if(marker?.run_id&&marker.run_id!==runId){error.status=409;error.code='stale_run';}
      throw error;
    }catch(error){
      last=error;
      if(error.status===401||error.status===403||runWasReplaced(error))throw error;
      const retryInMs=Math.min(retryDelayMs(++attempt),Math.max(0,deadline-now()));
      onRetry(error,{retryInMs,registered:registeredUntil>now()});
      if(isStopping()||retryInMs===0)break;
      await wait(retryInMs);
    }
  }
  throw last||new Error('Phiên đang dừng hoặc cổng web chưa sẵn sàng.');
}
export async function maintainPortal(settings,runId,upstream,options={}){
  let last;
  // An R2 compare-and-swap conflict is not a replaced run. Retry the same
  // authenticated heartbeat, rather than shutting down a working tunnel.
  for(let attempt=0;attempt<3;attempt++){
  try{await portalRequest(settings,'/__relay/heartbeat',{run_id:runId},options);return {reconnected:false};}
  catch(error){
    last=error;
    if(error.status===409&&error.code==='registry_changed'){
      if(attempt<2)await (options.wait||sleep)(250*2**attempt);
      continue;
    }
    // The same owned run may reconnect after a long Internet interruption.
    // A retired/replaced run must NOT take the portal back from a new launcher.
    if(error.status!==409||error.code!=='lease_expired')throw error;
    await registerAndVerify(settings,runId,upstream,{...options,deadlineMs:options.deadlineMs??30000});
    return {reconnected:true};
  }
  }
  throw last;
}
function equal(a,b){const x=Buffer.from(String(a)),y=Buffer.from(String(b));return x.length===y.length&&timingSafeEqual(x,y);}
function lines(stream,prefix,consume){let buffered='';stream?.on('data',chunk=>{buffered+=String(chunk);if(buffered.length>32768)buffered=buffered.slice(-32768);const rows=buffered.split(/\r?\n/);buffered=rows.pop();for(const row of rows)if(row){consume?.(row);console.log(`${prefix} ${maskTunnelUrls(row)}`);}});}
async function staleStateCheck(){
  if(!existsSync(STATE_FILE))return;
  let state;try{state=JSON.parse(readFileSync(STATE_FILE,'utf8'));}catch{}
  if(state?.service==='telematics-online-launcher'&&Number.isInteger(state.control_port)){
    const marker=await getMarker(state.control_port,'/health');
    if(marker?.service===state.service&&marker.run_id===state.run_id)throw new Error('Một phiên Online đang chạy. Dùng STOP_ONLINE.bat hoặc Ctrl+C ở cửa sổ đó trước.');
  }
  renameSync(STATE_FILE,join(RUNTIME_DIR,`online-run.stale-${Date.now()}.json`));
}

export async function startOnline(){
  const settings=readOnlineSettings(),cloudflared=findCloudflared();
  if(!cloudflared)throw new Error('Chưa có cloudflared. Chạy INSTALL_CLOUDFLARED.bat một lần rồi thử lại.');
  await staleStateCheck();
  if(await portInUse(settings.bridgePort))throw new Error(`Cổng bridge ${settings.bridgePort} đã có chương trình khác. Dừng phiên cũ hoặc đổi ONLINE_BRIDGE_PORT; không tự mở chương trình lạ ra Internet.`);
  const owned=new Set(),runId=randomBytes(18).toString('hex'),controlToken=randomBytes(32).toString('hex');
  let stopping=false,stopPromise,control,heartbeat,heartbeatBusy=false,registered=false,tunnelUrl=null,tunnelConnected=false;
  let finish;const completed=new Promise(resolve=>{finish=resolve;});
  const stop=reason=>{
    if(stopPromise)return stopPromise;stopping=true;clearInterval(heartbeat);
    stopPromise=(async()=>{
      console.log(`\n[ONLINE] Đang dừng phiên (${reason}). Không tắt các chương trình ngoài phiên này.`);
      if(registered){try{await portalRequest(settings,'/__relay/disconnect',{run_id:runId},{timeout:3500});}catch{console.log('[ONLINE] Chưa gửi được thông báo ngắt; cổng web sẽ tự đánh dấu ngoại tuyến khi hết hạn kết nối.');}}
      const children=[...owned];
      for(const child of children){try{if(child.connected)child.send({type:'telematics:shutdown'},()=>{});else child.kill('SIGTERM');}catch{}}
      const deadline=Date.now()+3500;
      while(children.some(child=>child.exitCode===null&&child.signalCode===null)&&Date.now()<deadline)await sleep(100);
      for(const child of children)if(child.exitCode===null&&child.signalCode===null){try{child.kill('SIGTERM');}catch{}}
      if(control)await new Promise(resolve=>{control.close(resolve);control.closeAllConnections?.();});
      try{const state=JSON.parse(readFileSync(STATE_FILE,'utf8'));if(state.run_id===runId)unlinkSync(STATE_FILE);}catch{}
      console.log('[ONLINE] Đã dừng kết nối. Link cố định vẫn giữ nguyên; web sẽ báo máy tính ngoại tuyến.');finish();
    })();return stopPromise;
  };
  const sigint=()=>{stop('Ctrl+C');},sigterm=()=>{stop('yêu cầu dừng');};
  process.once('SIGINT',sigint);process.once('SIGTERM',sigterm);
  function childProcess(command,args,prefix,{ipc=false,onLine}={}){
    const child=spawn(command,args,{cwd:ROOT,env:{...process.env,PORT:String(settings.targetPort),ONLINE_TARGET_PORT:String(settings.targetPort),ONLINE_BRIDGE_PORT:String(settings.bridgePort),ONLINE_RUN_ID:runId},windowsHide:true,stdio:ipc?['ignore','pipe','pipe','ipc']:['ignore','pipe','pipe']});
    owned.add(child);lines(child.stdout,prefix,onLine);lines(child.stderr,prefix,onLine);
    child.once('error',error=>{if(!stopping){console.error(`${prefix} Không khởi động được (${error.code||'process_error'}).`);process.exitCode=1;stop('thành phần khởi động lỗi');}});
    child.once('exit',(code,signal)=>{if(!stopping){console.error(`${prefix} đã dừng (${code??signal??'không rõ'}).`);if(code!==0)process.exitCode=1;stop('thành phần kết nối đã dừng');}});
    return child;
  }
  async function waitFor(port,path,predicate,child,signed=false){
    for(let i=0;i<60;i++){
      if(stopping)throw new Error('Phiên đang dừng.');
      if(child&&(child.exitCode!==null||child.signalCode!==null))throw new Error('Tiến trình dừng trước khi sẵn sàng.');
      const headers=signed?await signedHealthHeaders(settings,runId):{};
      const marker=await getMarker(port,path,700,headers);if(predicate(marker))return marker;await sleep(250);
    }
    throw new Error(`Không xác nhận được dịch vụ mới tại cổng ${port}; chưa mở Internet.`);
  }
  try{
    const mainMarker=await getMarker(settings.targetPort,'/api/internet-capabilities');
    if(compatibleMain(mainMarker))console.log(`[SERVER] Dùng lại máy chủ Online V${VERSION} đã chạy; khi dừng sẽ không tắt máy chủ này.`);
    else{
      if(await portInUse(settings.targetPort))throw new Error(`Cổng ${settings.targetPort} đang có máy chủ cũ hoặc dịch vụ khác. Đóng cửa sổ bản cũ trước; không tự tắt nó.`);
      const main=childProcess(process.execPath,[join(ROOT,'server.mjs')],'[SERVER]',{ipc:true});
      await waitFor(settings.targetPort,'/api/internet-capabilities',compatibleMain,main);
    }
    const bridge=childProcess(process.execPath,[join(ROOT,'online-bridge.mjs')],'[BRIDGE]',{ipc:true});
    await waitFor(settings.bridgePort,'/__relay/health',marker=>compatibleBridge(marker,runId),bridge,true);
    control=createServer((request,response)=>{
      response.setHeader('Content-Type','application/json; charset=utf-8');response.setHeader('Cache-Control','no-store');
      if(request.method==='GET'&&request.url==='/health'){response.end(JSON.stringify({service:'telematics-online-launcher',run_id:runId}));return;}
      if(request.method==='POST'&&request.url==='/stop'&&equal(request.headers.authorization||'',`Bearer ${controlToken}`)){
        response.end(JSON.stringify({ok:true}));setTimeout(()=>stop('người dùng yêu cầu dừng'),50);return;
      }
      response.writeHead(403);response.end(JSON.stringify({ok:false}));
    });
    await new Promise((resolve,reject)=>{control.once('error',reject);control.listen(0,'127.0.0.1',resolve);});
    mkdirSync(RUNTIME_DIR,{recursive:true});
    writeFileSync(STATE_FILE,JSON.stringify({service:'telematics-online-launcher',run_id:runId,launcher_pid:process.pid,control_port:control.address().port,control_token:controlToken,started_at:new Date().toISOString()},null,2),{flag:'wx',mode:0o600});
    console.log('[ONLINE] Đang tạo kết nối nội bộ và xác nhận qua link cố định. Chưa được coi là sẵn sàng.');
    childProcess(cloudflared,['tunnel','--no-autoupdate','--protocol','http2','--url',`http://127.0.0.1:${settings.bridgePort}`],'[KẾT NỐI]',{onLine:line=>{tunnelUrl??=extractTunnelUrl(line);tunnelConnected||=tunnelConnectionReady(line);}});
    const urlDeadline=Date.now()+60000;
    while((!tunnelUrl||!tunnelConnected)&&!stopping&&Date.now()<urlDeadline)await sleep(100);
    if(!tunnelUrl||!tunnelConnected)throw new Error('Đường hầm chưa kết nối thành công. Có địa chỉ chưa đồng nghĩa đã truy cập được; kiểm tra Internet, tường lửa hoặc log kết nối.');
    let retries=0;
    await registerAndVerify(settings,runId,tunnelUrl,{isStopping:()=>stopping,onRegistered:()=>{registered=true;},onRetry:(error,state)=>{if(++retries===1||retries%5===0)console.log(`[ONLINE] Chưa xác nhận truy cập từ xa (${error.code||'waiting_for_fixed_portal'}); tự thử lại sau ${Math.ceil(state.retryInMs/1000)} giây, không cần mở lại chương trình.`);}});
    registered=true;
    console.log('\n============================================================');
    console.log('ĐÃ XÁC NHẬN TRUY CẬP QUA WEB CỐ ĐỊNH:');console.log(settings.publicUrl);
    console.log('Điện thoại dùng Wi-Fi khác hoặc 4G/5G mở đúng link này.');
    console.log('Không cần mật khẩu. Ai có link cũng có quyền xem, cấu hình và xóa dữ liệu.');
    console.log('Giữ máy tính bật, có Internet và cửa sổ này mở. Dừng: Ctrl+C / STOP_ONLINE.bat.');
    console.log('============================================================\n');
    heartbeat=setInterval(async()=>{
      if(stopping||heartbeatBusy)return;heartbeatBusy=true;
      try{const result=await maintainPortal(settings,runId,tunnelUrl,{isStopping:()=>stopping});if(result.reconnected)console.log('[ONLINE] Đã khôi phục kết nối qua link cố định sau gián đoạn mạng.');}
      catch(error){console.log(`[ONLINE] Chưa xác nhận được kết nối định kỳ (${error.code||'network_error'}).`);if(runWasReplaced(error)){process.exitCode=1;stop('cổng web đã thuộc phiên mới');}}
      finally{heartbeatBusy=false;}
    },30000);
    await completed;
  }catch(error){const wasStopping=stopping;await stop('không thể kết nối web');if(!wasStopping)throw error;}
  finally{process.removeListener('SIGINT',sigint);process.removeListener('SIGTERM',sigterm);}
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url))startOnline().catch(error=>{console.error(`[ONLINE] ${error.message}`);process.exitCode=1;});
