import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, openSync, closeSync, writeSync, renameSync, unlinkSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const binDir = join(root, 'tools', 'bin');
const target = join(binDir, 'cloudflared.exe');
const userAgent = 'Telematics-Dashboard-Internet-Setup/11.5.4';

try {
  if (process.platform !== 'win32' || !['x64', 'ia32'].includes(process.arch)) throw new Error('Bộ tải tự động này dành cho Windows x64/x86. Hãy tải cloudflared phù hợp tại https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/downloads/ rồi đặt CLOUDFLARED_PATH.');
  if (existsSync(target)) {
    console.log('tools/bin/cloudflared.exe đã tồn tại; không ghi đè. Có thể chạy START_INTERNET_DASHBOARD.bat.');
  } else {
    console.log('Đang lấy bản phát hành chính thức từ github.com/cloudflare/cloudflared...');
    const releaseResponse = await fetch('https://api.github.com/repos/cloudflare/cloudflared/releases/latest', { headers: { 'User-Agent': userAgent, Accept: 'application/vnd.github+json' }, signal: AbortSignal.timeout(20000) });
    if (!releaseResponse.ok) throw new Error(`Không đọc được bản phát hành chính thức: HTTP ${releaseResponse.status}.`);
    const release = await releaseResponse.json();
    const name = process.arch === 'ia32' ? 'cloudflared-windows-386.exe' : 'cloudflared-windows-amd64.exe';
    const asset = release.assets?.find(item => item.name === name);
    if (!asset || !/^sha256:[a-f0-9]{64}$/i.test(asset.digest || '') || !/^https:\/\/github\.com\/cloudflare\/cloudflared\/releases\/download\//.test(asset.browser_download_url || '') || !Number.isInteger(asset.size) || asset.size < 1000000 || asset.size > 100 * 1024 * 1024) throw new Error('Thiếu tệp hoặc SHA-256 do GitHub công bố. Dừng tải; không chạy tệp chưa xác minh.');
    mkdirSync(binDir, { recursive: true });
    const temp = join(binDir, `cloudflared-download-${process.pid}.part`);
    let fd;
    try {
      const response = await fetch(asset.browser_download_url, { headers: { 'User-Agent': userAgent }, signal: AbortSignal.timeout(180000) });
      if (!response.ok || !response.body) throw new Error(`Tải thất bại: HTTP ${response.status}.`);
      const hash = createHash('sha256'); let bytes = 0;
      fd = openSync(temp, 'wx');
      for await (const chunk of response.body) {
        bytes += chunk.length;
        if (bytes > asset.size) throw new Error('Kích thước tệp tải về vượt metadata chính thức.');
        hash.update(chunk);
        let offset = 0;
        while (offset < chunk.length) offset += writeSync(fd, chunk, offset, chunk.length - offset);
      }
      closeSync(fd); fd = undefined;
      const actual = hash.digest('hex');
      if (bytes !== asset.size || actual !== asset.digest.slice(7).toLowerCase()) throw new Error('Kích thước hoặc SHA-256 không khớp. Tệp sẽ không được sử dụng.');
      if (existsSync(target)) throw new Error('Tệp đích vừa được tạo bởi phiên khác; không ghi đè.');
      renameSync(temp, target);
      writeFileSync(join(binDir, 'cloudflared-version.json'), JSON.stringify({ release: release.tag_name, asset: name, sha256: actual, source: asset.browser_download_url, checked_at: new Date().toISOString() }, null, 2));
      console.log(`Đã tải cloudflared ${release.tag_name}, kiểm tra SHA-256 thành công.`);
      console.log('Không cài dịch vụ Windows và không yêu cầu quyền quản trị. Chạy START_INTERNET_DASHBOARD.bat để mở Dashboard.');
    } finally {
      if (fd !== undefined) closeSync(fd);
      try { if (existsSync(temp)) unlinkSync(temp); } catch {}
    }
  }
} catch (error) { console.error(`[CÀI ĐẶT] ${error.message}`); process.exitCode = 1; }
