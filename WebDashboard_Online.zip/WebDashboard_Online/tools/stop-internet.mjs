// Compatibility entry point: stop only the currently owned online run.
import './stop-online.mjs';
