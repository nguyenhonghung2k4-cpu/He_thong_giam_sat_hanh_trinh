import { existsSync, mkdirSync, readFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { backup, DatabaseSync } from "node:sqlite";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const configPath = join(ROOT, "config.local.json");

try {
  const config = JSON.parse(readFileSync(configPath, "utf8"));
  const sourcePath = resolve(ROOT, String(config.databaseFile || "data/telematics.db"));
  if (!existsSync(sourcePath)) throw new Error("Chưa có database để sao lưu. Hãy chạy dashboard và nhận dữ liệu trước.");

  const backupDirectory = join(ROOT, "backups");
  mkdirSync(backupDirectory, { recursive: true });
  const stamp = new Date().toISOString().replace(/[-:]/g, "").replace("T", "_").slice(0, 15);
  const destination = join(backupDirectory, `telematics_${stamp}.db`);
  const database = new DatabaseSync(sourcePath);
  try { await backup(database, destination); }
  finally { database.close(); }
  console.log(`Đã tạo: ${destination}`);
} catch (error) {
  console.error(`Sao lưu thất bại: ${error.message}`);
  process.exitCode = 1;
}
