﻿$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $PSScriptRoot
$config = Get-Content -Raw -Encoding UTF8 (Join-Path $projectRoot "config.local.json") | ConvertFrom-Json
$baseUrl = "http://localhost:$($config.port)"
$headers = @{ Authorization = "Bearer $($config.ingestApiKey)" }
$bootId = "local-test-$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())"
$now = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
$telemetry = @{
  type = "telemetry"; device_id = "blackbox-local-test"; boot_id = $bootId; seq = 1; ts = $now; uptime_ms = 15000
  location = @{ valid = $true; lat = 10.77818; lon = 106.70402; speed_kph = 32.4; satellites = 12; hdop = 0.9; altitude_m = 8.4; course_deg = 64 }
  ecu = @{ online = $true; uptime_s = 7240; status = 0; speed_kph = 33.1; rpm = $null; adc_raw = 2048; temperature_c = 84.2; dtc_code = 0; dtc_severity = 0; dtc_active = $false }
  road = @{ valid = $true; label = "duong_bang_phang"; confidence = 0.9821; x_g = 0.01; y_g = -0.02; z_g = 1.01; inference_ms = 18; scores = @{ duong_bang_phang = 0.9821; go_giam_toc = 0.0102; o_ga = 0.0077 } }
  system = @{ sd_ok = $true; wifi_rssi = -54; free_heap = 238400; free_psram = 8165000; queue_bytes = 0; navigation_ready = $true; ai_ready = $true; ecu_runtime_ready = $true; adxl_healthy = $true; adxl_fifo_overruns = 0; adxl_fifo_services = 3200; sd_io_failures = 0; sd_remounts = 0; sd_failure_streak = 0; event_queue_bytes = 0; network_last_http = 201; network_sent_count = 120; firmware_version = "10.2.0-I2C-SPEAKER"; model_version = "telematics-ei-1.0.1" }
  trip = @{ distance_km = 4.82 }
}
$potholeEvent = @{
  type = "event"; device_id = "blackbox-local-test"; boot_id = $bootId; seq = 2; ts = $now; uptime_ms = 15100
  location = $telemetry.location; ecu = $telemetry.ecu
  road = @{ valid = $true; label = "o_ga"; confidence = 0.957; x_g = 0.32; y_g = -0.18; z_g = 1.74; inference_ms = 18; scores = @{ duong_bang_phang = 0.031; go_giam_toc = 0.012; o_ga = 0.957 } }
  system = $telemetry.system
  event = @{ name = "pothole_detected"; severity = "warning"; gps_attached = $true; new_map_point = $true; saved_to_sd = $true; map_capacity_full = $false }
}
$speedBumpLocation = @{ valid = $true; lat = 10.78015; lon = 106.70664; speed_kph = 31.8; satellites = 12; hdop = 0.9; altitude_m = 8.5; course_deg = 64 }
$speedBumpEvent = @{
  type = "event"; device_id = "blackbox-local-test"; boot_id = $bootId; seq = 3; ts = $now; uptime_ms = 15200
  location = $speedBumpLocation; ecu = $telemetry.ecu
  road = @{ valid = $true; label = "go_giam_toc"; confidence = 0.989; x_g = 0.19; y_g = -0.09; z_g = 1.42; inference_ms = 18; scores = @{ duong_bang_phang = 0.007; go_giam_toc = 0.989; o_ga = 0.004 } }
  system = $telemetry.system
  event = @{ name = "speed_bump_detected"; severity = "info"; hazard_type = "go_giam_toc"; gps_attached = $true; new_map_point = $true; saved_to_sd = $true; map_capacity_full = $false }
}
Write-Host "Đang gửi telemetry mẫu..."
Invoke-RestMethod -Method Post -Uri "$baseUrl/api/telemetry" -Headers $headers -ContentType "application/json" -Body ($telemetry | ConvertTo-Json -Depth 8 -Compress) | Out-Null
Write-Host "Đang gửi sự kiện ổ gà mẫu..."
Invoke-RestMethod -Method Post -Uri "$baseUrl/api/events" -Headers $headers -ContentType "application/json" -Body ($potholeEvent | ConvertTo-Json -Depth 8 -Compress) | Out-Null
Write-Host "Đang gửi sự kiện gờ giảm tốc mẫu..."
Invoke-RestMethod -Method Post -Uri "$baseUrl/api/events" -Headers $headers -ContentType "application/json" -Body ($speedBumpEvent | ConvertTo-Json -Depth 8 -Compress) | Out-Null
$dashboard = Invoke-RestMethod -Method Get -Uri "$baseUrl/api/dashboard?device_id=blackbox-local-test"
if (-not $dashboard.ok -or -not $dashboard.latest) { throw "Dashboard không đọc lại được dữ liệu mẫu" }
if ($dashboard.potholes.Count -lt 1 -or $dashboard.speed_bumps.Count -lt 1) { throw "API chưa trả đủ marker ổ gà và gờ giảm tốc" }
Write-Host "Thành công. Hãy mở $baseUrl và chọn blackbox-local-test nếu cần." -ForegroundColor Green
