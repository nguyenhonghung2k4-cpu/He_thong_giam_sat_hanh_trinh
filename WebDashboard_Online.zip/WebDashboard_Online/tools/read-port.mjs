import { readFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
try {
  const config = JSON.parse(readFileSync(join(root, "config.local.json"), "utf8"));
  const port = Math.min(65535, Math.max(1, Number(config.port) || 3000));
  process.stdout.write(String(port));
} catch {
  process.stdout.write("3000");
}
