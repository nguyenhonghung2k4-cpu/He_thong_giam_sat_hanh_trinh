import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtemp,rm} from 'node:fs/promises';
import {createServer} from 'node:net';
import {tmpdir} from 'node:os';
import {dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
const ROOT=resolve(dirname(fileURLToPath(import.meta.url)),'..'),DEMO='blackbox-esp32s3-auto-demo',REAL='blackbox-esp32s3-01',KEY='roundtrip-test-key';
const wait=ms=>new Promise(r=>setTimeout(r,ms));
async function freePort(){const s=createServer();await new Promise(r=>s.listen(0,'127.0.0.1',r));const p=s.address().port;await new Promise(r=>s.close(r));return p;}
function meters(a,b){const r=x=>x*Math.PI/180,h=Math.sin(r(b.lat-a.lat)/2)**2+Math.cos(r(a.lat))*Math.cos(r(b.lat))*Math.sin(r(b.lon-a.lon)/2)**2;return 6371000*2*Math.atan2(Math.sqrt(h),Math.sqrt(Math.max(0,1-h)));}
const temp=await mkdtemp(join(tmpdir(),'telematics-roundtrip-')),port=await freePort(),base=`http://127.0.0.1:${port}`;
const env={...process.env,HOST:'127.0.0.1',PORT:String(port),DATABASE_FILE:join(temp,'test.db'),INGEST_API_KEY:KEY,DEMO_SPEAKER_ENABLED:'true',DEMO_SPEAKER_DEVICE_ID:REAL};
const server=spawn(process.execPath,[join(ROOT,'server.mjs')],{cwd:ROOT,env,windowsHide:true,stdio:['ignore','pipe','pipe']});
let output='',demo=null,heartbeat=null,seq=0;server.stdout.on('data',c=>output+=c);server.stderr.on('data',c=>output+=c);
async function req(path,method='GET',body){const r=await fetch(base+path,{method,headers:{Authorization:`Bearer ${KEY}`,'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});const d=await r.json();assert.ok(r.ok&&d.ok,`${path}: ${JSON.stringify(d)}`);return d;}
async function realHeartbeat(){return req('/api/telemetry','POST',{device_id:REAL,boot_id:'real-test',seq:++seq,ts:new Date().toISOString(),location:{valid:true,lat:20.9036,lon:105.8266,speed_kph:0,satellites:10,hdop:1},ecu:{online:true,speed_kph:0},road:{valid:true,label:'duong_bang_phang',confidence:.99},system:{sd_ok:true,ai_ready:true}});}
try{
  for(let i=0;i<100;i++){try{await req('/api/health');break;}catch{if(i===99)throw Error(output);await wait(50);}}
  await realHeartbeat();heartbeat=setInterval(()=>realHeartbeat().catch(()=>{}),600);
  demo=spawn(process.execPath,[join(ROOT,'tools','auto-demo.mjs'),'--speed','6'],{cwd:ROOT,env,windowsHide:true,stdio:['ignore','pipe','pipe']});
  let demoOutput='';demo.stdout.on('data',c=>demoOutput+=c);demo.stderr.on('data',c=>demoOutput+=c);
  const code=await new Promise((r,j)=>{const t=setTimeout(()=>{demo.kill();j(Error('Demo exceeded 60 seconds'));},60000);demo.once('error',j);demo.once('exit',c=>{clearTimeout(t);r(c);});});assert.equal(code,0,demoOutput);assert.match(demoOutput,/\[VỀ\]/);
  const routes=await req(`/api/routes?device_id=${DEMO}`);assert.equal(routes.active_route,null);const completed=routes.routes.find(r=>r.status==='completed');assert.ok(completed);
  const detail=await req(`/api/routes/${completed.id}?device_id=${DEMO}`);assert.ok(detail.points.length>=100,`Expected dense points, got ${detail.points.length}`);assert.ok(Number(detail.route.distance_km)>.5);assert.ok(meters(detail.points[0],detail.points.at(-1))<.5);
  assert.ok(detail.points.some(p=>meters(p,{lat:20.9058639,lon:105.8276887})<.1),'Lost turning vertex');
  const intervals=detail.points.slice(1).map((p,i)=>Number(p.ingested_at)-Number(detail.points[i].ingested_at)).sort((a,b)=>a-b);
  const median=intervals[Math.floor(intervals.length*.5)],p90=intervals[Math.floor(intervals.length*.9)];
  console.log(`TIMING: nominal tick <=200 ms; localhost p50=${median} ms, p90=${p90} ms, max=${intervals.at(-1)} ms. Congestion pauses progress; no vertices skipped.`);
  assert.ok(median<=350,'Median localhost update latency too high');
  for(let i=1;i<detail.points.length;i++)assert.ok(meters(detail.points[i-1],detail.points[i])<9,'Vehicle jumped a road segment');
  for(const name of ['pothole_detected','speed_bump_detected','pothole_proximity','speed_bump_proximity'])assert.equal(detail.events.filter(e=>e.name===name).length,0,`Unclicked demo fabricated ${name}`);
  for(const name of ['overspeed','overspeed_cleared','dtc_active','ecu_offline','ecu_recovered'])assert.equal(detail.events.filter(e=>e.name===name).length,1,`Lost ${name}`);
  const dash=await req(`/api/dashboard?device_id=${DEMO}`);assert.equal(dash.potholes.length,0);assert.equal(dash.speed_bumps.length,0);assert.equal(Number(dash.latest.road_valid),0);assert.equal(dash.latest.road_label,'unknown');
  assert.ok(dash.telemetry.some(row=>Math.abs(Number(row.speed_kph)-Number(row.ecu_speed_kph))>1),'GNSS speed still copies simulated CAN scenario speed');
  assert.equal((await req(`/api/device-commands/next?device_id=${REAL}`)).command,null,'Unclicked demo queued fake voice');for(let i=0;i<3;i++)assert.equal((await req('/api/dashboard')).device_id,REAL,'Mixed live/demo');
  const self=await req(`/api/self-test?device_id=${DEMO}`);assert.equal(self.checks.find(c=>c.key==='sd')?.status,'wait');assert.notEqual(self.overall,'ready');
  console.log('PASS V11.4.0: dense road roundtrip, no automatic AI/hazards, CAN/DTC/ECU and live/demo isolation.');
}catch(e){throw Error(`${e.message}\nSERVER:\n${output}`);}finally{clearInterval(heartbeat);if(demo&&!demo.killed)demo.kill();if(!server.killed)server.kill();await wait(500);await rm(temp,{recursive:true,force:true});}
