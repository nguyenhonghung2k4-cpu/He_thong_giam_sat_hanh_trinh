import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { createServer } from "node:net";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const DEVICE_ID = "blackbox-v113-test";
const API_KEY = "v113-test-key";
const SD_DIAGNOSTICS = {
  sd_card_type: "sdhc_sdxc",
  sd_total_bytes: 15_900_000_000,
  sd_used_bytes: 786_432_000,
  sd_daily_log_bytes: 33_554_432,
  sd_daily_log_quota_bytes: 2_147_483_648,
  sd_write_block_reason: "none",
  sd_log_drop_count: 3,
};

const delay = milliseconds => new Promise(resolveDelay => setTimeout(resolveDelay, milliseconds));

async function freePort() {
  const socket = createServer();
  await new Promise((resolveListen, reject) => socket.once("error", reject).listen(0, "127.0.0.1", resolveListen));
  const port = socket.address().port;
  await new Promise(resolveClose => socket.close(resolveClose));
  return port;
}

async function waitForServer(baseUrl) {
  for (let attempt = 0; attempt < 80; attempt++) {
    try {
      const response = await fetch(`${baseUrl}/api/health`, { cache: "no-store" });
      if (response.ok) return;
    } catch {}
    await delay(50);
  }
  throw new Error("Local server did not become ready");
}

async function postJson(baseUrl, path, payload) {
  const response = await fetch(`${baseUrl}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${API_KEY}` },
    body: JSON.stringify(payload),
  });
  const body = await response.json();
  assert.equal(response.status, 201, `${path} returned ${response.status}: ${JSON.stringify(body)}`);
  assert.equal(body.ok, true);
  return body;
}

function telemetryPayload() {
  return {
    type: "telemetry", device_id: DEVICE_ID, boot_id: "boot-v113", seq: 1,
    ts: new Date().toISOString(), uptime_ms: 1000,
    location: { valid: true, lat: 20.905712, lon: 105.827550, speed_kph: 36, satellites: 12, hdop: 0.9 },
    ecu: { online: true, speed_kph: 36, rpm: 2200, temperature_c: 82, dtc_active: false },
    road: { valid: true, label: "duong_bang_phang", confidence: 0.99 },
    system: { sd_ok: true, sd_state: "online", wifi_rssi: -45, ...SD_DIAGNOSTICS },
  };
}

function hazardPayload({ seq, id, name, lat, lon, label }) {
  return {
    type: "event", device_id: DEVICE_ID, boot_id: "boot-v113", seq,
    ts: new Date().toISOString(), uptime_ms: seq * 1000,
    location: { valid: true, lat, lon, speed_kph: 34, satellites: 12, hdop: 0.9 },
    ecu: { online: true, speed_kph: 34, dtc_active: false },
    road: { valid: true, label, confidence: 0.986 },
    event: { id, name, severity: "warning", gps_attached: true, new_map_point: true, saved_to_sd: true, confidence: 0.986 },
  };
}

async function collectSse(response, received, signal) {
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  try {
    while (!signal.aborted) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true }).replaceAll("\r\n", "\n");
      let boundary;
      while ((boundary = buffer.indexOf("\n\n")) >= 0) {
        const packet = buffer.slice(0, boundary); buffer = buffer.slice(boundary + 2);
        const data = packet.split("\n").filter(line => line.startsWith("data:")).map(line => line.slice(5).trim()).join("\n");
        if (!data) continue;
        try { received.push(JSON.parse(data)); } catch {}
      }
    }
  } catch (error) {
    if (!signal.aborted) throw error;
  }
}

async function waitUntil(predicate, message) {
  for (let attempt = 0; attempt < 80; attempt++) {
    if (predicate()) return;
    await delay(50);
  }
  throw new Error(message);
}

async function verifyFrontendHasNoColorTrails() {
  const [dashboard, styles, html, realtime, firmware, network, storage, alerts, powerArbiter, config, storageHeader] = await Promise.all([
    readFile(join(ROOT, "public", "dashboard.js"), "utf8"),
    readFile(join(ROOT, "public", "dashboard.css"), "utf8"),
    readFile(join(ROOT, "public", "index.html"), "utf8"),
    readFile(join(ROOT, "public", "v11.js"), "utf8"),
    readFile(resolve(ROOT, "..", "Arduino", "ESP32S3_Telematics", "ESP32S3_Telematics.ino"), "utf8"),
    readFile(resolve(ROOT, "..", "Arduino", "ESP32S3_Telematics", "telemetry_network.cpp"), "utf8"),
    readFile(resolve(ROOT, "..", "Arduino", "ESP32S3_Telematics", "storage.cpp"), "utf8"),
    readFile(resolve(ROOT, "..", "Arduino", "ESP32S3_Telematics", "alerts.cpp"), "utf8"),
    readFile(resolve(ROOT, "..", "Arduino", "ESP32S3_Telematics", "power_arbiter.cpp"), "utf8"),
    readFile(resolve(ROOT, "..", "Arduino", "ESP32S3_Telematics", "config.h"), "utf8"),
    readFile(resolve(ROOT, "..", "Arduino", "ESP32S3_Telematics", "storage.h"), "utf8"),
  ]);
  for (const forbidden of ["renderRoadQuality", "quality-heat", "quality-toggle", "hazard-area"]) {
    assert.equal(`${dashboard}\n${styles}\n${html}`.includes(forbidden), false, `Forbidden map trail feature remains: ${forbidden}`);
  }
  assert.equal((dashboard.match(/\bL\.circle\s*\(/g)||[]).length, 1, "Only one range-ring implementation may create Leaflet circles");
  assert.match(dashboard, /L\.circle\(pos,\{pane:"hazard-range"[^\n]+radius:warningM[^\n]+fill:false/);
  assert.match(dashboard, /rangeCircle\.setRadius\(warningM\)/);
  assert.match(styles, /leaflet-hazard-range-pane/);
  assert.match(styles, /hazard-range-ring\{fill:none!important/);
  assert.match(dashboard, /hazard-pin/);
  assert.match(dashboard, /data-hazard-distance/);
  assert.match(dashboard, /haversine\(vehiclePos,pos\)\*1000/);
  assert.match(styles, /border-left:13px solid transparent/);
  assert.match(styles, /border-top:18px solid/);
  assert.match(dashboard, /acceptRealtimeEvent/);
  assert.match(realtime, /detail\.kind !== "telemetry"/);
  assert.match(dashboard, /sourceGeneration/);
  assert.match(dashboard, /requestedDevice!==String\(state\.selectedDevice/);
  assert.match(realtime, /detail\.kind === "demo"[^\n]+loadDemoStatus\(\); return/);
  assert.match(realtime, /detail\.device_id !== pinned/);
  assert.match(realtime, /enterDemoView/);
  assert.match(dashboard, /sdPresentation/);
  assert.match(dashboard, /sdTransientStates/);
  const sdPresentation=dashboard.slice(dashboard.indexOf("function sdPresentation"),dashboard.indexOf("function haversine"));
  const sdPriority=["demoSource","!fresh","physical_full","daily_log_quota","sdTransientStates","sd_ok"].map(token=>sdPresentation.indexOf(token));
  assert.ok(sdPriority.every(index=>index>=0)&&sdPriority.every((index,i)=>i===0||index>sdPriority[i-1]),"MicroSD presentation priority must be demo, stale, physical full, daily quota, transient, online, then persistent failure");
  assert.match(html, /health-sd-capacity/);
  assert.match(html, /health-sd-daily/);
  assert.match(html, /v=11\.3\.9/);
  assert.match(styles, /status-pill\.wait i/);
  assert.equal(firmware.includes("sd_state"),true);
  assert.match(firmware, /storageStateText\(\)/);
  const geofenceAudio = firmware.indexOf("if (kind == HazardKind::Pothole) alertPothole(); else alertSpeedBump();", firmware.indexOf("static void checkCatalogGeofence"));
  const geofenceDeliver = firmware.indexOf('deliver("event", json);', geofenceAudio);
  assert.ok(geofenceAudio >= 0 && geofenceDeliver > geofenceAudio, "Geofence event can reserve SD/HTTP before the one-shot speaker alert");
  const remoteAudioHandler = network.indexOf('}else if(action=="audio_play")');
  const remoteAudioAck = network.indexOf('commandHttpPost(apiBaseUrl()+"/api/device-commands/result"', remoteAudioHandler);
  const remoteAudioPlay = network.indexOf('if(audioAfterAck==1)alertPothole();else alertSpeedBump();', remoteAudioHandler);
  assert.ok(remoteAudioHandler >= 0 && remoteAudioAck > remoteAudioHandler && remoteAudioPlay > remoteAudioAck,
    "Remote demo audio must ACK the command before closing the HTTP gate and playing MAX98357A");
  assert.match(storage, /postAudioVerifyPending/);
  assert.match(storage, /post-audio read-only health check passed/);
  assert.match(storage, /SD_WORKER_FAILURE_GAP_MS/);
  assert.match(storage, /prepareSdBusLocked/);
  assert.match(storage, /SPI\.end\(\)/);
  assert.match(storage, /verifyWritableCardLocked/);
  assert.match(storage, /verifyWritableCardReliablyLocked/);
  assert.match(storage, /SD_WRITE_PROBE_ATTEMPTS/);
  assert.match(storage, /write_probe_remount_failed/);
  assert.match(storage, /recoveryBusy\|\|sdState==SdState::Verifying/);
  assert.match(storage, /if\(succeeded\)\{delete logRecord;logRecord=nullptr;\}/);
  assert.match(storage, /queueFileBytes==0&&queueNextBytes>0/);
  assert.match(storage, /queueRecoveryDegraded/);
  assert.match(storage, /queueTrackingReliable/);
  const eventPersist=storage.slice(storage.indexOf("static PersistResult persistEventRecordLocked"),storage.indexOf("static void printQueueStatus"));
  assert.ok((eventPersist.match(/!queueTrackingReliable/g)||[]).length>=2,
    "Critical event persistence must recheck queue accounting after a forced full-to-free capacity refresh");
  assert.match(powerArbiter, /powerAcquireSd/);
  assert.match(powerArbiter, /powerAcquireHttp/);
  assert.match(storage, /powerAcquireSd/);
  assert.match(network, /powerAcquireHttp/);
  assert.ok((network.match(/WiFi\.setTxPower\(WIFI_TX_POWER_LEVEL\)/g)||[]).length>=2,
    "Wi-Fi TX limit must be applied at boot and after every reconnect");
  assert.match(config, /#include <stdint\.h>/,
    "config.h must define fixed-width integer types even when included before Arduino.h");
  assert.match(config, /#include <stddef\.h>/,
    "config.h must define size_t even when included before Arduino.h");
  assert.match(config, /MAX_DAILY_LOG_SEGMENTS = 128/);
  assert.match(config, /SD_CRITICAL_FREE_BYTES = 512ULL \* 1024ULL/);
  assert.match(storageHeader, /uint32_t storageQueueEvent/);
  assert.match(storageHeader, /storageEventTicketDurable/);
  assert.match(storage, /noteEventDurable\(record\.ticket\)/);
  assert.match(network, /storageEventTicketDurable\(item->eventPersistenceTicket\)/);
  assert.match(storage, /offline_cursor_capacity_hold/);
  assert.match(storage, /event_cursor_capacity_hold/);
  const dailyAppend=storage.slice(storage.indexOf("static LogAppendResult appendTelemetryLocked"),storage.indexOf("enum class PersistResult"));
  const quotaBranch=dailyAppend.slice(dailyAppend.indexOf("selected==LogSelectResult::DayQuota"),dailyAppend.indexOf("selected==LogSelectResult::MediaFull"));
  assert.equal(quotaBranch.includes("markStorageFault"),false,"Daily log quota must never increment the SD I/O/remount streak");
  assert.equal(storage.includes("SD.format"),false,"Firmware must never auto-format the user's card");
  assert.equal(storage.includes('markStorageFault("post_audio_verify_failed")'), false,
    "An advisory post-audio probe must not unmount MicroSD directly");
  assert.match(alerts, /AUDIO_BOOT_INHIBIT_MS/);
  assert.match(alerts, /millis\(\) - alertsStartedMs < AUDIO_BOOT_INHIBIT_MS/);
  const storageExit = alerts.indexOf("storageExitAudioCritical(amplifierWasEnabled);");
  const recoveryGuard = alerts.indexOf("if (amplifierWasEnabled)", storageExit);
  const recoveryWait = alerts.indexOf("while (storageRecoveryBusy()", recoveryGuard);
  const networkExit = alerts.indexOf("networkExitAudioCritical();", recoveryWait);
  assert.ok(storageExit >= 0 && recoveryGuard > storageExit && recoveryWait > recoveryGuard && networkExit > recoveryWait,
    "MAX98357A must keep HTTP gated through bounded MicroSD recovery after amplifier activity");
  assert.match(alerts, /storageExitAudioCritical\(false\);\s*networkExitAudioCritical\(\);/,
    "An unplayed alert must release both gates without scheduling post-audio recovery");
}

async function main() {
  await verifyFrontendHasNoColorTrails();
  const tempRoot = await mkdtemp(join(tmpdir(), "telematics-v113-"));
  const databaseFile = join(tempRoot, "telematics-test.db");
  const port = await freePort();
  const baseUrl = `http://127.0.0.1:${port}`;
  const child = spawn(process.execPath, [join(ROOT, "server.mjs")], {
    cwd: ROOT,
    env: { ...process.env, HOST: "127.0.0.1", PORT: String(port), DATABASE_FILE: databaseFile, INGEST_API_KEY: API_KEY },
    stdio: ["ignore", "pipe", "pipe"],
  });
  let serverOutput = "";
  child.stdout.on("data", chunk => { serverOutput += chunk; });
  child.stderr.on("data", chunk => { serverOutput += chunk; });
  const sseAbort = new AbortController();
  try {
    await waitForServer(baseUrl);
    const sseResponse = await fetch(`${baseUrl}/api/stream?device_id=${encodeURIComponent(DEVICE_ID)}`, { signal: sseAbort.signal });
    assert.equal(sseResponse.ok, true);
    const sseMessages = [];
    const sseCollector = collectSse(sseResponse, sseMessages, sseAbort.signal);

    await postJson(baseUrl, "/api/telemetry", telemetryPayload());
    const diagnosticsDashboard=await (await fetch(`${baseUrl}/api/dashboard?device_id=${encodeURIComponent(DEVICE_ID)}`,{cache:"no-store"})).json();
    for(const [field,value] of Object.entries(SD_DIAGNOSTICS))assert.equal(diagnosticsDashboard.latest[field],value,`SD diagnostic field ${field} did not round-trip through SQLite/API`);
    const pothole = hazardPayload({ seq: 2, id: "hazard-pothole-v113", name: "pothole_detected", label: "o_ga", lat: 20.905712, lon: 105.827550 });
    const bump = hazardPayload({ seq: 3, id: "hazard-bump-v113", name: "speed_bump_detected", label: "go_giam_toc", lat: 20.905780, lon: 105.827610 });
    const firstPothole = await postJson(baseUrl, "/api/events", pothole);
    await postJson(baseUrl, "/api/events", bump);
    const proximity = hazardPayload({ seq: 4, id: "hazard-pothole-proximity-v113", name: "pothole_proximity", label: "o_ga", lat: 20.905712, lon: 105.827550 });
    proximity.event.distance_m = 7.4;
    await postJson(baseUrl, "/api/events", proximity);
    const duplicatePothole = await postJson(baseUrl, "/api/events", pothole);
    assert.equal(firstPothole.duplicate, false);
    assert.equal(duplicatePothole.duplicate, true);

    await waitUntil(() => sseMessages.filter(message => message.kind === "event" && message.event).length >= 3, "SSE did not deliver detected/proximity TinyML events");
    const eventUpdates = sseMessages.filter(message => message.kind === "event" && message.event);
    assert.ok(eventUpdates.some(message => message.event.event_uid === "hazard-pothole-v113" && message.event.name === "pothole_detected"));
    assert.ok(eventUpdates.some(message => message.event.event_uid === "hazard-bump-v113" && message.event.name === "speed_bump_detected"));
    assert.ok(eventUpdates.some(message => message.event.event_uid === "hazard-pothole-proximity-v113" && Number(message.event.distance_m) === 7.4));

    const retryTelemetry=telemetryPayload();
    retryTelemetry.seq=5;retryTelemetry.uptime_ms=5000;
    retryTelemetry.system={sd_ok:false,sd_state:"retry_wait",sd_last_error:"mount_failed",sd_recovery_busy:false,sd_frequency_hz:0,wifi_rssi:-45};
    await postJson(baseUrl,"/api/telemetry",retryTelemetry);

    const dashboard = await (await fetch(`${baseUrl}/api/dashboard?device_id=${encodeURIComponent(DEVICE_ID)}`, { cache: "no-store" })).json();
    const eventCenter = await (await fetch(`${baseUrl}/api/events/search?device_id=${encodeURIComponent(DEVICE_ID)}&category=all&limit=200`, { cache: "no-store" })).json();
    assert.equal(dashboard.ok, true);
    assert.equal(eventCenter.ok, true);
    assert.equal(eventCenter.events.filter(event => event.event_uid === "hazard-pothole-v113").length, 1, "Retry created a duplicate Event Center row");
    assert.equal(eventCenter.events.find(event => event.event_uid === "hazard-pothole-proximity-v113")?.distance_m, 7.4, "Proximity distance is missing from Event Center");
    assert.equal(dashboard.potholes.filter(event => event.event_uid === "hazard-pothole-v113").length, 1, "Retry created a duplicate pothole marker");
    assert.equal(dashboard.speed_bumps.filter(event => event.event_uid === "hazard-bump-v113").length, 1, "Speed-bump marker is missing or duplicated");
    assert.equal(dashboard.latest.sd_state,"retry_wait");
    assert.equal(dashboard.latest.sd_last_error,"mount_failed");
    const selfTestWaiting=await (await fetch(`${baseUrl}/api/self-test?device_id=${encodeURIComponent(DEVICE_ID)}`,{cache:"no-store"})).json();
    assert.equal(selfTestWaiting.checks.find(check=>check.key==="sd")?.status,"wait","First 30 seconds of automatic SD retry must be WAIT, not an immediate hard FAIL");

    const recoveryTelemetry=telemetryPayload();
    recoveryTelemetry.seq=6;recoveryTelemetry.uptime_ms=15000;
    recoveryTelemetry.system={sd_ok:true,sd_state:"post_audio_verify",sd_last_error:"post_audio_verify_retry",sd_recovery_busy:true,sd_frequency_hz:1000000,wifi_rssi:-45};
    await postJson(baseUrl,"/api/telemetry",recoveryTelemetry);
    const selfTestRecovering=await (await fetch(`${baseUrl}/api/self-test?device_id=${encodeURIComponent(DEVICE_ID)}`,{cache:"no-store"})).json();
    assert.equal(selfTestRecovering.checks.find(check=>check.key==="sd")?.status,"wait","Mounted SD under post-audio verification must be WAIT, not a misleading PASS");

    const failedTelemetry=telemetryPayload();
    failedTelemetry.seq=7;failedTelemetry.uptime_ms=31000;
    failedTelemetry.system={...retryTelemetry.system};
    await postJson(baseUrl,"/api/telemetry",failedTelemetry);
    const selfTestFailed=await (await fetch(`${baseUrl}/api/self-test?device_id=${encodeURIComponent(DEVICE_ID)}`,{cache:"no-store"})).json();
    assert.equal(selfTestFailed.checks.find(check=>check.key==="sd")?.status,"fail","A persistent mount failure after boot grace must remain visible");

    const fullTelemetry=telemetryPayload();
    fullTelemetry.seq=8;fullTelemetry.uptime_ms=45000;
    fullTelemetry.system={...fullTelemetry.system,sd_ok:true,sd_state:"full",sd_last_error:"storage_full",sd_used_bytes:fullTelemetry.system.sd_total_bytes-1_048_576,sd_write_block_reason:"physical_full",sd_log_drop_count:12};
    await postJson(baseUrl,"/api/telemetry",fullTelemetry);
    const selfTestFull=await (await fetch(`${baseUrl}/api/self-test?device_id=${encodeURIComponent(DEVICE_ID)}`,{cache:"no-store"})).json();
    assert.equal(selfTestFull.checks.find(check=>check.key==="sd")?.status,"fail","A physically full card must FAIL even while the card remains mounted");

    const quotaTelemetry=telemetryPayload();
    quotaTelemetry.seq=9;quotaTelemetry.uptime_ms=50000;
    quotaTelemetry.system={...quotaTelemetry.system,sd_ok:true,sd_state:"log_quota",sd_last_error:"daily_log_quota",sd_daily_log_bytes:quotaTelemetry.system.sd_daily_log_quota_bytes,sd_write_block_reason:"daily_log_quota",sd_log_drop_count:21};
    await postJson(baseUrl,"/api/telemetry",quotaTelemetry);
    const selfTestQuota=await (await fetch(`${baseUrl}/api/self-test?device_id=${encodeURIComponent(DEVICE_ID)}`,{cache:"no-store"})).json();
    assert.equal(selfTestQuota.checks.find(check=>check.key==="sd")?.status,"wait","Daily log quota must WAIT because the mounted card is still available for management and critical data");

    const legacyTelemetry=telemetryPayload();
    legacyTelemetry.seq=10;legacyTelemetry.uptime_ms=55000;
    legacyTelemetry.system={sd_ok:true,wifi_rssi:-45};
    await postJson(baseUrl,"/api/telemetry",legacyTelemetry);
    const legacyDashboard=await (await fetch(`${baseUrl}/api/dashboard?device_id=${encodeURIComponent(DEVICE_ID)}`,{cache:"no-store"})).json();
    for(const field of Object.keys(SD_DIAGNOSTICS))assert.equal(legacyDashboard.latest[field],null,`Legacy payload must leave optional field ${field} null`);

    sseAbort.abort();
    await sseCollector;
    console.log("PASS V11.3.8: SDHC capacity/quota diagnostics, legacy payload, source isolation, SSE/Event Center and map checks passed.");
  } catch (error) {
    throw new Error(`${error.message}\n${serverOutput}`);
  } finally {
    sseAbort.abort();
    if (!child.killed) child.kill("SIGTERM");
    await Promise.race([new Promise(resolveExit => child.once("exit", resolveExit)), delay(3500)]);
    await rm(tempRoot, { recursive: true, force: true });
  }
}

await main();
