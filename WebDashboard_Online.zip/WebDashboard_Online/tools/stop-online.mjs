import { readFileSync } from 'node:fs';
import { dirname,join,resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
try{
  const state=JSON.parse(readFileSync(join(root,'.runtime','online-run.json'),'utf8'));
  if(state.service!=='telematics-online-launcher'||!Number.isInteger(state.control_port)||state.control_port<1||state.control_port>65535||!/^[a-f0-9]{64}$/.test(state.control_token||'')||!/^[a-f0-9]{36}$/.test(state.run_id||''))throw new Error('Thông tin phiên Online không hợp lệ. Dùng Ctrl+C trong cửa sổ đang chạy.');
  const base=`http://127.0.0.1:${state.control_port}`;
  const markerResponse=await fetch(base+'/health',{signal:AbortSignal.timeout(1200),redirect:'error'}),marker=await markerResponse.json();
  if(marker.service!==state.service||marker.run_id!==state.run_id)throw new Error('Không tìm thấy đúng phiên Online; không dừng tiến trình nào.');
  const response=await fetch(base+'/stop',{method:'POST',headers:{Authorization:`Bearer ${state.control_token}`},signal:AbortSignal.timeout(1500),redirect:'error'});
  if(!response.ok)throw new Error('Yêu cầu dừng bị từ chối.');
  console.log('Đã yêu cầu đóng đúng phiên Online. Link cố định vẫn giữ nguyên; máy chủ có sẵn từ trước được giữ lại.');
}catch(error){console.error(error.code==='ENOENT'?'Không có phiên Online do bộ khởi chạy này quản lý. Nếu mở thủ công, hãy Ctrl+C ở cửa sổ tương ứng.':error.message);process.exitCode=1;}
