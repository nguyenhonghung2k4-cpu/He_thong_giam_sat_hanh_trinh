import { readFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const WEB_DIR = join(dirname(fileURLToPath(import.meta.url)), "..");
// One road segment takes three seconds: the complete 36-segment round trip
// takes about 108 seconds. Positions, not just the scenario, update at 5 Hz.
const DEFAULT_INTERVAL_MS = 3000;
const POSITION_TICK_MS = 200;
const DEMO_DEVICE_ID = "blackbox-esp32s3-auto-demo";
const DEMO_ROUTE_NAME = "Đường dân sinh Xuân Nê hai chiều (OpenStreetMap way 897388119)";
let stopRequested = false;
for (const signal of ["SIGINT", "SIGTERM"]) process.once(signal, () => { stopRequested = true; });

const scenario = [
  { title: "Khởi động", speed: 18 },
  { title: "Tăng tốc ổn định", speed: 28 },
  { title: "Chạy dọc tuyến", speed: 36 },
  { title: "Chạy dọc tuyến", speed: 43 },
  { title: "Chờ người dùng gửi mẫu gia tốc", speed: 24 },
  { title: "Chạy dọc tuyến", speed: 30 },
  { title: "Chạy dọc tuyến", speed: 42 },
  { title: "Chờ người dùng gửi mẫu gia tốc", speed: 26 },
  { title: "Chạy dọc tuyến", speed: 38 },
  { title: "Tăng tốc ECU mô phỏng", speed: 78 },
  { title: "Tiếp tục tăng tốc ECU mô phỏng", speed: 112 },
  { title: "Cảnh báo quá tốc", speed: 128, overspeed: true, event: "overspeed", severity: "critical" },
  { title: "Duy trì quá tốc", speed: 136, overspeed: true },
  { title: "Đã giảm về vùng an toàn", speed: 112, event: "overspeed_cleared", severity: "success" },
  { title: "DTC đang hoạt động", speed: 48, dtc: true, event: "dtc_active", severity: "critical" },
  { title: "DTC đã được xóa", speed: 44 },
  { title: "ECU mất kết nối", speed: 22, ecuOnline: false, event: "ecu_offline", severity: "critical" },
  { title: "ECU đã kết nối lại", speed: 25, event: "ecu_recovered", severity: "success" },
  { title: "Cuối tuyến — quay đầu", speed: 18 },
];

// Keep all original road vertices. Dense samples are interpolated separately
// inside each segment; a turn can never become a shortcut through a building.
const DEMO_ROUTE_POINTS = [
  { lat: 20.9036124, lon: 105.8266023 },
  { lat: 20.9037170, lon: 105.8267143 },
  { lat: 20.9038280, lon: 105.8268124 },
  { lat: 20.9039210, lon: 105.8266997 },
  { lat: 20.9040425, lon: 105.8266675 },
  { lat: 20.9041591, lon: 105.8267648 },
  { lat: 20.9042800, lon: 105.8268551 },
  { lat: 20.9044043, lon: 105.8269407 },
  { lat: 20.9045249, lon: 105.8270325 },
  { lat: 20.9046497, lon: 105.8271176 },
  { lat: 20.9047751, lon: 105.8272018 },
  { lat: 20.9049017, lon: 105.8272836 },
  { lat: 20.9050326, lon: 105.8273577 },
  { lat: 20.9051667, lon: 105.8274242 },
  { lat: 20.9053043, lon: 105.8274825 },
  { lat: 20.9054432, lon: 105.8275372 },
  { lat: 20.9055823, lon: 105.8275912 },
  { lat: 20.9057231, lon: 105.8276400 },
  { lat: 20.9058639, lon: 105.8276887 },
];

function printHelp() {
  console.log(`BỘ DEMO — HỆ THỐNG GIÁM SÁT HÀNH TRÌNH
AUTO_DEMO.bat                  Mặc định khoảng 1 phút 48 giây
AUTO_DEMO.bat --speed 2        Nhanh gấp hai lần
AUTO_DEMO.bat --interval 1000  Mỗi đoạn đường dài 1000 ms
--speed: 0.25 đến 12; --interval: 250 đến 10000 ms; không dùng cả hai.
Vị trí được cập nhật tối đa mỗi 200 ms. Tốc độ CAN là tình huống mô phỏng,
không phải tốc độ di chuyển hình học trên bản đồ. Không tạo nhãn AI giả.
Gửi mẫu trong bảng cạnh map; chỉ TinyML thật trên ESP32-S3 tạo điểm cảnh báo.`);
}
function parseArguments(argv) {
  let speed = null, interval = null, help = false;
  for (let i = 0; i < argv.length; i++) {
    const token = argv[i];
    if (token === "--help" || token === "-h") { help = true; continue; }
    const name = token.split("=")[0];
    if (!["--speed", "--interval"].includes(name)) throw new Error(`Tùy chọn không hợp lệ: ${token}`);
    const raw = token.includes("=") ? token.slice(token.indexOf("=") + 1) : argv[++i];
    const value = Number(raw), min = name === "--speed" ? 0.25 : 250, max = name === "--speed" ? 12 : 10000;
    if (!Number.isFinite(value) || value < min || value > max) throw new Error(`${name} phải nằm trong khoảng ${min} đến ${max}.`);
    if (name === "--speed") speed = value; else interval = value;
  }
  if (speed !== null && interval !== null) throw new Error("Chỉ dùng --speed hoặc --interval.");
  return { help, intervalMs: Math.round(interval ?? DEFAULT_INTERVAL_MS / (speed ?? 1)) };
}
async function loadConfig() {
  const config = JSON.parse(await readFile(join(WEB_DIR, "config.local.json"), "utf8"));
  const port = Number(process.env.PORT ?? config.port);
  const apiKey = String(process.env.INGEST_API_KEY ?? config.ingestApiKey ?? "").trim();
  if (!Number.isInteger(port) || port < 1 || port > 65535 || !apiKey) throw new Error("Cấu hình port/ingestApiKey không hợp lệ.");
  return { port, apiKey };
}
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const radians = x => x * Math.PI / 180;
function distanceKm(a, b) {
  const h = Math.sin(radians(b.lat - a.lat) / 2) ** 2 + Math.cos(radians(a.lat)) * Math.cos(radians(b.lat)) * Math.sin(radians(b.lon - a.lon) / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(Math.max(0, 1 - h)));
}
function heading(a, b) {
  const delta = radians(b.lon - a.lon), lat1 = radians(a.lat), lat2 = radians(b.lat);
  return (Math.atan2(Math.sin(delta) * Math.cos(lat2), Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(delta)) * 180 / Math.PI + 360) % 360;
}
function buildJourney() {
  const out = scenario.map((step, i) => ({ point: DEMO_ROUTE_POINTS[i], step, direction: "ĐI" }));
  for (let i = DEMO_ROUTE_POINTS.length - 2; i >= 0; i--) {
    out.push({ point: DEMO_ROUTE_POINTS[i], direction: "VỀ", step: { title: "Lượt về — cảnh báo các điểm đã được TinyML ghi nhận", speed: Math.min(52, Math.max(24, Math.round(scenario[i].speed * .75))) } });
  }
  return out;
}
function createClient(base, key) {
  return async (path, { method = "GET", body } = {}) => {
    const response = await fetch(`${base}${path}`, { method, headers: { Accept: "application/json", Authorization: `Bearer ${key}`, ...(body ? { "Content-Type": "application/json" } : {}) }, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(8000) });
    const result = await response.json().catch(() => null);
    if (!response.ok || !result?.ok) throw new Error(`${method} ${path}: ${result?.error || `HTTP ${response.status}`}`);
    return result;
  };
}
async function main() {
  const options = parseArguments(process.argv.slice(2));
  if (options.help) { printHelp(); return; }
  const config = await loadConfig(), base = `http://127.0.0.1:${config.port}`, request = createClient(base, config.apiKey);
  const journey = buildJourney();
  const bootId = process.env.DEMO_SESSION_ID || `auto-demo-${Date.now()}-${process.pid}`;
  const startedAt = Date.now();
  let sequence = 0, routeId = null, routeEnded = false, tripDistanceKm = 0, previousPoint = null, previousSentAt=0;
  const payload = (step, index, point, courseDeg,gnssSpeed) => {
    const online = step.ecuOnline !== false, speed = Number(step.speed), seq = ++sequence;
    return {
      type: "telemetry", device_id: DEMO_DEVICE_ID, boot_id: bootId, session_id: bootId, seq,
      ts: new Date().toISOString(), uptime_ms: Date.now() - startedAt,
      location: { valid: true, ...point, speed_kph: gnssSpeed, satellites: 12, hdop: .9, altitude_m: 16.8, course_deg: courseDeg },
      ecu: { online, uptime_s: 7200 + Math.floor((Date.now() - startedAt) / 1000), status: online ? 0 : 1, speed_kph: online ? speed : null, overspeed: online && Boolean(step.overspeed), rpm: online ? Math.round(Math.min(6500, 850 + speed * 31)) : null, adc_raw: online ? Math.round(speed / 180 * 4095) : null, temperature_c: online ? Number((82 + Math.sin(index / 3) * 1.7).toFixed(1)) : null, dtc_code: step.dtc ? 301 : 0, dtc_severity: step.dtc ? 2 : 0, dtc_active: online && Boolean(step.dtc) },
      // All classifications come from a real inference ACK, never this runner.
      road: { valid: false, label: "unknown", confidence: 0, x_g: 0, y_g: 0, z_g: 0, inference_ms: 0, scores: {} },
      system: { sd_ok: true, wifi_rssi: -48, free_heap: 226000, free_psram: 8172000, queue_bytes: 0, navigation_ready: true, ai_ready: false, ecu_runtime_ready: online, adxl_healthy: false, network_last_http: 201, network_sent_count: seq, firmware_version: "AUTO-DEMO-RAW-TINYML", model_version: "Chờ TinyML thật trên Gateway" },
      sd_ok: true, wifi_rssi: -48, trip: { distance_km: Number(tripDistanceKm.toFixed(5)) },
    };
  };
  const sendPosition = async (step, index, point, courseDeg) => {
    if (stopRequested) throw new Error("demo_stopped");
    const now=Date.now(),distance=previousPoint?distanceKm(previousPoint,point):0;
    const gnssSpeed=previousPoint&&now>previousSentAt?Number((distance*3600000/(now-previousSentAt)).toFixed(2)):0;
    tripDistanceKm += distance;
    previousPoint = point;
    previousSentAt=now;
    const data = payload(step, index, point, courseDeg,gnssSpeed);
    await request("/api/telemetry", { method: "POST", body: data });
    return data;
  };
  const sendEvent = async (step, state) => {
    if (!step.event) return;
    const seq = ++sequence;
    await request("/api/events", { method: "POST", body: { ...state, type: "event", seq, ts: new Date().toISOString(), event: { id: `${bootId}:${seq}:${step.event}`, name: step.event, severity: step.severity || "info", gps_attached: true, lat: state.location.lat, lon: state.location.lon } } });
  };
  console.log(`\nBỘ DEMO — HỆ THỐNG GIÁM SÁT HÀNH TRÌNH\nDashboard: ${base}\nTuyến: ${DEMO_ROUTE_NAME}\nSession: ${bootId}\nThời gian: khoảng ${Math.round((journey.length - 1) * options.intervalMs / 1000)} giây`);
  console.log("Chuyển động 5 Hz; không tạo cảnh báo AI tự động. Gửi dữ liệu gia tốc ở bảng cạnh map.");
  try {
    await request("/api/health");
    const routes = await request(`/api/routes?device_id=${DEMO_DEVICE_ID}`);
    if (routes.active_route) await request("/api/routes/end", { method: "POST", body: { device_id: DEMO_DEVICE_ID, route_id: routes.active_route.id } });
    const start = await request("/api/routes/start", { method: "POST", body: { device_id: DEMO_DEVICE_ID } });
    routeId = Number(start.route.id);
    await sendPosition(journey[0].step, 0, journey[0].point, heading(journey[0].point, journey[1].point));
    for (let index = 1; index < journey.length; index++) {
      const from = journey[index - 1], to = journey[index];
      const segmentStart = Date.now(), course = heading(from.point, to.point);
      console.log(`[${String(index).padStart(2, "0")}/${journey.length - 1}] [${to.direction}] ${to.step.title} | CAN ${to.step.speed} km/h`);
      // Never jump to catch up after a slow HTTP write. Every small geometric
      // subdivision is sent; a congested server slows/pauses the demo instead.
      // No blocking speaker-ACK waits during movement.
      const samples=Math.max(1,Math.ceil(options.intervalMs/POSITION_TICK_MS));
      const tickMs=options.intervalMs/samples;
      let nextTickAt=segmentStart+tickMs,lastState;
      for(let sample=1;sample<=samples;sample++) {
        if (stopRequested) throw new Error("demo_stopped");
        const waitMs = Math.max(0,nextTickAt-Date.now());
        if (waitMs > 0) await sleep(waitMs);
        const progress = sample/samples;
        const point = { lat: from.point.lat + (to.point.lat - from.point.lat) * progress, lon: from.point.lon + (to.point.lon - from.point.lon) * progress };
        lastState = await sendPosition(to.step, index, point, course);
        nextTickAt=Math.max(nextTickAt+tickMs,Date.now());
      }
      await sendEvent(to.step, lastState);
    }
    const ended = await request("/api/routes/end", { method: "POST", body: { device_id: DEMO_DEVICE_ID, route_id: routeId } });
    routeEnded = true;
    console.log(`\n[HOÀN TẤT] Lộ trình ${ended.route.route_no ?? routeId}: ${ended.route.point_count} điểm, ${Number(ended.route.distance_km || 0).toFixed(3)} km. Chỉ các mẫu đã gửi và được ESP suy luận mới tạo điểm cảnh báo.`);
  } catch (error) {
    if (routeId && !routeEnded) {
      try { await request("/api/routes/end", { method: "POST", body: { device_id: DEMO_DEVICE_ID, route_id: routeId } }); } catch {}
    }
    if (stopRequested || error.message === "demo_stopped") { console.log("[DỪNG] Đã đóng lộ trình demo an toàn."); return; }
    throw error;
  }
}
main().catch(error => { console.error(`[THẤT BẠI] ${error.message}`); process.exitCode = 1; });
