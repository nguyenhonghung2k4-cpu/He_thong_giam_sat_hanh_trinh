// Run locally once. Never print or put the connector key in browser code.
import { randomBytes } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
const root=join(dirname(fileURLToPath(import.meta.url)),'..');
const file=join(root,'online.private.json');
const config=JSON.parse(readFileSync(join(root,'online.config.json'),'utf8'));
if(!existsSync(file)){
  writeFileSync(file,JSON.stringify({connectorSecret:randomBytes(32).toString('hex')},null,2)+'\n',{encoding:'utf8',flag:'wx',mode:0o600});
  console.log('Đã thiết lập khóa kết nối máy tính. Khóa chỉ lưu trong online.private.json, không phải mật khẩu trình duyệt.');
}else console.log('Đã có cấu hình kết nối; không thay đổi khóa.');
console.log('Địa chỉ cố định: '+config.publicUrl);
