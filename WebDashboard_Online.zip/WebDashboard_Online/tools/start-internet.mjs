// Compatibility entry point: the public portal has no browser-password flow.
import { startOnline } from './start-online.mjs';
startOnline().catch(error => {
  console.error(`[ONLINE] ${error.message}`);
  process.exitCode = 1;
});
