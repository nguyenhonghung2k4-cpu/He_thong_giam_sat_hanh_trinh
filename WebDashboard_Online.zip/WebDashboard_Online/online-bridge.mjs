// The browser portal is public by the owner's choice. This loopback service is
// NOT public: only signed requests from the fixed cloud portal can reach Node.
import { createServer, request as httpRequest } from 'node:http';
import { readFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { verifyRelay, sha256Hex, DEVICE_PATHS } from '../CloudPortal/worker/protocol.js';

const ROOT = dirname(fileURLToPath(import.meta.url));
export const VERSION = '11.6.1';
const HOP = new Set(['connection','keep-alive','proxy-authenticate','proxy-authorization','te','trailer','transfer-encoding','upgrade']);
const ALLOWED_METHODS = new Set(['GET','HEAD','POST','DELETE','OPTIONS']);
export function validPublicOrigin(value) {
  let url; try { url = new URL(String(value)); } catch { throw new Error('Địa chỉ web cố định không hợp lệ.'); }
  if (url.protocol !== 'https:' || url.username || url.password || url.port || url.pathname !== '/' || url.search || url.hash)
    throw new Error('Địa chỉ web cố định phải là một origin HTTPS, không chứa đường dẫn hoặc khóa truy cập.');
  return url.origin;
}
export function validateSecret(value) {
  if (typeof value !== 'string' || value.length < 32 || new TextEncoder().encode(value).length > 1024 || /[\r\n\0]/.test(value))
    throw new Error('Khóa kết nối chưa hợp lệ. Không đưa khóa này vào JavaScript trình duyệt.');
  return value;
}
const security = { 'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff', 'X-Frame-Options':'DENY', 'Referrer-Policy':'strict-origin-when-cross-origin' };
const SECURITY_HEADERS = new Set(Object.keys(security).map(name => name.toLowerCase()));
function json(response,status,value) {
  response.writeHead(status,{...security,'Content-Type':'application/json; charset=utf-8'});
  response.end(JSON.stringify(value));
}
async function readBody(request, limit) {
  const declared=Number(request.headers['content-length']||0);
  if (!Number.isFinite(declared) || declared<0 || declared>limit) { const e=new Error('payload_too_large');e.status=413;throw e; }
  const chunks=[];let total=0;
  for await(const chunk of request) { total+=chunk.length;if(total>limit){const e=new Error('payload_too_large');e.status=413;throw e;}chunks.push(chunk); }
  return Buffer.concat(chunks);
}
export function createOnlineBridge(options={}) {
  const connectorSecret=validateSecret(options.connectorSecret);
  const publicOrigin=validPublicOrigin(options.publicUrl);
  const runId=String(options.runId||'');
  if(!/^[A-Za-z0-9_-]{8,100}$/.test(runId))throw new Error('Mã phiên bridge không hợp lệ.');
  const target=new URL(options.targetUrl||'http://127.0.0.1:3000');
  if(target.protocol!=='http:'||!['127.0.0.1','localhost','[::1]'].includes(target.hostname)||target.username||target.password||target.pathname!=='/'||target.search||target.hash)
    throw new Error('Bridge chỉ được chuyển tới máy chủ HTTP loopback.');
  const now=options.now||Date.now, maxBodyBytes=options.maxBodyBytes??256*1024;
  const headerTimeoutMs=options.headerTimeoutMs??15000;
  const pending=new Set();
  const server=createServer(async(request,response)=>{
    try {
      if(!ALLOWED_METHODS.has(request.method)){json(response,405,{ok:false,code:'method_not_allowed'});return;}
      if(!request.url?.startsWith('/')||request.url.startsWith('//')){json(response,400,{ok:false,code:'invalid_path'});return;}
      const url=new URL(request.url,publicOrigin),path=url.pathname+url.search;
      const body=await readBody(request,maxBodyBytes);
      const origin=String(request.headers['x-hht-relay-origin']||'');
      const timestamp=String(request.headers['x-hht-relay-time']||'');
      const signedRun=String(request.headers['x-hht-relay-run']||'');
      const signature=String(request.headers['x-hht-relay-signature']||'');
      const health=request.method==='GET'&&url.pathname==='/__relay/health';
      if(origin!==publicOrigin||signedRun!==runId||!await verifyRelay(connectorSecret,{
        purpose:health?'health':'proxy',method:request.method,path,origin,runId:signedRun,timestamp,
        bodyHash:await sha256Hex(body),signature,
      },{now:now()})) { json(response,403,{ok:false,code:'signed_relay_required'});return; }
      if(!['GET','HEAD','OPTIONS'].includes(request.method)&&request.headers.origin!==publicOrigin){
        json(response,403,{ok:false,code:'cross_origin_denied'});return;
      }
      if(health){json(response,200,{ok:true,service:'telematics-pc-bridge',version:VERSION,run_id:runId});return;}
      if(url.pathname.startsWith('/__relay/')){json(response,404,{ok:false,code:'not_found'});return;}
      if(DEVICE_PATHS.has(url.pathname)){json(response,403,{ok:false,code:'device_endpoint_not_public'});return;}
      if(url.pathname==='/api/stream'){json(response,409,{ok:false,code:'use_http_polling',transport:'poll'});return;}
      if(request.method==='GET'&&url.pathname==='/api/access-status'){
        json(response,200,{ok:true,service:'telematics-online-bridge',version:VERSION,mode:'internet',transport:'poll',
          requires_login:false,access_mode:'public',authenticated:false,run_id:runId});return;
      }
      const headers={host:target.host};
      for(const name of ['accept','accept-language','content-type','if-none-match','if-modified-since','range','user-agent'])
        if(request.headers[name])headers[name]=request.headers[name];
      if(!['GET','HEAD'].includes(request.method)){headers.origin=target.origin;headers['sec-fetch-site']='same-origin';}
      if(body.length)headers['content-length']=String(body.length);
      let waiting=true;
      const outgoing=httpRequest({hostname:target.hostname.replace(/^\[|\]$/g,''),port:target.port||80,
        method:request.method,path,headers},upstream=>{
        waiting=false;clearTimeout(headerTimer);
        const outHeaders={...security};
        for(const [name,value]of Object.entries(upstream.headers)){
          if(HOP.has(name)||SECURITY_HEADERS.has(name)||name==='set-cookie'||name.startsWith('access-control-')||name.startsWith('x-hht-')||name.startsWith('oai-'))continue;
          outHeaders[name]=value;
        }
        Object.assign(outHeaders,security);
        if(outHeaders.location){
          try { const location=new URL(outHeaders.location,target);outHeaders.location=location.origin===target.origin?location.pathname+location.search+location.hash:undefined; }
          catch { delete outHeaders.location; }
          if(!outHeaders.location)delete outHeaders.location;
        }
        response.writeHead(upstream.statusCode||502,outHeaders);
        response.flushHeaders?.();
        upstream.on('error',()=>response.destroy());
        // Stream files under backpressure. No full-response timeout truncates
        // a valid MicroSD download after its headers have arrived.
        upstream.pipe(response);
      });
      const headerTimer=setTimeout(()=>{if(waiting)outgoing.destroy(new Error('upstream_header_timeout'));},headerTimeoutMs);
      headerTimer.unref?.();pending.add(outgoing);
      outgoing.on('close',()=>{clearTimeout(headerTimer);pending.delete(outgoing);});
      outgoing.on('error',()=>{clearTimeout(headerTimer);if(response.destroyed||response.writableEnded)return;if(!response.headersSent)json(response,502,{ok:false,code:'pc_dashboard_unavailable'});else response.destroy();});
      request.on('aborted',()=>outgoing.destroy());
      response.on('close',()=>{if(!response.writableFinished)outgoing.destroy();});
      outgoing.end(body);
    } catch(error) {
      if(!response.headersSent)json(response,error.status===413?413:500,{ok:false,code:error.status===413?'payload_too_large':'bridge_request_failed'});
      else response.destroy();
    }
  });
  server.requestTimeout=20000;server.headersTimeout=10000;server.keepAliveTimeout=5000;
  server.on('upgrade',(_request,socket)=>socket.end('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n'));
  server.on('close',()=>{for(const outgoing of pending)outgoing.destroy();pending.clear();});
  return server;
}
export function loadOnlineBridgeSettings(root=ROOT,env=process.env) {
  let local={},online,privateConfig;
  try{local=JSON.parse(readFileSync(join(root,'config.local.json'),'utf8'));}catch(error){if(error.code!=='ENOENT')throw new Error('config.local.json không hợp lệ.');}
  try{online=JSON.parse(readFileSync(join(root,'online.config.json'),'utf8'));privateConfig=JSON.parse(readFileSync(join(root,'online.private.json'),'utf8'));}
  catch{throw new Error('Thiếu cấu hình kết nối cổng web. Không mở đường hầm khi chưa có online.config.json và online.private.json hợp lệ.');}
  const port=(value,fallback)=>{const n=Number(value??fallback);if(!Number.isInteger(n)||n<1||n>65535)throw new Error('Cổng bridge không hợp lệ.');return n;};
  const targetPort=port(env.ONLINE_TARGET_PORT??env.PORT??local.port,3000);
  const bridgePort=port(env.ONLINE_BRIDGE_PORT??env.INTERNET_ACCESS_PORT,targetPort===3001?3002:3001);
  if(targetPort===bridgePort)throw new Error('Hai cổng máy chủ và bridge phải khác nhau.');
  return {port:bridgePort,targetUrl:`http://127.0.0.1:${targetPort}`,publicUrl:validPublicOrigin(online.publicUrl),
    connectorSecret:validateSecret(privateConfig.connectorSecret),runId:String(env.ONLINE_RUN_ID||'')};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  try{
    const options=loadOnlineBridgeSettings();const server=createOnlineBridge(options);
    server.on('error',error=>{console.error(`[BRIDGE] Không khởi động được: ${error.code||'server_error'}`);process.exitCode=1;});
    server.listen(options.port,'127.0.0.1',()=>console.log(`[BRIDGE] Đã sẵn sàng tại cổng nội bộ ${options.port}; chỉ nhận request ký từ cổng web cố định.`));
    let stopping=false;
    const stop=()=>{if(stopping)return;stopping=true;server.close(()=>{if(process.connected)process.disconnect();});server.closeAllConnections?.();};
    process.once('SIGINT',stop);process.once('SIGTERM',stop);process.on('message',message=>{if(message?.type==='telematics:shutdown')stop();});
  }catch(error){console.error(`[BRIDGE] ${error.message}`);process.exitCode=1;}
}
