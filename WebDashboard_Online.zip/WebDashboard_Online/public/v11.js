(() => {
  "use strict";

  const $ = id => document.getElementById(id);
  const state = {
    sse: null,
    sseDevice: null,
    sseRefreshTimer: 0,
    demoBusy: false,
    demoStatus: null,
    demoViewActive: false,
    demoPreviousDevice: "",
    demoWasRunning: false,
    demoRestoreTimer: 0,
    directLocked: false,
    accessPromise: null,
    connectionGeneration: 0,
    livePoll: null,
    unloading: false,
    accessRetryTimer: 0,
    accessFailures: 0,
    authExpired: false,
    connectedSourceGeneration: null,
  };

  function currentDevice() {
    const selected = $("device-select")?.value?.trim();
    if (selected) return selected;
    const text = $("device-id")?.textContent?.trim() || "";
    return /^(Chờ|Không|—)/i.test(text) ? "" : text;
  }

  function setSseStatus(mode, text) {
    const node = $("sse-pill");
    if (!node) return;
    node.classList.remove("live", "offline", "waiting");
    node.classList.add(mode);
    const label = node.querySelector("span");
    if (label) label.textContent = text;
  }

  function scheduleDashboardRefresh(detail = {}) {
    // Event/ACK packets are rare and must never be overwritten by the next
    // telemetry packet. Only high-frequency telemetry is debounced.
    if (detail.kind !== "telemetry") {
      window.dispatchEvent(new CustomEvent("telematics:sse-update", { detail }));
      return;
    }
    clearTimeout(state.sseRefreshTimer);
    state.sseRefreshTimer = window.setTimeout(() => {
      window.dispatchEvent(new CustomEvent("telematics:sse-update", { detail }));
    }, 45);
  }

  function handleSseMessage(event) {
    let detail = {};
    try { detail = JSON.parse(event.data || "{}"); } catch {}
    // Demo status updates only its control panel. Telemetry/events may refresh
    // the map only when they belong to the device currently pinned on screen.
    if (detail.kind === "demo") { loadDemoStatus(); return; }
    const pinned = currentDevice();
    if (pinned && detail.device_id && detail.device_id !== pinned) return;
    // The 5 Hz motion lane is already a complete, confirmed firmware snapshot.
    // It must not trigger SQLite history/route/event downloads or a full render.
    if (detail.kind === "direct_realtime") {
      window.dispatchEvent(new CustomEvent("telematics:direct-realtime", { detail }));
      return;
    }
    scheduleDashboardRefresh(detail);
  }

  async function selectDashboardDevice(deviceId, label = "") {
    const api = window.telematicsDashboard;
    if (api?.selectDevice) {
      await api.selectDevice(deviceId, label);
      state.sseDevice = null;
      connectSse();
      return;
    }
    const select = $("device-select");
    if (!select) return;
    const value = String(deviceId || "");
    if (value && ![...select.options].some(option => option.value === value)) {
      const option = document.createElement("option"); option.value = value; option.textContent = label || value; select.append(option);
    }
    select.value = value;
    select.dispatchEvent(new Event("change", { bubbles: true }));
  }

  async function enterDemoView(deviceId) {
    if (!deviceId) return;
    clearTimeout(state.demoRestoreTimer);
    state.demoRestoreTimer = 0;
    if (!state.demoViewActive) {
      const previous = currentDevice();
      state.demoPreviousDevice = previous === deviceId ? "" : previous;
      state.demoViewActive = true;
    }
    if (currentDevice() !== deviceId) await selectDashboardDevice(deviceId, `${deviceId} · DEMO ĐANG CHẠY`);
  }

  function scheduleLiveRestore() {
    if (!state.demoViewActive || state.demoRestoreTimer) return;
    state.demoRestoreTimer = window.setTimeout(async () => {
      const target = state.demoPreviousDevice;
      state.demoRestoreTimer = 0;
      state.demoViewActive = false;
      state.demoPreviousDevice = "";
      await selectDashboardDevice(target, target);
    }, 2500);
  }

  function discoverAccess() {
    if (!state.accessPromise) state.accessPromise = fetch('/api/access-status', { cache: 'no-store', signal: AbortSignal.timeout(8000) })
      .then(response => { if (!response.ok) throw new Error('Không xác định được chế độ truy cập'); return response.json(); })
      .then(data => {
        if (data.mode === 'internet' && data.requires_login !== false && !data.authenticated) {
          state.authExpired = true;
          window.location.assign('/login'); throw new Error('Cần đăng nhập');
        }
        const remote = data.mode === 'internet';
        window.TelematicsAccess = { remote, mode: remote ? 'internet' : 'local', transport: remote ? 'poll' : 'sse', requiresLogin: remote && data.requires_login !== false, publicAccess: data.access_mode === 'public' };
        window.dispatchEvent(new CustomEvent('telematics:access-status', { detail: window.TelematicsAccess }));
        return window.TelematicsAccess;
      }).catch(error => { state.accessPromise = null; throw error; });
    return state.accessPromise;
  }

  async function connectSse() {
    clearTimeout(state.accessRetryTimer); state.accessRetryTimer = 0;
    const generation = ++state.connectionGeneration;
    const selected = $("device-select")?.value?.trim() || "";
    const sourceGeneration = window.telematicsDashboard?.getSourceGeneration?.();
    if (state.sseDevice !== selected || state.connectedSourceGeneration !== sourceGeneration) {
      state.sse?.close(); state.sse = null; state.livePoll?.stop(); state.livePoll = null;
    }
    let access;
    try { access = await discoverAccess(); }
    catch {
      if (generation !== state.connectionGeneration || state.unloading || state.authExpired) return;
      setSseStatus('offline', 'CHỜ KẾT NỐI');
      const delay = Math.min(10000, 1000 * 2 ** Math.min(state.accessFailures++, 4));
      state.accessRetryTimer = window.setTimeout(connectSse, delay);
      return;
    }
    if (generation !== state.connectionGeneration || state.unloading) return;
    state.accessFailures = 0;
    if ((state.sse || state.livePoll) && state.sseDevice === selected && state.connectedSourceGeneration === sourceGeneration) return;
    state.sse?.close(); state.sse = null;
    state.livePoll?.stop(); state.livePoll = null;
    state.sseDevice = selected;
    state.connectedSourceGeneration = sourceGeneration;
    if (access.remote) {
      setSseStatus('waiting', 'ĐANG KẾT NỐI');
      state.livePoll = window.TelematicsLivePolling.create({
        hidden: () => document.hidden,
        onUnauthorized: () => window.location.assign('/login'),
        onStatus: live => {const online=window.telematicsDashboard?.recordServerTransport?.(live)??live;setSseStatus(online?'live':'offline',live?'CẬP NHẬT HTTP':online?'HTTP · ĐANG THỬ LẠI':'ĐANG KẾT NỐI LẠI');},
        onSnapshot: data => {
          window.telematicsDashboard?.acceptServerClock?.(data);
          if (Object.prototype.hasOwnProperty.call(data, 'latest')) {
            window.dispatchEvent(new CustomEvent('telematics:live-snapshot', { detail: { ...data, source_generation: sourceGeneration } }));
          }
          if (data.direct_realtime) window.dispatchEvent(new CustomEvent('telematics:direct-realtime', { detail: data.direct_realtime }));
        },
        onUpdate: detail => handleSseMessage({ data: JSON.stringify(detail) }),
      });
      state.livePoll.start(selected);
      return;
    }
    if (!("EventSource" in window)) {
      setSseStatus("offline", "SSE KHÔNG HỖ TRỢ");
      return;
    }
    setSseStatus("waiting", "SSE ĐANG KẾT NỐI");
    const query = selected ? `?device_id=${encodeURIComponent(selected)}` : "";
    const source = new EventSource(`/api/stream${query}`);
    state.sse = source;
    source.onopen = () => setSseStatus("live", "REALTIME SSE");
    source.onerror = () => setSseStatus("offline", "SSE FALLBACK 5 GIÂY");
    source.onmessage = handleSseMessage;
    source.addEventListener("update", handleSseMessage);
    source.addEventListener("connected", () => setSseStatus("live", "REALTIME SSE"));
    source.addEventListener("heartbeat", () => setSseStatus("live", "REALTIME SSE"));
  }

  function updateReportButton() {
    const button = $("route-report-btn");
    if (button) button.disabled = !$("route-select")?.value;
  }

  function openTripReport() {
    const routeId = $("route-select")?.value;
    if (!routeId) return;
    const query = new URLSearchParams({ route_id: routeId, autoprint: "1" });
    const device = currentDevice();
    if (device) query.set("device_id", device);
    window.open(`/trip-report.html?${query}`, "_blank", "noopener");
  }

  function renderDemoStatus(data) {
    const demo = data?.demo ?? data ?? {};
    state.demoStatus = demo;
    window.dispatchEvent(new CustomEvent("telematics:demo-status",{detail:demo}));
    const running = Boolean(demo.running);
    const start = $("demo-start-btn"), stop = $("demo-stop-btn"), status = $("demo-status");
    if (start) start.disabled = state.demoBusy || running || state.directLocked;
    if (stop) stop.disabled = state.demoBusy || !running;
    if (!status) return;
    status.className = `demo-status ${running ? "running" : demo.error ? "error" : demo.completed ? "done" : ""}`;
    const label = status.querySelector("span") || status;
    if (running) label.textContent = demo.last_line || demo.stage || `Demo đang chạy${demo.device_id ? ` · ${demo.device_id}` : ""}...`;
    else if (demo.error) label.textContent = `Demo lỗi: ${demo.error}`;
    else if (demo.completed) label.textContent = demo.last_line || "Demo hai chiều đã hoàn tất; chỉ các mẫu đã được TinyML thật xác nhận mới tạo cảnh báo.";
    else label.textContent = demo.last_line || "Demo sẵn sàng tạo dữ liệu riêng để kiểm tra dashboard.";
  }

  async function loadDemoStatus() {
    try {
      const response = await fetch("/api/demo/status", { cache: "no-store" });
      if (!response.ok) return;
      const payload = await response.json(), demo = payload?.demo || {};
      renderDemoStatus(payload);
      if (demo.running) await enterDemoView(demo.device_id);
      else if (state.demoWasRunning) scheduleLiveRestore();
      state.demoWasRunning = Boolean(demo.running);
    } catch {}
  }

  async function demoAction(action) {
    if (state.demoBusy || (action === "start" && state.directLocked)) return;
    state.demoBusy = true;
    renderDemoStatus({ running: action === "start", stage: action === "start" ? "Đang khởi động demo..." : "Đang dừng demo..." });
    try {
      const response = await fetch(`/api/demo/${action}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: "{}",
      });
      const data = await response.json();
      if (!response.ok || !data.ok) throw new Error(data.error || `HTTP ${response.status}`);
      renderDemoStatus(data);
      if (action === "start") {
        state.demoWasRunning = true;
        await enterDemoView(data.demo?.device_id);
      } else scheduleLiveRestore();
      scheduleDashboardRefresh({ kind: "demo" });
    } catch (error) {
      renderDemoStatus({ error: `${error.message}. Có thể chạy AUTO_DEMO.bat trong thư mục WebDashboard_Localhost.` });
    } finally {
      state.demoBusy = false;
      renderDemoStatus(state.demoStatus || {});
    }
  }

  $("route-report-btn")?.addEventListener("click", openTripReport);
  $("route-select")?.addEventListener("change", updateReportButton);
  $("demo-start-btn")?.addEventListener("click", () => demoAction("start"));
  $("demo-stop-btn")?.addEventListener("click", () => demoAction("stop"));
  $("device-select")?.addEventListener("change", () => {
    state.sseDevice = null;
    connectSse();
  });
  // Programmatic source selection must reconnect SSE too, not fall back to a
  // five-second poll while still subscribed to the physical device.
  window.addEventListener("telematics:source-changed", connectSse);
  window.addEventListener("telematics:direct-demo-status", event => {
    state.directLocked = Boolean(event.detail?.locked);
    if (state.directLocked) {
      clearTimeout(state.demoRestoreTimer); state.demoRestoreTimer = 0;
      state.demoViewActive = false; state.demoWasRunning = false;
      state.demoPreviousDevice = "";
    }
    const button = $("demo-start-btn");
    if (button) button.disabled = state.demoBusy || Boolean(state.demoStatus?.running) || state.directLocked;
  });

  const routeObserver = new MutationObserver(updateReportButton);
  if ($("route-select")) routeObserver.observe($("route-select"), { childList: true, subtree: true });

  updateReportButton();
  connectSse();
  loadDemoStatus();
  window.setInterval(loadDemoStatus, 2500);
  window.addEventListener("beforeunload", () => {
    state.unloading = true; state.connectionGeneration++; state.livePoll?.stop();
    state.sse?.close(); clearTimeout(state.demoRestoreTimer); clearTimeout(state.sseRefreshTimer);
    clearTimeout(state.accessRetryTimer);
  });
})();
