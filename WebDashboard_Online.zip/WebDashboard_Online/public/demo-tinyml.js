(() => {
  "use strict";
  const $ = id => document.getElementById(id);
  const AUTO_DEMO_DEVICE_ID = "blackbox-esp32s3-auto-demo";
  const labels = { o_ga: "Ổ gà", go_giam_toc: "Gờ giảm tốc", duong_bang_phang: "Đường bằng phẳng" };
  const state = { catalog: null, loading: false, busy: false, lastSignature: null, timer: 0, commandId: null, commandFeedback: false };
  const wait = ms => new Promise(resolve => window.setTimeout(resolve, ms));
  function feedback(message, tone = "") {
    const node = $("demo-tinyml-status");
    if (!node) return;
    node.textContent = message; node.className = `demo-tinyml-status ${tone}`;
  }
  async function jsonRequest(path, options = {}) {
    const response = await fetch(path, { cache: "no-store", signal: AbortSignal.timeout(12000), ...options });
    const data = await response.json().catch(() => null);
    if (!response.ok || !data?.ok) throw new Error(data?.error || `HTTP ${response.status}`);
    return data;
  }
  function drawWaveform(canvas, sample) {
    const values = Array.isArray(sample.values) ? sample.values : [];
    const triples = Math.floor(values.length / 3);
    const ratio = window.devicePixelRatio || 1, width = canvas.clientWidth || 300, height = 48;
    canvas.width = Math.round(width * ratio); canvas.height = Math.round(height * ratio);
    const c = canvas.getContext("2d"); c.scale(ratio, ratio); c.clearRect(0, 0, width, height);
    if (!triples) return;
    const low = Math.min(...values), high = Math.max(...values), span = Math.max(.01, high - low), margin = 5;
    c.strokeStyle = "#dce7ee"; c.lineWidth = 1;
    for (const f of [.25, .5, .75]) { c.beginPath(); c.moveTo(0, height * f); c.lineTo(width, height * f); c.stroke(); }
    ["#06b6d4", "#f59e0b", "#8b5cf6"].forEach((color, axis) => {
      c.strokeStyle = color; c.lineWidth = 1.2; c.beginPath();
      for (let i = 0; i < triples; i++) {
        const x = margin + i / Math.max(1, triples - 1) * (width - margin * 2);
        const y = height - margin - (Number(values[i * 3 + axis]) - low) / span * (height - margin * 2);
        if (i) c.lineTo(x, y); else c.moveTo(x, y);
      }
      c.stroke();
    });
  }
  function positionReady() {
    const position = window.telematicsDashboard?.getDisplayedVehiclePosition?.();
    const demo = state.catalog?.demo;
    if (!position || position.device_id !== AUTO_DEMO_DEVICE_ID || !demo?.running || !demo?.session_id) return null;
    if (position.boot_id && position.boot_id !== demo.session_id) return null;
    return position;
  }
  function refreshButtons() {
    const gatewayOnline = Boolean(state.catalog?.gateway?.online), position = positionReady();
    document.querySelectorAll("[data-demo-sample]").forEach(button => {
      button.disabled = state.busy || !gatewayOnline || !position;
      button.title = !state.catalog?.demo?.running ? "Bắt đầu demo tự động trước" : !gatewayOnline ? "Gateway thật đang offline" : !position ? "Chờ vị trí xe của phiên demo hiện tại" : "Gửi gia tốc thật tới ESP32-S3 tại vị trí xe đang hiển thị";
    });
    const badge = $("demo-tinyml-gateway");
    if (badge) { badge.textContent = gatewayOnline ? "GATEWAY ONLINE" : "GATEWAY OFFLINE"; badge.classList.toggle("stale", !gatewayOnline); badge.title = String(state.catalog?.gateway?.device_id || "Chưa cấu hình Gateway"); }
    if(!state.busy&&!state.commandFeedback&&state.catalog){
      feedback(!state.catalog.demo?.running ? "Bắt đầu demo tự động để gửi mẫu." : !gatewayOnline ? "Demo đang chạy nhưng Gateway thật đang offline; không tạo kết quả AI giả." : !position ? "Đang chờ vị trí xe của phiên demo hiện tại…" : "Chọn mẫu và bấm Gửi tới ESP. Vị trí xe tại lúc bấm sẽ được giữ nguyên để gắn kết quả TinyML.");
    }
  }
  function renderCatalog() {
    const samples = state.catalog?.samples || [], host = $("demo-tinyml-samples");
    if (!host) return;
    const signature = samples.map(sample => `${sample.id}:${sample.frequency_hz}:${sample.values?.length}:${sample.source_start_row}`).join("|");
    if (signature === state.lastSignature) { refreshButtons(); return; }
    state.lastSignature = signature; host.replaceChildren();
    if (!samples.length) { const empty = document.createElement("p"); empty.className = "demo-tinyml-empty"; empty.textContent = "Chưa có mẫu gia tốc thực địa hợp lệ."; host.append(empty); }
    for (const sample of samples) {
      const card = document.createElement("div"); card.className = `demo-tinyml-card ${sample.id === "go_giam_toc" || /bump/i.test(sample.id) ? "bump" : ""}`;
      const head = document.createElement("div"); head.className = "demo-tinyml-card-head";
      const title = document.createElement("h3"); title.textContent = sample.id === "pothole" ? "Mẫu CSV ổ gà (chọn lọc)" : sample.id === "speed_bump" ? "Mẫu CSV gờ giảm tốc" : sample.title || labels[sample.id] || sample.id;
      const send = document.createElement("button"); send.type = "button"; send.className = "sd-btn primary"; send.dataset.demoSample = sample.id; send.textContent = "↗ Gửi tới ESP"; send.disabled = true;
      send.addEventListener("click", () => sendSample(sample)); head.append(title, send);
      const canvas = document.createElement("canvas"); canvas.className = "demo-tinyml-wave"; canvas.setAttribute("aria-label", `Gia tốc X, Y, Z — ${title.textContent}`);
      const meta = document.createElement("p"); meta.className = "demo-tinyml-meta";
      const count = Math.floor((sample.values?.length || 0) / 3), frequency = Number(sample.frequency_hz), duration = frequency > 0 ? (count / frequency).toFixed(2) : "—";
      meta.textContent = `${frequency || "—"} Hz · ${count} mẫu XYZ · ${duration} s · ${sample.units || "—"}\nNguồn: ${sample.source_file || "—"} · từ dòng ${sample.source_start_row ?? "—"}\nMẫu chọn lọc để demo; confidence không phải accuracy thực địa.`;
      const details = document.createElement("details"), summary = document.createElement("summary"), raw = document.createElement("pre"); summary.textContent = "Xem dữ liệu gia tốc X / Y / Z"; raw.className = "demo-tinyml-raw";
      const lines = ["#     X           Y           Z"];
      for (let i = 0; i < count; i++) lines.push(`${String(i + 1).padStart(3)}  ${sample.values.slice(i * 3, i * 3 + 3).map(value => Number(value).toFixed(5).padStart(10)).join(" ")}`);
      raw.textContent = lines.join("\n"); details.append(summary, raw); card.append(head, canvas, meta, details); host.append(card);
      requestAnimationFrame(() => drawWaveform(canvas, sample));
    }
    refreshButtons();
  }
  async function loadCatalog() {
    if (state.loading) return;
    state.loading = true;
    try { state.catalog = await jsonRequest("/api/demo/tinyml"); renderCatalog(); }
    catch (error) { state.catalog = null; refreshButtons(); if (!state.busy&&!state.commandFeedback) feedback(`Không tải được mẫu/Gateway: ${error.message}`, "error"); }
    finally { state.loading = false; }
  }
  async function waitForInference(commandId, sessionId) {
    const deadline = Date.now() + 45000;
    while (Date.now() < deadline) {
      const data = await jsonRequest(`/api/device-commands/${commandId}`), command = data.command;
      if (!command) throw new Error("Không tìm thấy lệnh suy luận.");
      if (command.status === "done") return command;
      if (["failed", "expired", "cancelled"].includes(command.status)) throw new Error(command.result?.error || command.status);
      if (state.catalog?.demo?.session_id && state.catalog.demo.session_id !== sessionId) throw new Error("Phiên demo đã thay đổi; không gắn kết quả sang phiên mới.");
      feedback("Lệnh đang chờ Gateway — chưa có kết quả TinyML. Không tạo điểm trước khi ESP32-S3 xác nhận.", "busy");
      await wait(300);
    }
    throw new Error("Hết thời gian chờ TinyML. Không tạo điểm cảnh báo khi chưa có ACK.");
  }
  async function sendSample(sample) {
    if (state.busy) return;
    state.commandFeedback=true;
    // Read Leaflet's visible marker NOW, before any async request or catalog
    // refresh. Do not substitute the latest database point or result location.
    const position = positionReady(), sessionId = state.catalog?.demo?.session_id;
    if (!position || !state.catalog?.gateway?.online) { feedback("Cần demo đang chạy, đúng vị trí phiên hiện tại và Gateway thật online.", "error"); refreshButtons(); return; }
    const captured = { lat: position.lat, lon: position.lon };
    state.busy = true; refreshButtons();
    feedback(`Đang gửi ${sample.title || sample.id} tại ${captured.lat.toFixed(6)}, ${captured.lon.toFixed(6)}…`, "busy");
    try {
      const response = await jsonRequest("/api/demo/tinyml", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ sample_id: sample.id, session_id: sessionId, position: captured }) });
      if (!response.command?.id) throw new Error("Server không trả ID lệnh suy luận.");
      state.commandId = response.command.id;
      const command = await waitForInference(state.commandId, sessionId), result = command.result || {}, inference = result.inference || result;
      if (!inference.label || !Number.isFinite(Number(inference.confidence))) throw new Error("ACK không có kết quả TinyML hợp lệ.");
      const label = labels[inference.label] || inference.label, confidence = (Number(inference.confidence) * 100).toFixed(1);
      feedback(`TinyML thật: ${label} · ${confidence}% · ${captured.lat.toFixed(6)}, ${captured.lon.toFixed(6)}. ${result.map_point_created !== true ? "Không tạo điểm cảnh báo: kết quả không đạt điều kiện hoặc điểm đã tồn tại." : "Đã cập nhật sự kiện và điểm cảnh báo theo kết quả xác nhận."}`, "success");
      window.dispatchEvent(new CustomEvent("telematics:sse-update", { detail: { kind: "event", device_id: AUTO_DEMO_DEVICE_ID } }));
    } catch (error) { feedback(`Không hoàn tất suy luận: ${error.message}. Không gán nhãn/đánh dấu giả.`, "error"); }
    finally { state.busy = false; state.commandId = null; await loadCatalog(); refreshButtons(); }
  }
  window.addEventListener("telematics:demo-status", loadCatalog);
  window.addEventListener("resize", () => { document.querySelectorAll(".demo-tinyml-wave").forEach((canvas, i) => { const sample = state.catalog?.samples?.[i]; if (sample) drawWaveform(canvas, sample); }); });
  loadCatalog(); state.timer = window.setInterval(loadCatalog, 2500);
  window.addEventListener("beforeunload", () => clearInterval(state.timer), { once: true });
})();
