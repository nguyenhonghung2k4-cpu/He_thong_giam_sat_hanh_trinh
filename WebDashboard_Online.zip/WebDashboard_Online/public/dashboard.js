(() => {
  "use strict";
  const $ = id => document.getElementById(id);
  const roadLabels = { duong_bang_phang: "Đường bằng phẳng", go_giam_toc: "Gờ giảm tốc", o_ga: "Ổ gà", unknown: "Chưa xác định" };
  // SSE requests an immediate refresh after each new packet. This slower poll
  // remains as a safety fallback when EventSource is unavailable or reconnecting.
  const DASHBOARD_POLL_MS = 5000;
  const DASHBOARD_TIMEOUT_MS = 1500;
  const ROUTE_TIMEOUT_MS = 2000;
  const SELF_TEST_AUTO_HIDE_MS = 10000;
  // Start in LIVE mode so simulated values can never be mistaken for ESP32 data.
  const state = { mode: "live", modeLocked: false, liveData: null, data: null, selectedDevice: "", sourceGeneration: 0, requestInFlight: false, pollPending: false, serverOnline: false, tick: 0, lastRows: [], map: null, layers: null, mapFitted: false, tileErrors: 0, mapResizeObserver: null, mapResizeTimer: 0, lastVehicleKey: "", hazardLayers: new Map(), routeCasing: null, routeCore: null, routeStartMarker: null, routeEndMarker: null, vehicleHalo: null, vehicleCore: null, replayMarker: null, routes: [], activeRoute: null, selectedRouteId: null, displayedRoute: null, routePoints: [], routeEvents: [], routeStats: null, routeRequestInFlight: false, routeFeedbackTimer: 0, replayTimer: 0, replayPosition: 0, replayPlaying: false, eventCenterEvents: [], eventTotal: 0, eventNextOffset: 0, eventHasMore: false, eventCenterLoaded: false, eventFiltersApplied: false, eventSearchInFlight: false, eventSearchPending: false, configBusy: false, deviceConfig: null, selfTest: null, selfTestHideTimer: 0, sdCommandBusy: false, sdFiles: [], sdLastResult: null, sdFeedbackTimer: 0, hazardCatalog:[], v10LastLoad:0, v10Busy:false, v10ReloadPending:false, v10Generation:0, hazardBusy:false };
  // A failed history query must not override a successful live packet.
  // Sensor/ECU freshness is still gated independently at its original limits.
  const serverTransport={lastSuccess:0,lastFailure:0};
  function recordServerTransport(ok){
    const now=Date.now();
    if(ok)serverTransport.lastSuccess=now;else serverTransport.lastFailure=now;
    state.serverOnline=serverTransport.lastSuccess>0&&now-serverTransport.lastSuccess<8000;
    return state.serverOnline;
  }
  const AUTO_DEMO_DEVICE_ID="blackbox-esp32s3-auto-demo";
  const isAutoDemoDevice=value=>String(value||"")===AUTO_DEMO_DEVICE_ID;
  const isDirectDemoDevice=value=>String(value||"").endsWith("-direct-demo");
  const isMovingDemoDevice=value=>isAutoDemoDevice(value)||isDirectDemoDevice(value);
  const directView={session:null,route:null,key:"",preview:null,layer:null,rotated:false,controls:null,handlers:[],resize:0,confirmedDistance:null};
  const routeRequests={list:null,detail:null};
  const DIRECT_REALTIME_MAX_AGE_MS=1500;
  const directRealtime={packet:null};
  const directTransportAges=new WeakMap();
  const newerUint32=(a,b)=>{const d=(Number(a)-Number(b))>>>0;return d>0&&d<0x80000000;};
  const captureMs=snapshot=>number(snapshot?.capture_ms);
  function realtimeFresh(packet){
    let age=serverTimeMs()-number(packet?.received_at_ms,0);
    const transit=packet&&directTransportAges.get(packet);
    if(transit)age=Math.max(age,transit.age+Math.max(0,monotonicTimeMs()-transit.receivedTick));
    return age>=-1000&&age<DIRECT_REALTIME_MAX_AGE_MS;
  }
  function directMotionPacket(){
    const packet=directRealtime.packet,session=directView.session,snapshot=packet?.direct_demo;
    if(!packet||!session||!window.TelematicsDirectGeometry.confirmed(session.state)||snapshot?.session_id!==session.session_id||packet.device_id!==currentDeviceId())return null;
    if(session.physical_boot_id&&packet.boot_id!==session.physical_boot_id)return null;
    const durable=session.last_snapshot;
    if(durable&&Number(durable.pass_index)>Number(snapshot.pass_index))return null;
    if(durable&&captureMs(durable)!==null&&captureMs(snapshot)!==null&&newerUint32(captureMs(durable),captureMs(snapshot)))return null;
    const latest=state.data?.latest,stored=directSnapshot(latest);
    if(stored?.session_id===snapshot.session_id){
      if(Number(stored.pass_index)>Number(snapshot.pass_index))return null;
      const storedCapture=captureMs(stored)??number(latest.uptime_ms);
      if(storedCapture!==null&&newerUint32(storedCapture,captureMs(snapshot)))return null;
    }
    return packet;
  }
  function directMapLatest(latest){
    const packet=directMotionPacket();if(!packet||!directView.route)return latest;
    const durable=directSnapshot(latest),motion=packet.direct_demo;
    if(durable?.session_id===motion.session_id){
      if(Number(durable.pass_index)>Number(motion.pass_index))return latest;
      const durableCapture=captureMs(durable)??number(latest?.uptime_ms);
      if(durableCapture!==null&&captureMs(motion)!==null&&newerUint32(durableCapture,captureMs(motion)))return latest;
    }
    // Position only: never refresh TinyML, ADXL, SD or other sensor timestamps.
    // Keep the newest confirmed endpoint even if an older durable query returns.
    const pos=window.TelematicsDirectGeometry.at(directView.route,motion.distance_m);
    return {...latest,device_id:packet.device_id,boot_id:motion.session_id,lat:pos[0],lon:pos[1],location_valid:true,gnss_filter_version:null,
      ingested_at:packet.received_at_ms,uptime_ms:packet.uptime_ms,motion_sequence:packet.sequence,direct_realtime:true,direct_demo:motion};
  }
  function renderDirectRealtimeReadings(){
    const packet=directMotionPacket();if(!packet)return;
    let fresh=realtimeFresh(packet),snap=packet.direct_demo,can=fresh&&snap.can_fresh!==false&&snap.state!=="can_stale"&&packet.ecu?.online!==false;
    if(!fresh&&snap.can_fresh!==false&&snap.state!=="can_stale"&&packet.ecu?.online!==false){
      const latest=state.data?.latest,durable=directSnapshot(latest),session=directView.session;
      // An expired motion frame must not erase an independent current CAN
      // snapshot. Keep the same 1.5s budget and exact scope; never override an
      // explicit CAN loss with an older success that merely arrived later.
      const sameSource=latest?.device_id===session?.virtual_device_id&&latest?.device_id===currentDeviceId()&&
        latest?.boot_id===session?.session_id&&durable?.session_id===session?.session_id&&
        Number(durable?.pass_index)===Number(session?.last_snapshot?.pass_index??session?.pass_index)&&
        (!session?.physical_boot_id||!latest?.physical_boot_id||latest.physical_boot_id===session.physical_boot_id);
      if(sameSource&&telemetryFresh(latest,DIRECT_REALTIME_MAX_AGE_MS)){
        snap=durable;fresh=true;can=truth(latest.ecu_online)&&number(latest.ecu_speed_kph)!==null&&durable.can_fresh!==false&&durable.state!=="can_stale";
        snap={...durable,input_speed_kph:latest.ecu_speed_kph};
      }
    }
    setText("gnss-speed",fmt(fresh?snap.speed_kph:null));
    setText("speed",fmt(can?snap.input_speed_kph:null));
    setText("speed-source",can?"CAN":"—");
    const limit=number(state.deviceConfig?.overspeed_warning_kph,120),over=can&&number(snap.input_speed_kph,0)>limit;
    $("speed-card").className=`metric ${over?"tone-red":"tone-cyan"}`;
    if(over)setText("speed-source","CẢNH BÁO");
    setText("speed-note",!fresh?"Luồng chuyển động đã cũ — giữ vị trí cuối":!can?"Chờ tốc độ CAN mới":over?`QUÁ TỐC: ${fmt(snap.input_speed_kph)} km/h > ${fmt(limit)} km/h`:"Nguồn chính: ECU · CAN 0x101 · cập nhật trực tiếp");
  }
  function applyDirectRealtime(packet){
    const session=directView.session,snap=packet?.direct_demo;
    if(state.mode!=="live"||!session||!window.TelematicsDirectGeometry.confirmed(session.state)||packet?.device_id!==currentDeviceId()||packet.device_id!==session.virtual_device_id||snap?.session_id!==session.session_id||!realtimeFresh(packet))return false;
    if(session.physical_boot_id&&packet.boot_id!==session.physical_boot_id)return false;
    if(packet.source_device_id!==session.device_id||!Number.isFinite(snap.distance_m)||snap.distance_m<0||!Number.isFinite(snap.speed_kph)||!Number.isInteger(packet.sequence)||packet.sequence<0||packet.sequence>0xffffffff||!Number.isInteger(captureMs(snap))||captureMs(snap)<0||captureMs(snap)>0xffffffff||!Number.isInteger(snap.pass_index)||snap.pass_index<1||!window.TelematicsDirectGeometry.confirmed(snap.state))return false;
    const previous=directRealtime.packet;
    if(previous?.direct_demo?.session_id===snap.session_id){
      if(previous.boot_id!==packet.boot_id||!newerUint32(packet.sequence,previous.sequence)||!newerUint32(captureMs(snap),captureMs(previous.direct_demo)))return false;
      if(Number(snap.pass_index)<Number(previous.direct_demo.pass_index))return false;
    }
    const durable=session.last_snapshot;
    if(durable&&Number(snap.pass_index)<Number(durable.pass_index))return false;
    if(durable&&captureMs(durable)!==null&&newerUint32(captureMs(durable),captureMs(snap)))return false;
    const stored=directSnapshot(state.data?.latest);
    const storedCapture=captureMs(stored)??number(state.data?.latest?.uptime_ms);
    if(stored?.session_id===snap.session_id&&(Number(stored.pass_index)>Number(snap.pass_index)||(storedCapture!==null&&newerUint32(storedCapture,captureMs(snap)))))return false;
    directRealtime.packet=packet;
    const latest=directMapLatest(state.data?.latest),pos=[latest.lat,latest.lon];
    if(!state.vehicleCore)updateMap({...state.data,latest});
    else animateDirectVehicle(latest,pos);
    renderDirectRealtimeReadings();return true;
  }
  const demoDisplay={clientId:globalThis.crypto?.randomUUID?.()||`view-${Date.now()}-${Math.random().toString(36).slice(2)}`,sequence:0,lastAt:-Infinity,pending:false};
  const vehicleMotion={frame:0,key:"",source:"",sampleMs:0,displayMs:0,target:null,displayed:null,path:[],lengths:[],total:0,start:0,duration:200,routeRows:[],hazardsAt:0};
  function reportDisplayedDemoPosition(pos){
    const latest=state.data?.latest,now=performance.now();
    if(demoDisplay.pending||now-demoDisplay.lastAt<200||document.visibilityState==="hidden"||state.mode!=="live"||!isAutoDemoDevice(latest?.device_id)||!latest.boot_id||state.displayedRoute?.status!=="active"||!telemetryFresh(latest))return;
    demoDisplay.lastAt=now;demoDisplay.pending=true;
    // A report acknowledges the position actually displayed by this page.
    // The server leases one visible page and rechecks this position before
    // sending audio, so a newer telemetry point cannot trigger early audio.
    const body={session_id:String(latest.boot_id),client_id:demoDisplay.clientId,sequence:++demoDisplay.sequence,position:{lat:pos[0],lon:pos[1]}};
    fetch("/api/demo/display-position",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body),signal:AbortSignal.timeout(1500)})
      .catch(()=>{}).finally(()=>{demoDisplay.pending=false;});
  }
  function stopVehicleMotion(reset=false){
    cancelAnimationFrame(vehicleMotion.frame);vehicleMotion.frame=0;
    if(reset){vehicleMotion.key="";vehicleMotion.source="";vehicleMotion.target=null;vehicleMotion.displayed=null;vehicleMotion.sampleMs=0;vehicleMotion.displayMs=0;vehicleMotion.routeRows=[];vehicleMotion.hazardsAt=0;vehicleMotion.directDistance=null;vehicleMotion.directPass=null;}
  }
  function drawVehiclePosition(pos){
    vehicleMotion.displayed=pos.slice();
    state.vehicleHalo?.setLatLng(pos);state.vehicleCore?.setLatLng(pos);
    if(isMovingDemoDevice(state.data?.latest?.device_id)&&state.displayedRoute?.status==="active"&&(vehicleMotion.routeRows.length||directView.route)){
      // The live trail ends at the displayed vehicle, not the newer packet that
      // is still being interpolated. Completed/saved routes are never changed.
      const segments=isDirectDemoDevice(state.data?.latest?.device_id)&&directView.route&&Number.isFinite(vehicleMotion.directDistance)
        ? [window.TelematicsDirectGeometry.path(directView.route,0,vehicleMotion.directDistance)]
        : window.TelematicsRouteGeometry.splitRouteSegments(vehicleMotion.routeRows.filter(row=>timeMs(row.ingested_at)<=vehicleMotion.displayMs)).map(segment=>segment.map(row=>[number(row.lat),number(row.lon)]));
      if(!segments.length)segments.push([]);
      segments[segments.length-1].push(pos.slice());state.routeCasing?.setLatLngs(segments);state.routeCore?.setLatLngs(segments);
    }
    if(isMovingDemoDevice(state.data?.latest?.device_id)){
      setText("map-coords",`${fmt(pos[0],6)}, ${fmt(pos[1],6)}`);
      // Distances and the in-range highlight follow the marker being painted,
      // not the newer server packet at the far end of the animation.
      const now=performance.now();
      if(now-vehicleMotion.hazardsAt>=100){vehicleMotion.hazardsAt=now;reconcileHazards(state.data,pos);}
      reportDisplayedDemoPosition(pos);
    }
  }
  function animateDemoVehicle(latest,pos,routeRows){
    const source=`${latest.device_id}:${latest.boot_id||""}:${state.sourceGeneration}`;
    const key=`${source}:${latest.sequence??latest.id??latest.ingested_at}`;
    // A refresh for events/config/ACK must not restart the same animation.
    if(key===vehicleMotion.key){if(vehicleMotion.displayed)drawVehiclePosition(vehicleMotion.displayed);return;}
    const sampleMs=timeMs(latest.ingested_at),previousMs=vehicleMotion.sampleMs;
    const discontinuity=source!==vehicleMotion.source||!vehicleMotion.displayed||!previousMs||sampleMs-previousMs>2500||sampleMs<=previousMs;
    vehicleMotion.key=key;vehicleMotion.source=source;vehicleMotion.sampleMs=sampleMs;
    stopVehicleMotion();
    if(discontinuity){vehicleMotion.target=pos.slice();vehicleMotion.displayMs=sampleMs;drawVehiclePosition(pos);return;}
    const from=vehicleMotion.displayed.slice(),fromMs=vehicleMotion.displayMs,path=[from];
    if(vehicleMotion.target)path.push(vehicleMotion.target.slice());
    const intermediate=(routeRows||[]).filter(row=>hasCoords(row)&&timeMs(row.ingested_at)>previousMs&&timeMs(row.ingested_at)<=sampleMs);
    if(intermediate.some(row=>truth(row.segment_start))){vehicleMotion.target=pos.slice();vehicleMotion.displayMs=sampleMs;drawVehiclePosition(pos);return;}
    // Follow received road vertices across corners instead of drawing a chord.
    for(const row of intermediate)path.push([number(row.lat),number(row.lon)]);
    path.push(pos.slice());vehicleMotion.target=pos.slice();
    vehicleMotion.path=path;vehicleMotion.lengths=[];vehicleMotion.total=0;
    for(let i=1;i<path.length;i++){const length=haversine(path[i-1],path[i])*1000;vehicleMotion.lengths.push(length);vehicleMotion.total+=length;}
    if(vehicleMotion.total<.001){vehicleMotion.displayMs=sampleMs;drawVehiclePosition(pos);return;}
    vehicleMotion.start=performance.now();vehicleMotion.duration=Math.max(80,Math.min(300,sampleMs-previousMs));
    drawVehiclePosition(from);
    const frame=now=>{
      const fraction=Math.min(1,(now-vehicleMotion.start)/vehicleMotion.duration);
      let remaining=vehicleMotion.total*fraction,point=pos;
      for(let i=0;i<vehicleMotion.lengths.length;i++){
        const length=vehicleMotion.lengths[i];
        if(remaining<=length&&length>0){const f=remaining/length,a=path[i],b=path[i+1];point=[a[0]+(b[0]-a[0])*f,a[1]+(b[1]-a[1])*f];break;}
        remaining-=length;
      }
      vehicleMotion.displayMs=fromMs+(sampleMs-fromMs)*fraction;drawVehiclePosition(point);
      vehicleMotion.frame=fraction<1?requestAnimationFrame(frame):0;
    };
    vehicleMotion.frame=requestAnimationFrame(frame);
  }
  function directSnapshot(latest){
    if(latest?.direct_demo)return latest.direct_demo;
    try{return JSON.parse(latest?.raw_json||"{}").direct_demo||null;}catch{return null;}
  }
  function animateDirectVehicle(latest,pos){
    const snapshot=directSnapshot(latest),route=directView.route;
    if(!route||snapshot?.session_id!==directView.session?.session_id||!Number.isFinite(snapshot.distance_m)){stopVehicleMotion(true);drawVehiclePosition(pos);return;}
    const source=`${latest.device_id}:${snapshot.session_id}:${state.sourceGeneration}`;
    const key=`${source}:${captureMs(snapshot)===null?latest.sequence??latest.id??latest.ingested_at:`capture-${captureMs(snapshot)}`}`;
    if(key===vehicleMotion.key){if(vehicleMotion.displayed)drawVehiclePosition(vehicleMotion.displayed);return;}
    const sampleMs=timeMs(latest.ingested_at),previousMs=vehicleMotion.sampleMs,oldDistance=directView.confirmedDistance,to=Math.max(0,Math.min(route.total,snapshot.distance_m));
    const discontinuity=source!==vehicleMotion.source||vehicleMotion.directPass!==snapshot.pass_index||oldDistance===null||!previousMs||sampleMs<=previousMs||sampleMs-previousMs>2500||to<oldDistance||(latest.direct_realtime&&(snapshot.state!=="running"||number(snapshot.speed_kph,0)<=0));
    stopVehicleMotion();vehicleMotion.key=key;vehicleMotion.source=source;vehicleMotion.sampleMs=sampleMs;vehicleMotion.directPass=snapshot.pass_index;directView.confirmedDistance=to;
    if(discontinuity){vehicleMotion.directDistance=to;vehicleMotion.displayMs=sampleMs;drawVehiclePosition(window.TelematicsDirectGeometry.at(route,to));return;}
    const from=Number.isFinite(vehicleMotion.directDistance)?vehicleMotion.directDistance:oldDistance,fromMs=vehicleMotion.displayMs,start=performance.now();
    // Only interpolate BETWEEN confirmed firmware distances, never extrapolate.
    // A missing/stale packet freezes the marker at the last confirmed endpoint.
    const duration=Math.max(60,Math.min(latest.direct_realtime?160:1200,sampleMs-previousMs));
    const frame=now=>{const f=Math.min(1,(now-start)/duration),d=from+(to-from)*f;vehicleMotion.directDistance=d;vehicleMotion.displayMs=fromMs+(sampleMs-fromMs)*f;drawVehiclePosition(window.TelematicsDirectGeometry.at(route,d));vehicleMotion.frame=f<1?requestAnimationFrame(frame):0;};
    vehicleMotion.frame=requestAnimationFrame(frame);
  }
  function clearDirectMapView(){
    if(!directView.rotated)return;
    cancelRouteRequests();
    const map=state.map,element=$("map");
    directView.rotated=false;directView.preview=null;directView.key="";directView.confirmedDistance=null;directRealtime.packet=null;
    $("map-card").classList.remove("direct-map-active","direct-route-open");$("direct-map-label").hidden=true;
    $("direct-route-toggle").hidden=true;$("direct-route-toggle").setAttribute("aria-expanded","false");
    element.style.cssText="";$("map-card").style.removeProperty("--direct-counter-angle");
    if(directView.controls)element.append(directView.controls);
    for(const handler of directView.handlers)handler.enable();directView.handlers=[];
    if(directView.layer){map.removeLayer(directView.layer);directView.layer=null;}
    stopVehicleMotion(true);map.invalidateSize({animate:false,pan:false});state.mapFitted=false;
  }
  function fitDirectMap(){
    const map=state.map,r=directView.route,host=$("map-card"),element=$("map");if(!map||!r||!directView.rotated)return;
    const w=host.clientWidth,h=host.clientHeight,side=Math.ceil(Math.hypot(w,h))+4,view=window.TelematicsDirectGeometry.view(r,w,h);
    Object.assign(element.style,{inset:"auto",width:`${side}px`,height:`${side}px`,left:"50%",top:"50%",transform:`translate(-50%,-50%) rotate(${view.angle}deg)`,transformOrigin:"50% 50%",pointerEvents:"none"});
    host.style.setProperty("--direct-counter-angle",`${-view.angle}deg`);
    map.invalidateSize({animate:false,pan:false});map.setView(view.center,view.zoom,{animate:false});state.mapFitted=true;
  }
  function setDirectMapView(session,preview=false){
    initMap();if(!state.map||!window.TelematicsDirectGeometry)return false;
    if(!session?.route?.points)return false;
    const key=`${session.session_id||"preview"}:${session.route.id||JSON.stringify(session.route.points)}`;
    if(key===directView.key&&directView.rotated){
      if(directRouteScope(directView.session)!==directRouteScope(preview?null:session))cancelRouteRequests();
      directView.session=preview?null:session;return true;
    }
    const r=window.TelematicsDirectGeometry.route(session.route.points);if(!r)return false;
    clearDirectMapView();directView.key=key;directView.route=r;directView.session=preview?null:session;directView.preview=preview?session.route:null;directView.rotated=true;
    const map=state.map,element=$("map"),host=$("map-card");
    directView.controls=element.querySelector(".leaflet-control-container");if(directView.controls)host.append(directView.controls);
    for(const name of["dragging","scrollWheelZoom","doubleClickZoom","touchZoom","boxZoom","keyboard"]){const handler=map[name];if(handler?.enabled()){directView.handlers.push(handler);handler.disable();}}
    directView.layer=window.L.polyline(r.points,{pane:"route-casing",color:"#087f8c",weight:5,opacity:.45,dashArray:"8 9",interactive:false}).addTo(map);
    host.classList.add("direct-map-active");$("direct-route-toggle").hidden=false;$("direct-map-label").hidden=false;$("direct-map-label").textContent=preview?"Xem trước đường demo · trái → phải":"Tọa độ mô phỏng – AI thực · trái → phải";
    map.closePopup();fitDirectMap();return true;
  }
  const sdTransientStates=new Set(["boot_settling","mounting","verifying","post_mount_settle","post_audio_settle","post_audio_verify"]);
  const sdStateLabels={boot_settling:"Đang ổn định nguồn",mounting:"Đang nhận thẻ",verifying:"Đang kiểm tra thẻ",post_mount_settle:"Đã nhận thẻ · chờ ghi",post_audio_settle:"Đang ổn định sau loa",post_audio_verify:"Đang kiểm tra sau loa",retry_wait:"Đang tự thử lại",online:"Đang ghi log",degraded:"Online · khôi phục hàng đợi",full:"Thẻ đầy vật lý",log_quota:"Đủ hạn mức log ngày"};
  const demoRoute = [[10.77595,106.70010],[10.77640,106.70108],[10.77688,106.70215],[10.77748,106.70308],[10.77818,106.70402],[10.77892,106.70492],[10.77946,106.70575],[10.78015,106.70664],[10.78085,106.70745],[10.78148,106.70828],[10.78205,106.70920],[10.78262,106.71002]];

  function number(value, fallback = null) { if (value === null || value === undefined || value === "") return fallback; const parsed = Number(value); return Number.isFinite(parsed) ? parsed : fallback; }
  function truth(value) { return value === true || value === 1 || value === "1"; }
  function fmt(value, digits = 0) { const parsed = number(value); return parsed === null ? "—" : new Intl.NumberFormat("vi-VN", { maximumFractionDigits: digits, minimumFractionDigits: digits }).format(parsed); }
  function bytes(value) { const size = number(value); if (size === null) return "—"; return size < 1024 ? `${fmt(size)} B` : size < 1048576 ? `${fmt(size / 1024, 1)} KB` : size < 1073741824 ? `${fmt(size / 1048576, 1)} MB` : `${fmt(size / 1073741824, 2)} GB`; }
  function sdCardType(value) { const type=String(value||"").toLowerCase(); return type==="sdhc_sdxc"?"SDHC/SDXC":type==="sdsc"?"SDSC":type==="mmc"?"MMC":type?type.toUpperCase():"Chưa rõ loại"; }
  function clock(value) { const date = new Date(typeof value === "number" ? value : String(value ?? "")); return Number.isNaN(date.getTime()) ? "--:--:--" : date.toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit", second: "2-digit" }); }
  function dateTime(value) { const date = new Date(typeof value === "number" ? value : String(value ?? "")); return Number.isNaN(date.getTime()) ? "—" : date.toLocaleString("vi-VN", { day:"2-digit", month:"2-digit", year:"numeric", hour:"2-digit", minute:"2-digit", second:"2-digit" }); }
  function timeMs(value) { const parsed = typeof value === "number" ? value : Date.parse(String(value ?? "")); return Number.isFinite(parsed) ? parsed : 0; }
  function hasCoords(row) { const lat = number(row?.lat), lon = number(row?.lon); return lat !== null && lon !== null && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180; }
  function hasGnssFix(row) {
    return truth(row?.location_valid) && hasCoords(row) &&
      (number(row?.gnss_filter_version) === null ||
        (number(row.gnss_filter_version) === 1 && ["stationary", "moving"].includes(row.gnss_filter_state)));
  }
  function gnssLabel(row, fresh) {
    if (!fresh || !hasGnssFix(row)) return "Chờ GPS";
    if (number(row?.gnss_filter_version) === null) return "Đã định vị";
    return truth(row.gnss_stationary) ? "Giữ vị trí" : "Đang di chuyển";
  }
  function gnssDetail(row, fresh) {
    if (!fresh) return "Gateway chưa có dữ liệu mới; tọa độ cũ không phải phép đo hiện tại.";
    if (number(row?.gnss_filter_version) === null) return "Firmware cũ / demo: chưa cung cấp trạng thái bộ lọc GNSS.";
    return `GNSS ${row.gnss_filter_state || "invalid"} · GPS gốc: ${fmt(row.gnss_raw_lat,6)}, ${fmt(row.gnss_raw_lon,6)} · ${fmt(row.gnss_raw_speed_kph,1)} km/h\n` +
      `Sau lọc: ${fmt(row.lat,6)}, ${fmt(row.lon,6)} · ${fmt(row.speed_kph,1)} km/h · Fix #${fmt(row.gnss_fix_seq)} · Bỏ qua ${fmt(row.gnss_rejected_fixes)} mẫu`;
  }
  function monotonicTimeMs(){return typeof performance!=="undefined"&&typeof performance.now==="function"?performance.now():Date.now();}
  function serverTimeMs() {
    const clock=state.serverClock;
    return clock?clock.value+Math.max(0,clock.receivedTick===undefined?Date.now()-clock.receivedAt:monotonicTimeMs()-clock.receivedTick):Date.now();
  }
  function rememberServerClock(data) {
    const raw=timeMs(data?.server_now);if(!raw)return;
    const receivedAt=Date.now(),receivedTick=monotonicTimeMs(),measured=number(data?.transport_delay_ms),delay=measured===null?null:Math.max(0,measured);
    // A slow query's conservative transit bound belongs only to ITS frame,
    // not the common clock used by unrelated faster sensor/motion requests.
    const frame=data?.direct_realtime,frameTime=number(frame?.received_at_ms);
    if(frame&&typeof frame==='object'&&frameTime!==null&&delay!==null)
      directTransportAges.set(frame,{age:Math.max(0,raw-frameTime)+delay,receivedTick});
    const current=state.serverClock;
    const calibrated=current&&current.roundtripMs!==null&&current.roundtripMs!==undefined;
    const qualityExpired=current&&receivedTick-number(current.qualityWindowTick,current.receivedTick??receivedTick)>=30000;
    if(current){
      const before=number(current.serverNow,current.value);
      if(raw<before||(raw===before&&calibrated))return;
      if(calibrated&&(delay===null||(delay>current.roundtripMs&&!qualityExpired)))return;
    }
    // Refresh calibration quality after 30s without jumping by a slow RTT.
    // Intersect the response interval with the existing monotonic projection.
    const value=calibrated?Math.min(raw+delay,Math.max(raw,serverTimeMs())):raw+(delay??0);
    state.serverClock={value,receivedAt,receivedTick,serverNow:raw,roundtripMs:delay,
      qualityWindowTick:!current||qualityExpired?receivedTick:(current.qualityWindowTick??receivedTick)};
  }
  function telemetryFresh(row, maxAgeMs = 10000) { const t=timeMs(row?.ingested_at),age=serverTimeMs()-t; return t>0 && age>=-1000 && age<maxAgeMs; }
  function roadState(latest,data=state.data) {
    return window.TelematicsRoadState.resolve(latest,data?.road_current,{mode:state.mode,now:Date.now(),receivedAt:data?._received_at,serverNow:data?.server_now,transportDelay:data?.transport_delay_ms});
  }
  function newestSnapshot(incoming,current) {
    // Preserve confirmed events received after an older history snapshot was
    // taken. A current server snapshot (including deletions) is authoritative.
    const snapshotTime=timeMs(incoming?.server_now);
    if(snapshotTime&&current?.device_id===incoming?.device_id){
      const newer=(current.events||[]).filter(event=>timeMs(event.ingested_at)>snapshotTime);
      if(newer.length){
        incoming={...incoming,events:[...(incoming.events||[])],potholes:[...(incoming.potholes||[])],speed_bumps:[...(incoming.speed_bumps||[])]};
        for(const event of newer){
          upsertEventRow(incoming.events,event);
          if(event.name==='pothole_detected')upsertHazardEvent(incoming.potholes,event);
          if(event.name==='speed_bump_detected')upsertHazardEvent(incoming.speed_bumps,event);
        }
      }
    }
    // A slow history response must not replace a more recent lightweight packet.
    if(current?.latest&&incoming?.latest&&String(current.latest.device_id)===String(incoming.latest.device_id)&&timeMs(current.latest.ingested_at)>timeMs(incoming.latest.ingested_at)){
      return {...incoming,latest:current.latest,road_current:current.road_current,server_now:current.server_now,transport_delay_ms:current.transport_delay_ms,_received_at:current._received_at};
    }
    return incoming;
  }
  function sdPresentation(row,fresh,demoSource=false){
    if(demoSource)return {tone:"wait",label:"Demo tách biệt · MicroSD N/A",health:"Không kiểm tra phần cứng trong demo"};
    if(!fresh)return {tone:"bad",label:"Không có trạng thái MicroSD",health:"Gateway ngoại tuyến"};
    const state=String(row?.sd_state||""),error=String(row?.sd_last_error||"unknown"),block=String(row?.sd_write_block_reason||"none");
    const retryGrace=state==="retry_wait"&&number(row?.uptime_ms,0)<30000;
    if(block==="physical_full"||state==="full"||error==="storage_full")return {tone:"bad",label:"MicroSD đầy · đã dừng ghi",health:"Thẻ đầy vật lý · cần sao lưu và xóa log"};
    if(block==="daily_log_quota"||state==="log_quota"||error==="daily_log_quota")return {tone:"wait",label:"MicroSD online · đủ hạn mức log ngày",health:"Đủ hạn mức log ngày · thẻ vẫn được nhận"};
    if(sdTransientStates.has(state)||truth(row?.sd_recovery_busy)||retryGrace)return {tone:"wait",label:`MicroSD · ${sdStateLabels[state]||"đang khởi tạo"}`,health:`${sdStateLabels[state]||"Đang khởi tạo"} · ${error}`};
    if(truth(row?.sd_ok))return {tone:"ok",label:state==="degraded"?"MicroSD online · đang phục hồi hàng đợi":"MicroSD sẵn sàng",health:sdStateLabels[state]||"Đang ghi log"};
    return {tone:"bad",label:`Lỗi MicroSD · ${error}`,health:`Không mount được · ${error}`};
  }
  function haversine(a, b) { const p = Math.PI / 180, dp = (b[0] - a[0]) * p, dl = (b[1] - a[1]) * p; const h = Math.sin(dp / 2) ** 2 + Math.cos(a[0] * p) * Math.cos(b[0] * p) * Math.sin(dl / 2) ** 2; return 6371 * 2 * Math.atan2(Math.sqrt(Math.min(1, h)), Math.sqrt(Math.max(0, 1 - h))); }

  function makeDemo(tick) {
    const index = tick % demoRoute.length, now = Date.now();
    const telemetry = Array.from({ length: 54 }, (_, i) => {
      const point = demoRoute[(index + i + demoRoute.length - 53) % demoRoute.length], wave = i / 3;
      return { id:i, ingested_at:now-(53-i)*1000, recorded_at:new Date(now-(53-i)*1000).toISOString(), lat:point[0], lon:point[1], speed_kph:35+Math.sin(wave)*8, ecu_speed_kph:36+Math.sin(wave)*8, rpm:null, temperature_c:82+Math.sin(wave*.25)*2.8, satellites:12, hdop:.9, altitude_m:8.4, course_deg:64, ecu_online:1, ecu_uptime_s:7240+i, ecu_status:0, adc_raw:2048, dtc_code:0, dtc_severity:0, dtc_active:0, road_valid:1, road_label:i===39?"go_giam_toc":"duong_bang_phang", confidence:.96+Math.sin(wave)*.02, flat_confidence:.967, speed_bump_confidence:.021, pothole_confidence:.012, inference_ms:18, x_g:Math.sin(wave*2)*.11, y_g:Math.cos(wave*1.6)*.08, z_g:1+Math.sin(wave*2.4)*.13, sd_ok:1, wifi_rssi:-56, free_heap:238400, free_psram:8165000, queue_bytes:0, trip_distance_km:4.82, location_valid:1, device_id:"blackbox-esp32s3-demo" };
    });
    return { latest:telemetry.at(-1), telemetry, potholes:[
      {id:1,lat:10.77818,lon:106.70402,confidence:.957,recorded_at:new Date(now-246000).toISOString()},
      {id:2,lat:10.78148,lon:106.70828,confidence:.934,recorded_at:new Date(now-712000).toISOString()},
    ], speed_bumps:[
      {id:3,lat:10.78015,lon:106.70664,confidence:.989,recorded_at:new Date(now-92000).toISOString()},
    ], events:[
      {id:1,name:"pothole_proximity",severity:"warning",distance_m:8.4,recorded_at:new Date(now-18000).toISOString(),lat:10.77818,lon:106.70402},
      {id:2,name:"speed_bump_detected",severity:"info",recorded_at:new Date(now-92000).toISOString(),confidence:.989,lat:10.78015,lon:106.70664},
      {id:3,name:"pothole_detected",severity:"warning",recorded_at:new Date(now-246000).toISOString(),confidence:.957,gps_attached:1,new_map_point:1,saved_to_sd:1},
      {id:4,name:"ecu_recovered",severity:"success",recorded_at:new Date(now-420000).toISOString()},
    ] };
  }

  function setText(id, value) { const node = $(id); if (node) node.textContent = value; }
  function setHealth(id, textValue, ok, tone = null) { const node = $(id); if (!node) return; node.textContent = textValue; node.className = tone || (ok ? "good" : "warn"); }
  function setGauge(id, value, max) { const node = $(id), parsed = number(value); const pct = parsed === null ? 0 : Math.min(100, Math.max(0, parsed / max * 100)); node?.style.setProperty("--gauge", `${pct * 3.6}deg`); }

  function statusPill(ok, label, tone = null) { const node = document.createElement("span"); node.className = `status-pill ${tone || (ok ? "ok" : "bad")}`; const dot = document.createElement("i"); node.append(dot, document.createTextNode(label)); return node; }
  function renderStatuses(latest, fresh, roadValid) {
    const strip = $("status-strip"), ecu = fresh && truth(latest.ecu_online), gps = fresh && hasGnssFix(latest), demoSource=state.mode==="demo"||isAutoDemoDevice(latest.device_id), sdView=sdPresentation(latest,fresh,demoSource), dtc = fresh && ecu && truth(latest.dtc_active);
    const speedWarn=number(state.deviceConfig?.overspeed_warning_kph,120), ecuSpeed = ecu ? number(latest.ecu_speed_kph) : null, overspeed = ecu && (truth(latest.overspeed) || (ecuSpeed !== null && ecuSpeed > speedWarn));
    strip.replaceChildren(
      statusPill(fresh, fresh ? "Gateway trực tuyến" : "Mất kết nối Gateway"),
      statusPill(ecu, ecu ? "ECU trực tuyến" : "ECU ngoại tuyến"),
      statusPill(gps, gps ? `GNSS · ${fmt(latest.satellites)} vệ tinh` : "Chưa có GPS"),
      statusPill(roadValid, demoSource ? "TinyML · dữ liệu demo riêng" : roadValid ? "TinyML sẵn sàng" : "TinyML mất dữ liệu",demoSource?"wait":null),
      statusPill(sdView.tone==="ok",sdView.label,sdView.tone),
      statusPill(!dtc, dtc ? `DTC ${fmt(latest.dtc_code)}` : "Không có DTC"),
      statusPill(!overspeed, overspeed ? `QUÁ TỐC ${fmt(ecuSpeed)} km/h` : `Tốc độ ≤ ${fmt(speedWarn)} km/h`)
    );
    const sync = document.createElement("span"); sync.className = "last-sync"; sync.textContent = `Cập nhật ${clock(latest.recorded_at ?? latest.ingested_at)}`; strip.append(sync);
  }

  function routeDistance(rows) { const points = rows.filter(hasGnssFix); return points.reduce((sum, row, i) => i ? sum + haversine([number(points[i-1].lat),number(points[i-1].lon)],[number(row.lat),number(row.lon)]) : 0, 0); }

  function renderRoad(latest, data=state.data) {
    const current=roadState(latest,data),roadValid=current.valid,shown=current.label,confidence=current.confidence;
    const badge = $("road-badge"); badge.textContent = current.demo ? "DEMO" : roadValid ? "AI THỰC" : "CHỜ AI"; badge.classList.toggle("stale", !roadValid&&!current.demo);badge.classList.toggle("demo",current.demo);
    $("road-result").className = `road-result road-${shown}`;
    setText("road-icon", shown === "o_ga" ? "!" : shown === "go_giam_toc" ? "≋" : shown === "unknown" ? "?" : "✓");
    setText("road-title",current.demo ? "Demo tự động — không đo mặt đường hiện tại" : roadValid ? roadLabels[shown] : "Chờ dữ liệu TinyML mới");
    const reasons={gateway_offline:"Gateway ngoại tuyến",ai_not_ready:"Chờ cảm biến",ai_stale:"Chờ AI mới",missing:"Chưa có dữ liệu"};
    setText("road-confidence", current.demo ? "Dữ liệu mô phỏng" : roadValid ? `Độ tin cậy ${fmt(confidence * 100, 1)}%` : reasons[current.reason]||"Chờ AI");
    $("confidence-bar").style.width = `${roadValid ? Math.min(100, confidence * 100) : 0}%`;
    const scores = [["flat",current.scores.duong_bang_phang],["bump",current.scores.go_giam_toc],["pothole",current.scores.o_ga]];
    for (const [key, value] of scores) { const available=roadValid&&value!==null,pct=available?value*100:0;$(`score-${key}-bar`).style.width=`${pct}%`;setText(`score-${key}`,available?`${fmt(pct,1)}%`:"—"); }
    for(const axis of ["x","y","z"]){const value=current[`${axis}_g`];setText(`axis-${axis}`,roadValid&&value!==null?`${fmt(value,3)} g`:"—");}
    setText("road-source",current.demo?"Demo tự động":isDirectDemoDevice(latest.device_id)?"ADXL345 thật · vị trí mô phỏng":"ADXL345 · ESP32-S3");
    setText("road-updated",roadValid?`${clock(current.sample_time_ms||current.received_at)} · ${fmt(Math.max(0,current.age_ms)/1000,1)} s`:current.demo?"Mô phỏng":"Chờ AI");
    setText("model-note", "");
    if($("model-note"))$("model-note").hidden=true;
    const admission=current.event;
    const admissionText={warmup:"Đang ổn định",scope_settling:"Đang thu mẫu",flat:"",below_threshold:`Chưa đạt ngưỡng ${fmt(number(admission?.threshold,0)*100)}%`,pending_confirmation:`Đang xác nhận (${fmt(admission?.candidate_windows)}/${fmt(admission?.required_windows)})`,confirmed:"Đã xác nhận",latched:"Đã ghi nhận"};
    let markerNote=roadValid?(admissionText[admission?.state]||""):"";
    const confirmed=roadValid&&["confirmed","latched"].includes(admission?.state)&&(!admission.last_event_label||admission.last_event_label===shown);
    if(confirmed&&admission.last_event_reason==='no_position')markerNote="Chưa có vị trí";
    else if(confirmed&&admission.last_event_reason==='capacity_full')markerNote="Danh mục điểm đã đầy";
    const stored=(data?.events||[]).some(event=>String(event.event_uid||event.id||'')===String(admission?.last_event_id||''));
    if(confirmed&&admission.last_event_id&&stored&&admission.last_event_label===shown&&admission.last_event_position_attached)markerNote="Đã ghi điểm";
    if($("road-event-status")){setText("road-event-status",markerNote);$("road-event-status").hidden=!markerNote;}
    return current;
  }

  function renderHealth(latest, fresh) {
    const ecu = fresh && truth(latest.ecu_online), gps = fresh && hasGnssFix(latest), demoSource=state.mode==="demo"||isAutoDemoDevice(latest.device_id), sdView=sdPresentation(latest,fresh,demoSource), queue = number(latest.queue_bytes), rssi = number(latest.wifi_rssi), uptime = number(latest.ecu_uptime_s);
    setText("sat-value", fmt(fresh?latest.satellites:null)); setGauge("sat-gauge", fresh?latest.satellites:null, 20);
    setText("rssi-value", fmt(rssi)); setGauge("rssi-gauge", rssi === null ? null : Math.max(0, Math.min(100, (rssi + 100) / 60 * 100)), 100);
    setText("hdop-value", fmt(fresh?latest.hdop:null,1)); setGauge("hdop-gauge", fresh?latest.hdop:null, 5);
    setHealth("health-can", ecu ? "Bình thường" : "Mất kết nối", ecu); setHealth("health-gps", gnssLabel(latest,fresh), gps); setHealth("health-sd",sdView.health,sdView.tone==="ok",sdView.tone==="ok"?"good":sdView.tone==="wait"?"wait":"warn");
    $("health-gps").title=gnssDetail(latest,fresh);
    setHealth("health-queue", queue === null ? "Chưa có dữ liệu" : queue === 0 ? "Đã đồng bộ" : `${bytes(queue)} chờ gửi`, fresh && queue === 0);
    setText("health-adc", fresh?`${fmt(latest.adc_raw)} · ${uptime === null ? "—" : `${fmt(uptime / 60)} phút`}`:"—"); setText("health-ecu-status", fmt(latest.ecu_status));
    setText("health-nav", `${fmt(latest.altitude_m,1)} m · ${fmt(latest.course_deg)}°`); setText("health-memory", `${bytes(latest.free_heap)} · ${bytes(latest.free_psram)}`);
    setText("health-adxl-overrun",fresh?`${fmt(latest.adxl_fifo_overruns)} · ${truth(latest.adxl_healthy)?"HEALTHY":"CHECK"}`:"—");setText("health-sd-errors",demoSource?"Không áp dụng trong demo":fresh?`${latest.sd_state||"legacy"} · ${latest.sd_last_error||"—"} · ${fmt(latest.sd_io_failures)} I/O · ${fmt(latest.sd_remounts)} remount`:"—");
    setText("health-sd-capacity",demoSource?"N/A trong demo":fresh?`${sdCardType(latest.sd_card_type)} · ${bytes(latest.sd_used_bytes)} / ${bytes(latest.sd_total_bytes)}`:"—");
    setText("health-sd-daily",demoSource?"N/A trong demo":fresh?`${bytes(latest.sd_daily_log_bytes)} / ${bytes(latest.sd_daily_log_quota_bytes)} · bỏ ${fmt(latest.sd_log_drop_count)} mẫu`:"—");
    setText("health-event-queue",fresh?bytes(latest.event_queue_bytes):"—");setText("health-version",fresh?`${latest.firmware_version||"—"} · ${latest.model_version||"—"}`:"—");
  }

  function clearSelfTestAutoHide(){
    clearTimeout(state.selfTestHideTimer);
    state.selfTestHideTimer=0;
  }
  function setSelfTestDetailsVisible(visible){
    const details=$("self-test-details"),toggle=$("self-test-toggle"),available=Boolean(state.selfTest);
    if(!details||!toggle)return;
    details.hidden=!visible||!available;
    toggle.hidden=!available;
    const expanded=available&&!details.hidden;
    toggle.setAttribute("aria-expanded",String(expanded));
    toggle.textContent=expanded?"Ẩn kết quả":"Xem kết quả";
  }
  function scheduleSelfTestAutoHide(){
    clearSelfTestAutoHide();
    if(!state.selfTest||state.selfTest.running)return;
    state.selfTestHideTimer=window.setTimeout(()=>{
      state.selfTestHideTimer=0;
      setSelfTestDetailsVisible(false);
    },SELF_TEST_AUTO_HIDE_MS);
  }
  async function runSelfTest(){
    const device=currentDeviceId();
    if(!device)return;
    const btn=$("self-test-btn");
    clearSelfTestAutoHide();
    if(state.mode==="demo"){
      state.selfTest={overall:"waiting",checks:[{key:"demo",label:"Self-test phần cứng",status:"wait",detail:"N/A · hãy chuyển về Dữ liệu trực tiếp"}],running:false};
      renderSelfTest();setSelfTestDetailsVisible(true);scheduleSelfTestAutoHide();return;
    }
    state.selfTest={overall:"waiting",checks:[],running:true};
    renderSelfTest();
    setSelfTestDetailsVisible(true);
    btn.disabled=true;
    btn.textContent="Đang chạy...";
    try{
      const r=await fetch(`/api/self-test?device_id=${encodeURIComponent(device)}`,{cache:"no-store"}),d=await r.json();
      if(!r.ok||!d.ok)throw new Error(d.error||`HTTP ${r.status}`);
      if(currentDeviceId()!==device)return;
      state.selfTest=d;
      renderSelfTest();
    }catch(e){
      if(currentDeviceId()!==device)return;
      state.selfTest={overall:"fail",checks:[],error:e.message};
      renderSelfTest();
    }finally{
      btn.disabled=false;
      btn.textContent="Chạy Self-test";
      scheduleSelfTestAutoHide();
    }
  }
  function renderSelfTest(){
    const d=state.selfTest,n=$("self-test-summary"),list=$("self-test-list");
    if(!d){
      n.textContent="Chưa chạy self-test.";
      n.className="self-test-summary";
      list.replaceChildren();
      setSelfTestDetailsVisible(false);
      return;
    }
    n.className=`self-test-summary ${d.overall}`;
    n.textContent=d.running?"Đang kiểm tra các khối hệ thống...":d.error?`Self-test lỗi: ${d.error}`:d.overall==="ready"?"SYSTEM READY · các khối chính đã sẵn sàng":d.overall==="waiting"?"SYSTEM WAITING · đang chờ một số khối":"SYSTEM FAIL · cần kiểm tra";
    list.replaceChildren();
    for(const c of d.checks||[]){
      const item=document.createElement("div"),a=document.createElement("span"),b=document.createElement("b");
      item.className="self-test-item";
      a.textContent=`${c.label}: ${c.detail||""}`;
      b.className=c.status;
      b.textContent=String(c.status).toUpperCase();
      item.append(a,b);
      list.append(item);
    }
  }

  const eventNames = { pothole_detected:"Phát hiện ổ gà", pothole_proximity:"Sắp đến gần ổ gà", speed_bump_detected:"Phát hiện gờ giảm tốc", speed_bump_proximity:"Sắp đến gần gờ giảm tốc", dtc_active:"Cảnh báo lỗi động cơ", overspeed:"Cảnh báo quá tốc", overspeed_cleared:"Đã hết cảnh báo quá tốc", ecu_recovered:"ECU đã kết nối lại", ecu_offline:"Mất kết nối ECU" };
  function eventDetail(event) {
    const replayPrefix=truth(event.is_resend)?"Đồng bộ lại từ MicroSD · ":"";
    if (event.name === "dtc_active") return `${replayPrefix}Mã DTC ${fmt(event.dtc_code)} · Mức ${fmt(event.dtc_severity)}`;
    if (event.name === "overspeed") return `${replayPrefix}Tốc độ ECU đã vượt ngưỡng ${fmt(state.deviceConfig?.overspeed_warning_kph ?? 120)} km/h`;
    if (event.name === "overspeed_cleared") return `${replayPrefix}Tốc độ đã giảm xuống vùng an toàn (≤${fmt(state.deviceConfig?.overspeed_clear_kph ?? 115)} km/h)`;
    if (truth(event.map_capacity_full)) return `${replayPrefix}Bộ nhớ bản đồ điểm cảnh báo đã đầy`;
    const parts = []; if (truth(event.is_resend)) parts.push("Đồng bộ lại từ MicroSD"); if (number(event.distance_m) !== null) parts.push(`Cách xe ${fmt(event.distance_m)} m`); if (number(event.confidence) !== null) parts.push(`Tin cậy ${fmt(number(event.confidence)*100,1)}%`);
    if (event.name === "pothole_detected" || event.name === "speed_bump_detected") { if (!truth(event.gps_attached)) parts.push("Chưa có tọa độ GPS"); else if (!truth(event.new_map_point)) parts.push("Điểm đã có trên bản đồ"); else parts.push(truth(event.saved_to_sd) ? "Đã lưu catalog SD" : "Event đã ghi bền vững · catalog SD lưu trễ"); }
    return parts.join(" · ") || "Hệ thống hoạt động bình thường";
  }
  function eventIdentity(event){return String(event?.event_uid||`id:${event?.id??"unknown"}`);}
  function eventTimestamp(event){return number(event?.event_time_ms,0)||number(event?.hazard_epoch,0)*1000||timeMs(event?.recorded_at)||number(event?.ingested_at,0);}
  function upsertEventRow(rows,event){
    const key=eventIdentity(event),index=rows.findIndex(item=>eventIdentity(item)===key),inserted=index<0;
    if(inserted)rows.unshift(event);else rows[index]={...rows[index],...event};
    rows.sort((a,b)=>eventTimestamp(b)-eventTimestamp(a)||number(b.id,0)-number(a.id,0));
    return inserted;
  }
  function eventMatchesFilters(event){
    const groups={pothole:["pothole_detected","pothole_proximity"],bump:["speed_bump_detected","speed_bump_proximity"],overspeed:["overspeed","overspeed_cleared"],dtc:["dtc_active"],system:["ecu_offline","ecu_recovered"]},category=$("event-category")?.value||"all",name=String(event?.name||"");
    if(category!=="all"&&!(groups[category]||[]).includes(name))return false;
    const timestamp=eventTimestamp(event),from=$("event-from")?.value,to=$("event-to")?.value;
    if(from&&timestamp<Date.parse(`${from}T00:00:00`))return false;if(to&&timestamp>Date.parse(`${to}T23:59:59.999`))return false;
    const query=$("event-query")?.value?.trim().toLowerCase();if(!query)return true;
    return [event.name,event.severity,event.event_uid,event.road_label,event.boot_id].some(value=>String(value||"").toLowerCase().includes(query));
  }
  function upsertHazardEvent(rows,event){
    if(!hasCoords(event)||event.gps_attached===0||event.gps_attached===false)return;
    const pos=[number(event.lat),number(event.lon)],index=rows.findIndex(item=>hasCoords(item)&&haversine(pos,[number(item.lat),number(item.lon)])*1000<=8);
    if(index<0)rows.unshift(event);else rows[index]={...rows[index],...event};
  }
  function mergeDashboardEvents(events){
    if(!state.eventCenterLoaded)return;
    for(const event of events||[])if(eventMatchesFilters(event))upsertEventRow(state.eventCenterEvents,event);
    state.eventTotal=Math.max(state.eventTotal,state.eventCenterEvents.length);
  }
  function acceptRealtimeEvent(detail){
    const event=detail?.event;if(!event||detail.suppressed||state.mode!=="live")return false;
    const device=String(event.device_id||detail.device_id||""),current=currentDeviceId();if(current&&device&&device!==current)return false;
    if(isDirectDemoDevice(device)&&directView.session?.session_id&&event.boot_id&&event.boot_id!==directView.session.session_id)return false;
    const live=state.liveData||{device_id:device||null,latest:null,telemetry:[],events:[],potholes:[],speed_bumps:[]};
    live.events=Array.isArray(live.events)?live.events:[];live.potholes=Array.isArray(live.potholes)?live.potholes:[];live.speed_bumps=Array.isArray(live.speed_bumps)?live.speed_bumps:[];
    upsertEventRow(live.events,event);
    if(event.name==="pothole_detected")upsertHazardEvent(live.potholes,event);
    if(event.name==="speed_bump_detected")upsertHazardEvent(live.speed_bumps,event);
    state.liveData=live;
    if(state.eventCenterLoaded&&eventMatchesFilters(event)){const inserted=upsertEventRow(state.eventCenterEvents,event);if(inserted)state.eventTotal=Math.max(state.eventTotal+1,state.eventCenterEvents.length);}
    render(live);
    return true;
  }
  function focusEventOnMap(event){if(!state.map||!hasCoords(event))return;const pos=[number(event.lat),number(event.lon)];state.map.setView(pos,Math.max(17,state.map.getZoom()),{animate:true});window.L.popup().setLatLng(pos).setContent(popup(eventNames[String(event.name)]||String(event.name||"Sự kiện"),eventDetail(event))).openOn(state.map);}
  function renderEvents(events,resetScroll=false){
    const total=state.mode==="live"&&state.eventCenterLoaded?state.eventTotal:events.length;
    setText("event-count",`${total} sự kiện`);
    const note=$("event-center-note");
    if(note)note.textContent=total>events.length?`Đã tải ${events.length}/${total} sự kiện · cuộn xuống cuối khung để tải tiếp.`:`Đã hiển thị đủ ${total} sự kiện · khung giữ chiều cao 5 dòng và có thể cuộn.`;
    const list=$("event-list"),previousTop=list.scrollTop,previousHeight=list.scrollHeight;
    list.replaceChildren();
    if(!events.length){const e=document.createElement("div");e.className="empty-state";e.textContent=state.eventFiltersApplied?"Không có sự kiện phù hợp bộ lọc":"Chưa có sự kiện từ ESP32";list.append(e);list.scrollTop=0;return;}
    for(const event of events){const row=document.createElement("div");row.className=`event-row severity-${String(event.severity||"info")}${hasCoords(event)?" clickable":""}`;const symbol=document.createElement("div");symbol.className="event-symbol";symbol.textContent=event.name?.startsWith("pothole")?"!":event.name?.startsWith("speed_bump")?"≋":event.name==="dtc_active"||event.name==="overspeed"?"⚠":"✓";const copy=document.createElement("div"),title=document.createElement("strong"),detail=document.createElement("p"),time=document.createElement("time");title.textContent=eventNames[String(event.name)]||String(event.name||"Sự kiện");detail.textContent=eventDetail(event);time.textContent=dateTime(event.event_time_ms??event.recorded_at??event.ingested_at);copy.append(title,detail);row.append(symbol,copy,time);if(hasCoords(event))row.addEventListener("click",()=>focusEventOnMap(event));list.append(row);}
    if(resetScroll){list.scrollTop=0;return;}
    const insertedHeight=previousTop>1?Math.max(0,list.scrollHeight-previousHeight):0;list.scrollTop=Math.min(previousTop+insertedHeight,Math.max(0,list.scrollHeight-list.clientHeight));
  }
  function eventSearchParams(device,offset,limit){const q=new URLSearchParams({device_id:device,category:$("event-category").value||"all",limit:String(limit),offset:String(offset)}),from=$("event-from").value,to=$("event-to").value,term=$("event-query").value.trim();if(from)q.set("from",from);if(to)q.set("to",to);if(term)q.set("q",term);return{q,filtered:Boolean(from||to||term||q.get("category")!=="all")};}
  async function searchEventCenter(force=false,append=false,preserveScroll=false){
    if(state.mode!=="live")return;
    if(state.eventSearchInFlight){state.eventSearchPending={force,append,preserveScroll};return;}
    const device=currentDeviceId();if(!device)return;
    state.eventSearchInFlight=true;
    try{
      const pageSize=200,target=append?pageSize:(preserveScroll&&state.eventCenterLoaded?Math.max(pageSize,state.eventCenterEvents.length):pageSize);
      let offset=append?state.eventNextOffset:0,total=0,hasMore=false,nextOffset=offset;
      const collected=append?state.eventCenterEvents.slice():[],seen=new Set(collected.map(event=>String(event.event_uid||`id:${event.id}`)));
      do{
        const remaining=append?pageSize:target-collected.length;
        const {q,filtered}=eventSearchParams(device,offset,Math.min(pageSize,Math.max(1,remaining)));
        const r=await fetch(`/api/events/search?${q}`,{cache:"no-store"}),d=await r.json();if(!r.ok||!d.ok)throw new Error(d.error||`HTTP ${r.status}`);
        total=Number(d.total||0);hasMore=Boolean(d.has_more);nextOffset=d.next_offset===null?offset+(d.events||[]).length:Number(d.next_offset??offset+(d.events||[]).length);state.eventFiltersApplied=force||filtered;
        for(const event of d.events||[]){const key=String(event.event_uid||`id:${event.id}`);if(seen.has(key))continue;seen.add(key);collected.push(event);}
        offset=nextOffset;
      }while(!append&&hasMore&&collected.length<target);
      state.eventCenterEvents=collected;state.eventTotal=total;state.eventNextOffset=nextOffset;state.eventHasMore=hasMore;state.eventCenterLoaded=true;
      renderEvents(state.eventCenterEvents,!append&&!preserveScroll);
    }catch(e){console.warn("Event Center:",e);}finally{
      state.eventSearchInFlight=false;
      const pending=state.eventSearchPending;state.eventSearchPending=false;
      if(pending)queueMicrotask(()=>searchEventCenter(pending.force,pending.append,pending.preserveScroll));
    }
  }
  function clearEventFilters(){$("event-category").value="all";$("event-from").value="";$("event-to").value="";$("event-query").value="";state.eventFiltersApplied=false;state.eventCenterEvents=[];state.eventTotal=0;state.eventNextOffset=0;state.eventHasMore=false;state.eventCenterLoaded=false;if(state.data)renderEvents(state.data.events||[],true);searchEventCenter(false,false,false);}


  function clearDeletedMapArtifacts(clearHazards=false){
    state.v10Generation++;state.v10LastLoad=0;
    // Close a popup anchored to a layer that has just been deleted.
    state.map?.closePopup();
    if(!clearHazards)return;
    state.hazardCatalog=[];
    if(state.liveData){state.liveData.potholes=[];state.liveData.speed_bumps=[];}
    if(state.data&&state.data!==state.liveData){state.data.potholes=[];state.data.speed_bumps=[];}
    reconcileHazards({potholes:[],speed_bumps:[]});renderHazardManager();
  }
  function renderHazardManager(){
    const type=$("hazard-type-filter")?.value||"all",rows=(state.hazardCatalog||[]).filter(h=>type==="all"||h.kind===type);setText("hazard-manager-count",`${rows.length} điểm`);const body=$("hazard-table-body");if(!body)return;body.replaceChildren();if(!rows.length){const tr=document.createElement("tr"),td=document.createElement("td");td.colSpan=7;td.className="empty-state";td.textContent="Không có điểm cảnh báo phù hợp.";tr.append(td);body.append(tr);return;}
    for(const h of rows){const tr=document.createElement("tr"),kind=document.createElement("td"),pos=document.createElement("td"),first=document.createElement("td"),last=document.createElement("td"),count=document.createElement("td"),conf=document.createElement("td"),actions=document.createElement("td");kind.innerHTML=`<span class="hazard-kind ${h.kind}"><i></i>${h.kind==="pothole"?"Ổ gà":"Gờ giảm tốc"}</span>`;pos.innerHTML=`<span class="hazard-coords">${fmt(h.lat,6)}, ${fmt(h.lon,6)}</span>`;first.textContent=dateTime(h.first_seen);last.textContent=dateTime(h.last_seen);count.textContent=String(h.detection_count||1);conf.textContent=`${fmt(number(h.max_confidence,0)*100,1)}%`;actions.className="hazard-actions";const view=document.createElement("button");view.type="button";view.textContent="Xem";view.addEventListener("click",()=>focusHazard(h));const del=document.createElement("button");del.type="button";del.className="danger";del.textContent="Xóa";del.disabled=state.hazardBusy;del.addEventListener("click",()=>deleteHazardPoint(h));actions.append(view,del);tr.append(kind,pos,first,last,count,conf,actions);body.append(tr);}
  }
  function focusHazard(h){if(!state.map||!hasCoords(h))return;const p=[number(h.lat),number(h.lon)];state.map.setView(p,Math.max(18,state.map.getZoom()),{animate:true});window.L.popup().setLatLng(p).setContent(popup(h.kind==="pothole"?"Ổ gà":"Gờ giảm tốc",`Đã ghi nhận ${h.detection_count||1} lần · max ${fmt(number(h.max_confidence,0)*100,1)}%`)).openOn(state.map);document.getElementById("map-card")?.scrollIntoView({behavior:"smooth",block:"center"});}
  function hazardFeedback(msg,error=false){const n=$("hazard-feedback");if(!n)return;n.textContent=msg;n.classList.toggle("error",error);}
  async function deleteHazardPoint(h){
    const device=currentDeviceId();if(!device||state.hazardBusy)return;if(!window.confirm(`Xóa ${h.kind==="pothole"?"ổ gà":"gờ giảm tốc"} tại ${fmt(h.lat,6)}, ${fmt(h.lon,6)}?\n\nESP32 sẽ xóa điểm trên MicroSD trước; server chỉ xóa marker sau ACK.`))return;state.hazardBusy=true;renderHazardManager();hazardFeedback("Đang chờ ESP32 xóa điểm khỏi MicroSD...");try{const r=await fetch("/api/hazards/delete",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({device_id:device,kind:h.kind,lat:h.lat,lon:h.lon,radius_m:8})}),d=await r.json();if(!r.ok||!d.ok)throw new Error(d.error||`HTTP ${r.status}`);const cmd=await waitDeviceCommand(Number(d.command.id));if(cmd.status!=="done")throw new Error(cmd.result?.error||"hazard_delete_failed");hazardFeedback(`Đã xóa điểm. SD: ${cmd.result?.deleted??0} · server: ${cmd.result?.server_hazards_deleted??0}.`);clearDeletedMapArtifacts(true);state.mapFitted=false;await loadV10Data(true);await poll();}catch(e){hazardFeedback(`Không thể xóa: ${e.message}`,true);}finally{state.hazardBusy=false;renderHazardManager();}
  }
  async function loadV10Data(force=false){
    const device=currentDeviceId();if(!device||state.mode!=="live")return;if(state.v10Busy){if(force)state.v10ReloadPending=true;return;}if(!force&&Date.now()-state.v10LastLoad<20000)return;const generation=state.v10Generation;state.v10Busy=true;try{const q=`device_id=${encodeURIComponent(device)}`,response=await fetch(`/api/hazards?${q}`,{cache:"no-store"}),data=await response.json();if(generation!==state.v10Generation||device!==currentDeviceId())return;if(data?.ok)state.hazardCatalog=data.hazards||[];state.v10LastLoad=Date.now();renderHazardManager();}catch(e){console.warn("Hazard data:",e);}finally{state.v10Busy=false;if(state.v10ReloadPending){state.v10ReloadPending=false;setTimeout(()=>loadV10Data(true),0);}}
  }


  function initMap() {
    if (state.map || !window.L) { if (!window.L) $("map-offline").hidden = false; return; }
    const L = window.L, map = L.map("map", { zoomControl:false, attributionControl:true, zoomSnap:1, zoomDelta:1, fadeAnimation:false, markerZoomAnimation:false }).setView([16.0,108.0], 6); L.control.zoom({position:"bottomright"}).addTo(map);
    const paneConfig = [
      ["route-casing",610,"none"],
      ["hazard-range",615,"none"],
      ["route-core",620,"none"],
      ["hazard-marker",640,"auto"],
      ["vehicle",660,"none"],
      ["replay",670,"none"],
    ];
    for (const [name,zIndex,pointerEvents] of paneConfig) { const pane=map.createPane(name); pane.style.zIndex=String(zIndex); pane.style.pointerEvents=pointerEvents; }
    const tileUrl=mapTileUrl();
    const tiles = L.tileLayer(tileUrl, { tileSize:256, zoomOffset:0, maxNativeZoom:19, maxZoom:19, detectRetina:false, updateWhenIdle:true, updateWhenZooming:false, keepBuffer:2, referrerPolicy:"strict-origin-when-cross-origin", attribution:'© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap contributors</a>' }).addTo(map);
    state.tiles=tiles;state.tileUrl=tileUrl;state.tileLoaded=0;
    tiles.on("loading",()=>{state.tileErrors=0;state.tileLoaded=0;});
    tiles.on("tileload",()=>{state.tileLoaded++;if(state.tileLoaded>0&&state.tileErrors<3)$("map-offline").hidden=true;});
    tiles.on("tileerror", () => { state.tileErrors++;if(state.tileErrors>=3)showMapNotice("Chưa tải được nền bản đồ. Điểm cảnh báo vẫn được giữ; bấm Thử lại bản đồ."); });
    // Leaflet fires load even when every tile failed. Do not immediately hide
    // the only explanation for the phone's otherwise completely gray map.
    tiles.on("load",()=>{if(state.tileLoaded===0&&state.tileErrors)showMapNotice("Chưa tải được nền bản đồ. Kiểm tra mạng rồi bấm Thử lại bản đồ.");else if(!state.tileErrors)$("map-offline").hidden=true;});
    state.map = map; state.layers = { route:L.layerGroup().addTo(map), hazards:L.layerGroup().addTo(map), vehicle:L.layerGroup().addTo(map) };
    state.routeCasing = L.polyline([],{pane:"route-casing",className:"route-casing",color:"#020912",weight:9,opacity:.94,lineCap:"round",lineJoin:"round",interactive:false}).addTo(state.layers.route);
    state.routeCore = L.polyline([],{pane:"route-core",className:"route-core",color:"#22d3ee",weight:4,opacity:1,lineCap:"round",lineJoin:"round",interactive:false}).addTo(state.layers.route);
    const resizeMap = () => {
      clearTimeout(state.mapResizeTimer);
      state.mapResizeTimer = setTimeout(() => {if(directView.rotated)fitDirectMap();else state.map?.invalidateSize({ animate:false, pan:false, debounceMoveend:true });}, 80);
    };
    if ("ResizeObserver" in window) { state.mapResizeObserver = new ResizeObserver(resizeMap); state.mapResizeObserver.observe($("map-card")); }
    requestAnimationFrame(resizeMap);
    window.addEventListener("orientationchange",resizeMap);
    window.addEventListener("online",()=>retryMapTiles());
    document.addEventListener("visibilitychange",()=>{if(!document.hidden)resizeMap();});
  }
  function mapTileUrl(){
    // The public portal serves tiles directly, bypassing the PC tunnel. Local
    // LAN use retains normal OSM HTTPS tiles and the same attribution.
    const online=window.TelematicsAccess?.remote===true||window.location?.protocol==='https:';
    return online?'/map-tiles/{z}/{x}/{y}.png':'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
  }
  function showMapNotice(message){
    const copy=$("map-offline-message");if(copy)copy.textContent=message;
    $("map-offline").hidden=false;
  }
  function retryMapTiles(){
    const url=mapTileUrl();
    if(state.tiles&&state.tileUrl!==url){state.tileUrl=url;state.tiles.setUrl(url);}
    else state.tiles?.redraw();
    if(directView.rotated)fitDirectMap();else state.map?.invalidateSize({animate:false,pan:false});
  }
  function popup(title, detail) { const box = document.createElement("div"), strong = document.createElement("strong"), line = document.createElement("div"); strong.textContent = title; line.textContent = detail; line.style.marginTop = "4px"; box.append(strong,line); return box; }
  function hazardKey(kind, point) {
    const lat=number(point.lat),lon=number(point.lon);
    return `${kind}:${lat?.toFixed(6)}:${lon?.toFixed(6)}`;
  }
  function reconcileHazards(data,vehiclePos=null) {
    if(!state.map||!state.layers)return;
    const L=window.L,desired=new Set(),warningM=number(state.deviceConfig?.geofence_warning_m,10);
    const addHazard=(kind,point)=>{
      if(!hasCoords(point))return;
      const key=hazardKey(kind,point);desired.add(key);
      const pos=[number(point.lat),number(point.lon)], pothole=kind==="pothole";
      const opposite=pothole?(data.speed_bumps||[]):(data.potholes||[]),overlap=opposite.some(other=>hasCoords(other)&&haversine(pos,[number(other.lat),number(other.lon)])*1000<=3),offset=overlap?(pothole?" overlap-left":" overlap-right"):"";
      const label=pothole?"Ổ gà":"Gờ giảm tốc",symbol=pothole?"!":"≋",distance=vehiclePos?haversine(vehiclePos,pos)*1000:null,inside=distance!==null&&distance<=warningM;
      const distanceText=distance===null?`Vòng cảnh báo ${fmt(warningM)} m`:distance>=1000?`Cách ${fmt(distance/1000,1)} km · vòng ${fmt(warningM)} m`:inside?`Còn ${fmt(distance,1)} m · trong vòng ${fmt(warningM)} m`:`Cách ${fmt(distance,1)} m · vòng ${fmt(warningM)} m`;
      let record=state.hazardLayers.get(key);
      if(!record){
        const rangeCircle=L.circle(pos,{pane:"hazard-range",interactive:false,radius:warningM,color:pothole?"#ef476f":"#d97706",weight:2,opacity:.72,fill:false,dashArray:"7 5",className:`hazard-range-ring ${pothole?"pothole":"bump"}`}).addTo(state.layers.hazards);
        const icon=L.divIcon({className:"map-marker-wrap",html:`<span class="hazard-pin ${pothole?"pothole":"bump"}${offset}${inside?" in-range":""}"><span class="hazard-pin-label"><b>${symbol}</b><span class="hazard-pin-copy"><strong>${label}</strong><small data-hazard-distance>${distanceText}</small></span></span><i></i></span>`,iconSize:[160,68],iconAnchor:[80,68]});
        const marker=L.marker(pos,{pane:"hazard-marker",icon}).addTo(state.layers.hazards);
        record={marker,rangeCircle,lastPopup:""};state.hazardLayers.set(key,record);
      }
      record.marker.setLatLng(pos);
      record.rangeCircle.setLatLng(pos);record.rangeCircle.setRadius(warningM);record.rangeCircle.setStyle({weight:inside?3:2,opacity:inside?1:.72,fill:false});
      const element=record.marker.getElement(),pin=element?.querySelector(".hazard-pin"),distanceNode=element?.querySelector("[data-hazard-distance]");
      if(pin){pin.classList.toggle("in-range",inside);pin.classList.toggle("overlap-left",overlap&&pothole);pin.classList.toggle("overlap-right",overlap&&!pothole);}
      if(distanceNode)distanceNode.textContent=distanceText;
      const popupDetail=`${distanceText} · Tin cậy ${fmt(number(point.confidence,0)*100,1)}% · loa 1 lần/lượt khi điểm đã tái kích hoạt và xe vào ≤${fmt(warningM)} m`;
      if(record.lastPopup!==popupDetail){const content=popup(label,popupDetail);if(record.marker.getPopup())record.marker.setPopupContent(content);else record.marker.bindPopup(content);record.lastPopup=popupDetail;}
    };
    (data.potholes||[]).forEach(point=>addHazard("pothole",point));
    (data.speed_bumps||[]).forEach(point=>addHazard("bump",point));
    for(const [key,record] of state.hazardLayers){
      if(desired.has(key))continue;
      state.layers.hazards.removeLayer(record.marker);state.layers.hazards.removeLayer(record.rangeCircle);
      state.hazardLayers.delete(key);
    }
  }
  function updateMap(data) {
    if(isDirectDemoDevice(data.latest?.device_id)||directView.session?.virtual_device_id===currentDeviceId())data={...data,latest:directMapLatest(data.latest)};
    initMap(); setText("map-device", String(data.latest?.device_id || data.device_id || "Chờ GPS"));
    const mapWaiting=$("map-waiting"),hasTelemetry=Boolean(data.latest),directPosition=isDirectDemoDevice(data.latest?.device_id)&&hasGnssFix(data.latest),hasPosition=hasTelemetry&&(state.mode==="demo"||telemetryFresh(data.latest)||directPosition)&&hasGnssFix(data.latest);
    if (hasPosition) setText("map-coords", `${fmt(data.latest.lat,6)}, ${fmt(data.latest.lon,6)}`); else setText("map-coords", "Chờ GPS");
    if(mapWaiting){mapWaiting.hidden=!hasTelemetry||hasPosition||Boolean(directView.preview);const detail=mapWaiting.querySelector("span");if(detail)detail.textContent=isDirectDemoDevice(data.latest?.device_id)?"Chờ dữ liệu mới từ ESP; không tự ngoại suy vị trí demo.":`Đang chờ GNSS · ${fmt(data.latest?.satellites)} vệ tinh · HDOP ${fmt(data.latest?.hdop,1)}`;}
    if (!state.map || !state.layers) return; const L = window.L;
    const routeRows = state.mode === "demo" ? (data.telemetry||[]) : (state.routePoints||[]);
    const segments = window.TelematicsRouteGeometry.splitRouteSegments(routeRows)
      .map(segment => segment.map(row => [number(row.lat),number(row.lon)]));
    const points = segments.flat();
    vehicleMotion.routeRows=routeRows;
    state.routeCasing?.setLatLngs(segments);state.routeCore?.setLatLngs(segments);
    if (state.routeStartMarker) { state.layers.route.removeLayer(state.routeStartMarker); state.routeStartMarker=null; }
    if (state.routeEndMarker) { state.layers.route.removeLayer(state.routeEndMarker); state.routeEndMarker=null; }
    if (state.mode === "live" && points.length) {
      state.routeStartMarker=L.circleMarker(points[0],{pane:"route-core",className:"route-start-marker",interactive:false,radius:5,color:"#d1fae5",weight:2,fillColor:"#22c55e",fillOpacity:1}).addTo(state.layers.route);
      if (state.displayedRoute?.status === "completed" && points.length>1) state.routeEndMarker=L.circleMarker(points[points.length-1],{pane:"route-core",className:"route-end-marker",interactive:false,radius:5,color:"#fee2e2",weight:2,fillColor:"#ef4444",fillOpacity:1}).addTo(state.layers.route);
    }
    const vehiclePos=hasPosition?[number(data.latest.lat),number(data.latest.lon)]:null;
    const displayedPos=isMovingDemoDevice(data.latest?.device_id)&&vehicleMotion.source.startsWith(`${data.latest.device_id}:${data.latest.boot_id||""}:`)?vehicleMotion.displayed:null;
    reconcileHazards(data,displayedPos||vehiclePos);
    // A saved route must stay visible even after live telemetry becomes stale.
    // Previously fitBounds only ran while GPS was fresh, so replay could remain
    // at the default Viet Nam overview and make the road-level path invisible.
    if (!directView.rotated && !state.mapFitted && points.length > 1) {
      state.map.fitBounds(points,{padding:[42,42],maxZoom:18,animate:false});
      state.mapFitted=true;
    }
    if (hasPosition) {
      const pos=vehiclePos, vehicleKey=`${pos[0].toFixed(6)},${pos[1].toFixed(6)}`, positionChanged=vehicleKey!==state.lastVehicleKey;
      if(!state.vehicleHalo){
        state.vehicleHalo=L.circleMarker(pos,{pane:"vehicle",className:"vehicle-position-halo",interactive:false,radius:9,color:"#22d3ee",weight:2,fill:false,fillOpacity:0,opacity:.75}).addTo(state.layers.vehicle);
        state.vehicleCore=L.circleMarker(pos,{pane:"vehicle",className:"vehicle-position-core",interactive:false,radius:4.5,color:"#f4fdff",weight:2,fillColor:"#22d3ee",fillOpacity:1,opacity:1}).addTo(state.layers.vehicle);
      }
      if(isDirectDemoDevice(data.latest.device_id)&&state.mode==="live")animateDirectVehicle(data.latest,pos);
      else if(isAutoDemoDevice(data.latest.device_id)&&state.mode==="live")animateDemoVehicle(data.latest,pos,routeRows);
      else{stopVehicleMotion(true);drawVehiclePosition(pos);}
      if (!directView.rotated && !state.mapFitted) { state.map.setView(pos,Math.max(15,state.map.getZoom()),{animate:false}); state.mapFitted=true; }
      else if (!directView.rotated && positionChanged && !state.map.getBounds().pad(-.16).contains(pos)) state.map.panTo(pos,{animate:true,duration:.25});
      state.lastVehicleKey=vehicleKey;
    } else {
      stopVehicleMotion(true);
      if(state.vehicleHalo){state.layers.vehicle.removeLayer(state.vehicleHalo);state.layers.vehicle.removeLayer(state.vehicleCore);state.vehicleHalo=null;state.vehicleCore=null;}
      state.lastVehicleKey="";
    }
  }


  function currentDeviceId() {
    return String(state.selectedDevice || state.liveData?.device_id || state.liveData?.latest?.device_id || "");
  }
  function selectedCompletedRoute() {
    const id=Number(state.selectedRouteId);
    return state.routes.find(route=>route.status==="completed"&&Number(route.id)===id)||null;
  }
  function setRouteFeedback(message="", error=false) {
    const node=$("route-feedback"); if(!node)return;
    clearTimeout(state.routeFeedbackTimer); node.textContent=message; node.classList.toggle("error",error);
    if(message) state.routeFeedbackTimer=setTimeout(()=>{node.textContent="";node.classList.remove("error");},5000);
  }
  function formatDuration(sec){const t=Math.max(0,Math.round(number(sec,0))),h=Math.floor(t/3600),m=Math.floor((t%3600)/60),z=t%60;return h?`${h}h ${m}m`:`${m}m ${z}s`;}
  function stopReplay(reset=false){clearInterval(state.replayTimer);state.replayTimer=0;state.replayPlaying=false;if(reset){state.replayPosition=0;if(state.replayMarker&&state.map){state.map.removeLayer(state.replayMarker);state.replayMarker=null;}}renderReplayControls();}
  function updateReplayMarker(){if(!state.map||!window.L||!state.routePoints.length)return;const i=Math.max(0,Math.min(state.routePoints.length-1,Math.round(state.replayPosition))),pt=state.routePoints[i];if(!hasCoords(pt))return;const pos=[number(pt.lat),number(pt.lon)];if(!state.replayMarker)state.replayMarker=window.L.circleMarker(pos,{pane:"replay",className:"replay-marker",interactive:false,radius:6,color:"#fff",weight:2,fillColor:"#a78bfa",fillOpacity:1}).addTo(state.map);else state.replayMarker.setLatLng(pos);$("route-replay-slider").value=String(i);let text=`${dateTime(pt.recorded_at||pt.ingested_at)} · ${fmt(pt.speed_kph,1)} km/h`;const t=timeMs(pt.ingested_at||pt.recorded_at),hit=(state.routeEvents||[]).find(e=>Math.abs(timeMs(e.ingested_at||e.recorded_at)-t)<=1100);if(hit)text+=` · ${eventNames[hit.name]||hit.name}`;setText("route-replay-status",text);}
  function renderReplayControls(){const selected=selectedCompletedRoute(),ready=Boolean(selected&&state.routePoints.length>1),play=$("route-replay-btn"),pause=$("route-replay-pause-btn"),slider=$("route-replay-slider");play.disabled=!ready||state.replayPlaying;pause.disabled=!ready||!state.replayPlaying;slider.disabled=!ready;slider.max=String(Math.max(0,state.routePoints.length-1));slider.value=String(Math.round(state.replayPosition));const st=state.routeStats||{},vals=[["Thời gian",formatDuration(st.duration_s)],["TB",`${fmt(st.avg_speed_kph,1)} km/h`],["Max",`${fmt(st.max_speed_kph,1)} km/h`],["Quá tốc",fmt(st.overspeed_events)],["Ổ gà",fmt(st.pothole_events)],["Gờ",fmt(st.speed_bump_events)],["DTC",fmt(st.dtc_events)]],box=$("route-stats");box.replaceChildren(...vals.map(([a,b])=>{const x=document.createElement("span"),v=document.createElement("b");x.append(document.createTextNode(a),v);v.textContent=b;return x;}));if(!ready&&!state.replayPlaying)setText("route-replay-status","Chọn lộ trình đã kết thúc để phát lại.");}
  function startReplay(){if(!selectedCompletedRoute()||state.routePoints.length<2)return;clearInterval(state.replayTimer);if(state.replayPosition>=state.routePoints.length-1)state.replayPosition=0;state.replayPlaying=true;state.replayTimer=setInterval(()=>{const speed=Math.max(1,number($("route-replay-speed").value,1));state.replayPosition+=speed*.25;if(state.replayPosition>=state.routePoints.length-1){state.replayPosition=state.routePoints.length-1;updateReplayMarker();stopReplay(false);return;}updateReplayMarker();},250);updateReplayMarker();renderReplayControls();}
  function renderRouteControls(){const live=state.mode==="live",active=state.activeRoute,selected=selectedCompletedRoute(),shown=active||selected||state.displayedRoute,start=$("route-start-btn"),end=$("route-end-btn"),del=$("route-delete-btn"),select=$("route-select"),rec=$("route-live-dot"),device=currentDeviceId();start.disabled=!live||!device||Boolean(active)||isDirectDemoDevice(device);end.disabled=!live||!active||isDirectDemoDevice(device);start.title=end.title=isDirectDemoDevice(device)?"Điều khiển bằng bảng Demo trực tiếp":"";del.disabled=!live||Boolean(active)||!selected;select.disabled=!live||Boolean(active);rec.hidden=!active;if(active){setText("route-status","Đang ghi lộ trình");setText("route-detail",`Bắt đầu ${dateTime(active.started_at)} · ${fmt(active.distance_km,2)} km · ${fmt(active.point_count)} điểm`);}else if(selected){setText("route-status",`Lộ trình ${selected.route_no}`);setText("route-detail",`${dateTime(selected.started_at)} → ${dateTime(selected.ended_at)} · ${fmt(selected.distance_km,2)} km · ${fmt(selected.point_count)} điểm`);}else{setText("route-status",live?"Chưa bắt đầu":"Chế độ mô phỏng");setText("route-detail",isDirectDemoDevice(device)?'Điều khiển lộ trình qua bảng Demo trực tiếp.':live?'Nhấn “Bắt đầu” để ghi đường đi trên bản đồ.':'Điều khiển lộ trình chỉ dùng dữ liệu trực tiếp.');}const prev=String(state.selectedRouteId||"");select.replaceChildren();const empty=document.createElement("option");empty.value="";empty.textContent=state.routes.some(r=>r.status==="completed")?"Chọn lộ trình đã lưu":"Chưa có lộ trình";select.append(empty);for(const r of state.routes.filter(r=>r.status==="completed").sort((a,b)=>Number(b.route_no)-Number(a.route_no))){const o=document.createElement("option");o.value=String(r.id);o.textContent=`Lộ trình ${r.route_no} · ${fmt(r.distance_km,2)} km`;select.append(o);}if([...select.options].some(o=>o.value===prev))select.value=prev;if(shown){setText("trip",fmt(shown.distance_km,2));setText("trip-route-badge",shown.status==="active"?"ĐANG GHI":`LT ${shown.route_no}`);setText("trip-note",`${fmt(shown.point_count)} ${isDirectDemoDevice(device)?"điểm mô phỏng":"điểm GPS"}`);}else if(live){setText("trip","—");setText("trip-route-badge","GNSS");setText("trip-note","Chưa bắt đầu lộ trình");}renderReplayControls();}
  function directRouteScope(session){return session?`${session.session_id}:${session.pass_index??session.last_snapshot?.pass_index??0}:${session.state}`:"";}
  function routeContext(){const device=currentDeviceId();return {device,generation:state.sourceGeneration,scope:directView.session?.virtual_device_id===device?directRouteScope(directView.session):""};}
  function routeContextCurrent(context){const current=routeContext();return state.mode==="live"&&context.device===current.device&&context.generation===current.generation&&context.scope===current.scope;}
  function cancelRouteRequests(){
    // Clearing ownership before aborting prevents old finally/catch handlers
    // from releasing a newer request's lock or painting an old source/pass.
    const {list,detail}=routeRequests;routeRequests.list=routeRequests.detail=null;
    state.routeRequestInFlight=false;list?.controller.abort();detail?.controller.abort();
  }
  async function fetchRouteJson(url,controller){
    let rejectAbort;
    const aborted=new Promise((_,reject)=>{rejectAbort=()=>reject(new Error("route_request_aborted"));});
    controller.signal.addEventListener("abort",rejectAbort,{once:true});
    if(controller.signal.aborted)rejectAbort();
    const timeout=setTimeout(()=>controller.abort(),window.TelematicsAccess?.remote?10000:ROUTE_TIMEOUT_MS);
    try{
      // Race also bounds adapters/proxies which do not promptly reject fetch
      // after cancellation. The abandoned promise never mutates UI state.
      return await Promise.race([aborted,(async()=>{
        const response=await fetch(url,{cache:"no-store",signal:controller.signal});
        if(!response.ok)throw new Error(`HTTP ${response.status}`);
        const data=await response.json();if(!data.ok)throw new Error(data.error||"route_error");return data;
      })()]);
    }finally{clearTimeout(timeout);controller.signal.removeEventListener("abort",rejectAbort);}
  }
  async function fetchRouteDetail(routeId, force=false) {
    routeRequests.detail?.controller.abort();
    const context=routeContext(),job={context,controller:new AbortController()};routeRequests.detail=job;
    try{
      const id=Number(routeId);if(!Number.isSafeInteger(id)||id<=0){state.displayedRoute=null;state.routePoints=[];return true;}
      if(!force&&state.displayedRoute&&Number(state.displayedRoute.id)===id&&state.displayedRoute.status==="completed")return true;
      const query=context.device?`?device_id=${encodeURIComponent(context.device)}`:"";
      const data=await fetchRouteJson(`/api/routes/${id}${query}`,job.controller);
      if(routeRequests.detail!==job||!routeContextCurrent(context))return false;
      const changed=!state.displayedRoute||Number(state.displayedRoute.id)!==id;
      if(changed)stopReplay(true);state.displayedRoute=data.route;state.routePoints=data.points||[];state.routeEvents=data.events||[];state.routeStats=data.stats||null;if(changed)state.mapFitted=false;
      return true;
    }catch(error){if(routeRequests.detail!==job||!routeContextCurrent(context))return false;throw error;}
    finally{if(routeRequests.detail===job)routeRequests.detail=null;}
  }
  async function loadRoutes(forceDetail=false) {
    if(state.mode!=="live") { renderRouteControls(); return false; }
    if(routeRequests.list&&routeContextCurrent(routeRequests.list.context))return false;
    if(routeRequests.list)cancelRouteRequests();
    const context=routeContext(),device=context.device;
    if(!device){state.routes=[];state.activeRoute=null;state.displayedRoute=null;state.routePoints=[];renderRouteControls();return true;}
    const job={context,controller:new AbortController()};routeRequests.list=job;state.routeRequestInFlight=true;
    try{
      const data=await fetchRouteJson(`/api/routes?device_id=${encodeURIComponent(device)}`,job.controller);
      if(routeRequests.list!==job||!routeContextCurrent(context))return false;
      state.routes=data.routes||[];state.activeRoute=data.active_route||null;
      let target=null;
      if(state.activeRoute){target=state.activeRoute;state.selectedRouteId=null;}
      else{
        const selected=selectedCompletedRoute();target=selected||state.routes.find(route=>route.status==="completed")||null;
        if(target&&!state.selectedRouteId)state.selectedRouteId=Number(target.id);
      }
      if(target){if(!await fetchRouteDetail(target.id,forceDetail||target.status==="active"))return false;}
      else{state.displayedRoute=null;state.routePoints=[];state.routeEvents=[];state.routeStats=null;stopReplay(true);}
      if(routeRequests.list!==job||!routeContextCurrent(context))return false;
      renderRouteControls();return true;
    }catch(error){if(routeRequests.list===job&&routeContextCurrent(context))setRouteFeedback("Lộ trình chưa phản hồi; dữ liệu trực tiếp vẫn cập nhật. Sẽ thử lại.",true);return false;}
    finally{if(routeRequests.list===job){routeRequests.list=null;state.routeRequestInFlight=false;}}
  }
  async function postRoute(path,body) {
    const response=await fetch(path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
    const data=await response.json().catch(()=>({ok:false,error:`HTTP ${response.status}`}));if(!response.ok||!data.ok)throw new Error(data.error||`HTTP ${response.status}`);return data;
  }
  async function startRouteAction(){
    const device=currentDeviceId();if(!device)return setRouteFeedback("Chưa có thiết bị ESP32 để bắt đầu lộ trình",true);
    try{const data=await postRoute("/api/routes/start",{device_id:device});state.selectedRouteId=null;state.mapFitted=false;setRouteFeedback(data.already_active?"Lộ trình đang được ghi":"Đã bắt đầu lộ trình");await loadRoutes(true);if(state.data)render(state.data);}catch(error){setRouteFeedback(`Không thể bắt đầu: ${error.message}`,true);}
  }
  async function endRouteAction(){
    const active=state.activeRoute,device=currentDeviceId();if(!active||!device)return;
    try{const data=await postRoute("/api/routes/end",{device_id:device,route_id:active.id});state.selectedRouteId=Number(data.route.id);state.mapFitted=false;setRouteFeedback(`Đã kết thúc · Lộ trình ${data.route.route_no}`);await loadRoutes(true);if(state.data)render(state.data);}catch(error){setRouteFeedback(`Không thể kết thúc: ${error.message}`,true);}
  }
  async function deleteRouteAction(){
    const route=selectedCompletedRoute(),device=currentDeviceId();if(!route||!device)return;
    if(!window.confirm(`Xóa Lộ trình ${route.route_no}? Đường đi đã lưu sẽ bị xóa khỏi bản đồ. Sự kiện ổ gà/gờ giảm tốc không bị xóa.`))return;
    try{const response=await fetch(`/api/routes/${route.id}?device_id=${encodeURIComponent(device)}`,{method:"DELETE"});const data=await response.json().catch(()=>({ok:false,error:`HTTP ${response.status}`}));if(!response.ok||!data.ok)throw new Error(data.error||`HTTP ${response.status}`);state.selectedRouteId=null;state.displayedRoute=null;state.routePoints=[];state.mapFitted=false;setRouteFeedback(`Đã xóa Lộ trình ${route.route_no}`);await loadRoutes(true);if(state.data)render(state.data);}catch(error){setRouteFeedback(`Không thể xóa: ${error.message}`,true);}
  }


  function configFeedback(msg,error=false){const n=$("config-feedback");n.textContent=msg;n.classList.toggle("error",error);}
  function configViewId(c){return String(c?.view_device_id||c?.device_id||"");}
  function fillConfig(c,forceInputs=false){
    if(!c)return;
    state.deviceConfig={...c};
    if(forceInputs||(!state.configDirty&&!state.configBusy)){
      $("cfg-speed-warn").value=number(c.overspeed_warning_kph,120);$("cfg-speed-clear").value=number(c.overspeed_clear_kph,115);
      $("cfg-geo-warn").value=number(c.geofence_warning_m,10);$("cfg-geo-rearm").value=number(c.geofence_rearm_m,20);
      $("cfg-pothole").value=Math.round(number(c.pothole_confidence,.8)*100);$("cfg-bump").value=Math.round(number(c.speed_bump_confidence,.8)*100);
      if(forceInputs)state.configDirty=false;
    }
    const pending=c.pending_command?.status==="pending"||state.configBusy;
    const target=String(c.target_device_id||c.device_id||""),confirmed=c.confirmed===true||c.source==="device"||c.source==="NVS";
    const status=pending?`Chờ ESP xác nhận · vòng hiện tại ${fmt(c.geofence_warning_m,0)} m`:confirmed?`ESP đã xác nhận · vòng ${fmt(c.geofence_warning_m,0)} m`:`Chưa xác nhận từ ESP · tạm ${fmt(c.geofence_warning_m,0)} m`;
    setText("config-status",status);
    if($("config-status"))$("config-status").title=target?`Nguồn cấu hình: ${target}${c.updated_at?` · ${dateTime(c.updated_at)}`:""}`:"Chưa có Gateway thật";
    setText("config-target-note",isAutoDemoDevice(configViewId(c))?`Demo dùng cấu hình của Gateway ${target||"chưa xác định"}. Vòng trên map chỉ đổi sau khi ESP xác nhận; giá trị đang nhập chưa có hiệu lực.`:"NVS giữ cấu hình sau reset. Vòng trên map chỉ đổi sau khi ESP xác nhận cấu hình mới.");
    $("config-read-btn").disabled=$("config-save-btn").disabled=Boolean(pending);
    if(state.data)reconcileHazards(state.data,vehicleMotion.displayed||(hasCoords(state.data.latest)?[number(state.data.latest.lat),number(state.data.latest.lon)]:null));
  }
  async function waitDeviceCommand(id){const end=Date.now()+30000;while(Date.now()<end){const r=await fetch(`/api/device-commands/${id}`,{cache:"no-store"}),d=await r.json();if(!r.ok||!d.ok)throw new Error(d.error||`HTTP ${r.status}`);if(d.command.status!=="pending")return d.command;await new Promise(x=>setTimeout(x,500));}throw new Error("ESP32 chưa phản hồi");}
  async function loadCachedConfig(forceInputs=false){
    const device=currentDeviceId(),generation=state.sourceGeneration;if(!device)return;
    try{const r=await fetch(`/api/device-config?device_id=${encodeURIComponent(device)}`,{cache:"no-store"}),d=await r.json();if(generation!==state.sourceGeneration||device!==currentDeviceId())return;if(r.ok&&d.ok)fillConfig({...d.config,view_device_id:device},forceInputs);}
    catch{if(generation===state.sourceGeneration&&configViewId(state.deviceConfig)!==device)fillConfig({device_id:device,view_device_id:device,overspeed_warning_kph:120,overspeed_clear_kph:115,geofence_warning_m:10,geofence_rearm_m:20,pothole_confidence:.80,speed_bump_confidence:.80,source:"default",confirmed:false},forceInputs);}
  }
  async function readConfigFromDevice(){
    const device=currentDeviceId(),generation=state.sourceGeneration;if(!device)return configFeedback("Chưa có ESP32",true);if(state.configBusy)return;
    state.configBusy=true;fillConfig(state.deviceConfig);configFeedback("Đang chờ Gateway đọc cấu hình NVS…");
    try{const r=await fetch("/api/device-config/read",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({device_id:device})}),d=await r.json();if(!r.ok||!d.ok)throw new Error(d.error||`HTTP ${r.status}`);const cmd=await waitDeviceCommand(d.command.id);if(cmd.status!=="done")throw new Error(cmd.result?.error||"config_get_failed");if(generation!==state.sourceGeneration)return;await loadCachedConfig(true);configFeedback("Đã đọc cấu hình NVS từ Gateway; map và demo dùng cùng ngưỡng.");}
    catch(e){if(generation===state.sourceGeneration)configFeedback(e.message,true);}
    finally{state.configBusy=false;if(generation===state.sourceGeneration){await loadCachedConfig();fillConfig(state.deviceConfig);}}
  }
  async function saveConfigToDevice(){
    if(state.configBusy)return;
    const device=currentDeviceId(),generation=state.sourceGeneration,sw=number($("cfg-speed-warn").value),sc=number($("cfg-speed-clear").value),gw=number($("cfg-geo-warn").value),gr=number($("cfg-geo-rearm").value),pc=number($("cfg-pothole").value),bc=number($("cfg-bump").value);
    if(!device)return configFeedback("Chưa có ESP32",true);
    if([sw,sc,gw,gr,pc,bc].some(v=>v===null)||sw<30||sw>180||sc>=sw||sw-sc<1||gw<3||gw>50||gr<gw+2||gr>100||pc<50||pc>99||bc<50||bc>99)return configFeedback("Thông số không hợp lệ; kiểm tra lại giới hạn.",true);
    state.configBusy=true;fillConfig(state.deviceConfig);configFeedback("Đang chờ ESP xác nhận lưu NVS; map vẫn dùng ngưỡng đã xác nhận trước đó.");
    try{const payload={device_id:device,overspeed_warning_kph:sw,overspeed_clear_kph:sc,geofence_warning_m:gw,geofence_rearm_m:gr,pothole_confidence:pc/100,speed_bump_confidence:bc/100},r=await fetch("/api/device-config",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)}),d=await r.json();if(!r.ok||!d.ok)throw new Error(d.error||`HTTP ${r.status}`);const cmd=await waitDeviceCommand(d.command.id);if(cmd.status!=="done")throw new Error(cmd.result?.error||"config_set_failed");if(generation!==state.sourceGeneration)return;await loadCachedConfig(true);configFeedback("ESP đã xác nhận lưu NVS. Vòng cảnh báo và demo đã cập nhật cùng cấu hình.");}
    catch(e){if(generation===state.sourceGeneration)configFeedback(e.message,true);}
    finally{state.configBusy=false;if(generation===state.sourceGeneration){await loadCachedConfig();fillConfig(state.deviceConfig);}}
  }


  function sdFeedback(message,error=false,persistent=false){
    const node=$("sd-feedback");if(!node)return;clearTimeout(state.sdFeedbackTimer);node.textContent=message;node.classList.toggle("error",error);
    if(message&&!persistent)state.sdFeedbackTimer=setTimeout(()=>{node.textContent="";node.classList.remove("error");},7000);
  }
  function setSdBusy(busy,label=""){
    state.sdCommandBusy=busy;setText("sd-command-status",busy?(label||"Đang chờ ESP32"):"Sẵn sàng");
    ["sd-refresh-btn","sd-view-btn","sd-export-btn","sd-export-all-btn","sd-delete-custom-btn"].forEach(id=>{const n=$(id);if(n)n.disabled=busy||((id==="sd-view-btn"||id==="sd-export-btn")&&!$("sd-log-select")?.value);});
    document.querySelectorAll("[data-sd-range]").forEach(button=>button.disabled=busy);
  }
  function dateYmd(date){const y=date.getFullYear(),m=String(date.getMonth()+1).padStart(2,"0"),d=String(date.getDate()).padStart(2,"0");return `${y}-${m}-${d}`;}
  function localDayStartEpoch(date){return Math.floor(new Date(date.getFullYear(),date.getMonth(),date.getDate(),0,0,0,0).getTime()/1000);}
  function localDayEndEpoch(date){return Math.floor(new Date(date.getFullYear(),date.getMonth(),date.getDate(),23,59,59,999).getTime()/1000);}
  function presetRange(kind){
    const now=new Date(),to=new Date(now.getFullYear(),now.getMonth(),now.getDate()),from=new Date(to);
    if(kind==="7days")from.setDate(from.getDate()-6);else if(kind==="30days")from.setDate(from.getDate()-29);else if(kind==="month")from.setDate(1);
    if(kind==="all")return {delete_all:true,from_date:"",to_date:"",from_epoch:0,to_epoch:4294967295};
    return {delete_all:false,from_date:dateYmd(from),to_date:dateYmd(to),from_epoch:localDayStartEpoch(from),to_epoch:localDayEndEpoch(to)};
  }
  async function runSdCommand(action,params={},timeoutMs=30000){
    const device=currentDeviceId();if(!device)throw new Error("Chưa có thiết bị ESP32-S3 để điều khiển");
    if(isAutoDemoDevice(device))throw new Error("MicroSD vật lý không tham gia phiên demo; hãy chờ dashboard trở về Gateway thật");
    setSdBusy(true,"Đang gửi lệnh");
    try{
      const response=await fetch("/api/sd/commands",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({device_id:device,action,...params})});
      const created=await response.json().catch(()=>({ok:false,error:`HTTP ${response.status}`}));if(!response.ok||!created.ok)throw new Error(created.error||`HTTP ${response.status}`);
      const id=Number(created.command?.id);if(!Number.isSafeInteger(id))throw new Error("Server không trả command id");
      const deadline=Date.now()+timeoutMs;setText("sd-command-status",`Lệnh #${id} · chờ ESP32`);
      while(Date.now()<deadline){
        await new Promise(resolve=>setTimeout(resolve,800));
        const poll=await fetch(`/api/sd/commands/${id}`,{cache:"no-store"});const data=await poll.json().catch(()=>({ok:false}));
        if(!poll.ok||!data.ok)continue;const command=data.command;
        if(command?.status==="done")return command.result||{};
        if(command?.status==="failed")throw new Error(command.result?.error||"ESP32 báo lệnh thất bại");
      }
      throw new Error(`Lệnh #${id} vẫn đang chờ ESP32. Server vẫn giữ lệnh và thiết bị sẽ thực hiện khi online.`);
    }finally{setSdBusy(false);}
  }
  function renderSdList(result){
    state.sdLastResult=result;state.sdFiles=Array.isArray(result.files)?result.files:[];
    const total=number(result.card_total_bytes),used=number(result.card_used_bytes),select=$("sd-log-select");
    setText("sd-manager-state","MicroSD ONLINE");setText("sd-capacity",bytes(total));setText("sd-used",total&&used!==null?`${bytes(used)} · ${fmt(used/total*100,1)}%`:bytes(used));setText("sd-log-count",fmt(result.file_count??state.sdFiles.length));
    const dated=state.sdFiles.map(file=>file.date).filter(Boolean).sort();setText("sd-oldest",dated[0]||"Không có log theo ngày");setText("sd-newest",dated.at(-1)||"Không có log theo ngày");
    const previous=select.value;select.replaceChildren();const empty=document.createElement("option");empty.value="";empty.textContent=state.sdFiles.length?"Chọn file log":"Không có file log";select.append(empty);
    for(const file of [...state.sdFiles].sort((a,b)=>String(b.name).localeCompare(String(a.name)))){const option=document.createElement("option");option.value=String(file.name);option.textContent=`${file.name}${file.legacy?" · LEGACY":""} · ${bytes(file.size)}`;select.append(option);}select.value=[...select.options].some(o=>o.value===previous)?previous:"";
    $("sd-view-btn").disabled=state.sdCommandBusy||!select.value;$("sd-export-btn").disabled=state.sdCommandBusy||!select.value;
  }
  async function refreshSdManager(){
    if(state.mode!=="live"){sdFeedback("Quản lý MicroSD chỉ hoạt động với dữ liệu trực tiếp.",true);return;}
    try{sdFeedback("Đang yêu cầu ESP32 đọc danh sách file...",false,true);const result=await runSdCommand("sd_list");renderSdList(result);sdFeedback(`Đã đọc ${fmt(result.file_count)} file log trên MicroSD.`);await refreshLocalLogCopies();}
    catch(error){setText("sd-manager-state","Không phản hồi");sdFeedback(error.message,true,true);}
  }
  async function viewSdLog(){
    const file=$("sd-log-select").value;if(!file)return;
    try{sdFeedback(`Đang đọc ${file}...`,false,true);const result=await runSdCommand("sd_read",{file,max_lines:12});const viewer=$("sd-log-viewer");viewer.textContent=(result.lines||[]).join("\n")||"File không có dòng log để hiển thị.";sdFeedback(`Đã đọc phần cuối ${file}.`);}
    catch(error){sdFeedback(error.message,true,true);}
  }
  async function refreshLocalLogCopies(){
    const device=currentDeviceId();if(!device)return;
    try{
      const response=await fetch(`/api/sd/local-files?device_id=${encodeURIComponent(device)}`,{cache:"no-store"});
      const data=await response.json();if(!response.ok||!data.ok)return;
      setText("sd-project-path",data.relative_dir||"SD_Logs/");setText("sd-project-count",`${(data.files||[]).length} file đã xuất`);
      const viewer=$("sd-project-files");viewer.textContent=(data.files||[]).map(file=>`${file.name} · ${bytes(file.size)} · ${file.relative_path}`).join("\n")||"Chưa có file nào được xuất từ MicroSD.";
    }catch{}
  }
  async function exportSelectedSdLog(){
    const file=$("sd-log-select").value;if(!file)return;
    try{
      sdFeedback(`Đang sao chép ${file} từ MicroSD vào thư mục project. ADXL345 vẫn lấy mẫu độc lập qua I²C...`,false,true);
      const result=await runSdCommand("sd_export",{file},600000);
      sdFeedback(`Đã xuất ${file} (${bytes(result.exported_bytes??result.size)}) → ${result.relative_path||"SD_Logs/"}.`,false,true);
      await refreshLocalLogCopies();
    }catch(error){sdFeedback(`Xuất log thất bại: ${error.message}`,true,true);}
  }
  async function exportAllSdLogs(){
    if(!state.sdFiles?.length){try{await refreshSdManager();}catch{} }
    const files=[...(state.sdFiles||[])];if(!files.length)return sdFeedback("Không có file log nào trên MicroSD để xuất.",true,true);
    if(!window.confirm(`Đồng bộ ${files.length} file log từ MicroSD vào thư mục project?\n\nViệc này có thể mất thời gian. Nên thực hiện khi xe đang dừng để dành tối đa tài nguyên cho AI.`))return;
    let done=0;
    try{
      for(const item of files){
        sdFeedback(`Đồng bộ ${done+1}/${files.length}: ${item.name}...`,false,true);
        await runSdCommand("sd_export",{file:item.name},600000);done++;
      }
      sdFeedback(`Đã đồng bộ ${done}/${files.length} file vào thư mục project.`,false,true);await refreshLocalLogCopies();
    }catch(error){sdFeedback(`Đã đồng bộ ${done}/${files.length} file. Dừng vì: ${error.message}`,true,true);await refreshLocalLogCopies();}
  }

  async function deleteSdRange(range,label){
    const deleteHazards=Boolean($("sd-delete-hazards")?.checked);const hazardText=deleteHazards?"\n\nĐIỂM CẢNH BÁO ổ gà/gờ giảm tốc trong cùng khoảng thời gian cũng sẽ bị xóa khỏi MicroSD và map sau khi ESP32 ACK.":"\n\nĐiểm cảnh báo và lộ trình sẽ được GIỮ NGUYÊN.";
    if(!window.confirm(`Xóa log: ${label}?${hazardText}\n\nOutbox chưa ACK (events.pending / pending) không bị xóa.`))return;
    try{
      sdFeedback("Đang xóa trên MicroSD. Không tắt nguồn ESP32...",false,true);
      const result=await runSdCommand("sd_delete",{...range,delete_hazards:deleteHazards});
      sdFeedback(`Đã xóa ${fmt(result.deleted_files)} file (${bytes(result.deleted_bytes)}). Ổ gà: ${fmt(result.deleted_potholes)} · Gờ: ${fmt(result.deleted_speed_bumps)} · Marker server: ${fmt(result.server_hazards_deleted)}.`);
      // Clear the old Leaflet heat/hazard layers immediately after the device
      // ACK. A generation token prevents an older in-flight V10 response from
      // painting those deleted colours back onto the map.
      // Every deleted log range owns its road-quality trail. Hazard markers are
      // removed only when the explicit checkbox was selected.
      clearDeletedMapArtifacts(deleteHazards);
      $("sd-log-viewer").textContent="Log viewer và bản đồ đã làm mới sau thao tác xóa.";await refreshSdManager();
      await loadV10Data(true);
      await poll();
    }catch(error){sdFeedback(error.message,true,true);}
  }
  function customSdRange(){
    const from=$("sd-from-date").value,to=$("sd-to-date").value;if(!from||!to||from>to)throw new Error("Hãy chọn khoảng ngày hợp lệ.");
    const fromDate=new Date(`${from}T00:00:00`),toDate=new Date(`${to}T23:59:59`);return {delete_all:false,from_date:from,to_date:to,from_epoch:Math.floor(fromDate.getTime()/1000),to_epoch:Math.floor(toDate.getTime()/1000)};
  }

  function drawChart(rows) {
    state.lastRows = rows; const canvas = $("accel-chart"), box = canvas.getBoundingClientRect(), dpr = window.devicePixelRatio || 1; if (!box.width || !box.height) return;
    canvas.width = Math.round(box.width*dpr); canvas.height = Math.round(box.height*dpr); const ctx = canvas.getContext("2d"); ctx.setTransform(dpr,0,0,dpr,0,0); const w=box.width,h=box.height; ctx.clearRect(0,0,w,h);
    ctx.strokeStyle="rgba(148,163,184,.11)";ctx.lineWidth=1;for(let i=1;i<5;i++){ctx.beginPath();ctx.moveTo(0,h*i/5);ctx.lineTo(w,h*i/5);ctx.stroke();}
    const slice=rows.slice(-54), maxAbs=Math.max(1.5,...slice.flatMap(row=>[Math.abs(number(row.x_g,0)),Math.abs(number(row.y_g,0)),Math.abs(number(row.z_g,0))]));
    for(const [key,color] of [["x_g","#22d3ee"],["y_g","#f59e0b"],["z_g","#a78bfa"]]){ctx.beginPath();ctx.strokeStyle=color;ctx.lineWidth=1.8;slice.forEach((row,i)=>{const x=slice.length>1?i/(slice.length-1)*w:0,y=h/2-number(row[key],0)/maxAbs*(h*.43);i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.stroke();}
  }

  function renderReadings(data,withRouteControls=true) {
    const hasTelemetry=Boolean(data.latest),latest=data.latest||{},rows=data.telemetry||[];
    const fresh=state.mode==="demo"||telemetryFresh(latest),roadValid=roadState(latest,data).valid,ecu=fresh&&truth(latest.ecu_online),gnssFix=fresh&&hasGnssFix(latest),gnssSpeed=gnssFix?number(latest.speed_kph):null,ecuSpeed=number(latest.ecu_speed_kph),canSpeedLive=ecu&&ecuSpeed!==null;
    renderStatuses(latest,fresh,roadValid); setText("device-id",String(latest.device_id||"Chờ ESP32"));setText("sync-time",clock(latest.ingested_at));$("overview").classList.toggle("stale",!fresh);
    const primarySpeed=canSpeedLive?ecuSpeed:gnssSpeed!==null?gnssSpeed:null;
    const speedWarn=number(state.deviceConfig?.overspeed_warning_kph,120),overspeed = canSpeedLive && (truth(latest.overspeed) || (primarySpeed !== null && primarySpeed > speedWarn));
    setText("speed",fmt(primarySpeed));
    setText("speed-source",overspeed?"CẢNH BÁO":canSpeedLive?"CAN":gnssSpeed!==null?"GNSS":"—");
    $("speed-card").className=`metric ${overspeed?"tone-red":"tone-cyan"}`;
    setText("speed-note",overspeed?`QUÁ TỐC: ${fmt(primarySpeed)} km/h > ${fmt(speedWarn)} km/h`:!hasTelemetry?"Chờ tốc độ từ ECU hoặc GNSS":!fresh?"Dữ liệu cũ đã bị khóa — chờ gói mới":canSpeedLive?"Nguồn chính: ECU · CAN 0x101 · dải 0–180 km/h":gnssSpeed!==null?"Dự phòng: GNSS M10 · ECU chưa có tốc độ":"Chưa có tốc độ hợp lệ");
    setText("gnss-speed",fmt(gnssSpeed));
    setText("gnss-speed-note",isDirectDemoDevice(latest.device_id)?"Vị trí mô phỏng theo biến trở × hệ số · không phải tốc độ GPS thật":isAutoDemoDevice(latest.device_id)?"Demo tổng hợp · tốc độ theo chuyển động trên map":state.mode==="demo"?"Nguồn: GNSS M10 · dữ liệu mô phỏng":`${gnssLabel(latest,fresh)} · ${number(latest.gnss_filter_version)===1?"GNSS đã lọc":"GNSS M10"}`);
    setText("gnss-speed-heading",isDirectDemoDevice(latest.device_id)?"TỐC ĐỘ XE ẢO":"TỐC ĐỘ GNSS");
    setText("gnss-speed-source",isDirectDemoDevice(latest.device_id)?"CAN × HỆ SỐ":"GNSS / DEMO");
    $("gnss-speed-note").title=gnssDetail(latest,fresh);
    $("map-coords").title=gnssDetail(latest,fresh);
    setText("temperature",fmt(fresh&&ecu?latest.temperature_c:null,1));
    setText("temperature-note",!hasTelemetry?"Chờ ECU · CAN 0x102":fresh?(ecu?"Nguồn: ECU · CAN 0x102":"Mất heartbeat ECU · CAN 0x102"):"Nguồn: ECU/CAN · giá trị cuối");
    $("temperature-card").className=`metric ${number(latest.temperature_c,0)>95?"tone-red":"tone-amber"}`;
    if(state.mode==="demo"){const trip=number(latest.trip_distance_km);setText("trip",fmt(trip===null?routeDistance(rows):trip,2));setText("trip-route-badge","DEMO");setText("trip-note","Lộ trình mô phỏng");}else if(withRouteControls)renderRouteControls();
    renderRoad(latest,data);renderHealth(latest,fresh);
    renderDirectRealtimeReadings();renderConnection();
  }

  function render(data) {
    state.data=data;const latest=data.latest||{},rows=data.telemetry||[],events=data.events||[];
    if(state.mode==="live")mergeDashboardEvents(events);
    renderReadings(data);
    renderEvents(state.mode==="live"&&state.eventCenterLoaded?state.eventCenterEvents:events);updateMap({device_id:data.device_id,latest,telemetry:rows,events,potholes:data.potholes||[],speed_bumps:data.speed_bumps||[]});drawChart(rows);
  }

  function applyLiveSnapshot(data,sourceGeneration=state.sourceGeneration) {
    if(sourceGeneration!==state.sourceGeneration||!data?.ok||state.mode!=="live"||!Object.prototype.hasOwnProperty.call(data,"latest"))return false;
    const device=String(data.device_id||data.latest?.device_id||""),expected=String(state.selectedDevice||currentDeviceId());
    if(expected&&device!==expected)return false;
    if(data.latest&&String(data.latest.device_id||device)!==device)return false;
    const existing=state.liveData?.device_id===device?state.liveData:null;
    if(existing?.latest&&data.latest&&timeMs(existing.latest.ingested_at)>timeMs(data.latest.ingested_at))return false;
    const snapshot={...(existing||{telemetry:[],events:[],potholes:[],speed_bumps:[]}),device_id:device,latest:data.latest,road_current:data.road_current,server_now:data.server_now,transport_delay_ms:data.transport_delay_ms,_received_at:Date.now()};
    rememberServerClock(data);recordServerTransport(true);state.liveData=snapshot;state.data=snapshot;
    // No route/history/event fetch, canvas redraw or hazard rebuild on the fast
    // Internet lane. The normal dashboard refresh remains responsible for them.
    renderReadings(snapshot,false);
    const latest=isDirectDemoDevice(device)?directMapLatest(data.latest):data.latest;
    if(latest&&telemetryFresh(latest)&&hasGnssFix(latest)&&state.vehicleCore){
      const pos=[number(latest.lat),number(latest.lon)];
      if(isDirectDemoDevice(device))animateDirectVehicle(latest,pos);
      else if(isAutoDemoDevice(device))animateDemoVehicle(latest,pos,vehicleMotion.routeRows);
      else drawVehiclePosition(pos);
      setText("map-coords",`${fmt(pos[0],6)}, ${fmt(pos[1],6)}`);
    }
    return true;
  }

  function renderConnection(){
    state.serverOnline=serverTransport.lastSuccess>0&&Date.now()-serverTransport.lastSuccess<8000;
    const online=state.serverOnline,pill=$("server-pill"),footer=$("footer-status"),sidebar=$("sidebar-sync"),notice=$("connection-notice"),hasLive=Boolean(state.liveData?.latest);
    const remote=window.TelematicsAccess?.remote===true;
    if($("logout-button"))$("logout-button").hidden=!remote||window.TelematicsAccess?.requiresLogin!==true;
    setText("access-heading","TRUNG TÂM ĐIỀU HÀNH");
    setText("access-note",remote?"Truy cập từ xa qua HTTPS · máy tính phải đang bật":"Máy chủ dữ liệu trên máy tính");
    pill.classList.toggle("offline",!online);pill.querySelector("span").textContent=online?(remote?"KẾT NỐI HTTPS":"MÁY CHỦ NỘI BỘ"):"MẤT MÁY CHỦ";
    footer.textContent=online?`${state.mode==="demo"?"Demo":"Đã kết nối"} · ${remote?"HTTPS từ xa":"mạng nội bộ"}`:"Mất kết nối server";footer.classList.toggle("offline",!online);sidebar.classList.toggle("offline",!online);setText("sync-label",online?"Đồng bộ":"Mất server");
    if(!online){notice.hidden=false;notice.classList.add("offline");setText("connection-notice-title",remote?"Chưa kết nối được máy chủ qua Internet":"Máy chủ chưa phản hồi");setText("connection-notice-detail",remote?"Kiểm tra Internet và đường hầm HTTPS; máy tính chạy hệ thống phải đang bật. Trang sẽ tự thử kết nối lại.":"Hãy chạy START_DASHBOARD.bat và giữ cửa sổ server mở. Trang sẽ tự kết nối lại sau mỗi 5 giây.");}
    else if(!hasLive){notice.hidden=false;notice.classList.remove("offline");setText("connection-notice-title","Server đã sẵn sàng — đang chờ ESP32-S3");setText("connection-notice-detail","Kiểm tra Serial Monitor phải có dòng [WEB ] OK ... HTTP 201. Dữ liệu sẽ xuất hiện tự động.");}
    else notice.hidden=true;
  }

  function updateModeButton(){const button=$("mode-button"),demo=state.mode==="demo";button.classList.toggle("demo",demo);button.querySelector("span").textContent=demo?"Dữ liệu mô phỏng":"Dữ liệu trực tiếp";}
  async function poll(){
    if(state.requestInFlight){state.pollPending=true;return;}
    state.requestInFlight=true;
    const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),window.TelematicsAccess?.remote?6000:DASHBOARD_TIMEOUT_MS),startedAt=performance.now();
    const generation=state.sourceGeneration,requestedDevice=String(state.selectedDevice||"");
    try{
      const query=requestedDevice?`?device_id=${encodeURIComponent(requestedDevice)}`:"";
      const response=await fetch(`/api/dashboard${query}`,{cache:"no-store",signal:controller.signal});if(!response.ok)throw new Error(`HTTP ${response.status}`);
      const data=await response.json();
      data.transport_delay_ms=Math.max(0,Math.round(performance.now()-startedAt));
      if(generation!==state.sourceGeneration||requestedDevice!==String(state.selectedDevice||""))return;
      if(requestedDevice&&String(data.device_id||data.latest?.device_id||"")!==requestedDevice)return;
      recordServerTransport(true);
      if(data.ok){
        rememberServerClock(data);
        state.liveData=newestSnapshot({device_id:data.device_id,latest:data.latest,telemetry:data.telemetry||[],events:data.events||[],potholes:data.potholes||[],speed_bumps:data.speed_bumps||[],server_now:data.server_now,transport_delay_ms:data.transport_delay_ms,road_current:data.road_current,_received_at:Date.now()},state.liveData);
        const liveDevice=String(data.device_id||data.latest?.device_id||"");
        if(data.device_config)fillConfig({...data.device_config,view_device_id:liveDevice});
        else if(liveDevice&&configViewId(state.deviceConfig)!==liveDevice){await loadCachedConfig();if(generation!==state.sourceGeneration)return;if(!state.deviceConfig)fillConfig({device_id:liveDevice,overspeed_warning_kph:120,overspeed_clear_kph:115,geofence_warning_m:10,geofence_rearm_m:20,pothole_confidence:.80,speed_bump_confidence:.80,source:"default",confirmed:false});}
        if(data.latest&&!state.modeLocked){if(state.mode!=="live")state.mapFitted=false;state.mode="live";updateModeButton();}
        if(state.mode==="live"){
          // Fresh ECU/sensor/event data must not wait for route history. A
          // stalled route query used to hold the entire dashboard poll lock.
          render(state.liveData);
          void loadRoutes(false).then(changed=>{
            if(changed&&generation===state.sourceGeneration&&requestedDevice===String(state.selectedDevice||"")&&state.mode==="live"&&state.data){
              renderRouteControls();updateMap(state.data);
            }
          });
          loadV10Data(false);searchEventCenter(false,false,true);
        }else renderConnection();
      }
    }
    catch{if(generation!==state.sourceGeneration)return;recordServerTransport(false);if(state.data)render(state.data);else renderConnection();}
    finally{clearTimeout(timeout);state.requestInFlight=false;if(state.pollPending){state.pollPending=false;queueMicrotask(poll);}}
  }
  async function loadDevices(){try{const response=await fetch("/api/devices",{cache:"no-store"}),data=await response.json();if(!data.ok)return;const select=$("device-select"),current=String(state.selectedDevice||select.value||"");select.replaceChildren();const automatic=document.createElement("option");automatic.value="";automatic.textContent="Tự động chọn";select.append(automatic);for(const device of data.devices||[]){const option=document.createElement("option");option.value=String(device.device_id);option.textContent=`${device.device_id} · ${clock(device.last_seen)}`;select.append(option);}if(current&&![...select.options].some(option=>option.value===current)){const pinned=document.createElement("option");pinned.value=current;pinned.textContent=`${current} · ĐANG KHÓA NGUỒN`;select.append(pinned);}select.value=current; }catch{}}

  const SIDEBAR_PREF_KEY="hx_sidebar_collapsed";
  const isMobileSidebar=()=>window.matchMedia("(max-width:820px)").matches;
  function setDrawer(open){
    if(!isMobileSidebar()) return;
    $("sidebar").classList.toggle("open",open);
    $("drawer-overlay").hidden=!open;
    $("menu-button").setAttribute("aria-expanded",String(open));
    document.body.classList.toggle("drawer-open",open);
  }
  function setDesktopSidebarCollapsed(collapsed,persist=true){
    if(isMobileSidebar()) return;
    document.body.classList.toggle("sidebar-collapsed",collapsed);
    $("menu-button").setAttribute("aria-expanded",String(!collapsed));
    $("menu-button").setAttribute("aria-label",collapsed?"Hiện thanh điều hướng":"Ẩn thanh điều hướng");
    $("menu-button").title=collapsed?"Hiện thanh điều hướng":"Ẩn thanh điều hướng";
    if(persist){try{localStorage.setItem(SIDEBAR_PREF_KEY,collapsed?"1":"0");}catch(_){}}
  }
  function restoreSidebarPreference(){
    if(isMobileSidebar()){
      document.body.classList.remove("sidebar-collapsed");
      setDrawer(false);
      return;
    }
    let collapsed=false;
    try{collapsed=localStorage.getItem(SIDEBAR_PREF_KEY)==="1";}catch(_){}
    setDesktopSidebarCollapsed(collapsed,false);
  }
  $("menu-button").addEventListener("click",()=>{
    if(isMobileSidebar()) setDrawer(!$("sidebar").classList.contains("open"));
    else setDesktopSidebarCollapsed(!document.body.classList.contains("sidebar-collapsed"));
  });
  $("drawer-overlay").addEventListener("click",()=>setDrawer(false));
  document.querySelectorAll(".sidebar nav a").forEach(link=>link.addEventListener("click",()=>{if(isMobileSidebar())setDrawer(false);}));
  document.addEventListener("keydown",event=>{
    if(event.key!=="Escape")return;
    if(isMobileSidebar())setDrawer(false);
    else if(!document.body.classList.contains("sidebar-collapsed"))setDesktopSidebarCollapsed(true);
  });
  window.addEventListener("resize",restoreSidebarPreference);
  restoreSidebarPreference();
  $("mode-button").addEventListener("click",async()=>{state.modeLocked=true;if(state.mode==="demo"&&state.liveData?.latest){state.mode="live";state.mapFitted=false;await loadRoutes(true);}else state.mode="demo";updateModeButton();renderRouteControls();render(state.mode==="demo"?makeDemo(state.tick):state.liveData||{latest:null,telemetry:[],events:[],potholes:[],speed_bumps:[]});});
  async function selectDeviceSource(deviceValue){
    cancelRouteRequests();
    directRealtime.packet=null;
    if(directView.rotated&&String(deviceValue)!==directView.session?.virtual_device_id)clearDirectMapView();
    stopVehicleMotion(true);
    stopReplay(true);
    clearSelfTestAutoHide();
    state.sourceGeneration++;state.selectedDevice=String(deviceValue||"");state.selectedRouteId=null;state.activeRoute=null;state.displayedRoute=null;state.routePoints=[];state.routeEvents=[];state.routeStats=null;state.mapFitted=false;state.sdFiles=[];state.sdLastResult=null;state.selfTest=null;state.deviceConfig=null;state.configDirty=false;state.eventFiltersApplied=false;state.eventCenterEvents=[];state.eventTotal=0;state.eventNextOffset=0;state.eventHasMore=false;state.eventCenterLoaded=false;
    clearDeletedMapArtifacts(true);
    renderSelfTest();setText("sd-manager-state","Chờ làm mới");fillConfig({device_id:currentDeviceId(),overspeed_warning_kph:120,overspeed_clear_kph:115,geofence_warning_m:10,geofence_rearm_m:20,pothole_confidence:.80,speed_bump_confidence:.80,source:"default"});
    await loadCachedConfig();poll();
  }
  $("device-select").addEventListener("change",async event=>{await selectDeviceSource(event.target.value);window.dispatchEvent(new CustomEvent("telematics:source-changed",{detail:{device_id:event.target.value}}));});
  $("direct-route-toggle").addEventListener("click",()=>{const open=$("map-card").classList.toggle("direct-route-open");$("direct-route-toggle").setAttribute("aria-expanded",String(open));});
  window.telematicsDashboard=Object.freeze({
    currentDeviceId,
    applyLiveSnapshot,
    acceptServerClock:rememberServerClock,
    getServerTimeMs:serverTimeMs,
    getSourceGeneration(){return state.sourceGeneration;},
    recordServerTransport(ok){const online=recordServerTransport(ok);renderConnection();return online;},
    applyDirectRealtime,
    getDirectRealtime(){return directMotionPacket();},
    refreshDirectRealtime:renderDirectRealtimeReadings,
    setDirectDemoView(session){return setDirectMapView(session,false);},
    previewDirectDemoRoad(route){return setDirectMapView({route},true);},
    clearDirectDemoView(){clearDirectMapView();if(state.data)updateMap(state.data);},
    getDisplayedVehiclePosition(){
      const latest=state.data?.latest;
      if(!latest||!telemetryFresh(latest)||!state.vehicleCore)return null;
      const point=state.vehicleCore.getLatLng();
      return {lat:point.lat,lon:point.lng,device_id:String(latest.device_id||""),boot_id:String(latest.boot_id||"")};
    },
    async selectDevice(deviceValue,label=""){
      state.mode="live";state.modeLocked=true;updateModeButton();
      const value=String(deviceValue||""),select=$("device-select");
      if(value&&![...select.options].some(option=>option.value===value)){
        const option=document.createElement("option");option.value=value;option.textContent=label||value;select.append(option);
      }
      select.value=value;
      await selectDeviceSource(value);
      window.dispatchEvent(new CustomEvent("telematics:source-changed",{detail:{device_id:value}}));
    }
  });
  $("route-start-btn").addEventListener("click",startRouteAction);$("route-end-btn").addEventListener("click",endRouteAction);$("route-delete-btn").addEventListener("click",deleteRouteAction);
  $("route-replay-btn").addEventListener("click",startReplay);
  $("route-replay-pause-btn").addEventListener("click",()=>stopReplay(false));
  $("route-replay-slider").addEventListener("input",event=>{stopReplay(false);state.replayPosition=number(event.target.value,0);updateReplayMarker();renderReplayControls();});
  $("self-test-btn").addEventListener("click",runSelfTest);
  $("self-test-toggle").addEventListener("click",()=>{
    clearSelfTestAutoHide();
    const show=$("self-test-details").hidden;
    setSelfTestDetailsVisible(show);
    if(show)scheduleSelfTestAutoHide();
  });
  $("event-search-btn").addEventListener("click",()=>searchEventCenter(true));
  $("event-clear-btn").addEventListener("click",clearEventFilters);
  $("event-query").addEventListener("keydown",event=>{if(event.key==="Enter"){event.preventDefault();searchEventCenter(true);}});
  $("event-list").addEventListener("scroll",event=>{const list=event.currentTarget;if(state.eventHasMore&&!state.eventSearchInFlight&&list.scrollTop+list.clientHeight>=list.scrollHeight-120)searchEventCenter(false,true,true);});
  $("config-read-btn").addEventListener("click",readConfigFromDevice);
  $("config-save-btn").addEventListener("click",saveConfigToDevice);
  ["cfg-speed-warn","cfg-speed-clear","cfg-geo-warn","cfg-geo-rearm","cfg-pothole","cfg-bump"].forEach(id=>$(id).addEventListener("input",()=>{state.configDirty=true;configFeedback("Thông số đang sửa chưa áp dụng. Bấm Lưu vào NVS và chờ ESP xác nhận.");}));
  $("route-select").addEventListener("change",async event=>{state.selectedRouteId=event.target.value?Number(event.target.value):null;state.mapFitted=false;try{if(state.selectedRouteId)await fetchRouteDetail(state.selectedRouteId,true);else{state.displayedRoute=null;state.routePoints=[];state.routeEvents=[];state.routeStats=null;stopReplay(true);}renderRouteControls();if(state.data)render(state.data);state.v10LastLoad=0;loadV10Data(true);}catch(error){setRouteFeedback("Không tải được lộ trình đã chọn",true);}});
  $("sd-refresh-btn").addEventListener("click",refreshSdManager);
  $("sd-view-btn").addEventListener("click",viewSdLog);
  $("sd-log-select").addEventListener("change",()=>{const empty=!$("sd-log-select").value;$("sd-view-btn").disabled=state.sdCommandBusy||empty;$("sd-export-btn").disabled=state.sdCommandBusy||empty;});
  $("sd-export-btn").addEventListener("click",exportSelectedSdLog);
  $("sd-export-all-btn").addEventListener("click",exportAllSdLogs);
  document.querySelectorAll("[data-sd-range]").forEach(button=>button.addEventListener("click",()=>{const kind=button.dataset.sdRange;const labels={today:"hôm nay",'7days':"7 ngày gần nhất",'30days':"30 ngày gần nhất",month:"tháng hiện tại",all:"TẤT CẢ LOG"};deleteSdRange(presetRange(kind),labels[kind]||kind);}));
  $("sd-delete-custom-btn").addEventListener("click",()=>{try{const range=customSdRange();deleteSdRange(range,`${range.from_date} → ${range.to_date}`);}catch(error){sdFeedback(error.message,true);}});
  $("hazard-refresh-btn").addEventListener("click",()=>loadV10Data(true));
  $("hazard-type-filter").addEventListener("change",renderHazardManager);
  window.addEventListener("telematics:sse-update",event=>{
    const detail=event.detail||{};
    if(detail.kind==="event"){
      acceptRealtimeEvent(detail);
      searchEventCenter(false,false,true);
      loadV10Data(true);
    }
    if(detail.kind==="config"||detail.kind==="device_config")loadCachedConfig();
    poll();
  });
  window.addEventListener("telematics:direct-realtime",event=>applyDirectRealtime(event.detail));
  window.addEventListener("telematics:live-snapshot",event=>applyLiveSnapshot(event.detail,event.detail?.source_generation??state.sourceGeneration));
  window.addEventListener("telematics:access-status",()=>{renderConnection();if(state.tiles&&state.tileUrl!==mapTileUrl())retryMapTiles();});
  $("map-retry")?.addEventListener("click",retryMapTiles);
  $("logout-button")?.addEventListener("click",async()=>{
    const button=$("logout-button");button.disabled=true;
    try{const response=await fetch("/logout",{method:"POST",credentials:"same-origin"});if(!response.ok)throw new Error(`HTTP ${response.status}`);window.location.assign("/login");}
    catch{button.disabled=false;button.textContent="Thử đăng xuất lại";button.title="Chưa nhận được xác nhận từ máy chủ. Kiểm tra Internet rồi thử lại.";}
  });
  const resizeObserver="ResizeObserver" in window?new ResizeObserver(()=>drawChart(state.lastRows)):null;resizeObserver?.observe($("accel-chart"));window.addEventListener("beforeunload",()=>{stopVehicleMotion(true);resizeObserver?.disconnect();state.mapResizeObserver?.disconnect();clearTimeout(state.mapResizeTimer);clearSelfTestAutoHide();},{once:true});
  function updateClock(){const now=new Date();setText("clock",now.toLocaleTimeString("vi-VN",{hour:"2-digit",minute:"2-digit"}));setText("date",now.toLocaleDateString("vi-VN",{day:"2-digit",month:"2-digit",year:"numeric"}));state.tick++;if(state.mode==="demo")render(makeDemo(state.tick));else if(state.data)renderReadings(state.data,false);}
  {const today=new Date();$("sd-to-date").value=dateYmd(today);const week=new Date(today);week.setDate(week.getDate()-6);$("sd-from-date").value=dateYmd(week);}
  fillConfig({device_id:"",overspeed_warning_kph:120,overspeed_clear_kph:115,geofence_warning_m:10,geofence_rearm_m:20,pothole_confidence:.80,speed_bump_confidence:.80,source:"default"});renderSelfTest();renderHazardManager();updateModeButton();renderRouteControls();render({latest:null,telemetry:[],events:[],potholes:[],speed_bumps:[]});updateClock();poll();loadDevices();setInterval(updateClock,1000);setInterval(poll,DASHBOARD_POLL_MS);setInterval(loadDevices,15000);
})();
