(() => {
  "use strict";

  const $ = id => document.getElementById(id);
  const SVG_NS = "http://www.w3.org/2000/svg";
  let reportMap = null;
  window.__tripReportReady = false;
  window.__tripReportMapStatus = "pending";
  const numberFormat = new Intl.NumberFormat("vi-VN", { maximumFractionDigits: 2 });
  const dateFormat = new Intl.DateTimeFormat("vi-VN", {
    day: "2-digit", month: "2-digit", year: "numeric",
    hour: "2-digit", minute: "2-digit", second: "2-digit",
  });

  const eventLabels = Object.freeze({
    pothole_detected: "Phát hiện ổ gà",
    pothole_proximity: "Đến gần ổ gà",
    speed_bump_detected: "Phát hiện gờ giảm tốc",
    speed_bump_proximity: "Đến gần gờ giảm tốc",
    overspeed: "Cảnh báo quá tốc",
    overspeed_cleared: "Đã hết cảnh báo quá tốc",
    dtc_active: "Mã lỗi động cơ DTC",
    ecu_offline: "Mất kết nối ECU",
    ecu_recovered: "ECU đã kết nối lại",
    device_rebooted: "Thiết bị khởi động lại",
  });

  const severityLabels = Object.freeze({
    warning: "Cảnh báo", error: "Lỗi", critical: "Nghiêm trọng",
    success: "Bình thường", info: "Thông tin",
  });

  function finite(value) {
    const result = Number(value);
    return value !== null && value !== undefined && value !== "" && Number.isFinite(result) ? result : null;
  }

  function validCoordinates(item) {
    const lat = finite(item?.lat), lon = finite(item?.lon);
    return lat !== null && lon !== null && Math.abs(lat) <= 90 && Math.abs(lon) <= 180 && !(lat === 0 && lon === 0);
  }

  function setText(id, value) {
    const node = $(id);
    if (node) node.textContent = value ?? "—";
  }

  function formatNumber(value, digits = 1) {
    const number = finite(value);
    if (number === null) return "—";
    return new Intl.NumberFormat("vi-VN", { minimumFractionDigits: digits, maximumFractionDigits: digits }).format(number);
  }

  function parseTime(value) {
    if (value === null || value === undefined || value === "") return null;
    const date = new Date(typeof value === "number" || /^\d+$/.test(String(value)) ? Number(value) : value);
    return Number.isFinite(date.getTime()) ? date : null;
  }

  function formatDateTime(value) {
    const date = parseTime(value);
    return date ? dateFormat.format(date) : "—";
  }

  function formatEventTime(event) {
    return formatDateTime(event?.recorded_at || event?.ingested_at);
  }

  function formatDuration(value) {
    const total = finite(value);
    if (total === null) return "—";
    const seconds = Math.max(0, Math.round(total));
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const rest = seconds % 60;
    return [hours, minutes, rest].map(part => String(part).padStart(2, "0")).join(":");
  }

  function eventKind(name = "") {
    const value = String(name).toLowerCase();
    if (value.includes("pothole")) return "pothole";
    if (value.includes("speed_bump")) return "bump";
    if (value.includes("overspeed")) return value.includes("cleared") ? "ok" : "overspeed";
    if (value.includes("dtc")) return "dtc";
    if (value.includes("recovered")) return "ok";
    return "system";
  }

  function eventLabel(event) {
    const name = String(event?.name || "unknown");
    return eventLabels[name] || name.replaceAll("_", " ");
  }

  function eventDetails(event) {
    const details = [];
    const confidence = finite(event?.confidence);
    const distance = finite(event?.distance_m);
    const dtc = finite(event?.dtc_code);
    if (confidence !== null && confidence > 0) details.push(`Tin cậy ${formatNumber(confidence * 100, 1)}%`);
    if (distance !== null) details.push(`Khoảng cách ${formatNumber(distance, 1)} m`);
    if (dtc !== null && dtc > 0) details.push(`DTC ${Math.round(dtc)}`);
    if (event?.road_label) details.push(String(event.road_label).replaceAll("_", " "));
    return details.length ? details.join(" · ") : "—";
  }

  function coordinatesText(item) {
    if (!validCoordinates(item)) return "—";
    return `Lat ${formatNumber(item.lat, 6)} ; Lon ${formatNumber(item.lon, 6)}`;
  }

  function svgElement(name, attributes = {}) {
    const node = document.createElementNS(SVG_NS, name);
    for (const [key, value] of Object.entries(attributes)) node.setAttribute(key, String(value));
    return node;
  }

  function appendSvgText(parent, text, attributes) {
    const node = svgElement("text", attributes);
    node.textContent = text;
    parent.append(node);
    return node;
  }

  function samplePoints(points, limit = 3000) {
    if (points.length <= limit) return points;
    const sampled = [points[0]];
    const stride = (points.length - 1) / (limit - 1);
    for (let index = 1; index < limit - 1; index += 1) sampled.push(points[Math.round(index * stride)]);
    sampled.push(points.at(-1));
    return sampled;
  }

  function renderVectorFallback(points, events) {
    const host = $("route-map");
    const routeSegments = window.TelematicsRouteGeometry.splitRouteSegments(
      (Array.isArray(points) ? points : []).map(point => validCoordinates(point) ? point : null));
    const routePoints = routeSegments.flat();
    const locatedEvents = (Array.isArray(events) ? events : []).filter(validCoordinates);
    host.classList.add("is-fallback");
    host.replaceChildren();

    if (!routePoints.length) {
      const message = document.createElement("p");
      message.textContent = "Lộ trình chưa có điểm GNSS hợp lệ để dựng sơ đồ.";
      host.append(message);
      setText("map-caption", "Không có dữ liệu tọa độ hợp lệ trong lộ trình này.");
      return;
    }

    const width = 920, height = 370, padding = 48;
    const allLocated = [...routePoints, ...locatedEvents];
    const meanLatitude = allLocated.reduce((sum, item) => sum + Number(item.lat), 0) / allLocated.length;
    const longitudeFactor = Math.max(.2, Math.cos(meanLatitude * Math.PI / 180));
    const projected = item => ({ x: Number(item.lon) * longitudeFactor, y: Number(item.lat) });
    const projectedAll = allLocated.map(projected);
    let minX = Math.min(...projectedAll.map(item => item.x));
    let maxX = Math.max(...projectedAll.map(item => item.x));
    let minY = Math.min(...projectedAll.map(item => item.y));
    let maxY = Math.max(...projectedAll.map(item => item.y));
    if (maxX - minX < 1e-7) { minX -= 5e-7; maxX += 5e-7; }
    if (maxY - minY < 1e-7) { minY -= 5e-7; maxY += 5e-7; }
    const scale = Math.min((width - padding * 2) / (maxX - minX), (height - padding * 2) / (maxY - minY));
    const offsetX = (width - (maxX - minX) * scale) / 2;
    const offsetY = (height - (maxY - minY) * scale) / 2;
    const screen = item => {
      const value = projected(item);
      return { x: offsetX + (value.x - minX) * scale, y: height - offsetY - (value.y - minY) * scale };
    };

    const svg = svgElement("svg", { viewBox: `0 0 ${width} ${height}`, role: "img", "aria-labelledby": "route-map-svg-title route-map-svg-desc", preserveAspectRatio: "xMidYMid meet" });
    const title = svgElement("title", { id: "route-map-svg-title" });
    title.textContent = "Sơ đồ tuyến đường theo dữ liệu GNSS";
    const description = svgElement("desc", { id: "route-map-svg-desc" });
    description.textContent = `Lộ trình gồm ${routePoints.length} điểm GNSS và ${locatedEvents.length} sự kiện có tọa độ.`;
    svg.append(title, description);

    const defs = svgElement("defs");
    const gradient = svgElement("linearGradient", { id: "map-background", x1: "0", y1: "0", x2: "1", y2: "1" });
    gradient.append(svgElement("stop", { offset: "0", "stop-color": "#f8fcfd" }), svgElement("stop", { offset: "1", "stop-color": "#edf7f9" }));
    const shadow = svgElement("filter", { id: "route-shadow", x: "-20%", y: "-20%", width: "140%", height: "140%" });
    shadow.append(svgElement("feDropShadow", { dx: "0", dy: "2", stdDeviation: "2", "flood-color": "#0e7490", "flood-opacity": ".23" }));
    defs.append(gradient, shadow);
    svg.append(defs, svgElement("rect", { width, height, fill: "url(#map-background)" }));

    const grid = svgElement("g", { stroke: "#dce9ee", "stroke-width": "1" });
    for (let x = 55; x < width; x += 82) grid.append(svgElement("line", { x1: x, y1: 0, x2: x, y2: height }));
    for (let y = 36; y < height; y += 56) grid.append(svgElement("line", { x1: 0, y1: y, x2: width, y2: y }));
    svg.append(grid);

    for (const segment of routeSegments) {
      const linePoints = samplePoints(segment).map(item => { const p = screen(item); return `${p.x.toFixed(2)},${p.y.toFixed(2)}`; }).join(" ");
      svg.append(
        svgElement("polyline", { points: linePoints, fill: "none", stroke: "#ffffff", "stroke-width": "10", "stroke-linecap": "round", "stroke-linejoin": "round", opacity: ".94" }),
        svgElement("polyline", { points: linePoints, fill: "none", stroke: "#0891b2", "stroke-width": "5", "stroke-linecap": "round", "stroke-linejoin": "round", filter: "url(#route-shadow)" }),
      );
    }

    const eventLayer = svgElement("g", { "aria-label": "Các sự kiện có tọa độ" });
    const markerColors = { pothole: "#ef4444", bump: "#f59e0b", overspeed: "#f97316", dtc: "#8b5cf6", ok: "#10b981", system: "#64748b" };
    for (const event of locatedEvents.slice(0, 500)) {
      const position = screen(event), kind = eventKind(event.name);
      const group = svgElement("g");
      const hint = svgElement("title");
      hint.textContent = `${eventLabel(event)} · ${formatEventTime(event)}`;
      group.append(
        hint,
        svgElement("circle", { cx: position.x, cy: position.y, r: "8", fill: "#ffffff", opacity: ".92" }),
        svgElement("circle", { cx: position.x, cy: position.y, r: "5", fill: markerColors[kind] || markerColors.system, stroke: "#ffffff", "stroke-width": "1.5" }),
      );
      eventLayer.append(group);
    }
    svg.append(eventLayer);

    const addEndpoint = (item, label, fill) => {
      const position = screen(item), group = svgElement("g");
      group.append(
        svgElement("circle", { cx: position.x, cy: position.y, r: "11", fill: "#ffffff", stroke: fill, "stroke-width": "2.5" }),
        svgElement("circle", { cx: position.x, cy: position.y, r: "5.5", fill }),
      );
      appendSvgText(group, label, { x: position.x + 15, y: position.y - 10, fill: "#173b57", "font-size": "12", "font-family": "Segoe UI, Arial, sans-serif", "font-weight": "700", stroke: "#ffffff", "stroke-width": "3", "paint-order": "stroke" });
      svg.append(group);
    };
    addEndpoint(routePoints[0], "Bắt đầu", "#10b981");
    addEndpoint(routePoints.at(-1), "Kết thúc", "#ef4444");

    const compass = svgElement("g", { transform: `translate(${width - 34} 32)`, "aria-hidden": "true" });
    compass.append(svgElement("circle", { r: "18", fill: "#ffffff", stroke: "#c9dbe4" }), svgElement("path", { d: "M0 -12 L5 3 L0 0 L-5 3 Z", fill: "#164e63" }));
    appendSvgText(compass, "B", { x: "0", y: "13", "text-anchor": "middle", fill: "#4f6f85", "font-size": "8", "font-family": "Segoe UI, Arial, sans-serif", "font-weight": "800" });
    svg.append(compass);
    host.append(svg);

    const omitted = Math.max(0, locatedEvents.length - 500);
    setText("map-caption", `Sơ đồ từ ${numberFormat.format(routePoints.length)} điểm GNSS${locatedEvents.length ? ` · ${numberFormat.format(locatedEvents.length)} sự kiện có tọa độ` : ""}${omitted ? ` · ${numberFormat.format(omitted)} điểm sự kiện không vẽ để bảo đảm hiệu năng` : ""}.`);
  }

  function waitForLeaflet(timeoutMs = 2500) {
    if (window.L?.map && window.L?.tileLayer) return Promise.resolve(window.L);
    return new Promise(resolve => {
      const startedAt = performance.now();
      const timer = window.setInterval(() => {
        if (window.L?.map && window.L?.tileLayer) {
          window.clearInterval(timer);
          resolve(window.L);
        } else if (performance.now() - startedAt >= timeoutMs) {
          window.clearInterval(timer);
          resolve(null);
        }
      }, 50);
    });
  }

  function waitForTileLayer(layer, timeoutMs = 5500) {
    return new Promise(resolve => {
      let finished = false;
      let tileErrors = 0;
      const finish = status => {
        if (finished) return;
        finished = true;
        window.clearTimeout(timer);
        layer.off("load", onLoad);
        layer.off("tileerror", onTileError);
        resolve(status);
      };
      const onLoad = () => finish(tileErrors ? "partial" : "loaded");
      const onTileError = () => { tileErrors += 1; };
      const timer = window.setTimeout(() => finish(tileErrors ? "partial" : "timeout"), timeoutMs);
      layer.on("load", onLoad);
      layer.on("tileerror", onTileError);
    });
  }

  function nextPaint() {
    return new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
  }

  function leafletIcon(leaflet, kind, endpoint = false) {
    const safeKind = ["start", "end", "pothole", "bump", "overspeed", "dtc", "ok", "system"].includes(kind) ? kind : "system";
    const size = endpoint ? 24 : 18;
    return leaflet.divIcon({
      className: `report-map-marker ${safeKind}${endpoint ? " endpoint" : ""}`,
      html: '<span aria-hidden="true"></span>',
      iconSize: [size, size],
      iconAnchor: [size / 2, size / 2],
    });
  }

  async function renderRouteMap(points, events) {
    const host = $("route-map");
    const routeSegments = window.TelematicsRouteGeometry.splitRouteSegments(
      (Array.isArray(points) ? points : []).map(point => validCoordinates(point) ? point : null));
    const routePoints = routeSegments.flat();
    const locatedEvents = (Array.isArray(events) ? events : []).filter(validCoordinates);
    const omitted = Math.max(0, locatedEvents.length - 500);

    if (reportMap) {
      reportMap.remove();
      reportMap = null;
    }
    host.classList.remove("is-fallback");
    host.replaceChildren();

    if (!routePoints.length) {
      host.classList.add("is-fallback");
      const message = document.createElement("p");
      message.textContent = "Lộ trình chưa có điểm GNSS hợp lệ để hiển thị trên bản đồ.";
      host.append(message);
      setText("map-caption", "Không có dữ liệu tọa độ hợp lệ trong lộ trình này.");
      window.__tripReportMapStatus = "empty";
      return "empty";
    }

    const leaflet = await waitForLeaflet();
    if (!leaflet) {
      renderVectorFallback(points, locatedEvents);
      setText("map-caption", `Không tải được thư viện bản đồ; hệ thống đang hiển thị sơ đồ GNSS dự phòng từ ${numberFormat.format(routePoints.length)} điểm.`);
      window.__tripReportMapStatus = "fallback";
      return "fallback";
    }

    try {
      reportMap = leaflet.map(host, {
        attributionControl: true,
        fadeAnimation: false,
        markerZoomAnimation: false,
        preferCanvas: false,
        scrollWheelZoom: false,
        zoomAnimation: false,
        zoomControl: false,
      });
      reportMap.attributionControl.setPrefix(false);
      leaflet.control.zoom({ position: "topright" }).addTo(reportMap);

      const reportParameters = new URLSearchParams(location.search);
      const useBundledDemoTiles = reportParameters.get("device_id") === "blackbox-esp32s3-auto-demo";
      // Auto Demo has a small bundled OSM tile set, so its PDF works without
      // disclosing demo coordinates or depending on Internet availability.
      // Real trips continue to use the normal OpenStreetMap tile service.
      const tileUrl = useBundledDemoTiles
        ? "/vendor/osm-demo/{z}/{x}/{y}.png"
        : "https://tile.openstreetmap.org/{z}/{x}/{y}.png";
      const tiles = leaflet.tileLayer(tileUrl, {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        crossOrigin: true,
        detectRetina: false,
        keepBuffer: 2,
        minZoom: useBundledDemoTiles ? 17 : 0,
        maxNativeZoom: useBundledDemoTiles ? 17 : 19,
        maxZoom: useBundledDemoTiles ? 17 : 19,
        tileSize: useBundledDemoTiles ? 128 : 256,
        updateWhenIdle: true,
        updateWhenZooming: false,
        zoomOffset: useBundledDemoTiles ? 1 : 0,
      });
      const tilesReady = waitForTileLayer(tiles);
      tiles.addTo(reportMap);

      const routeLatLngs = routeSegments
        .map(segment => samplePoints(segment).map(point => [Number(point.lat), Number(point.lon)]));
      leaflet.polyline(routeLatLngs, {
        color: "#ffffff", opacity: .94, weight: 9,
        lineCap: "round", lineJoin: "round", interactive: false,
      }).addTo(reportMap);
      const routeLine = leaflet.polyline(routeLatLngs, {
        color: "#0891b2", opacity: 1, weight: 5,
        lineCap: "round", lineJoin: "round", interactive: false,
      }).addTo(reportMap);

      for (const event of locatedEvents.slice(0, 500)) {
        const kind = eventKind(event.name);
        leaflet.marker([Number(event.lat), Number(event.lon)], {
          icon: leafletIcon(leaflet, kind),
          keyboard: false,
          riseOnHover: true,
          title: `${eventLabel(event)} · ${formatEventTime(event)}`,
          zIndexOffset: 300,
        }).addTo(reportMap).bindTooltip(`${eventLabel(event)} · ${formatEventTime(event)}`, {
          className: "report-map-tooltip",
          direction: "top",
          offset: [0, -7],
        });
      }

      const addEndpoint = (point, kind, label, direction) => {
        leaflet.marker([Number(point.lat), Number(point.lon)], {
          icon: leafletIcon(leaflet, kind, true),
          keyboard: false,
          title: label,
          zIndexOffset: 1000,
        }).addTo(reportMap).bindTooltip(label, {
          className: "report-map-tooltip",
          direction,
          offset: direction === "left" ? [-10, 0] : [10, 0],
          permanent: true,
        });
      };
      addEndpoint(routePoints[0], "start", "Bắt đầu", "right");
      addEndpoint(routePoints.at(-1), "end", "Kết thúc", "left");

      const bounds = routeLine.getBounds();
      for (const event of locatedEvents.slice(0, 500)) bounds.extend([Number(event.lat), Number(event.lon)]);
      if (bounds.isValid() && !bounds.getNorthEast().equals(bounds.getSouthWest())) {
        reportMap.fitBounds(bounds, {
          animate: false,
          maxZoom: useBundledDemoTiles ? 17 : 18,
          padding: useBundledDemoTiles ? [10, 10] : [35, 35],
        });
      } else {
        reportMap.setView(routeLatLngs[0][0], 18, { animate: false });
      }

      await nextPaint();
      reportMap.invalidateSize({ animate: false, pan: false });
      const tileStatus = await tilesReady;
      await nextPaint();
      window.__tripReportMapStatus = useBundledDemoTiles ? "bundled" : tileStatus;

      const eventPart = locatedEvents.length ? ` · ${numberFormat.format(locatedEvents.length)} sự kiện có tọa độ` : "";
      const omittedPart = omitted ? ` · ${numberFormat.format(omitted)} marker không vẽ để bảo đảm hiệu năng` : "";
      if (useBundledDemoTiles) {
        setText("map-caption", `Bản đồ OpenStreetMap cục bộ của Auto Demo từ ${numberFormat.format(routePoints.length)} điểm GNSS${eventPart}${omittedPart}.`);
      } else if (tileStatus === "loaded") {
        setText("map-caption", `Bản đồ OpenStreetMap từ ${numberFormat.format(routePoints.length)} điểm GNSS${eventPart}${omittedPart}.`);
      } else {
        setText("map-caption", `Nền OpenStreetMap chưa tải đầy đủ; lộ trình từ ${numberFormat.format(routePoints.length)} điểm GNSS vẫn được giữ nguyên${eventPart}${omittedPart}.`);
      }
      return tileStatus;
    } catch (error) {
      if (reportMap) {
        reportMap.remove();
        reportMap = null;
      }
      renderVectorFallback(points, locatedEvents);
      setText("map-caption", `Bản đồ nền không khả dụng; sơ đồ GNSS dự phòng vẫn hiển thị ${numberFormat.format(routePoints.length)} điểm lộ trình.`);
      window.__tripReportMapStatus = "fallback";
      console.warn("Không thể dựng bản đồ báo cáo:", error);
      return "fallback";
    }
  }

  function renderEventTable(events) {
    const rows = Array.isArray(events) ? events : [];
    const body = $("event-table-body");
    const noEvents = $("no-events");
    body.replaceChildren();
    noEvents.hidden = rows.length > 0;
    setText("event-total", `${numberFormat.format(rows.length)} SỰ KIỆN`);

    for (const [index, event] of rows.entries()) {
      const row = document.createElement("tr");
      const cells = Array.from({ length: 6 }, () => document.createElement("td"));
      cells[0].textContent = numberFormat.format(index + 1);
      cells[1].textContent = formatEventTime(event);

      const name = document.createElement("span");
      name.className = "event-name";
      const marker = document.createElement("i");
      marker.className = `event-marker ${eventKind(event.name)}`;
      marker.setAttribute("aria-hidden", "true");
      name.append(marker, document.createTextNode(eventLabel(event)));
      cells[2].append(name);

      const severity = document.createElement("span");
      const severityKey = String(event?.severity || "info").toLowerCase();
      severity.className = `severity ${["warning", "error", "critical", "success", "info"].includes(severityKey) ? severityKey : "info"}`;
      severity.textContent = severityLabels[severityKey] || event?.severity || "Thông tin";
      cells[3].append(severity);
      cells[4].textContent = eventDetails(event);
      cells[5].textContent = coordinatesText(event);
      row.append(...cells);
      body.append(row);
    }
  }

  function calculateStats(payload) {
    const route = payload.route || {}, points = Array.isArray(payload.points) ? payload.points : [];
    const events = Array.isArray(payload.events) ? payload.events : [];
    const provided = payload.stats || {};
    const speeds = points.map(point => finite(point.speed_kph)).filter(value => value !== null && value >= 0);
    const duration = finite(provided.duration_s) ?? Math.max(0, Math.round(((finite(route.ended_at) ?? Date.now()) - (finite(route.started_at) ?? Date.now())) / 1000));
    return {
      duration_s: duration,
      avg_speed_kph: finite(provided.avg_speed_kph) ?? (speeds.length ? speeds.reduce((sum, value) => sum + value, 0) / speeds.length : 0),
      max_speed_kph: finite(provided.max_speed_kph) ?? (speeds.length ? Math.max(...speeds) : 0),
      overspeed_events: finite(provided.overspeed_events) ?? events.filter(event => event.name === "overspeed").length,
      pothole_events: finite(provided.pothole_events) ?? events.filter(event => event.name === "pothole_detected").length,
      speed_bump_events: finite(provided.speed_bump_events) ?? events.filter(event => event.name === "speed_bump_detected").length,
      dtc_events: finite(provided.dtc_events) ?? events.filter(event => event.name === "dtc_active").length,
    };
  }

  async function renderReport(payload, latest = null) {
    const route = payload.route || {};
    const points = Array.isArray(payload.points) ? payload.points : [];
    const events = Array.isArray(payload.events) ? payload.events : [];
    const stats = calculateStats(payload);
    const routeName = route.route_no !== null && route.route_no !== undefined ? `Lộ trình ${route.route_no}` : `Lộ trình #${route.id ?? "—"}`;
    const active = route.status === "active";
    const routeVersion = payload.version || null;
    const firmware = routeVersion?.firmware_version ? String(routeVersion.firmware_version)
      : latest?.firmware_version ? String(latest.firmware_version) : "";
    const model = routeVersion?.model_version ? String(routeVersion.model_version)
      : latest?.model_version ? String(latest.model_version) : "";

    document.title = `${routeName} · Báo cáo hành trình`;
    const directDemo = payload.demo_mode === "direct";
    setText("report-subtitle", `${routeName} · ${route.device_id || "Thiết bị chưa xác định"}${directDemo ? " · DEMO: Tọa độ mô phỏng – AI thực" : ""}`);
    setText("generated-at", `Lập lúc ${formatDateTime(Date.now())}`);
    setText("route-status", active ? "ĐANG GHI" : "ĐÃ HOÀN THÀNH");
    $("route-status").classList.toggle("active", active);
    setText("route-badge", routeName.toUpperCase());
    setText("device-id", route.device_id || "—");
    setText("route-id", route.id === null || route.id === undefined ? "—" : `#${route.id}`);
    setText("route-start", formatDateTime(route.started_at));
    setText("route-end", active ? "Đang ghi" : formatDateTime(route.ended_at));
    setText("point-count", numberFormat.format(finite(route.point_count) ?? points.length));
    setText("version-label", routeVersion ? "Firmware / TinyML trong hành trình" : "Phiên bản thiết bị gần nhất");
    setText("version-info", firmware || model ? `${firmware || "Firmware —"} · ${model || "Model —"}` : "Chưa có dữ liệu phiên bản");
    setText("distance-km", formatNumber(route.distance_km, 2));
    setText("duration", formatDuration(stats.duration_s));
    setText("avg-speed", formatNumber(stats.avg_speed_kph, 1));
    setText("max-speed", formatNumber(stats.max_speed_kph, 1));
    setText("overspeed-count", numberFormat.format(stats.overspeed_events));
    setText("pothole-count", numberFormat.format(stats.pothole_events));
    setText("bump-count", numberFormat.format(stats.speed_bump_events));
    setText("dtc-count", numberFormat.format(stats.dtc_events));
    setText("footer-route", `${routeName} · ${route.device_id || "—"}${directDemo ? " · Quãng đường/tốc độ trên bản đồ là mô phỏng từ biến trở, không phải đo chuyển động bánh xe/GPS." : ""}`);
    renderEventTable(events);

    $("loading-state").hidden = true;
    $("error-state").hidden = true;
    $("report-content").hidden = false;
    await nextPaint();
    await renderRouteMap(points, events);
    $("report-sheet").setAttribute("aria-busy", "false");
  }

  async function fetchJson(url) {
    const response = await fetch(url, { cache: "no-store", headers: { Accept: "application/json" } });
    const data = await response.json().catch(() => null);
    if (!response.ok || !data?.ok) {
      const detail = data?.error && data.error !== "route_not_found" ? ` (${data.error})` : "";
      throw new Error(response.status === 404 ? "Không tìm thấy lộ trình đã chọn." : `Local Server trả về lỗi HTTP ${response.status}${detail}.`);
    }
    return data;
  }

  function showError(message) {
    window.__tripReportReady = false;
    window.__tripReportMapStatus = "error";
    $("loading-state").hidden = true;
    $("report-content").hidden = true;
    $("error-state").hidden = false;
    $("report-sheet").setAttribute("aria-busy", "false");
    setText("error-message", message);
  }

  async function loadReport() {
    const parameters = new URLSearchParams(location.search);
    const routeId = Number(parameters.get("route_id") || parameters.get("route") || parameters.get("id"));
    const requestedDevice = String(parameters.get("device_id") || "").trim();
    if (!Number.isSafeInteger(routeId) || routeId <= 0) {
      showError("Thiếu mã lộ trình. Hãy mở báo cáo từ một lộ trình đã lưu trên Dashboard.");
      return;
    }

    try {
      const routeUrl = new URL(`/api/routes/${routeId}`, location.origin);
      if (requestedDevice) routeUrl.searchParams.set("device_id", requestedDevice);
      const payload = await fetchJson(routeUrl);
      const deviceId = String(payload.route?.device_id || requestedDevice || "");
      let latest = null;
      if (deviceId) {
        try {
          const dashboardUrl = new URL("/api/dashboard", location.origin);
          dashboardUrl.searchParams.set("device_id", deviceId);
          const dashboard = await fetchJson(dashboardUrl);
          latest = dashboard.latest || null;
        } catch {
          // Version metadata is optional; the report remains valid without it.
        }
      }
      await renderReport(payload, latest);
      if (document.fonts?.ready) await document.fonts.ready.catch(() => {});
      await nextPaint();
      window.__tripReportReady = true;
      $("print-report").disabled = false;
      window.dispatchEvent(new CustomEvent("trip-report-ready", { detail: { routeId, deviceId } }));
      if (parameters.get("autoprint") === "1") {
        setTimeout(() => {
          reportMap?.invalidateSize({ animate: false, pan: false });
          window.print();
        }, 250);
      }
    } catch (error) {
      showError(error instanceof Error ? error.message : "Không thể tải dữ liệu lộ trình.");
    }
  }

  $("print-report").disabled = true;
  $("print-report").addEventListener("click", () => {
    if (!window.__tripReportReady) return;
    reportMap?.invalidateSize({ animate: false, pan: false });
    window.print();
  });
  window.addEventListener("beforeprint", () => reportMap?.invalidateSize({ animate: false, pan: false }));
  $("close-report").addEventListener("click", () => {
    if (window.opener && !window.opener.closed) window.close();
    else if (history.length > 1) history.back();
    else location.assign("/");
  });

  loadReport();
})();
