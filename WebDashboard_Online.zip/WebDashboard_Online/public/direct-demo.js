(() => {
  "use strict";
  const $ = id => document.getElementById(id), geometry = window.TelematicsDirectGeometry;
  const state = { session: null, roads: [], busy: false, loading: false, polling: false, requestEpoch: 0, applyEpoch: 0, watch: "", view: "", previous: "", preview: false, switching: false, autoRunning: false, available: false, timer: 0 };
  const terminal = value => ["stopped", "failed", "interrupted"].includes(value);
  const locked = session => Boolean(session && !terminal(session.state));
  const number = value => Number.isFinite(Number(value)) ? Number(value) : null;
  const fmt = value => number(value) === null ? "—" : Number(value).toLocaleString("vi-VN", { maximumFractionDigits: 1 });
  const selected = () => window.telematicsDashboard?.currentDeviceId?.() || "";
  const serverNow = () => window.telematicsDashboard?.getServerTimeMs?.() ?? Date.now();
  const labels = { starting: "CHỜ ESP XÁC NHẬN", running: "ĐANG CHẠY", paused: "TẠM DỪNG", can_stale: "CHỜ CAN", completed: "ĐÃ HẾT ĐƯỜNG", stopped: "ĐÃ KẾT THÚC", failed: "KHÔNG KHỞI ĐỘNG", interrupted: "ĐÃ GIÁN ĐOẠN", unknown: "CHƯA RÕ TRẠNG THÁI" };
  function feedback(text, error = false) { const n = $("direct-feedback"); n.textContent = text; n.classList.toggle("error", error); }
  function roadNote(text = "") { const n = $("direct-road-note"); n.textContent = text; n.hidden = !text; }
  async function request(path, body) {
    const response = await fetch(path, { cache: "no-store", signal: AbortSignal.timeout(6000), ...(body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }) });
    const data = await response.json().catch(() => null);
    if (!response.ok || data?.ok === false || !data) throw new Error(data?.error || `HTTP ${response.status}`);
    return data;
  }
  function renderMotion() {
    const s=state.session,api=window.telematicsDashboard,packet=api?.getDirectRealtime?.(),snap=packet?.direct_demo||s?.last_snapshot||{};
    $("direct-input-speed").textContent=`${fmt(snap.input_speed_kph)} km/h`;
    $("direct-virtual-speed").textContent=`${fmt(snap.speed_kph)} km/h`;
    $("direct-progress").textContent=`${fmt(snap.distance_m)} / ${fmt(snap.route_length_m||s?.route?.length_m)} m`;
    const max=Number(snap.route_length_m||s?.route?.length_m)||1;
    $("direct-progress-bar").max=max;$("direct-progress-bar").value=Math.max(0,Math.min(max,Number(snap.distance_m)||0));
    const age=packet?Math.max(0,serverNow()-packet.received_at_ms):null,fresh=age!==null&&age<1500,label=$("direct-realtime-status");
    label.textContent=packet?(fresh?`Chuyển động trực tiếp · ${Math.round(age)} ms${packet.audio_active?" · loa đang phát":""}`:"Luồng chuyển động đã cũ · giữ vị trí cuối; tốc độ trên bảng là mẫu cuối."):"Chờ luồng chuyển động trực tiếp · đang dùng gói dữ liệu định kỳ.";
    label.classList.toggle("error",Boolean(packet)&&!fresh);api?.refreshDirectRealtime?.();
  }
  function render() {
    const s = state.session, active = locked(s), waiting = Boolean(s?.pending_operation), confirmed = geometry.confirmed(s?.state), block = state.busy || !state.available;
    document.body.classList.toggle("direct-demo-session", active);
    $("direct-device").disabled = active || state.busy || state.loading;
    $("direct-roads").disabled = active || state.busy || state.loading;
    $("direct-road").disabled = active || state.busy || !state.roads.length;
    $("direct-multiplier").disabled = active || state.busy;
    $("direct-start").disabled = block || active || state.loading || state.autoRunning || !$("direct-device").value || !$("direct-road").value;
    $("direct-pause").disabled = block || waiting || !["running", "can_stale"].includes(s?.state);
    $("direct-resume").disabled = block || waiting || s?.state !== "paused";
    $("direct-repeat").disabled = block || waiting || !["paused", "completed"].includes(s?.state);
    // A lost ACK must not remove the stop control: the gateway may be running.
    $("direct-stop").disabled = block || !active || (waiting && s?.pending_operation === "stop");
    const badge = $("direct-demo-badge"); badge.textContent = !state.available ? "MẤT SERVER" : labels[s?.state] || "CHƯA CHẠY";
    badge.classList.toggle("stale", !state.available || Boolean(s?.stale) || !["running", "completed"].includes(s?.state));
    renderMotion();
    $("direct-view").hidden = !confirmed || state.view === s?.session_id;
    $("direct-view").disabled = state.busy;
    $("direct-map-reset").hidden = !state.preview && !state.view;
    window.dispatchEvent(new CustomEvent("telematics:direct-demo-status", { detail: { session: s, locked: active, available: state.available } }));
  }
  function stateMessage(s) {
    if (!s) return "Xe ảo không đo chuyển động bánh xe. Biến trở lớn hơn 0 thì marker vẫn chạy dù mô hình đứng yên.";
    if (s.pending_operation) return `Đang chờ ESP xác nhận ${s.pending_operation}. Trạng thái chưa được coi là đã thay đổi.`;
    if (s.state === "starting") return "Đã xếp lệnh bắt đầu; chờ ESP áp dụng. Chưa chuyển sang xe ảo, chưa tạo kết quả AI.";
    if (s.state === "unknown") return "Chưa xác nhận được trạng thái ESP. Giữ khóa phiên để tránh chạy hai demo; thử Kết thúc khi Gateway kết nối lại.";
    if (s.stale && !terminal(s.state)) {
      const packet=window.telematicsDashboard?.getDirectRealtime?.();
      if(packet&&serverNow()-packet.received_at_ms<1500)return "Gói dữ liệu định kỳ đang chậm; chuyển động vẫn cập nhật trực tiếp. TinyML, cảm biến và MicroSD chỉ dùng thời gian của gói dữ liệu riêng.";
      return "Dữ liệu Gateway đã cũ: vị trí giữ ở mẫu cuối, không tự chạy tiếp trên web. Kiểm tra kết nối và Serial.";
    }
    if (s.state === "can_stale") return "CAN chưa có tốc độ mới: xe ảo đang dừng. Kiểm tra Node ECU; không dùng tốc độ cũ để tiếp tục.";
    if (s.state === "completed") return "Đã hết đường. Đưa biến trở về 0 rồi bấm Chạy lại để kiểm tra loa khi đi vào vùng đã ghi nhận. Điểm cũ được giữ trong phiên.";
    if (s.state === "paused") return "Xe ảo đang tạm dừng. Dữ liệu cảm biến vẫn là dữ liệu thật; bấm Tiếp tục khi sẵn sàng.";
    if (terminal(s.state)) return s.state === "stopped" ? "ESP đã kết thúc phiên. Đã trở về nguồn dữ liệu thật; hành trình demo vẫn được lưu riêng." : `Phiên ${labels[s.state]?.toLowerCase()}. ${s.error || s.last_error || "Kiểm tra Gateway trước khi bắt đầu lại."}`;
    return "Biến trở → tốc độ xe ảo; ADXL345 → TinyML thật. Lần đầu ghi điểm; khi tái đi vào vùng cảnh báo, ESP phát loa theo cấu hình.";
  }
  async function enterView(s, epoch = state.applyEpoch) {
    if (!s || !geometry.confirmed(s.state)) return;
    const api = window.telematicsDashboard;
    if (!api) return;
    if (!state.view) state.previous = selected().endsWith("-direct-demo") ? s.device_id : selected() || s.device_id;
    state.switching = true;
    try {
      if (selected() !== s.virtual_device_id) await api.selectDevice(s.virtual_device_id, `${s.virtual_device_id} · AI THỰC`);
      if (epoch !== state.applyEpoch || state.session !== s) return;
      if (api.setDirectDemoView(s)) { state.view = s.session_id; state.preview = false; }
    } finally { state.switching = false; }
  }
  async function leaveView(restore = true) {
    const s = state.session, wasViewed = Boolean(state.view), epoch = state.applyEpoch;
    state.watch = ""; state.view = ""; state.preview = false;
    window.telematicsDashboard?.clearDirectDemoView();
    if (restore && wasViewed && selected() === s?.virtual_device_id) {
      state.switching = true;
      try { await window.telematicsDashboard?.selectDevice(state.previous || s.device_id); } finally { state.switching = false; }
    }
    if (epoch !== state.applyEpoch) return;
    state.previous = ""; render();
  }
  function acceptsSession(s) {
    const previous = state.session;
    if (!previous) return true;
    // Once a session exists, an old empty startup response cannot clear it.
    if (!s) return false;
    const revision = value => Number.isSafeInteger(value?.revision) && value.revision >= 0 ? value.revision : 0;
    const before = revision(previous), after = revision(s);
    if (after < before || (after === before && s.session_id !== previous.session_id)) return false;
    if (s.session_id !== previous.session_id) return after > before;
    if (terminal(previous.state) && !terminal(s.state)) return false;
    if (Number(s.pass_index) < Number(previous.pass_index)) return false;
    // Also protect against an older pre-upgrade response with no revision.
    if (!after && Number(s.updated_at) < Number(previous.updated_at)) return false;
    const capture = s.last_snapshot?.capture_ms, oldCapture = previous.last_snapshot?.capture_ms;
    if (s.pass_index === previous.pass_index && Number.isInteger(capture) && Number.isInteger(oldCapture) &&
        capture !== oldCapture && ((capture - oldCapture) >>> 0) >= 0x80000000) return false;
    return true;
  }
  async function applySession(s) {
    if (!acceptsSession(s)) return false;
    const epoch = ++state.applyEpoch;
    state.session = s || null;
    if (s && terminal(s.state) && (state.view === s.session_id || state.watch === s.session_id)) await leaveView(true);
    else if (s && geometry.confirmed(s.state) && (state.watch === s.session_id || state.view === s.session_id)) await enterView(s, epoch);
    if (epoch !== state.applyEpoch) return false;
    if(s?.realtime)window.telematicsDashboard?.applyDirectRealtime?.(s.realtime);
    feedback(stateMessage(s), ["failed", "unknown", "interrupted"].includes(s?.state)); render();
    return true;
  }
  async function poll() {
    if (state.polling || state.busy) return;
    state.polling = true;
    const epoch = state.requestEpoch;
    try {
      const data = await request("/api/direct-demo/state");
      if (epoch !== state.requestEpoch) return;
      state.available = true; await applySession(data.session);
    }
    catch (error) {
      if (epoch !== state.requestEpoch) return;
      state.available = false; feedback(`Không đọc được trạng thái: ${error.message}. Web không giả định ESP đã dừng.`, true); render();
    }
    finally { state.polling = false; }
  }
  async function loadDevices() {
    try {
      const data = await request("/api/devices"), choice = $("direct-device"), before = choice.value;
      const rows = (data.devices || []).filter(row => !/(?:-direct-demo|-auto-demo|-demo)$/.test(row.device_id));
      choice.replaceChildren(); const empty = document.createElement("option"); empty.value = ""; empty.textContent = "Chọn Gateway thật"; choice.append(empty);
      for (const row of rows) { const option = document.createElement("option"); option.value = row.device_id; option.textContent = row.device_id; choice.append(option); }
      const target = state.session && locked(state.session) ? state.session.device_id : before || selected();
      choice.value = rows.some(row => row.device_id === target) ? target : rows[0]?.device_id || "";
      render();
    } catch { /* Main state polling reports offline; do not erase selection. */ }
  }
  async function loadRoads() {
    if (state.loading || locked(state.session)) return;
    state.loading = true; render();
    roadNote("Đang tải tuyến demo…");
    try {
      const data = await request("/api/direct-demo/roads");
      state.roads = (data.roads || []).filter(road => geometry.route(road.points));
      const select = $("direct-road"),previous=select.value; select.replaceChildren();
      const empty = document.createElement("option"); empty.value = ""; empty.textContent = "Chọn tuyến demo có sẵn để xem trước"; select.append(empty);
      for (const road of state.roads) { const o = document.createElement("option"); o.value = road.id; o.textContent = road.name || `Tuyến mô phỏng · ${Number(road.length_m)>=1000?`${fmt(Number(road.length_m)/1000)} km`:`${fmt(road.length_m)} m`}`; select.append(o); }
      if(state.roads.some(road=>road.id===previous))select.value=previous;
      roadNote(state.roads.length ? "" : "Chưa có tuyến hợp lệ. Bấm Tải lại tuyến demo.");
    } catch (error) { roadNote(`Chưa tải được tuyến từ máy chủ: ${error.message}. Bấm Tải lại tuyến demo.`); }
    finally { state.loading = false; render(); }
  }
  function previewRoad() {
    const route = state.roads.find(row => row.id === $("direct-road").value);
    if (route && !locked(state.session)) state.preview = Boolean(window.telematicsDashboard?.previewDirectDemoRoad(route));
    else if (state.preview) { state.preview = false; window.telematicsDashboard?.clearDirectDemoView(); }
    render();
  }
  async function start() {
    if (state.busy || state.loading || locked(state.session) || !$("direct-device").value || !state.roads.some(road=>road.id===$("direct-road").value)) return;
    ++state.requestEpoch; ++state.applyEpoch;
    state.busy = true; render();
    try {
      const data = await request("/api/direct-demo/start", { device_id: $("direct-device").value, road_id: $("direct-road").value, speed_multiplier: Number($("direct-multiplier").value) });
      state.watch = data.session?.session_id || ""; await applySession(data.session);
    } catch (error) { feedback(`Chưa bắt đầu demo: ${error.message}`, true); }
    finally { state.busy = false; render(); }
  }
  async function control(operation) {
    if (state.busy || !locked(state.session)) return;
    ++state.requestEpoch; ++state.applyEpoch;
    state.busy = true; render();
    try { const data = await request("/api/direct-demo/control", { session_id: state.session.session_id, operation }); await applySession(data.session); }
    catch (error) { feedback(`Chưa xác nhận ${operation}: ${error.message}. Không coi lệnh là đã thực hiện.`, true); }
    finally { state.busy = false; render(); }
  }
  function gatewayChanged() { if (state.preview) leaveView(false); render(); }
  $("direct-roads").addEventListener("click", loadRoads);
  $("direct-road").addEventListener("change", previewRoad);
  $("direct-device").addEventListener("change", gatewayChanged);
  $("direct-start").addEventListener("click", start);
  for (const operation of ["pause", "resume", "repeat", "stop"]) $(`direct-${operation}`).addEventListener("click", () => control(operation));
  $("direct-view").addEventListener("click", async () => { state.watch = state.session?.session_id || ""; await enterView(state.session); render(); });
  $("direct-map-reset").addEventListener("click", () => leaveView(true));
  window.addEventListener("telematics:demo-status", event => { state.autoRunning = Boolean(event.detail?.running); render(); });
  window.addEventListener("telematics:direct-realtime",renderMotion);
  window.addEventListener("telematics:source-changed", () => {
    if (state.switching) return;
    if (state.view && selected() !== state.session?.virtual_device_id) leaveView(false);
    else if (state.session?.virtual_device_id === selected() && geometry.confirmed(state.session?.state)) { state.watch = state.session.session_id; enterView(state.session).then(render); }
  });
  let ticks = 0;
  poll(); loadDevices(); loadRoads(); state.timer = window.setInterval(() => { renderMotion(); if(++ticks%4===0)poll(); if(ticks%40===0)loadDevices(); }, 250);
  window.addEventListener("beforeunload", () => clearInterval(state.timer), { once: true });
})();
