// Shared by the live map and printable report. Never connect across a GPS gap.
(() => {
  "use strict";
  function splitRouteSegments(rows) {
    const segments = [];
    let current = null;
    for (const row of Array.isArray(rows) ? rows : []) {
      const lat = row?.lat, lon = row?.lon;
      const valid = lat !== null && lat !== undefined && lat !== "" &&
        lon !== null && lon !== undefined && lon !== "" &&
        Number.isFinite(Number(lat)) && Number.isFinite(Number(lon)) &&
        Math.abs(Number(lat)) <= 90 && Math.abs(Number(lon)) <= 180 &&
        (row.location_valid === undefined || row.location_valid === true || Number(row.location_valid) === 1);
      if (!valid) { current = null; continue; }
      if (!current || row.segment_start === true || Number(row.segment_start) === 1) {
        current = [];
        segments.push(current);
      }
      current.push(row);
    }
    return segments;
  }
  globalThis.TelematicsRouteGeometry = Object.freeze({ splitRouteSegments });
})();
