(() => {
  'use strict';
  // One request in flight; intermediate motion packets never download histories.
  function create(options = {}) {
    const request = options.fetch || globalThis.fetch.bind(globalThis);
    const later = options.setTimeout || globalThis.setTimeout;
    const cancel = options.clearTimeout || globalThis.clearTimeout;
    // Measure request duration/cadence with elapsed time. Automatic phone time
    // corrections must not manufacture a huge RTT or pause this sensor lane.
    // Preserve an injected test clock and the legacy browser fallback.
    const now = options.now || (() => typeof performance !== 'undefined' && typeof performance.now === 'function' ? performance.now() : Date.now());
    let generation = 0, timer = 0, controller = null, stopped = true;
    let device = '', cursor = '', lastFull = 0, direct = false, failures = 0;
    function stop() {
      stopped = true; generation++; cancel(timer); timer = 0;
      controller?.abort(); controller = null;
    }
    async function tick(version) {
      if (stopped || version !== generation) return;
      const hidden = Boolean(options.hidden?.());
      const full = !lastFull || now() - lastFull >= (hidden ? 5000 : 1000);
      const query = new URLSearchParams();
      if (device) query.set('device_id', device);
      if (cursor) query.set('cursor', cursor);
      if (!full) query.set('motion_only', '1');
      const active = new AbortController(); controller = active;
      const timeout = later(() => active.abort(), 8000);
      const started = now();
      try {
        const response = await request(`/api/live?${query}`, { cache: 'no-store', signal: active.signal });
        if (stopped || version !== generation) return;
        if (response.status === 401) { stop(); options.onUnauthorized?.(); return; }
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const data = await response.json();
        if (stopped || version !== generation) return;
        if (data.ok !== true || typeof data.cursor !== 'string') throw new Error('Invalid live snapshot');
        if (device && data.device_id && data.device_id !== device) throw new Error('Wrong live device');
        cursor = data.cursor; failures = 0; direct = Boolean(data.direct_active);
        if (full) lastFull = now();
        // Upper-bound response transit by the measured round trip. Slow network
        // delivery must never renew an old AI result or stale motion frame.
        options.onSnapshot?.({ ...data, transport_delay_ms: Math.max(0, now() - started) });
        if (data.refresh_required) options.onUpdate?.({ kind: 'sync', device_id: data.device_id });
        else for (const update of data.updates || []) options.onUpdate?.(update);
        options.onStatus?.(true);
      } catch (error) {
        if (stopped || version !== generation) return;
        failures++; options.onStatus?.(false, error);
      } finally {
        cancel(timeout);
        if (version === generation) controller = null;
        if (!stopped && version === generation) {
          const interval = failures ? Math.min(10000, 1000 * 2 ** Math.min(failures - 1, 4)) : hidden ? 5000 : direct ? 200 : 1000;
          timer = later(() => tick(version), Math.max(50, interval - (now() - started)));
        }
      }
    }
    return { stop, start(selected = '') {
      stop(); device = String(selected || ''); cursor = ''; lastFull = 0; direct = false; failures = 0;
      stopped = false; tick(generation);
    } };
  }
  globalThis.TelematicsLivePolling = { create };
})();
