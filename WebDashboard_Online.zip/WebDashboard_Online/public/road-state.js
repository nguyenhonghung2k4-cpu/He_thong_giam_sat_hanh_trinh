(() => {
  "use strict";
  const labels = new Set(["duong_bang_phang", "go_giam_toc", "o_ga"]);
  const numeric = value => value === null || value === undefined || value === "" ? null : Number.isFinite(Number(value)) ? Number(value) : null;
  const yes = value => value === true || value === 1 || value === "1";
  const epoch = value => typeof value === "number" ? value : Date.parse(String(value ?? ""));
  const probability = value => { const n = numeric(value); return n !== null && n >= 0 && n <= 1 ? n : null; };
  const MAX_AGE_MS = 3000;

  // Road recognition is an independent sensor lane. Motion packets, saved map
  // hazards, sample-injection results and receipt of an old replay cannot renew it.
  function resolve(latest = {}, meta = null, context = {}) {
    const now = numeric(context.now) ?? Date.now();
    const receivedAt = numeric(context.receivedAt) ?? now;
    const elapsed = Math.max(0, now - receivedAt);
    const transit = Math.max(0, numeric(context.transportDelay) ?? 0);
    const serverNow = Number.isFinite(epoch(context.serverNow)) ? epoch(context.serverNow) : receivedAt;
    const device = String(latest.device_id || "");
    const demo = context.mode === "demo" || device === "blackbox-esp32s3-auto-demo" || meta?.source === "auto_demo" || meta?.source === "sample_demo";
    const source = demo ? "auto_demo" : String(meta?.source || (device && !device.endsWith("-demo") || device.endsWith("-direct-demo") ? "adxl345" : "unknown"));
    const received = epoch(latest.ingested_at);
    const rawAge = meta ? numeric(meta.age_ms) : Number.isFinite(received) ? serverNow - received : null;
    const baseAge = rawAge === null ? null : rawAge + transit;
    const age = baseAge === null ? null : baseAge + elapsed;
    const label = String((meta ? meta.label : latest.road_label) ?? "unknown");
    const confidence = probability(meta ? meta.confidence : latest.confidence);
    let reason = String(meta?.reason || "missing");
    const ready = meta ? meta.valid === true : yes(latest.road_valid) && !yes(latest.is_resend) && latest.ai_ready !== false && latest.ai_ready !== 0 && latest.adxl_healthy !== false && latest.adxl_healthy !== 0;
    const valid = !demo && source === "adxl345" && ready && labels.has(label) && confidence !== null && age !== null && baseAge >= -1000 && age >= 0 && age < MAX_AGE_MS;
    if (!valid && !demo && ready && age !== null && age >= MAX_AGE_MS) reason = "ai_stale";
    const rawScores = meta?.scores || { duong_bang_phang: latest.flat_confidence, go_giam_toc: latest.speed_bump_confidence, o_ga: latest.pothole_confidence };
    return {
      valid, demo, source, reason: valid ? "fresh" : reason,
      label: valid ? label : "unknown", confidence: valid ? confidence : null,
      scores: Object.fromEntries([...labels].map(key => [key, valid ? probability(rawScores[key]) : null])),
      x_g: valid ? numeric(meta?.x_g ?? latest.x_g) : null,
      y_g: valid ? numeric(meta?.y_g ?? latest.y_g) : null,
      z_g: valid ? numeric(meta?.z_g ?? latest.z_g) : null,
      inference_ms: valid ? numeric(meta?.inference_ms ?? latest.inference_ms) : null,
      window_ms: numeric(meta?.window_ms) || 2000,
      age_ms: age, received_at: Number.isFinite(received) ? received : null,
      sample_time_ms: valid ? numeric(meta?.sample_time_ms) : null,
      event: meta?.event && typeof meta.event==='object' ? meta.event : null,
    };
  }
  globalThis.TelematicsRoadState = Object.freeze({ resolve, MAX_AGE_MS });
})();
