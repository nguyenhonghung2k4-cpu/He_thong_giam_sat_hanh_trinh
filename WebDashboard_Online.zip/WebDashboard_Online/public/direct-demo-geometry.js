/* Own, dependency-free geometry for the read-only direct-demo view. */
(function(root,factory){const api=factory();if(typeof module==="object"&&module.exports)module.exports=api;else root.TelematicsDirectGeometry=api;})(globalThis,()=>{
  "use strict";
  const R=6371000,rad=Math.PI/180;
  const valid=p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite)&&Math.abs(p[0])<85&&Math.abs(p[1])<=180;
  function distance(a,b){const x=(b[0]-a[0])*rad,y=(b[1]-a[1])*rad,q=Math.sin(x/2)**2+Math.cos(a[0]*rad)*Math.cos(b[0]*rad)*Math.sin(y/2)**2;return 2*R*Math.asin(Math.sqrt(Math.min(1,q)));}
  function route(points){if(!Array.isArray(points)||points.length<2||points.length>64||!points.every(valid))return null;const lengths=[0];for(let i=1;i<points.length;i++)lengths.push(lengths[i-1]+distance(points[i-1],points[i]));return lengths.at(-1)>0?{points:points.map(p=>p.slice()),lengths,total:lengths.at(-1)}:null;}
  function at(r,m){const d=Math.max(0,Math.min(r.total,Number(m)||0));for(let i=1;i<r.points.length;i++){if(d<=r.lengths[i]){const span=r.lengths[i]-r.lengths[i-1],f=span?(d-r.lengths[i-1])/span:0,a=r.points[i-1],b=r.points[i];return[a[0]+(b[0]-a[0])*f,a[1]+(b[1]-a[1])*f];}}return r.points.at(-1).slice();}
  function path(r,from,to){const a=Math.max(0,Math.min(r.total,from)),b=Math.max(a,Math.min(r.total,to));return[at(r,a),...r.points.filter((_,i)=>r.lengths[i]>a&&r.lengths[i]<b),at(r,b)];}
  const project=p=>[(p[1]+180)/360*256,(1-Math.log(Math.tan(Math.PI/4+p[0]*rad/2))/Math.PI)/2*256];
  const unproject=p=>[Math.atan(Math.sinh(Math.PI*(1-2*p[1]/256)))/rad,p[0]/256*360-180];
  function view(r,width,height){const p=r.points.map(project),first=p[0],last=p.at(-1),angle=-Math.atan2(last[1]-first[1],last[0]-first[0]),c=Math.cos(angle),s=Math.sin(angle),rot=p.map(([x,y])=>[x*c-y*s,x*s+y*c]),xs=rot.map(x=>x[0]),ys=rot.map(x=>x[1]),minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys),cx=(minX+maxX)/2,cy=(minY+maxY)/2,scale=Math.min(Math.max(80,width-150)/Math.max(1e-7,maxX-minX),Math.max(100,height-300)/Math.max(1e-7,maxY-minY));return{angle:angle/rad,center:unproject([cx*c+cy*s,-cx*s+cy*c]),zoom:Math.max(5,Math.min(19,Math.floor(Math.log2(scale))))};}
  function confirmed(state){return["running","paused","can_stale","completed"].includes(state);}
  function active(state){return["starting","running","paused","can_stale","completed"].includes(state);}
  return Object.freeze({valid,distance,route,at,path,view,confirmed,active});
});
