@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo Chưa tìm thấy Node.js 22.16 trở lên.
  pause
  exit /b 1
)
node -e "const [major,minor]=process.versions.node.split('.').map(Number); process.exit(major > 22 || (major === 22 && minor >= 16) ? 0 : 1)"
if errorlevel 1 (
  echo Cần Node.js 22.16 trở lên để sao lưu SQLite nhất quán.
  node --version
  pause
  exit /b 1
)
node "tools\backup-database.mjs"
if errorlevel 1 echo Sao lưu không thành công. Xem lỗi phía trên.
pause
