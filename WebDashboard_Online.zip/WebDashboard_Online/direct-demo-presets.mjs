// Real-road geometry captured from OpenStreetMap through OSRM, not a synthetic
// line cutting across the basemap. No GPS/network request or AI data at runtime.
import ADDITIONAL_ROADS from './direct-demo-roads.json' with { type: 'json' };
const EARTH_M = 6371000, RAD = Math.PI / 180;
const DESCRIPTION = 'Đường thật cạnh Học viện Kỹ thuật Mật mã; chuyển động demo là mô phỏng, ADXL345/TinyML vẫn nhận gia tốc thật.';
const POINTS = Object.freeze([
  [20.980368,105.796683],[20.980199,105.796478],[20.979712,105.795767],
  [20.979448,105.795979],[20.979237,105.796159],[20.979148,105.796243],
  [20.979,105.796375],[20.978875,105.796485],[20.978546,105.796775],
  [20.978587,105.797007],[20.978669,105.797499],[20.978709,105.797732],
  [20.978725,105.797827],[20.978772,105.798104],[20.978839,105.798497],
  [20.978913,105.798885],[20.978528,105.79893],[20.978054,105.79897],
].map(point => Object.freeze(point)));
export const DEMO_ROAD_SOURCE_POINTS = POINTS;
export const DEMO_ROAD_PROVENANCE = Object.freeze({
  provider: 'OpenStreetMap / OSRM', prepared_date: '2026-11-15',
  query_url: 'https://router.project-osrm.org/route/v1/driving/105.7966828,20.9803673;105.7989697,20.9780543?overview=full&geometries=geojson&steps=true&annotations=nodes',
  reported_distance_m: 604.9,
  attribution: '© OpenStreetMap contributors', license: 'ODbL-1.0',
  license_url: 'https://www.openstreetmap.org/copyright',
  campus_name: 'Học viện Kỹ thuật Mật mã',
  campus_address: '141 Chiến Thắng, phường Thanh Liệt, Hà Nội, Việt Nam',
  address_source: 'https://tuyensinh.actvn.edu.vn/833-2/',
  campus_osm_way_id: 1172381259,
  campus_reference: Object.freeze([20.9808209,105.7960754]),
  campus_reference_kind: 'OSM university polygon centroid, not an asserted gate or live GNSS position',
  geocoding_url: 'https://photon.komoot.io/api/?q=H%E1%BB%8Dc%20vi%E1%BB%87n%20K%E1%BB%B9%20thu%E1%BA%ADt%20M%E1%BA%ADt%20m%C3%A3&limit=3',
  street_names: Object.freeze(['Ngõ 143 Đường Chiến Thắng','Đường Chiến Thắng','Đường Tân Triều']),
  osm_route_way_ids: null,
  way_id_note: 'OSRM does not return route way IDs; no unverified way-ID mapping is claimed.',
  data_version: null,
  osm_node_ids: Object.freeze([9532060570,8333142798,8333142797,13529343580,5710675027,5710675039,2763232124,12017170560,1897849719,6415966270,6415966271,6652111325,6651975136,6415966261,6666577666,4867710521,6651975137,6651975138]),
});
function distance(a, b) {
  const dlat = (b[0] - a[0]) * RAD, dlon = (b[1] - a[1]) * RAD;
  const h = Math.sin(dlat / 2) ** 2 + Math.cos(a[0] * RAD) * Math.cos(b[0] * RAD) * Math.sin(dlon / 2) ** 2;
  return EARTH_M * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(Math.max(0, 1 - h)));
}
const length = points => points.slice(1).reduce((sum, point, i) => sum + distance(points[i], point), 0);
const actualLength = length(POINTS);
if (POINTS.length > 64 || actualLength < 400 || actualLength > 2000) throw new Error('OSM demo road outside firmware geometry limits');
const CATALOG = Object.freeze([Object.freeze({
  id: 'kma-chien-thang-tan-trieu',
  name: 'Ngõ 143 Chiến Thắng → Tân Triều · khoảng 605 m',
  points: POINTS, length_m: actualLength, nominal_length_m: Math.round(actualLength),
  source: 'osm_road', synthetic: false, motion_simulated: true,
  description: DESCRIPTION, geometry_source: 'OpenStreetMap / OSRM',
  attribution: DEMO_ROAD_PROVENANCE.attribution, license_url: DEMO_ROAD_PROVENANCE.license_url,
}), ...ADDITIONAL_ROADS.map(road=>{
  const points=Object.freeze(road.points.map(point=>Object.freeze([...point]))),meters=length(points);
  if(points.length<2||points.length>64||meters<400||meters>2000)throw new Error('Real demo route exceeds firmware limits: '+road.id);
  return Object.freeze({id:road.id,name:`${road.name} · khoảng ${Math.round(meters)} m`,points,length_m:meters,nominal_length_m:Math.round(meters),
    source:'osm_road',synthetic:false,motion_simulated:true,description:DESCRIPTION,geometry_source:'OpenStreetMap / OSRM',
    attribution:DEMO_ROAD_PROVENANCE.attribution,license_url:DEMO_ROAD_PROVENANCE.license_url,
    query_url:road.query_url,reported_distance_m:road.reported_distance_m,street_names:Object.freeze([...road.street_names])});
})].sort((a,b)=>a.length_m-b.length_m));
const clone = route => ({ ...route, points: route.points.map(point => [...point]) });
export const DEMO_PRESET_ATTRIBUTION = '© OpenStreetMap contributors · ODbL — https://www.openstreetmap.org/copyright';
export const DEMO_PRESET_MAX_LENGTH_M = 2000;
export function listDemoPresets() { return CATALOG.map(clone); }
export function getDemoPreset(id) {
  const route = typeof id === 'string' && CATALOG.find(item => item.id === id);
  return route ? clone(route) : null;
}
